# Namkeen ERP v56 — QC -> Production / Inventory / Compliance Integration

v56 turns v55 QC into a controlled production gate and settlement bridge.

## Scope
- production completion gate from server-evaluated QC
- PASS/HOLD/FAIL settlement
- release only when required QC passes and good output is recorded
- FAIL -> REWORK/REJECT decision support
- reject/rework inventory action intents
- automatic QC -> FSMS/FSSAI compliance trace-link structure
- CAPA-required propagation
- PostgreSQL migration `045_v56_qc_production_inventory_compliance.sql`
- Android offline factory-QC integration contract

## Key controls
- QC PASS alone is not enough: good output is required before batch completion.
- FAIL/HOLD never becomes saleable release.
- Reject/rework actions are intents/audit bridges; they must be posted by the authoritative inventory transaction service.
- Compliance linking does not claim legal compliance; it records traceability against the configured FSMS/FSSAI requirement.
- Offline client cannot bypass server specification, disposition or posting authority.

## Validation
Run `pytest`. v56 adds 10 focused tests and retains the inherited suite.
