# Namkeen ERP v17 — Mobile Sync, Customer Onboarding, Collections & Returns

v17 extends the v16 production transaction API into the field/mobile workflows that were still outside the persistent path.

## Added
- Customer onboarding with shop/GPS/document metadata and manager approval.
- Collection evidence requiring counterparty/shop photo, with optional GPS capture.
- Collection lifecycle: captured → deposit submitted → accounts/manager verified.
- Cash deposit modes constrained to company account or authorized company handover.
- Sales return initiation with evidence and mandatory QC-hold state.
- Return disposition: SALEABLE / REPACK / REWORK / DAMAGE / EXPIRED / DISPOSE with authorization.
- Persistent mobile sync-event ingestion with organization-scoped idempotency.
- Notification delivery tracking with retry state and pluggable provider interface.
- PostgreSQL migration `007_v17_mobile_collections_returns.sql`.
- Service/API tests covering onboarding/approval, collection verification, returns/QC, and sync idempotency.

## Important integrity rules
- Server remains authoritative after sync for customer approval, payment/deposit verification, stock, QC disposition and accounting state.
- Returned goods do not become saleable stock merely because a salesperson submitted a return.
- Customer documents are references to private object storage; the database does not store document bytes.
- Notifications are outbox-based; delivery providers remain replaceable (FCM/SMS/WhatsApp/email can be added without changing transaction records).

## Remaining production gates
- Execute migrations against real PostgreSQL/Alembic pipeline.
- Complete mobile delta sync/download APIs and explicit conflict-resolution UI.
- Add actual encrypted object storage and malware/file validation.
- Integrate FCM/SMS/WhatsApp/email providers.
- Complete production audit coverage for all v17 endpoints.
- Add load tests, backup/restore, security testing, and field UAT.
