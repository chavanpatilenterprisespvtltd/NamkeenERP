
from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import (
    String, Boolean, DateTime, Date, Numeric, ForeignKey, Text, BigInteger,
    UniqueConstraint, Index
)
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

class Entity(Base):
    __tablename__ = "entities"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    legal_name: Mapped[str] = mapped_column(String(250), nullable=False)
    gstin: Mapped[str|None] = mapped_column(String(20))
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("organization_id","code",name="uq_entities_org_code"),)

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    username: Mapped[str] = mapped_column(String(120), nullable=False, unique=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(50), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

class UserEntity(Base):
    __tablename__ = "user_entities"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    __table_args__ = (UniqueConstraint("user_id","entity_id",name="uq_user_entity"),)

class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("organization_id","code",name="uq_products_org_code"),)

class PackSize(Base):
    __tablename__ = "pack_sizes"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    net_weight_g: Mapped[Decimal] = mapped_column(Numeric(12,3), nullable=False)

class SKU(Base):
    __tablename__ = "skus"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), nullable=False)
    pack_size_id: Mapped[int] = mapped_column(ForeignKey("pack_sizes.id"), nullable=False)
    barcode: Mapped[str|None] = mapped_column(String(100))
    mrp: Mapped[Decimal|None] = mapped_column(Numeric(14,2))
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    code: Mapped[str] = mapped_column(String(60), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    mobile: Mapped[str|None] = mapped_column(String(30))
    gps_lat: Mapped[Decimal|None] = mapped_column(Numeric(10,7))
    gps_lng: Mapped[Decimal|None] = mapped_column(Numeric(10,7))
    approval_status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    credit_limit: Mapped[Decimal] = mapped_column(Numeric(16,2), nullable=False, default=0)
    credit_days: Mapped[int] = mapped_column(default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("organization_id","code",name="uq_customers_org_code"),)

class SalesOrder(Base):
    __tablename__ = "sales_orders"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), nullable=False)
    salesperson_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    order_no: Mapped[str] = mapped_column(String(60), nullable=False, unique=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False)
    payment_mode: Mapped[str] = mapped_column(String(30), nullable=False)
    payment_state: Mapped[str] = mapped_column(String(40), nullable=False)
    credit_state: Mapped[str] = mapped_column(String(40), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    __table_args__ = (Index("idx_sales_order_org_status","organization_id","status"),)

class SalesOrderLine(Base):
    __tablename__ = "sales_order_lines"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("sales_orders.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    qty: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    negotiated_price: Mapped[Decimal] = mapped_column(Numeric(14,2), nullable=False)
    floor_price: Mapped[Decimal] = mapped_column(Numeric(14,2), nullable=False)
    company_cost: Mapped[Decimal] = mapped_column(Numeric(14,2), nullable=False)

class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    order_id: Mapped[int|None] = mapped_column(ForeignKey("sales_orders.id"))
    customer_id: Mapped[int|None] = mapped_column(ForeignKey("customers.id"))
    mode: Mapped[str] = mapped_column(String(30), nullable=False)
    status: Mapped[str] = mapped_column(String(40), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric(16,2), nullable=False)
    reference: Mapped[str|None] = mapped_column(String(120))
    proof_file_id: Mapped[str|None] = mapped_column(String(120))
    collected_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    verified_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class InventoryLot(Base):
    __tablename__ = "inventory_lots"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    warehouse_code: Mapped[str] = mapped_column(String(50), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    batch_no: Mapped[str] = mapped_column(String(80), nullable=False)
    expiry_date: Mapped[date|None] = mapped_column(Date)
    qty_available: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    qty_reserved: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    __table_args__ = (
        UniqueConstraint("entity_id","warehouse_code","sku_id","batch_no",name="uq_inventory_lot"),
        Index("idx_inventory_fefo","entity_id","warehouse_code","sku_id","expiry_date","id")
    )

class InventoryLedger(Base):
    __tablename__ = "inventory_ledger"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    lot_id: Mapped[int] = mapped_column(ForeignKey("inventory_lots.id"), nullable=False)
    txn_type: Mapped[str] = mapped_column(String(40), nullable=False)
    qty: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    reference_type: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class ApprovalRequest(Base):
    __tablename__ = "approval_requests"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    request_type: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(100), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    reason: Mapped[str|None] = mapped_column(Text)
    decided_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int|None] = mapped_column(ForeignKey("entities.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    action: Mapped[str] = mapped_column(String(80), nullable=False)
    reference_type: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(100), nullable=False)
    reason: Mapped[str|None] = mapped_column(Text)
    before_json: Mapped[str|None] = mapped_column(Text)
    after_json: Mapped[str|None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class SyncEvent(Base):
    __tablename__ = "sync_events"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    device_id: Mapped[str] = mapped_column(String(120), nullable=False)
    client_event_id: Mapped[str] = mapped_column(String(120), nullable=False)
    event_type: Mapped[str] = mapped_column(String(60), nullable=False)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    __table_args__ = (UniqueConstraint("organization_id","client_event_id",name="uq_sync_org_event"),)

class ComplianceTask(Base):
    __tablename__ = "compliance_tasks"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    requirement_code: Mapped[str] = mapped_column(String(100), nullable=False)
    due_date: Mapped[date|None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="OPEN")
    owner_role: Mapped[str|None] = mapped_column(String(50))
