
from decimal import Decimal
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models import Customer, SalesOrder, SalesOrderLine, ApprovalRequest, AuditEvent, Payment
from .inventory import reserve_fefo, post_dispatch, InventoryError

MANAGEMENT={"MANAGER","MANAGEMENT","SUPER_ADMIN"}
ACCOUNTS={"ACCOUNTS","MANAGER","MANAGEMENT","SUPER_ADMIN"}

def _audit(db, *, org_id, entity_id, user_id, action, ref_type, ref_id, reason=None, before=None, after=None):
    db.add(AuditEvent(organization_id=org_id,entity_id=entity_id,user_id=user_id,action=action,
                      reference_type=ref_type,reference_id=ref_id,reason=reason,
                      before_json=None if before is None else str(before),
                      after_json=None if after is None else str(after)))

def create_order(db:Session, *, org_id, entity_id, customer_id, salesperson_id, order_no,
                 payment_mode, payment_state, credit_state, lines):
    customer=db.execute(select(Customer).where(Customer.id==customer_id,Customer.organization_id==org_id)).scalar_one()
    if customer.approval_status!="APPROVED": raise ValueError("CUSTOMER_NOT_APPROVED")
    exception=False
    line_objs=[]
    for x in lines:
        price=Decimal(str(x["negotiated_price"])); floor=Decimal(str(x["floor_price"])); cost=Decimal(str(x["company_cost"]))
        if price<floor or price<cost: exception=True
        line_objs.append((x,price,floor,cost))
    if payment_mode.upper()=="CHEQUE" and payment_state!="CLEARED":
        status="CHEQUE_HOLD"
    elif payment_state!="VERIFIED":
        status="PAYMENT_VERIFICATION"
    elif exception:
        status="PRICE_APPROVAL"
    else:
        status="READY_FOR_STOCK_CHECK"
    order=SalesOrder(organization_id=org_id,entity_id=entity_id,customer_id=customer_id,salesperson_id=salesperson_id,
                     order_no=order_no,status=status,payment_mode=payment_mode,payment_state=payment_state,credit_state=credit_state)
    db.add(order); db.flush()
    for x,p,f,cost in line_objs:
        db.add(SalesOrderLine(order_id=order.id,sku_id=x["sku_id"],qty=Decimal(str(x["qty"])),
                              negotiated_price=p,floor_price=f,company_cost=cost))
    _audit(db,org_id=org_id,entity_id=entity_id,user_id=salesperson_id,action="ORDER_CREATED",
           ref_type="SALES_ORDER",ref_id=order_no,after={"status":status})
    return order

def approve_order(db:Session, *, order_id, actor_user, reason):
    if actor_user.role not in MANAGEMENT: raise PermissionError("MANAGEMENT_APPROVAL_REQUIRED")
    order=db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    old=order.status
    if old not in ("PRICE_APPROVAL","CHEQUE_HOLD","PAYMENT_VERIFICATION"): 
        raise ValueError("ORDER_NOT_IN_APPROVAL_STATE")
    # approval is explicit even if reason is blank
    apr=ApprovalRequest(organization_id=order.organization_id,entity_id=order.entity_id,
                        request_type="SALES_ORDER",reference_id=order.order_no,
                        status="APPROVED",reason=reason,decided_by=actor_user.id,decided_at=datetime.utcnow())
    db.add(apr)
    order.status="READY_FOR_STOCK_CHECK"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,
           action="ORDER_OVERRIDE_APPROVED",ref_type="SALES_ORDER",ref_id=order.order_no,reason=reason,
           before=old,after=order.status)
    return order

def verify_payment(db:Session, *, order_id, actor_user, payment_id=None):
    if actor_user.role not in ACCOUNTS: raise PermissionError("ACCOUNTS_OR_MANAGEMENT_REQUIRED")
    order=db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    old=order.payment_state
    order.payment_state="VERIFIED"
    if order.status=="PAYMENT_VERIFICATION": order.status="READY_FOR_STOCK_CHECK"
    elif order.status=="CHEQUE_HOLD" and order.payment_mode.upper()!="CHEQUE": order.status="READY_FOR_STOCK_CHECK"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,
           action="PAYMENT_VERIFIED",ref_type="SALES_ORDER",ref_id=order.order_no,
           before=old,after=order.payment_state)
    if payment_id:
        p=db.execute(select(Payment).where(Payment.id==payment_id).with_for_update()).scalar_one()
        p.status="VERIFIED"; p.verified_by=actor_user.id
    return order

def clear_cheque(db:Session, *, order_id, actor_user):
    if actor_user.role not in ACCOUNTS: raise PermissionError("ACCOUNTS_OR_MANAGEMENT_REQUIRED")
    order=db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    if order.payment_mode.upper()!="CHEQUE": raise ValueError("NOT_CHEQUE_ORDER")
    order.payment_state="CLEARED"
    if order.status=="CHEQUE_HOLD": order.status="READY_FOR_STOCK_CHECK"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,
           action="CHEQUE_CLEARED",ref_type="SALES_ORDER",ref_id=order.order_no)
    return order

def reserve_order(db:Session, *, order_id, warehouse_code):
    order=db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    if order.status!="READY_FOR_STOCK_CHECK": raise ValueError(f"ORDER_NOT_READY:{order.status}")
    lines=db.execute(select(SalesOrderLine).where(SalesOrderLine.order_id==order.id)).scalars().all()
    allocations=[]
    for line in lines:
        allocations.extend(reserve_fefo(db,entity_id=order.entity_id,warehouse_code=warehouse_code,sku_id=line.sku_id,qty=line.qty))
    order.status="STOCK_RESERVED"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=order.salesperson_id,
           action="STOCK_RESERVED",ref_type="SALES_ORDER",ref_id=order.order_no,after=allocations)
    return order, allocations

def dispatch_order(db:Session, *, order_id, actor_user, allocations):
    if actor_user.role not in {"STORE","MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise PermissionError("DISPATCH_ROLE_REQUIRED")
    order=db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    if order.status!="STOCK_RESERVED": raise ValueError(f"ORDER_NOT_DISPATCH_READY:{order.status}")
    post_dispatch(db,organization_id=order.organization_id,entity_id=order.entity_id,
                  order_no=order.order_no,allocations=allocations)
    order.status="DISPATCHED"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,
           action="DISPATCH_POSTED",ref_type="SALES_ORDER",ref_id=order.order_no,after=order.status)
    return order
