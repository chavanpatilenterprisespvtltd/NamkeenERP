from fastapi import FastAPI
from app.api_v16 import app as v16_app
from app.api_v17 import app as v17_app

app=FastAPI(title="Namkeen ERP API")
app.mount("/v16",v16_app)
app.mount("/v17",v17_app)
