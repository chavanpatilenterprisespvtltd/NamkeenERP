from app.db.models import Payment
from app.db.models_v17 import CollectionEvidence, CollectionDeposit

COLLECT_ROLES = {"SALESPERSON", "MANAGER", "MANAGEMENT", "SUPER_ADMIN"}
VERIFY_ROLES = {"ACCOUNTS", "MANAGER", "MANAGEMENT", "SUPER_ADMIN"}

def capture_collection(db, *, org_id, entity_id, actor_id, payment_id, photo_file_id, lat=None, lng=None):
    p = db.query(Payment).filter(Payment.id==payment_id, Payment.organization_id==org_id, Payment.entity_id==entity_id).one()
    p.collected_by = actor_id
    if p.status not in {"RECEIVED", "COLLECTED", "VERIFIED"}: p.status = "COLLECTED"
    ev = CollectionEvidence(organization_id=org_id, entity_id=entity_id, payment_id=payment_id, counterparty_photo_file_id=photo_file_id,
                            captured_lat=lat, captured_lng=lng, collected_by=actor_id)
    db.add(ev); db.flush(); return p

def submit_deposit(db, *, org_id, entity_id, actor_id, payment_id, mode, deposit_ref=None):
    if mode not in {"COMPANY_ACCOUNT", "AUTHORIZED_HANDOVER"}: raise ValueError("Invalid deposit mode")
    p = db.query(Payment).filter(Payment.id==payment_id, Payment.organization_id==org_id, Payment.entity_id==entity_id).one()
    if db.query(CollectionEvidence).filter(CollectionEvidence.payment_id==payment_id).count() != 1:
        raise ValueError("Collection photo evidence is required before deposit")
    if p.status not in {"COLLECTED", "RECEIVED", "VERIFIED"}: raise ValueError("Payment is not collected")
    d = CollectionDeposit(organization_id=org_id, entity_id=entity_id, payment_id=payment_id, mode=mode, deposit_ref=deposit_ref,
                          deposited_by=actor_id, status="SUBMITTED")
    p.status = "DEPOSIT_PENDING"
    db.add(d); db.flush(); return d

def verify_deposit(db, *, org_id, entity_id, actor_id, actor_role, deposit_id):
    if actor_role not in VERIFY_ROLES: raise PermissionError("Deposit verification requires accounts/manager role")
    d = db.query(CollectionDeposit).filter(CollectionDeposit.id==deposit_id, CollectionDeposit.organization_id==org_id, CollectionDeposit.entity_id==entity_id).one()
    d.status = "VERIFIED"; d.verified_by = actor_id
    p = db.query(Payment).filter(Payment.id==d.payment_id).one(); p.status = "VERIFIED"
    db.flush(); return d
