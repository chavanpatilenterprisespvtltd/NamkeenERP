# Health / Readiness Contract

`/healthz` means the process is alive.

`/readyz` means the instance may receive traffic and has validated its critical dependencies.

Minimum readiness dependencies:
- database connection
- migration head
- required secret backend
- worker lease/queue connectivity where configured

External accounting/GST/EWB providers are **not** required for process liveness; their outbox health is monitored separately.
