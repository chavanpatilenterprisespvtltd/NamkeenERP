-- v71 deployment/e2e metadata
CREATE TABLE IF NOT EXISTS deployment_release (
  id BIGSERIAL PRIMARY KEY,
  release_version VARCHAR(32) NOT NULL,
  environment VARCHAR(32) NOT NULL,
  manifest_sha256 VARCHAR(64) NOT NULL,
  migration_head VARCHAR(64) NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'PREPARED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deployed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS integration_smoke_run (
  id BIGSERIAL PRIMARY KEY,
  environment VARCHAR(32) NOT NULL,
  run_key VARCHAR(128) NOT NULL UNIQUE,
  status VARCHAR(24) NOT NULL,
  passed_steps INTEGER NOT NULL DEFAULT 0,
  failed_steps INTEGER NOT NULL DEFAULT 0,
  details_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_integration_smoke_run_env_created ON integration_smoke_run(environment, created_at DESC);
