from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class Step:
    name: str
    ok: bool
    detail: str = ''

@dataclass
class SmokeRun:
    key: str
    steps: List[Step] = field(default_factory=list)

    @property
    def passed(self) -> int:
        return sum(1 for s in self.steps if s.ok)

    @property
    def failed(self) -> int:
        return sum(1 for s in self.steps if not s.ok)

    def summary(self) -> Dict[str, int | str]:
        return {'status': 'PASS' if self.failed == 0 else 'FAIL', 'passed': self.passed, 'failed': self.failed}
