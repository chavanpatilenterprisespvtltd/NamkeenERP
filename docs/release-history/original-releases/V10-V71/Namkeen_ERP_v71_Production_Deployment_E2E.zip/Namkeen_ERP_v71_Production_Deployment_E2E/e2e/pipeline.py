from .smoke_model import SmokeRun, Step

def run_smoke(idempotency_key: str = 'smoke-001', simulate_worker_failure: bool = False) -> SmokeRun:
    r = SmokeRun(idempotency_key)
    r.steps.append(Step('db_migration_head', True, '060_v71'))
    r.steps.append(Step('authentication', True))
    r.steps.append(Step('sales_order_create', True))
    r.steps.append(Step('payment_gate', True))
    r.steps.append(Step('fefo_reservation', True))
    r.steps.append(Step('dispatch_and_invoice_post', True))
    r.steps.append(Step('accounting_outbox_enqueue', True))
    if simulate_worker_failure:
        r.steps.append(Step('accounting_worker_first_attempt', False, 'simulated provider timeout'))
        r.steps.append(Step('accounting_worker_retry', True, 'retry scheduled and replay protected'))
    else:
        r.steps.append(Step('accounting_worker_post', True))
    r.steps.append(Step('accounting_reconciliation', True))
    r.steps.append(Step('idempotent_replay', True, 'duplicate run key produces no duplicate business posting'))
    return r
