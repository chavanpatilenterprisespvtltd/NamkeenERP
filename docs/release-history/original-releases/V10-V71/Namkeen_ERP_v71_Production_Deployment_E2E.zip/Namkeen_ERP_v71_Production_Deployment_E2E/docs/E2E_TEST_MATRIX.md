# v71 End-to-End Test Matrix

| Flow | Expected |
|---|---|
| DB migration head | 060_v71 |
| Authentication | succeeds |
| Sales order | persists exactly once |
| Payment gate | honored |
| FEFO reservation | succeeds |
| Dispatch + invoice | atomic business posting |
| Accounting outbox | created |
| Worker success | acknowledged |
| Worker timeout | retry without duplicate |
| Reconciliation | terminal match/mismatch state |
| Replay | idempotent |

The harness models provider failure without requiring live external credentials. Target-environment UAT must still execute against actual Tally/IRP/EWB providers.
