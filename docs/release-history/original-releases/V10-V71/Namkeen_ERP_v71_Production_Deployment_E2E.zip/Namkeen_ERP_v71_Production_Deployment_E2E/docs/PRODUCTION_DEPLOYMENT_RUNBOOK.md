# v71 Production Deployment Runbook

1. Build immutable API/worker images and record digests.
2. Provision managed secrets/KMS and TLS.
3. Provision PostgreSQL with SSL and backup policy.
4. Apply migrations through `060_v71_deployment_e2e.sql` using a controlled migration job.
5. Start DB, API and worker; verify `/healthz` and `/readyz`.
6. Run deployment gate and E2E smoke suite.
7. Verify accounting/GST/EWB outbox queues.
8. Execute customer-specific Tally/IRP/EWB UAT.
9. Verify backup + restore test.
10. Approve go-live and record release manifest/checksum.

Rollback: stop new traffic, preserve audit/outbox state, revert application image only when database compatibility allows it; use forward-only database migration fixes rather than destructive rollback.
