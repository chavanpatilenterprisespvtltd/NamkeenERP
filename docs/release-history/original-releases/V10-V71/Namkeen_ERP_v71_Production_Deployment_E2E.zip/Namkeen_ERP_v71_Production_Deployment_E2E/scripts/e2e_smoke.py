#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from e2e.pipeline import run_smoke

r = run_smoke('manual-smoke-001')
print(json.dumps(r.summary(), indent=2))
for s in r.steps:
    print(f"{'PASS' if s.ok else 'FAIL'}  {s.name} {s.detail}")
raise SystemExit(0 if r.failed == 0 else 1)
