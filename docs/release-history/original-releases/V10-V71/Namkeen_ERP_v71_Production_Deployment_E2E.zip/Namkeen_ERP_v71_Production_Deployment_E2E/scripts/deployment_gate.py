#!/usr/bin/env python3
import argparse, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.security import DeploymentConfig, validate_config

p=argparse.ArgumentParser(); p.add_argument('--environment', default='staging'); a=p.parse_args()
c=DeploymentConfig(a.environment, https_required=a.environment=='production', debug=a.environment!='production', secret_backend=os.getenv('ERP_SECRET_BACKEND','managed_secret_store'), db_ssl_required=a.environment=='production', audit_tamper_evident=True, backup_encryption_required=True)
errs=validate_config(c)
if errs:
    for e in errs: print('BLOCK:', e)
    raise SystemExit(2)
print(f'RELEASE GATE PASS: {a.environment}')
