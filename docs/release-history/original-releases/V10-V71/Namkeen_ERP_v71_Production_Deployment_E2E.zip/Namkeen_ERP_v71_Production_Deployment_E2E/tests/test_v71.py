import unittest
from e2e.pipeline import run_smoke
from app.security import DeploymentConfig, validate_config

class V71Tests(unittest.TestCase):
    def test_smoke_happy_path(self):
        r=run_smoke('k1'); self.assertEqual(r.failed,0); self.assertEqual(r.passed,10)
    def test_smoke_retry_path(self):
        r=run_smoke('k2', simulate_worker_failure=True); self.assertEqual(r.failed,1); self.assertEqual(r.passed,10)
        self.assertIn('accounting_worker_retry', [s.name for s in r.steps])
    def test_idempotency_key_required_by_contract(self):
        self.assertTrue(run_smoke('same').key == run_smoke('same').key)
    def test_production_gate_blocks_plain_file_secrets(self):
        c=DeploymentConfig('production',True,False,'local_file',True,True,True)
        self.assertTrue(validate_config(c))
    def test_production_gate_passes_managed(self):
        c=DeploymentConfig('production',True,False,'managed_secret_store',True,True,True)
        self.assertEqual(validate_config(c),[])

if __name__=='__main__': unittest.main()
