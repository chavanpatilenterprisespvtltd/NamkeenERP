# Namkeen ERP v71 — Automated Production Deployment + End-to-End Integration Harness

v71 is the deployment/integration stage after v70 security hardening. It does **not** claim that production has been deployed; it provides a repeatable staging path and automated checks for deployment readiness.

## Scope
- Versioned database migration runner manifest
- Docker Compose staging stack for API, worker, PostgreSQL and optional Tally/GST/EWB mock adapters
- Environment validation and fail-fast production gate
- API/worker/db startup ordering and health checks
- End-to-end smoke harness across auth → sales → accounting outbox → worker → reconciliation
- Idempotent replay test and failure/dead-letter simulation
- Backup/restore smoke gate hooks
- Security regression suite reusing v70 controls
- CI workflow for unit + integration-smoke tests
- Deployment manifest/checksum report
- PostgreSQL migration `060_v71_deployment_e2e.sql`

## Important
v71 is a **staging/deployment harness**, not proof of a successful production deployment. Real PostgreSQL, Tally, IRP/EWB, object storage, secrets/KMS, DNS/TLS and external-provider credentials must be supplied in the target environment.

## Run tests
`python -m unittest discover -s tests -v`

## Run local smoke harness
`python scripts/e2e_smoke.py`

## Deployment gate
`python scripts/deployment_gate.py --environment staging`
