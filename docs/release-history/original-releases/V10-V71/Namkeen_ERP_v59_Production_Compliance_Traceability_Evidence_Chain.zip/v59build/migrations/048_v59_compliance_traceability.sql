-- v59: compliance transaction bridges and unified inspection/evidence chain
CREATE TABLE IF NOT EXISTS compliance_trace_link (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    entity_type VARCHAR(64) NOT NULL,
    entity_id BIGINT NOT NULL,
    relation VARCHAR(64) NOT NULL,
    target_type VARCHAR(64) NOT NULL,
    target_id BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, site_id, entity_type, entity_id, relation, target_type, target_id)
);
CREATE INDEX IF NOT EXISTS idx_compliance_trace_entity
ON compliance_trace_link(organization_id, site_id, entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_compliance_trace_target
ON compliance_trace_link(organization_id, site_id, target_type, target_id);

CREATE TABLE IF NOT EXISTS compliance_evidence_record (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    evidence_type VARCHAR(64) NOT NULL,
    captured_on DATE NOT NULL,
    storage_ref TEXT NOT NULL,
    sha256 CHAR(64) NOT NULL,
    source_entity_type VARCHAR(64) NOT NULL,
    source_entity_id BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_compliance_evidence_source
ON compliance_evidence_record(organization_id, site_id, source_entity_type, source_entity_id, captured_on);

CREATE TABLE IF NOT EXISTS compliance_evidence_pack_run (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    root_entity_type VARCHAR(64) NOT NULL,
    root_entity_id BIGINT NOT NULL,
    include_internal BOOLEAN NOT NULL DEFAULT FALSE,
    row_count INTEGER NOT NULL DEFAULT 0,
    export_ref TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_compliance_pack_root
ON compliance_evidence_pack_run(organization_id, site_id, root_entity_type, root_entity_id, created_at);

-- Bridge intent examples: GRN -> incoming QC, production batch -> process QC,
-- packing run -> label review, product test -> CAPA, complaint -> investigation,
-- recall -> affected lots/customers. Actual domain posting remains authoritative.
