# Namkeen ERP v59 — Compliance Transaction Bridges & Inspection Evidence Chain

v59 connects transactional records to the compliance module through a unified trace-link/evidence layer and deterministic inspection-ready evidence packs.

## Added
- `compliance_trace_link` relationship graph
- `compliance_evidence_record` with SHA-256 integrity reference
- evidence-pack run metadata
- site/organization scoped trace chain
- inspection pack generator with internal-evidence exclusion by default
- FastAPI `/v59/compliance/trace-pack`
- Android offline evidence/trace contract
- PostgreSQL migration `048_v59_compliance_traceability.sql`

## Boundaries
The trace layer does not rewrite source transactions. Inventory, production, QC, recall, accounting and customer records remain authoritative in their own services. An inspection pack is operational support, not legal certification.

## Validation
Run `pytest`. v59 adds focused tests while retaining the inherited suite.
