# v59 Android Contract

Screens/contracts:
- Batch/Lot Trace
- Compliance Evidence Capture
- Evidence Upload Queue
- Inspection Pack Preview
- Complaint/Recall Trace

Evidence capture fields: `evidence_type`, `captured_on`, `storage_ref` (after sync), `sha256`, `source_entity_type`, `source_entity_id`, `client_event_id`.

Offline: capture and queue locally; server validates scope, hash, permissions and links after synchronization. The device cannot mark a compliance requirement legally satisfied by itself.
