from datetime import date
from app.v59.compliance_traceability import *
from app.v59.api import trace_pack


def ev(i, typ='PHOTO', src='PRODUCTION_BATCH', srcid=10):
    return Evidence(i, 1, 1, typ, date(2026,9,5), f's3://e/{i}', 'a'*64, src, srcid)


def test_evidence_sha256_required():
    bad = Evidence(1,1,1,'PHOTO',date(2026,9,5),'s3://x','bad','BATCH',1)
    try: validate_evidence(bad)
    except ComplianceTraceError as e: assert str(e) == 'EVIDENCE_SHA256_INVALID'
    else: assert False


def test_chain_is_site_scoped_and_deterministic():
    links = [TraceLink(2,1,1,'BATCH',10,'HAS_QC','QC',9), TraceLink(1,1,1,'BATCH',10,'HAS_GRN','GRN',8), TraceLink(99,2,2,'BATCH',10,'OTHER','QC',1)]
    c = build_chain(1,1,'BATCH',10,links,[ev(2),ev(1)])
    assert [x.link_id for x in c.nodes] == [1,2]
    assert [x.evidence_id for x in c.evidence] == [1,2]


def test_inspection_pack_excludes_internal_by_default():
    p = inspection_pack(build_chain(1,1,'BATCH',10,[],[ev(1),ev(2,'INTERNAL_NOTE')]))
    assert p['evidence_count'] == 1
    assert p['inspection_ready'] is True


def test_inspection_pack_can_include_internal_when_authorized():
    p = inspection_pack(build_chain(1,1,'BATCH',10,[],[ev(1),ev(2,'INTERNAL_NOTE')]), include_internal=True)
    assert p['evidence_count'] == 2


def test_api_rejects_bad_evidence_hash():
    payload = {'organization_id':1,'site_id':1,'root_type':'BATCH','root_id':10,
               'evidence':[{'evidence_id':1,'evidence_type':'PHOTO','captured_on':'2026-09-05','storage_ref':'x','sha256':'x','source_entity_type':'BATCH','source_entity_id':10}]}
    try: trace_pack(payload)
    except Exception as e: assert 'EVIDENCE_SHA256_INVALID' in str(e)
    else: assert False
