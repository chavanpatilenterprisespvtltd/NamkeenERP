from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from hashlib import sha256
from typing import Iterable, Optional

class ComplianceTraceError(ValueError):
    pass

@dataclass(frozen=True)
class Evidence:
    evidence_id: int
    organization_id: int
    site_id: int
    evidence_type: str
    captured_on: date
    storage_ref: str
    sha256_hex: str
    source_entity_type: str
    source_entity_id: int

@dataclass(frozen=True)
class TraceLink:
    link_id: int
    organization_id: int
    site_id: int
    entity_type: str
    entity_id: int
    relation: str
    target_type: str
    target_id: int
    created_at: datetime = field(default_factory=datetime.utcnow)

@dataclass(frozen=True)
class ComplianceChain:
    organization_id: int
    site_id: int
    root_type: str
    root_id: int
    nodes: tuple[TraceLink, ...]
    evidence: tuple[Evidence, ...]


def digest_bytes(payload: bytes) -> str:
    return sha256(payload).hexdigest()


def validate_evidence(e: Evidence) -> None:
    if e.evidence_id <= 0:
        raise ComplianceTraceError("INVALID_EVIDENCE_ID")
    if not e.storage_ref:
        raise ComplianceTraceError("EVIDENCE_STORAGE_REF_REQUIRED")
    if len(e.sha256_hex) != 64 or any(c not in '0123456789abcdef' for c in e.sha256_hex.lower()):
        raise ComplianceTraceError("EVIDENCE_SHA256_INVALID")
    if e.organization_id <= 0 or e.site_id <= 0:
        raise ComplianceTraceError("EVIDENCE_SCOPE_REQUIRED")
    if e.source_entity_id <= 0 or not e.source_entity_type:
        raise ComplianceTraceError("EVIDENCE_SOURCE_REQUIRED")


def build_chain(
    organization_id: int,
    site_id: int,
    root_type: str,
    root_id: int,
    links: Iterable[TraceLink],
    evidence: Iterable[Evidence],
) -> ComplianceChain:
    if organization_id <= 0 or site_id <= 0 or root_id <= 0:
        raise ComplianceTraceError("TRACE_ROOT_SCOPE_REQUIRED")
    selected_links = tuple(sorted(
        (x for x in links if x.organization_id == organization_id and x.site_id == site_id),
        key=lambda x: (x.entity_type, x.entity_id, x.relation, x.target_type, x.target_id, x.link_id),
    ))
    selected_evidence = tuple(sorted(
        (x for x in evidence if x.organization_id == organization_id and x.site_id == site_id),
        key=lambda x: (x.source_entity_type, x.source_entity_id, x.evidence_type, x.evidence_id),
    ))
    for item in selected_evidence:
        validate_evidence(item)
    return ComplianceChain(organization_id, site_id, root_type, root_id, selected_links, selected_evidence)


def inspection_pack(chain: ComplianceChain, *, include_internal: bool = False) -> dict:
    """Deterministic inspection-ready evidence pack metadata, not a legal filing."""
    allowed = chain.evidence if include_internal else tuple(e for e in chain.evidence if not e.evidence_type.upper().startswith('INTERNAL'))
    link_rows = [
        {"entity_type": n.entity_type, "entity_id": n.entity_id, "relation": n.relation,
         "target_type": n.target_type, "target_id": n.target_id, "link_id": n.link_id}
        for n in chain.nodes
    ]
    evidence_rows = [
        {"evidence_id": e.evidence_id, "evidence_type": e.evidence_type, "captured_on": e.captured_on.isoformat(),
         "storage_ref": e.storage_ref, "sha256": e.sha256_hex, "source_entity_type": e.source_entity_type,
         "source_entity_id": e.source_entity_id}
        for e in allowed
    ]
    return {
        "organization_id": chain.organization_id,
        "site_id": chain.site_id,
        "root": {"entity_type": chain.root_type, "entity_id": chain.root_id},
        "links": link_rows,
        "evidence": evidence_rows,
        "evidence_count": len(evidence_rows),
        "inspection_ready": bool(evidence_rows or link_rows),
        "disclaimer": "Operational inspection pack; not a legal certification or filing."
    }
