from fastapi import APIRouter, HTTPException
from .compliance_traceability import Evidence, TraceLink, build_chain, inspection_pack, ComplianceTraceError
from datetime import date

router = APIRouter(prefix='/v59/compliance', tags=['v59-compliance-traceability'])

@router.post('/trace-pack')
def trace_pack(payload: dict):
    try:
        oid, sid = int(payload['organization_id']), int(payload['site_id'])
        links = [TraceLink(int(x['link_id']), oid, sid, x['entity_type'], int(x['entity_id']), x['relation'], x['target_type'], int(x['target_id'])) for x in payload.get('links', [])]
        ev = [Evidence(int(x['evidence_id']), oid, sid, x['evidence_type'], date.fromisoformat(x['captured_on']), x['storage_ref'], x['sha256'], x['source_entity_type'], int(x['source_entity_id'])) for x in payload.get('evidence', [])]
        chain = build_chain(oid, sid, payload['root_type'], int(payload['root_id']), links, ev)
        return inspection_pack(chain, include_internal=bool(payload.get('include_internal', False)))
    except (KeyError, ValueError, ComplianceTraceError) as exc:
        raise HTTPException(400, str(exc))
