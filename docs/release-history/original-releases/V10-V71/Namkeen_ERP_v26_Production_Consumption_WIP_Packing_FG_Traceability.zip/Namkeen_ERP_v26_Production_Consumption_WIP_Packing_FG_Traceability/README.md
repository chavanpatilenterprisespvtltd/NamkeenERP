# Namkeen ERP v26 — Production Consumption, WIP, Packing & FG Traceability

Built on v25 inventory/warehouse foundation.

### Included
- RM and packaging lot issue into production/packing.
- WIP lot creation and controlled consumption.
- Packing run lifecycle.
- Packaging inventory consumption.
- FG lot creation directly into FG warehouse inventory.
- Production yield + reject capture.
- Production wastage with authorization control.
- Inventory ledger postings for issue/output.
- Canonical domain events for mobile/integration sync.
- PostgreSQL migration `015_v26_production_packing.sql`.
- Android workflow contract.
- v26 targeted tests.

### Important implementation boundary
The current generic `InventoryLot.qty_available` remains the stock balance field. v26 documents kg as the valuation/stock basis for production/WIP/FG while preserving `good_pack_qty` separately. A later UOM/pack-conversion master should become the single source of truth for piece → pack → carton → kg conversions.
