# Namkeen ERP v16 — Production Transaction API

v16 connects the PostgreSQL/auth foundation to the core sales transaction path and closes two important production gaps from v15: refresh-token lifecycle and persistent FEFO reservation/dispatch allocation.

## Main additions
- Refresh-token rotation with replay/invalid-token revocation behavior.
- Entity-scoped authenticated transaction API.
- PostgreSQL-backed sales order creation through authenticated actor identity.
- Persistent order approval, payment verification, cheque clearance.
- Persistent FEFO stock reservation table (`order_allocations`).
- Dispatch posts inventory ledger entries from the server-stored reservation set rather than trusting the mobile client to resend allocations.
- Migration `006_v16_transaction_api.sql`.
- API, refresh and persistent allocation tests.

## Security/data-integrity rule
Mobile clients may capture transactions offline, but the server remains authoritative for identity, entity scope, payment gates, price approval, inventory reservation and dispatch. Client-supplied allocation details are not accepted as the final stock movement instruction.

## Remaining production gates
Actual production deployment still requires real PostgreSQL/Alembic migration execution, secret management, HTTPS, encrypted private object storage, background workers, mobile offline conflict UAT, Tally UAT, backup/restore tests, load/security testing, and operational monitoring.
