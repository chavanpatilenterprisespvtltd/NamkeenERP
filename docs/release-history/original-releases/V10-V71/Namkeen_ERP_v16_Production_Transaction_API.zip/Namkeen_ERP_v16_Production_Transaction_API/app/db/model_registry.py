def load_all_models():
    from . import models, models_v15, integration_models
    return (models, models_v15, integration_models)
