
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from decimal import Decimal
from sqlalchemy import select
from app.db.session import SessionLocal
from app.db.models import User, Customer, Payment, SalesOrder, ComplianceTask
from app.services.order_posting import create_order, approve_order, verify_payment, clear_cheque, reserve_order, dispatch_order

app=FastAPI(title="Namkeen ERP v13 — PostgreSQL Transaction API",version="13.0")

def db_session():
    db=SessionLocal()
    try: yield db
    finally: db.close()

# Development auth: replace by JWT/session middleware from v11 in production.
DEMO_USERS={"sales":1,"manager":2,"accounts":3,"store":4,"management":5}
ROLES={"sales":"SALESPERSON","manager":"MANAGER","accounts":"ACCOUNTS","store":"STORE","management":"MANAGEMENT"}

def actor(x_role):
    key=(x_role or "").lower()
    if key not in DEMO_USERS: raise HTTPException(401,"Invalid development user")
    return type("Actor",(),{"id":DEMO_USERS[key],"role":ROLES[key]})()

class OrderLineIn(BaseModel):
    sku_id:int
    qty:Decimal
    negotiated_price:Decimal
    floor_price:Decimal
    company_cost:Decimal

class OrderIn(BaseModel):
    org_id:int
    entity_id:int
    customer_id:int
    salesperson_id:int
    order_no:str
    payment_mode:str
    payment_state:str
    credit_state:str
    lines:list[OrderLineIn]

@app.get("/health")
def health(): return {"status":"ok","version":"13.0"}

@app.post("/orders")
def order(body:OrderIn,x_role:str=Header(default="sales")):
    a=actor(x_role); db=SessionLocal()
    try:
        with db.begin():
            if a.role!="SALESPERSON" and a.role!="MANAGER" and a.role!="MANAGEMENT" and a.role!="SUPER_ADMIN":
                raise HTTPException(403,"Order creation not permitted")
            o=create_order(db,**body.model_dump())
        return {"id":o.id,"status":o.status}
    except HTTPException: raise
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/approve")
def approve(order_id:int,reason:str|None=None,x_role:str=Header(default="manager")):
    a=actor(x_role); db=SessionLocal()
    try:
        with db.begin(): o=approve_order(db,order_id=order_id,actor_user=a,reason=reason)
        return {"id":o.id,"status":o.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/payment-verify")
def pverify(order_id:int,x_role:str=Header(default="accounts")):
    a=actor(x_role); db=SessionLocal()
    try:
        with db.begin(): o=verify_payment(db,order_id=order_id,actor_user=a)
        return {"id":o.id,"status":o.status,"payment_state":o.payment_state}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/cheque-clear")
def cheque(order_id:int,x_role:str=Header(default="accounts")):
    a=actor(x_role); db=SessionLocal()
    try:
        with db.begin(): o=clear_cheque(db,order_id=order_id,actor_user=a)
        return {"id":o.id,"status":o.status,"payment_state":o.payment_state}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.get("/compliance/tasks")
def compliance(x_role:str=Header(default="management"),org_id:int=1):
    db=SessionLocal()
    try:
        return [{"id":x.id,"entity_id":x.entity_id,"requirement_code":x.requirement_code,
                 "due_date":x.due_date,"status":x.status,"owner_role":x.owner_role}
                for x in db.execute(select(ComplianceTask).where(ComplianceTask.organization_id==org_id)).scalars()]
    finally: db.close()
