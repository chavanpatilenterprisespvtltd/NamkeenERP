from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Iterable

class RecallError(ValueError):
    pass

COMPLAINT_STATES = ('OPEN','TRIAGED','INVESTIGATING','CAPA_REQUIRED','RESOLVED','CLOSED')
RECALL_STATES = ('DRAFT','PENDING_APPROVAL','APPROVED','INITIATED','COMMUNICATING','RECOVERING','EFFECTIVENESS_CHECK','CLOSED','CANCELLED')
DISPOSITIONS = ('BLOCK','RETURN','RECALL','DESTROY','HOLD','REWORK')

_ALLOWED_COMPLAINT = {
    'OPEN': {'TRIAGED','CLOSED'},
    'TRIAGED': {'INVESTIGATING','RESOLVED','CLOSED'},
    'INVESTIGATING': {'CAPA_REQUIRED','RESOLVED','CLOSED'},
    'CAPA_REQUIRED': {'RESOLVED','CLOSED'},
    'RESOLVED': {'CLOSED'},
    'CLOSED': set(),
}
_ALLOWED_RECALL = {
    'DRAFT': {'PENDING_APPROVAL','CANCELLED'},
    'PENDING_APPROVAL': {'APPROVED','CANCELLED'},
    'APPROVED': {'INITIATED','CANCELLED'},
    'INITIATED': {'COMMUNICATING','RECOVERING'},
    'COMMUNICATING': {'RECOVERING'},
    'RECOVERING': {'EFFECTIVENESS_CHECK'},
    'EFFECTIVENESS_CHECK': {'CLOSED'},
    'CLOSED': set(),
    'CANCELLED': set(),
}

@dataclass(frozen=True)
class Complaint:
    complaint_id: int
    organization_id: int
    site_id: int
    customer_id: int
    received_on: date
    severity: str
    description: str
    product_sku_id: int | None = None
    lot_id: int | None = None
    source_channel: str = 'OTHER'
    state: str = 'OPEN'
    recall_required: bool = False
    evidence_ids: tuple[int, ...] = ()

@dataclass(frozen=True)
class ComplaintInvestigation:
    investigation_id: int
    complaint_id: int
    organization_id: int
    site_id: int
    finding: str
    root_cause: str | None = None
    capa_id: int | None = None
    completed_on: date | None = None

@dataclass(frozen=True)
class Recall:
    recall_id: int
    organization_id: int
    site_id: int
    recall_number: str
    initiated_on: date | None
    reason: str
    severity: str
    state: str = 'DRAFT'
    source_complaint_id: int | None = None
    initiator_user_id: int | None = None
    approver_user_id: int | None = None
    approval_reason: str | None = None
    closed_on: date | None = None

@dataclass(frozen=True)
class RecallLot:
    recall_lot_id: int
    recall_id: int
    lot_id: int
    organization_id: int
    site_id: int
    quantity_affected_kg: float
    quantity_recovered_kg: float = 0.0
    stock_blocked: bool = False

@dataclass(frozen=True)
class RecallCustomer:
    recall_customer_id: int
    recall_id: int
    customer_id: int
    organization_id: int
    site_id: int
    quantity_dispatched_kg: float
    quantity_recovered_kg: float = 0.0
    notified_on: date | None = None
    communication_ref: str | None = None

@dataclass(frozen=True)
class RecallAction:
    action_id: int
    recall_id: int
    action_type: str
    status: str
    action_on: date
    responsible_user_id: int
    evidence_id: int | None = None
    notes: str | None = None

@dataclass(frozen=True)
class EffectivenessCheck:
    check_id: int
    recall_id: int
    organization_id: int
    site_id: int
    checked_on: date
    recovered_kg: float
    affected_kg: float
    open_customer_count: int
    effective: bool
    findings: str


def _require_scope(org_id: int, site_id: int) -> None:
    if org_id <= 0 or site_id <= 0:
        raise RecallError('SCOPE_REQUIRED')


def transition_complaint(c: Complaint, new_state: str) -> Complaint:
    if new_state not in COMPLAINT_STATES:
        raise RecallError('INVALID_COMPLAINT_STATE')
    if new_state not in _ALLOWED_COMPLAINT[c.state]:
        raise RecallError(f'INVALID_COMPLAINT_TRANSITION:{c.state}->{new_state}')
    return Complaint(**{**c.__dict__, 'state': new_state})


def mark_recall_required(c: Complaint, reason: str) -> Complaint:
    if not reason.strip():
        raise RecallError('RECALL_REASON_REQUIRED')
    return Complaint(**{**c.__dict__, 'recall_required': True, 'state': 'CAPA_REQUIRED'})


def transition_recall(r: Recall, new_state: str, *, actor_user_id: int | None = None, reason: str | None = None, on: date | None = None) -> Recall:
    if new_state not in RECALL_STATES:
        raise RecallError('INVALID_RECALL_STATE')
    if new_state not in _ALLOWED_RECALL[r.state]:
        raise RecallError(f'INVALID_RECALL_TRANSITION:{r.state}->{new_state}')
    if new_state == 'APPROVED':
        if actor_user_id is None or actor_user_id <= 0:
            raise RecallError('RECALL_APPROVER_REQUIRED')
        if r.initiator_user_id == actor_user_id:
            raise RecallError('SELF_APPROVAL_NOT_ALLOWED')
        if not (reason or '').strip():
            raise RecallError('RECALL_APPROVAL_REASON_REQUIRED')
    if new_state == 'INITIATED' and not r.initiated_on:
        r = Recall(**{**r.__dict__, 'initiated_on': on or date.today()})
    if new_state == 'CLOSED':
        r = Recall(**{**r.__dict__, 'closed_on': on or date.today()})
    updates = {'state': new_state}
    if new_state == 'APPROVED':
        updates.update({'approver_user_id': actor_user_id, 'approval_reason': reason})
    return Recall(**{**r.__dict__, **updates})


def validate_recall_lot(rl: RecallLot) -> None:
    _require_scope(rl.organization_id, rl.site_id)
    if rl.quantity_affected_kg <= 0:
        raise RecallError('AFFECTED_QTY_MUST_BE_POSITIVE')
    if rl.quantity_recovered_kg < 0 or rl.quantity_recovered_kg > rl.quantity_affected_kg:
        raise RecallError('RECOVERED_QTY_OUT_OF_RANGE')


def validate_recall_customer(rc: RecallCustomer) -> None:
    _require_scope(rc.organization_id, rc.site_id)
    if rc.quantity_dispatched_kg < 0 or rc.quantity_recovered_kg < 0:
        raise RecallError('RECALL_QTY_INVALID')
    if rc.quantity_recovered_kg > rc.quantity_dispatched_kg:
        raise RecallError('RECOVERED_QTY_EXCEEDS_DISPATCHED')
    if rc.notified_on and not rc.communication_ref:
        raise RecallError('COMMUNICATION_REF_REQUIRED')


def evaluate_effectiveness(check: EffectivenessCheck) -> bool:
    if check.affected_kg < 0 or check.recovered_kg < 0 or check.recovered_kg > check.affected_kg:
        raise RecallError('EFFECTIVENESS_QTY_INVALID')
    if check.open_customer_count < 0:
        raise RecallError('OPEN_CUSTOMER_COUNT_INVALID')
    return bool(check.effective)


def close_recall(r: Recall, checks: Iterable[EffectivenessCheck]) -> Recall:
    checks = tuple(checks)
    if not checks:
        raise RecallError('EFFECTIVENESS_CHECK_REQUIRED')
    if not all(evaluate_effectiveness(x) for x in checks):
        raise RecallError('RECALL_EFFECTIVENESS_NOT_ACCEPTABLE')
    if r.state != 'EFFECTIVENESS_CHECK':
        raise RecallError('RECALL_NOT_READY_TO_CLOSE')
    return Recall(**{**r.__dict__, 'state': 'CLOSED', 'closed_on': date.today()})
