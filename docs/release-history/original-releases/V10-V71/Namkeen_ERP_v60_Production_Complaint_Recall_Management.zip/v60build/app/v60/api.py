from fastapi import APIRouter, HTTPException
from .recall_management import Recall, transition_recall, RecallError, EffectivenessCheck, close_recall
from datetime import date

router = APIRouter(prefix='/v60/recall', tags=['v60-recall'])

@router.post('/transition')
def transition(payload: dict):
    try:
        r = Recall(
            recall_id=int(payload['recall_id']), organization_id=int(payload['organization_id']), site_id=int(payload['site_id']),
            recall_number=payload['recall_number'], initiated_on=date.fromisoformat(payload['initiated_on']) if payload.get('initiated_on') else None,
            reason=payload['reason'], severity=payload['severity'], state=payload.get('state','DRAFT'),
            source_complaint_id=int(payload['source_complaint_id']) if payload.get('source_complaint_id') else None,
            initiator_user_id=int(payload['initiator_user_id']) if payload.get('initiator_user_id') else None,
            approver_user_id=int(payload['approver_user_id']) if payload.get('approver_user_id') else None,
            approval_reason=payload.get('approval_reason')
        )
        out = transition_recall(r, payload['new_state'], actor_user_id=int(payload['actor_user_id']) if payload.get('actor_user_id') else None, reason=payload.get('reason_for_transition'), on=date.fromisoformat(payload['on']) if payload.get('on') else None)
        return out.__dict__
    except (KeyError, ValueError, RecallError) as exc:
        raise HTTPException(400, str(exc))

@router.post('/close')
def close(payload: dict):
    try:
        r = Recall(**payload['recall'])
        checks = [EffectivenessCheck(int(x['check_id']), r.recall_id, r.organization_id, r.site_id, date.fromisoformat(x['checked_on']), float(x['recovered_kg']), float(x['affected_kg']), int(x['open_customer_count']), bool(x['effective']), x['findings']) for x in payload.get('checks', [])]
        return close_recall(r, checks).__dict__
    except (KeyError, ValueError, RecallError, TypeError) as exc:
        raise HTTPException(400, str(exc))
