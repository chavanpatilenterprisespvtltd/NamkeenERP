# Namkeen ERP v60 — Complaint & Recall Management

v60 adds the controlled complaint and food-recall lifecycle on top of v59 compliance traceability.

Core path:
`Complaint -> Investigation -> CAPA -> Recall Approval -> Initiation -> Communication -> Recovery -> Effectiveness -> Closure`

Included:
- complaint and investigation models
- recall and affected-lot/customer models
- controlled stock-block records
- customer communication tracking
- recovery/reverse-logistics linkage primitives
- effectiveness checks and closure gate
- server-authoritative state transitions
- PostgreSQL migration `049_v60_recall_complaints.sql`
- Android offline workflow contract
- API contract and tests

The module is deliberately configurable for current legal/regulatory requirements and does not hard-code statutory response times.
