-- v60: complaint management, recall workflow, recovery and effectiveness checks
CREATE TABLE IF NOT EXISTS complaints (
  complaint_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  customer_id BIGINT NOT NULL,
  product_sku_id BIGINT NULL,
  lot_id BIGINT NULL,
  received_on DATE NOT NULL,
  severity VARCHAR(20) NOT NULL,
  source_channel VARCHAR(40) NOT NULL DEFAULT 'OTHER',
  description TEXT NOT NULL,
  state VARCHAR(30) NOT NULL DEFAULT 'OPEN',
  recall_required BOOLEAN NOT NULL DEFAULT FALSE,
  evidence_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_complaints_scope_state ON complaints(organization_id, site_id, state);
CREATE INDEX IF NOT EXISTS ix_complaints_lot ON complaints(organization_id, site_id, lot_id);

CREATE TABLE IF NOT EXISTS complaint_investigations (
  investigation_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  complaint_id BIGINT NOT NULL REFERENCES complaints(complaint_id),
  finding TEXT NOT NULL,
  root_cause TEXT NULL,
  capa_id BIGINT NULL,
  completed_on DATE NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS recalls (
  recall_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  recall_number VARCHAR(80) NOT NULL,
  source_complaint_id BIGINT NULL REFERENCES complaints(complaint_id),
  severity VARCHAR(20) NOT NULL,
  reason TEXT NOT NULL,
  state VARCHAR(32) NOT NULL DEFAULT 'DRAFT',
  initiated_on DATE NULL,
  initiator_user_id BIGINT NULL,
  approver_user_id BIGINT NULL,
  approval_reason TEXT NULL,
  closed_on DATE NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, recall_number)
);
CREATE INDEX IF NOT EXISTS ix_recalls_scope_state ON recalls(organization_id, site_id, state);

CREATE TABLE IF NOT EXISTS recall_lots (
  recall_lot_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  recall_id BIGINT NOT NULL REFERENCES recalls(recall_id),
  lot_id BIGINT NOT NULL,
  quantity_affected_kg NUMERIC(18,3) NOT NULL CHECK (quantity_affected_kg > 0),
  quantity_recovered_kg NUMERIC(18,3) NOT NULL DEFAULT 0 CHECK (quantity_recovered_kg >= 0),
  stock_blocked BOOLEAN NOT NULL DEFAULT FALSE,
  CHECK (quantity_recovered_kg <= quantity_affected_kg),
  UNIQUE (recall_id, lot_id)
);

CREATE TABLE IF NOT EXISTS recall_customers (
  recall_customer_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  recall_id BIGINT NOT NULL REFERENCES recalls(recall_id),
  customer_id BIGINT NOT NULL,
  quantity_dispatched_kg NUMERIC(18,3) NOT NULL DEFAULT 0 CHECK (quantity_dispatched_kg >= 0),
  quantity_recovered_kg NUMERIC(18,3) NOT NULL DEFAULT 0 CHECK (quantity_recovered_kg >= 0),
  notified_on DATE NULL,
  communication_ref VARCHAR(255) NULL,
  CHECK (quantity_recovered_kg <= quantity_dispatched_kg),
  UNIQUE (recall_id, customer_id)
);

CREATE TABLE IF NOT EXISTS recall_actions (
  action_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  recall_id BIGINT NOT NULL REFERENCES recalls(recall_id),
  action_type VARCHAR(50) NOT NULL,
  status VARCHAR(30) NOT NULL,
  action_on DATE NOT NULL,
  responsible_user_id BIGINT NOT NULL,
  evidence_id BIGINT NULL,
  notes TEXT NULL
);

CREATE TABLE IF NOT EXISTS recall_effectiveness_checks (
  check_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  recall_id BIGINT NOT NULL REFERENCES recalls(recall_id),
  checked_on DATE NOT NULL,
  recovered_kg NUMERIC(18,3) NOT NULL DEFAULT 0,
  affected_kg NUMERIC(18,3) NOT NULL DEFAULT 0,
  open_customer_count INTEGER NOT NULL DEFAULT 0 CHECK (open_customer_count >= 0),
  effective BOOLEAN NOT NULL,
  findings TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_recall_checks_recall ON recall_effectiveness_checks(organization_id, site_id, recall_id, checked_on);

CREATE TABLE IF NOT EXISTS recall_stock_blocks (
  block_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  site_id BIGINT NOT NULL,
  recall_id BIGINT NOT NULL REFERENCES recalls(recall_id),
  lot_id BIGINT NOT NULL,
  blocked_on TIMESTAMPTZ NOT NULL DEFAULT now(),
  released_on TIMESTAMPTZ NULL,
  release_reason TEXT NULL,
  UNIQUE (recall_id, lot_id)
);
