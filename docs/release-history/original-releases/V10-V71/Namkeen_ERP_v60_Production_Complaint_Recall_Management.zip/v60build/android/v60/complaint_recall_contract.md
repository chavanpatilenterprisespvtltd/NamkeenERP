# v60 Android contract — complaint & recall

Offline-capable screens:
- Complaint capture (customer, SKU/lot, severity, description, evidence/photo)
- Complaint triage/investigation
- CAPA link and status
- Recall lot/customer impact list
- Stock-block confirmation
- Customer communication log
- Recovery/return scan
- Effectiveness check and closure readiness

Offline rules:
- Capture creates an outbox event with `client_event_id`, device id, timestamp and evidence hashes.
- Recall initiation, approval, stock blocking, credit-note posting, inventory disposition and closure are server-authoritative.
- No device may mark a recalled lot saleable while offline.
- Evidence uploads are queued separately and retried with integrity verification.
