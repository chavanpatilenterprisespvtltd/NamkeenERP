from datetime import date
from app.v60.recall_management import *


def complaint(state='OPEN'):
    return Complaint(1,1,1,55,date(2026,9,5),'MAJOR','seal broken',lot_id=88,state=state)


def recall(state='DRAFT', approver=None, initiator=None):
    return Recall(1,1,1,'REC-001',None,'product complaint','MAJOR',state=state,initiator_user_id=initiator,approver_user_id=approver)


def test_complaint_transition_is_explicit():
    c = transition_complaint(complaint(), 'TRIAGED')
    assert c.state == 'TRIAGED'
    try: transition_complaint(c, 'CAPA_REQUIRED')
    except RecallError as e: assert str(e).startswith('INVALID_COMPLAINT_TRANSITION')
    else: assert False


def test_recall_required_adds_reason_and_capa_state():
    c = mark_recall_required(complaint('INVESTIGATING'), 'confirmed lot issue')
    assert c.recall_required and c.state == 'CAPA_REQUIRED'


def test_recall_approval_requires_separate_actor_and_reason():
    r = recall(initiator=8)
    try: transition_recall(r,'PENDING_APPROVAL')
    except RecallError: pass
    r2 = transition_recall(r,'PENDING_APPROVAL',actor_user_id=8)
    try: transition_recall(r2,'APPROVED',actor_user_id=8,reason='x')
    except RecallError as e: assert str(e) == 'SELF_APPROVAL_NOT_ALLOWED'
    else: assert False


def test_recall_approval_success():
    r = transition_recall(recall(initiator=8),'PENDING_APPROVAL',actor_user_id=8)
    r = transition_recall(r,'APPROVED',actor_user_id=9,reason='management approved')
    assert r.state == 'APPROVED' and r.approver_user_id == 9


def test_recall_lot_recovery_range():
    validate_recall_lot(RecallLot(1,1,88,1,1,100,50,True))
    try: validate_recall_lot(RecallLot(1,1,88,1,1,100,101,True))
    except RecallError as e: assert str(e) == 'RECOVERED_QTY_OUT_OF_RANGE'
    else: assert False


def test_notified_customer_requires_reference():
    rc=RecallCustomer(1,1,44,1,1,100,0,date(2026,9,5),None)
    try: validate_recall_customer(rc)
    except RecallError as e: assert str(e) == 'COMMUNICATION_REF_REQUIRED'
    else: assert False


def test_recovery_cannot_exceed_dispatched():
    rc=RecallCustomer(1,1,44,1,1,100,101)
    try: validate_recall_customer(rc)
    except RecallError as e: assert str(e) == 'RECOVERED_QTY_EXCEEDS_DISPATCHED'
    else: assert False


def test_effectiveness_check_required_and_close():
    r = recall('EFFECTIVENESS_CHECK')
    chk=EffectivenessCheck(1,1,1,1,date(2026,9,5),95,100,0,True,'adequate recovery')
    out=close_recall(r,[chk])
    assert out.state=='CLOSED' and out.closed_on


def test_failed_effectiveness_blocks_close():
    r=recall('EFFECTIVENESS_CHECK')
    chk=EffectivenessCheck(1,1,1,1,date(2026,9,5),20,100,2,False,'insufficient recovery')
    try: close_recall(r,[chk])
    except RecallError as e: assert str(e)=='RECALL_EFFECTIVENESS_NOT_ACCEPTABLE'
    else: assert False


def test_api_rejects_invalid_transition():
    from app.v60.api import transition
    try: transition({'recall_id':1,'organization_id':1,'site_id':1,'recall_number':'R','reason':'x','severity':'MAJOR','state':'DRAFT','new_state':'CLOSED'})
    except Exception as e: assert 'INVALID_RECALL_TRANSITION' in str(e)
    else: assert False
