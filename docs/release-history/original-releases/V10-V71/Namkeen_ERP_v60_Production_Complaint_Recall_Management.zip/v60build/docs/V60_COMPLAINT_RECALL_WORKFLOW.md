# v60 — Complaint & Recall Management

## Workflow
`Complaint -> Triage -> Investigation -> CAPA/Resolution -> Recall Decision -> Draft -> Approval -> Initiate -> Communicate -> Recover -> Effectiveness Check -> Close`

## Controls
- Organization/site scope is mandatory.
- Complaint states use explicit transitions; no silent state jumps.
- Recall approval requires a different approver from the designated initiator and a reason.
- Affected lots and customers are tracked separately because customer-dispatched quantities may differ from remaining stock.
- Recovered quantity can never exceed affected/dispatched quantity.
- Notified customers require a communication reference.
- Recall effectiveness must be documented before closure.
- Stock blocking is represented as a controlled action; it does not directly mutate the authoritative inventory ledger.
- Credit notes, inventory quarantine/return/disposal and accounting are downstream controlled transactions.
- Recall records are trace-linked to complaint, batch/lot, evidence, CAPA and delivery/customer records through the v59 evidence chain.

## Operational targets
The product supports configurable severity, response windows, communication templates and escalation rules. Legal/regulatory deadlines are data-driven and must be maintained from current official requirements; the ERP does not hard-code a universal statutory response time.

## Recall pack
A recall pack should include recall number/reason, affected products/lots, customer distribution list, communications, stock blocks, recovery quantities, disposition references, complaints/investigations, CAPA, effectiveness checks and evidence hashes.

## Boundary
This module is an operational recall-management and traceability system. It is not itself a legal certification, statutory filing or substitute for responsible food-safety/regulatory review.
