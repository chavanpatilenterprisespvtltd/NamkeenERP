# Namkeen ERP v36 — Accounts, Tax & Supplier Ageing

v36 extends the v35 Purchase-to-Pay foundation into Accounts.

## Added
- Effective-dated, configurable tax profiles
- Intra-state / inter-state tax components
- Tax-inclusive and tax-exclusive calculation
- CGST/SGST/IGST/UTGST/Cess component support
- Separate TDS/TCS configurable deductions
- Debit/Credit supplier adjustment notes
- Supplier payable ageing buckets
- Payment-to-payable bank reconciliation
- Short / over / unmatched reconciliation states
- Accounting posting validation and idempotency schema
- Due-date/ageing data model
- PostgreSQL migration `025_v36_accounts_tax_ageing.sql`
- FastAPI endpoints:
  - `/v36/tax/calculate`
  - `/v36/supplier-ageing`
  - `/v36/payments/reconcile`
- Android Accounts workflow contract

## Controls
Tax rates are never hard-coded. Accounting/tax rules must be configured and reviewed by the customer's authorised Accounts/CA/tax team. TDS/TCS are kept separate from GST. Tax calculation does not itself file a return or guarantee statutory compliance.

Inventory remains controlled by GRN/QC and the inventory ledger. Supplier invoices, notes and payments do not bypass inventory controls.

## Validation
The build reruns all inherited tests plus v36 tests. Live PostgreSQL execution is not claimed unless a PostgreSQL instance is available.

# Namkeen ERP v37 — Sales & Customer Accounts

Added customer-side accounts: customer invoices, receipts/allocation, customer ageing, credit exposure, debit/credit notes, customer ledger, and salesperson incentive basis. Tax determination remains configuration-driven from v36; incentive policy remains management-controlled.
