
from fastapi.testclient import TestClient
import sys, os
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from app.main import app
from app.repository import repo

c=TestClient(app)
h=lambda r: {"X-Role":r}

def setup_customer():
    r=c.post("/customers",headers=h("SALESPERSON"),json={"entity":"Y","name":"ABC SS","mobile":"9999999999","gps_lat":19.1,"gps_lng":73.1})
    assert r.status_code==200
    cid=r.json()["id"]
    assert c.post(f"/customers/{cid}/approve",headers=h("MANAGER")).status_code==200
    return cid

def test_end_to_end_paid_order():
    cid=setup_customer()
    order={"order_id":"SO-V12-1","entity":"Y","customer_id":cid,"salesperson_id":"SP1",
           "lines":[{"sku":"SHEV500","qty":20,"negotiated_price":124,"floor_price":123,"company_cost":115}],
           "payment_mode":"UPI","payment_state":"VERIFIED","credit_state":"CLEAR"}
    r=c.post("/orders",headers=h("SALESPERSON"),json=order)
    assert r.json()["status"]=="READY_FOR_STOCK_CHECK"
    assert c.post("/orders/SO-V12-1/reserve-fefo",headers=h("STORE")).json()["status"]=="STOCK_RESERVED"
    assert c.post("/orders/SO-V12-1/dispatch",headers=h("STORE")).json()["status"]=="DISPATCHED"

def test_cheque_hold_then_clear_then_dispatch():
    cid=setup_customer()
    order={"order_id":"SO-V12-2","entity":"Y","customer_id":cid,"salesperson_id":"SP1",
           "lines":[{"sku":"SHEV500","qty":10,"negotiated_price":125,"floor_price":123,"company_cost":115}],
           "payment_mode":"CHEQUE","payment_state":"PENDING","credit_state":"CLEAR"}
    assert c.post("/orders",headers=h("SALESPERSON"),json=order).json()["status"]=="CHEQUE_HOLD"
    assert c.post("/orders/SO-V12-2/cheque-clear",headers=h("ACCOUNTS")).json()["status"]=="READY_FOR_STOCK_CHECK"
    assert c.post("/orders/SO-V12-2/reserve-fefo",headers=h("STORE")).json()["status"]=="STOCK_RESERVED"

def test_price_exception_needs_management():
    cid=setup_customer()
    order={"order_id":"SO-V12-3","entity":"Y","customer_id":cid,"salesperson_id":"SP1",
           "lines":[{"sku":"SHEV500","qty":5,"negotiated_price":122,"floor_price":123,"company_cost":115}],
           "payment_mode":"UPI","payment_state":"VERIFIED","credit_state":"CLEAR"}
    assert c.post("/orders",headers=h("SALESPERSON"),json=order).json()["status"]=="PRICE_APPROVAL"
    assert c.post("/orders/SO-V12-3/approve",headers=h("MANAGEMENT"),params={"reason":"Commercial negotiation"}).json()["status"]=="READY_FOR_STOCK_CHECK"

def test_stock_shortage_alerts_manager():
    cid=setup_customer()
    order={"order_id":"SO-V12-4","entity":"Y","customer_id":cid,"salesperson_id":"SP1",
           "lines":[{"sku":"SHEV500","qty":1000,"negotiated_price":125,"floor_price":123,"company_cost":115}],
           "payment_mode":"UPI","payment_state":"VERIFIED","credit_state":"CLEAR"}
    assert c.post("/orders",headers=h("SALESPERSON"),json=order).json()["status"]=="READY_FOR_STOCK_CHECK"
    r=c.post("/orders/SO-V12-4/reserve-fefo",headers=h("STORE"))
    assert r.json()["status"]=="STOCK_SHORTAGE"
    assert any(n["code"]=="STOCK_SHORTAGE" for n in repo.notifications)

def test_sensitive_audit_boundary():
    assert c.get("/audit",headers=h("SALESPERSON")).status_code==403
    assert c.get("/audit",headers=h("MANAGEMENT")).status_code==200
