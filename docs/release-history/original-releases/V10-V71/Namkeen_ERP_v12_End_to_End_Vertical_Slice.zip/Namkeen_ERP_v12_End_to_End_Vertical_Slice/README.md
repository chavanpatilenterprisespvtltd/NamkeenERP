# Namkeen ERP v12 — End-to-End Vertical Slice

This is the first complete workflow slice tying UI/API intent to domain services.

Flow:
Customer onboarding → manager approval → salesperson order → price/payment/credit gates
→ stock reservation (FEFO) → dispatch → collection → audit/notifications.

Also covered:
- Cheque hold → Accounts clearance → release.
- Price-floor exception → Management approval.
- Stock shortage → manager notification.
- Sensitive audit access boundary.
- GPS fields in customer onboarding.
- Payment proof field on collection.
- Role-based API access.

Important: this is a vertical-slice development build. The next production step is to replace the repository with the real PostgreSQL transaction repository, add object-storage upload/signing, real authentication, notification workers and full offline device database.
