
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from app.repository import repo
from app.services.vertical_slice import (
    create_customer, approve_customer, create_order, approve_order, verify_payment,
    clear_cheque, reserve_fefo, dispatch, create_collection
)

app=FastAPI(title="Namkeen ERP v12 Vertical Slice",version="12.0")

ROLE_PERMS={
 "SALESPERSON":{"customer.create","order.create","collection.create"},
 "MANAGER":{"customer.approve","order.approve","payment.verify","cheque.clear","dispatch"},
 "MANAGEMENT":{"customer.approve","order.approve","payment.verify","cheque.clear","dispatch"},
 "ACCOUNTS":{"payment.verify","collection.verify","cheque.clear"},
 "STORE":{"dispatch"},
 "SUPER_ADMIN":{"*"},
}
def role(x): return x or "SALESPERSON"
def check(r,p):
    if "*" in ROLE_PERMS.get(r,set()) or p in ROLE_PERMS.get(r,set()): return
    raise HTTPException(403,f"PERMISSION_DENIED:{p}")

class CustomerIn(BaseModel):
    entity:str
    name:str
    mobile:str
    gps_lat:float|None=None
    gps_lng:float|None=None

class Line(BaseModel):
    sku:str
    qty:float
    negotiated_price:float
    floor_price:float
    company_cost:float

class OrderIn(BaseModel):
    order_id:str
    entity:str
    customer_id:str
    salesperson_id:str
    lines:list[Line]
    payment_mode:str
    payment_state:str
    credit_state:str

class CollectionIn(BaseModel):
    customer_id:str
    order_id:str
    amount:float
    mode:str
    proof_file:str|None=None

@app.get("/health")
def health(): return {"status":"ok","version":"12.0"}

@app.post("/customers")
def customer(body:CustomerIn,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"customer.create")
    c=create_customer(body.entity,body.name,body.mobile,body.gps_lat,body.gps_lng,x_role)
    return {"id":c.id,"approved":c.approved}

@app.post("/customers/{customer_id}/approve")
def customer_approve(customer_id:str,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"customer.approve")
    try: c=approve_customer(customer_id,x_role)
    except PermissionError as e: raise HTTPException(403,str(e))
    return {"id":c.id,"approved":c.approved}

@app.post("/orders")
def order(body:OrderIn,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"order.create")
    try:
        o=create_order(**body.model_dump())
        return {"id":o.id,"status":o.status}
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/orders/{order_id}/approve")
def order_approve(order_id:str,x_role:str=Header(default="SALESPERSON"),reason:str|None=None):
    check(x_role,"order.approve")
    try: o=approve_order(order_id,x_role,reason)
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    return {"id":o.id,"status":o.status,"approval_id":o.approval_id}

@app.post("/orders/{order_id}/payment-verify")
def payment_verify(order_id:str,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"payment.verify")
    try: o=verify_payment(order_id,x_role)
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    return {"id":o.id,"status":o.status,"payment_state":o.payment_state}

@app.post("/orders/{order_id}/cheque-clear")
def cheque_clear(order_id:str,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"cheque.clear")
    try: o=clear_cheque(order_id,x_role)
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    return {"id":o.id,"status":o.status,"payment_state":o.payment_state}

@app.post("/orders/{order_id}/reserve-fefo")
def reserve(order_id:str,x_role:str=Header(default="STORE")):
    check(x_role,"dispatch")
    try:o=reserve_fefo(order_id)
    except Exception as e: raise HTTPException(400,str(e))
    return {"id":o.id,"status":o.status,"allocations":o.allocations}

@app.post("/orders/{order_id}/dispatch")
def do_dispatch(order_id:str,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"dispatch")
    try:o=dispatch(order_id,x_role)
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    return {"id":o.id,"status":o.status}

@app.post("/collections")
def collection(body:CollectionIn,x_role:str=Header(default="SALESPERSON")):
    check(x_role,"collection.create")
    try: c=create_collection(**body.model_dump(),actor=x_role)
    except Exception as e: raise HTTPException(400,str(e))
    return {k:(str(v) if hasattr(v,"__class__") and k=="amount" else v) for k,v in c.items()}

@app.get("/notifications")
def notifications(x_role:str=Header(default="MANAGEMENT")):
    return [x for x in repo.notifications if x["role"] in {x_role,"MANAGER","MANAGEMENT"}][-100:]

@app.get("/audit")
def audit(x_role:str=Header(default="SALESPERSON")):
    if x_role not in {"MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise HTTPException(403,"AUDIT_ACCESS_DENIED")
    return repo.audit_events[-200:]
