
from datetime import date, datetime, timezone
from decimal import Decimal
from uuid import uuid4
from app.repository import repo, Customer, Order, OrderLine

MANAGEMENT_ROLES={"MANAGER","MANAGEMENT","SUPER_ADMIN"}

def audit(actor, action, reference_type, reference_id, reason=None, before=None, after=None):
    e={"time":datetime.now(timezone.utc).isoformat(),"actor":actor,"action":action,
       "reference_type":reference_type,"reference_id":reference_id,"reason":reason,
       "before":before,"after":after}
    repo.audit_events.append(e)
    return e

def notify(role, code, reference_id, message):
    repo.notifications.append({"role":role,"code":code,"reference_id":reference_id,"message":message})

def create_customer(entity, name, mobile, gps_lat=None, gps_lng=None, actor="salesperson"):
    cid=f"C-{uuid4().hex[:8].upper()}"
    c=Customer(cid,entity,name,mobile,False)
    repo.customers[cid]=c
    audit(actor,"CUSTOMER_CREATED","CUSTOMER",cid,after={"name":name,"mobile":mobile,"gps_lat":gps_lat,"gps_lng":gps_lng})
    notify("MANAGER","CUSTOMER_APPROVAL_REQUIRED",cid,f"New customer {name} requires approval")
    return c

def approve_customer(customer_id, actor_role):
    if actor_role not in MANAGEMENT_ROLES: raise PermissionError("CUSTOMER_APPROVAL_REQUIRES_MANAGEMENT")
    c=repo.customers[customer_id]
    c.approved=True
    audit(actor_role,"CUSTOMER_APPROVED","CUSTOMER",customer_id)
    return c

def create_order(*, order_id, entity, customer_id, salesperson_id, lines, payment_mode, payment_state, credit_state):
    c=repo.customers[customer_id]
    if not c.approved: raise ValueError("CUSTOMER_NOT_APPROVED")
    exception=False
    parsed=[]
    for x in lines:
        l=OrderLine(x["sku"],Decimal(str(x["qty"])),Decimal(str(x["negotiated_price"])),
                    Decimal(str(x["floor_price"])),Decimal(str(x["company_cost"])))
        if l.negotiated_price < l.floor_price: exception=True
        if l.negotiated_price-l.company_cost < Decimal("0"): exception=True
        parsed.append(l)
    if payment_mode.upper()=="CHEQUE" and payment_state!="CLEARED":
        status="CHEQUE_HOLD"
    elif payment_state!="VERIFIED":
        status="PAYMENT_VERIFICATION"
    elif exception:
        status="PRICE_APPROVAL"
    else:
        status="READY_FOR_STOCK_CHECK"
    order=Order(order_id,entity,customer_id,parsed,payment_mode,payment_state,credit_state,status,salesperson_id,
                override_required=exception)
    repo.orders[order_id]=order
    audit(salesperson_id,"ORDER_CREATED","SALES_ORDER",order_id,
          after={"status":status,"payment_state":payment_state,"credit_state":credit_state})
    if status=="CHEQUE_HOLD": notify("MANAGER","CHEQUE_HOLD",order_id,"Cheque clearance required or management override")
    if status=="PAYMENT_VERIFICATION": notify("ACCOUNTS","PAYMENT_VERIFICATION",order_id,"Payment proof requires verification")
    if status=="PRICE_APPROVAL": notify("MANAGER","PRICE_EXCEPTION",order_id,"Price is below configured floor/margin")
    return order

def approve_order(order_id, actor_role, override_reason=None):
    if actor_role not in MANAGEMENT_ROLES: raise PermissionError("ORDER_APPROVAL_REQUIRES_MANAGEMENT")
    o=repo.orders[order_id]
    before=o.status
    o.status="READY_FOR_STOCK_CHECK"
    o.approval_id=f"APR-{uuid4().hex[:8].upper()}"
    repo.approvals[o.approval_id]={"order_id":order_id,"decision":"APPROVED","actor":actor_role,"reason":override_reason}
    audit(actor_role,"ORDER_APPROVED","SALES_ORDER",order_id,reason=override_reason,before=before,after=o.status)
    return o

def verify_payment(order_id, actor_role):
    if actor_role not in {"ACCOUNTS","MANAGER","MANAGEMENT","SUPER_ADMIN"}:
        raise PermissionError("PAYMENT_VERIFICATION_REQUIRES_ACCOUNTS_OR_MANAGEMENT")
    o=repo.orders[order_id]
    o.payment_state="VERIFIED"
    if o.status in {"PAYMENT_VERIFICATION","CHEQUE_HOLD"}:
        o.status="READY_FOR_STOCK_CHECK" if not o.override_required else "PRICE_APPROVAL"
    audit(actor_role,"PAYMENT_VERIFIED","SALES_ORDER",order_id,after={"payment_state":o.payment_state})
    return o

def clear_cheque(order_id, actor_role):
    if actor_role not in {"ACCOUNTS","MANAGER","MANAGEMENT","SUPER_ADMIN"}:
        raise PermissionError("CHEQUE_CLEARANCE_REQUIRES_ACCOUNTS_OR_MANAGEMENT")
    o=repo.orders[order_id]
    if o.payment_mode.upper()!="CHEQUE": raise ValueError("NOT_A_CHEQUE_ORDER")
    o.payment_state="CLEARED"
    o.status="READY_FOR_STOCK_CHECK" if not o.override_required else "PRICE_APPROVAL"
    audit(actor_role,"CHEQUE_CLEARED","SALES_ORDER",order_id)
    return o

def reserve_fefo(order_id):
    o=repo.orders[order_id]
    if o.status!="READY_FOR_STOCK_CHECK":
        raise ValueError(f"ORDER_NOT_READY:{o.status}")
    allocation=[]
    for line in o.lines:
        remaining=line.qty
        lots=sorted([l for l in repo.lots if l.sku==line.sku and l.qty_available-l.qty_reserved>0],
                    key=lambda l: (l.expiry is None,l.expiry or date.max,l.batch))
        local=[]
        for lot in lots:
            free=lot.qty_available-lot.qty_reserved
            take=min(free,remaining)
            if take>0:
                lot.qty_reserved+=take
                local.append({"sku":line.sku,"batch":lot.batch,"qty":take,"expiry":str(lot.expiry) if lot.expiry else None})
                remaining-=take
            if remaining<=0: break
        if remaining>0:
            # rollback all allocations made by this order
            for a in local:
                for lot in repo.lots:
                    if lot.batch==a["batch"] and lot.sku==a["sku"]:
                        lot.qty_reserved-=a["qty"]
            for a in allocation:
                for lot in repo.lots:
                    if lot.batch==a["batch"] and lot.sku==a["sku"]:
                        lot.qty_reserved-=a["qty"]
            o.status="STOCK_SHORTAGE"
            notify("MANAGER","STOCK_SHORTAGE",order_id,f"Stock shortage for {line.sku}: {remaining}")
            audit("SYSTEM","STOCK_SHORTAGE","SALES_ORDER",order_id,after={"sku":line.sku,"shortage":str(remaining)})
            return o
        allocation.extend(local)
    o.allocations=allocation
    o.status="STOCK_RESERVED"
    audit("SYSTEM","STOCK_RESERVED","SALES_ORDER",order_id,after={"allocations":allocation})
    return o

def dispatch(order_id, actor_role):
    if actor_role not in {"STORE","MANAGER","MANAGEMENT","SUPER_ADMIN"}:
        raise PermissionError("DISPATCH_ROLE_REQUIRED")
    o=repo.orders[order_id]
    if o.status!="STOCK_RESERVED": raise ValueError(f"ORDER_NOT_READY_FOR_DISPATCH:{o.status}")
    for a in o.allocations:
        for lot in repo.lots:
            if lot.sku==a["sku"] and lot.batch==a["batch"]:
                lot.qty_reserved-=a["qty"]
                lot.qty_available-=a["qty"]
    o.status="DISPATCHED"
    audit(actor_role,"DISPATCH_POSTED","SALES_ORDER",order_id,after={"status":o.status})
    return o

def create_collection(customer_id, order_id, amount, mode, proof_file, actor):
    cid=f"PAY-{uuid4().hex[:8].upper()}"
    state="PENDING_ACCOUNTS_VERIFICATION"
    repo.collections[cid]={"id":cid,"customer_id":customer_id,"order_id":order_id,"amount":Decimal(str(amount)),
                           "mode":mode,"proof_file":proof_file,"status":state}
    notify("ACCOUNTS","PAYMENT_VERIFICATION",cid,"Collection proof requires Accounts verification")
    audit(actor,"COLLECTION_CREATED","PAYMENT",cid,after={"order_id":order_id,"amount":str(amount),"mode":mode})
    return repo.collections[cid]
