
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, List, Optional
from datetime import date

@dataclass
class Customer:
    id: str
    entity: str
    name: str
    mobile: str
    approved: bool = False
    credit_limit: Decimal = Decimal("0")
    credit_days: int = 0

@dataclass
class Lot:
    sku: str
    batch: str
    expiry: Optional[date]
    qty_available: Decimal
    qty_reserved: Decimal = Decimal("0")

@dataclass
class OrderLine:
    sku: str
    qty: Decimal
    negotiated_price: Decimal
    floor_price: Decimal
    company_cost: Decimal

@dataclass
class Order:
    id: str
    entity: str
    customer_id: str
    lines: List[OrderLine]
    payment_mode: str
    payment_state: str
    credit_state: str
    status: str
    salesperson_id: str
    override_required: bool = False
    approval_id: Optional[str] = None
    allocations: List[dict] = field(default_factory=list)
    audit: List[dict] = field(default_factory=list)

class Repo:
    def __init__(self):
        self.customers: Dict[str, Customer] = {}
        self.orders: Dict[str, Order] = {}
        self.lots: List[Lot] = [
            Lot("SHEV500","BATCH-EARLY",date(2026,11,1),Decimal("100")),
            Lot("SHEV500","BATCH-LATE",date(2026,12,15),Decimal("100")),
        ]
        self.approvals: Dict[str, dict] = {}
        self.collections: Dict[str, dict] = {}
        self.notifications: List[dict] = []
        self.audit_events: List[dict] = []

repo = Repo()
