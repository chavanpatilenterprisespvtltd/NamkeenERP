# Namkeen ERP v22 — Android Business Workflows

v22 adds the concrete salesperson-facing mobile workflow layer on top of the v21 security and synchronization foundation.

## Included
- Real login API contract with secure access/refresh-token storage
- Salesperson home/navigation shell
- Customer onboarding with GPS evidence hook and shop-photo hook
- Initial 15-product selector with server-master authority
- Dynamic reference pack-size selector: 100 g, 200 g, 250 g, 500 g, 1 kg, 2 kg, 5 kg
- Sales order capture with negotiated price and payment mode
- Collection capture with mandatory counterparty-photo evidence state
- Sales return capture with forced initial QC HOLD
- Sync/conflict center entry point
- Room offline outbox integration
- WorkManager manual sync scheduling
- Camera/location permissions
- Retrofit + kotlinx-serialization API client

## Critical business controls
The mobile client never becomes the authority for:
- pricing floors or margin approval
- credit approval
- payment verification
- stock reservation/dispatch
- return QC disposition or disposal
- accounting posting
- GST/tax interpretation

Those decisions remain server-side.

## Product and pack-size design
The UI contains the 15 initial products for a usable first build, but the architecture keeps product/SKU/pack-size masters server-authoritative and expandable. This is important because future pack sizes and products must not require a new Android build merely to exist in ERP.

## Hardware/evidence
GPS and camera permissions are declared. The production document queue should use actual device URIs and the v21 document-storage provider for encrypted upload; the current UI provides the business workflow hook without pretending a production object-storage service is already deployed.

## Validation
Python regression and v22 static Android contract tests: **39 passed**.

The Android source is a production-oriented client build stage; compile, device testing, API integration testing, and store/MDM deployment remain required before field rollout.
