# Namkeen ERP v42 — Accounting Outbox Worker + Tally Adapter Execution

v42 executes the accounting outbox created by v41 with retry, idempotency, dead-letter handling and reconciliation. External accounting systems are never called inside the core sales DB transaction.

Included:
- Tally XML adapter execution seam
- Idempotent outbound delivery by outbox idempotency key
- `PENDING -> PROCESSING -> POSTED` lifecycle
- Exponential backoff with jitter
- Dead-letter after configurable max attempts
- Reconciliation API
- Manual single-outbox processing API
- PostgreSQL migration `031_v42_accounting_outbox_worker.sql`
- Android Accounts integration contract

This is an integration foundation. Customer-specific TallyPrime endpoint/auth/company/voucher mappings require deployment configuration and UAT.
