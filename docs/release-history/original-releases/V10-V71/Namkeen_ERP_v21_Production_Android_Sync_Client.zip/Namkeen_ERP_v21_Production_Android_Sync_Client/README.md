# Namkeen ERP v21 — Production Domain Integration + Android Offline Skeleton

v20 extends v19 so the remaining operational domains participate in the canonical domain change stream, while adding a concrete Android Room/WorkManager reference skeleton.

## Included
- Customer onboarding + approval/rejection domain events
- Collection capture + deposit + verification domain events
- Sales return + QC disposition domain events
- Production-batch event bridge
- Compliance-task event bridge
- v20 domain-event contract and transaction rules
- PostgreSQL indexing migration `010_v20_domain_integration.sql`
- Android Room entities/DAO/database skeleton
- WorkManager sync worker skeleton
- v20 documentation and tests

## Validation
Run:

```bash
pytest -q
```

This package is an integration/build stage. It is not a claim that a complete Android application or live production deployment already exists.

## v21 additions
- Concrete Android client contract using Retrofit/OkHttp.
- Android Keystore-backed token storage.
- WorkManager connected-network sync contract with retry semantics.
- Explicit conflict-state contract.
- Document/image upload queue abstraction with SHA-256 integrity.
- Device registration and mobile-document PostgreSQL migration `011_v21_mobile_client.sql`.
- Server mobile push/pull/conflict endpoints under `/v21/mobile/*`.
