# Android Offline Architecture

Device local DB:
- drafts
- visits
- orders
- collections
- customer onboarding
- factory entries
- sync_queue

Every write includes:
client_event_id
device_id
user_id
created_at_device
entity_id
location_id
payload_version

Sync:
Local transaction → Sync Queue → API → Server validation → Accepted / Duplicate / Conflict / Rejected → local status update.

Never allow offline mode to permanently bypass:
- payment verification
- price floor exception approvals
- credit approval
- stock allocation
- batch QC release
- disposal approval

The app may capture the transaction offline, but the server must decide the authoritative final state once synchronized.
