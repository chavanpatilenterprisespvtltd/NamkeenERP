# Security Model v11

## Identity and authorization
- Organization/tenant is the top isolation boundary.
- Legal entity and location are scope boundaries.
- Role permissions are explicit.
- High-risk actions require management-authorized roles.
- Never trust a mobile/client supplied role; production role must come from the authenticated server-side identity.

## Sensitive documents
Aadhaar/PAN/payment proof/customer documents are sensitive. Store only metadata in PostgreSQL and files in encrypted object storage. Use expiring signed URLs and strict authorization. Log access.

## Audit
Record user, organization, entity, location, action, reference, timestamp, reason, before/after where relevant.

## Sessions/devices
Production must add short-lived access tokens, refresh-token rotation/revocation, device registration, session logout/revocation, password reset, optional MFA, rate limits and brute-force protection.

## Offline
Every write from a device gets a unique client_event_id. The server is authoritative for price, payment, stock, approval and compliance status. Offline replay must be idempotent and conflicts must be surfaced, not silently overwritten.
