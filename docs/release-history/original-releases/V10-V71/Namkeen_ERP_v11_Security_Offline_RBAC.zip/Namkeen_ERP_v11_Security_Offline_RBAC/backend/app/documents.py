
from dataclasses import dataclass
from pathlib import Path
import hashlib, shutil, uuid

@dataclass
class StoredDocument:
    document_id: str
    path: str
    sha256: str
    size: int

class DocumentStore:
    """
    Development object-store abstraction.
    Production should swap this for encrypted object storage with signed URLs.
    """
    def __init__(self, base_dir:str):
        self.base=Path(base_dir); self.base.mkdir(parents=True,exist_ok=True)

    def save(self, source_path:str) -> StoredDocument:
        src=Path(source_path)
        if not src.exists(): raise FileNotFoundError(source_path)
        doc_id=str(uuid.uuid4())
        dst=self.base/doc_id
        shutil.copy2(src,dst)
        data=dst.read_bytes()
        return StoredDocument(doc_id,str(dst),hashlib.sha256(data).hexdigest(),len(data))
