
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib, hmac, os, base64
import jwt

ROLES = {
    "SUPER_ADMIN": {"*"},
    "MANAGEMENT": {"dashboard.read","approval.decide","pricing.policy","incentive.policy","customer.approve","audit.read","compliance.read","compliance.manage"},
    "MANAGER": {"dashboard.read","approval.decide","customer.approve","audit.read","compliance.read","sales.approval"},
    "ACCOUNTS": {"payment.verify","receivable.read","intercompany.reconcile"},
    "PRODUCTION": {"production.write","batch.write","qc.read"},
    "QC": {"qc.read","qc.release","compliance.write"},
    "STORE": {"inventory.read","inventory.issue","inventory.receive","inventory.reserve"},
    "SALESPERSON": {"sales.order.write","customer.write","collection.write","return.write","visit.write"},
}

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)
    return "$".join(["pbkdf2_sha256","240000",
                     base64.urlsafe_b64encode(salt).decode(),
                     base64.urlsafe_b64encode(dk).decode()])

def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, rounds, salt_b64, digest_b64 = encoded.split("$", 3)
        salt = base64.urlsafe_b64decode(salt_b64)
        expected = base64.urlsafe_b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(rounds))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

def issue_access_token(user_id:int, org_id:int, role:str, secret:str, minutes:int=30) -> str:
    now=datetime.now(timezone.utc)
    payload={"sub":str(user_id),"org_id":org_id,"role":role,"iat":now,
             "exp":now+timedelta(minutes=minutes)}
    return jwt.encode(payload, secret, algorithm="HS256")

def decode_access_token(token:str, secret:str) -> dict:
    return jwt.decode(token, secret, algorithms=["HS256"])

def allowed(role:str, permission:str) -> bool:
    perms=ROLES.get(role, set())
    return "*" in perms or permission in perms

def require_permission(role:str, permission:str):
    if not allowed(role, permission):
        raise PermissionError(f"PERMISSION_DENIED:{permission}")
