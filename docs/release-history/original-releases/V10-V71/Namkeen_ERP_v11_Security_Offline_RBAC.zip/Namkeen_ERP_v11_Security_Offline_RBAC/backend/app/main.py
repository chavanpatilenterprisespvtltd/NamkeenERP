
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field
from decimal import Decimal
from app.security import allowed, require_permission
from app.offline import OfflineQueue
from app.notifications import NotificationWorker
from app.documents import DocumentStore

app=FastAPI(title="Namkeen ERP v11 — Security & Offline",version="11.0")
offline=OfflineQueue("/tmp/namkeen_erp_v11/sync.db")
notifications=NotificationWorker()
documents=DocumentStore("/tmp/namkeen_erp_v11/documents")

DEMO_USERS={
 "management": {"id":1,"org_id":1,"role":"MANAGEMENT"},
 "manager": {"id":2,"org_id":1,"role":"MANAGER"},
 "accounts": {"id":3,"org_id":1,"role":"ACCOUNTS"},
 "store": {"id":4,"org_id":1,"role":"STORE"},
 "sales": {"id":5,"org_id":1,"role":"SALESPERSON"},
}

def actor(x_token:str):
    if x_token not in DEMO_USERS: raise HTTPException(401,"Invalid session")
    return DEMO_USERS[x_token]

def auth(x_token:str, permission:str):
    u=actor(x_token)
    if not allowed(u["role"],permission):
        raise HTTPException(403,f"Permission denied: {permission}")
    return u

class SyncEvent(BaseModel):
    client_event_id: str
    event_type: str
    payload: dict

class PriceCheck(BaseModel):
    cost: Decimal=Field(gt=0)
    floor_price: Decimal=Field(gt=0)
    negotiated_price: Decimal=Field(gt=0)

@app.get("/health")
def health(): return {"status":"ok","version":"11.0"}

@app.get("/secure/dashboard")
def dashboard(x_token:str=Header(default="")):
    u=auth(x_token,"dashboard.read")
    return {"role":u["role"],"dashboard":"allowed"}

@app.post("/secure/approval")
def approval(body:dict,x_token:str=Header(default="")):
    u=auth(x_token,"approval.decide")
    return {"status":"APPROVED","approved_by":u["id"],"reason":body.get("reason")}

@app.post("/secure/payment-verify")
def payment_verify(body:dict,x_token:str=Header(default="")):
    u=auth(x_token,"payment.verify")
    return {"status":"VERIFIED","verified_by":u["id"]}

@app.post("/secure/price-check")
def price_check(body:PriceCheck,x_token:str=Header(default="")):
    u=auth(x_token,"sales.order.write")
    margin=body.negotiated_price-body.cost
    return {"role":u["role"],"margin":str(margin),
            "floor_ok":body.negotiated_price>=body.floor_price,
            "approval_required":body.negotiated_price<body.floor_price}

@app.post("/offline/enqueue")
def enqueue(e:SyncEvent,x_token:str=Header(default="")):
    u=actor(x_token)
    offline.enqueue(e.client_event_id,e.event_type,{**e.payload,"actor_id":u["id"],"role":u["role"]})
    return {"queued":True,"client_event_id":e.client_event_id}

@app.get("/offline/pending")
def pending(x_token:str=Header(default="")):
    actor(x_token)
    return offline.pending()

@app.post("/offline/mark-synced/{client_event_id}")
def mark_synced(client_event_id:str,x_token:str=Header(default="")):
    actor(x_token); offline.mark_synced(client_event_id)
    return {"status":"SYNCED"}

@app.post("/notify")
def notify(body:dict,x_token:str=Header(default="")):
    u=actor(x_token)
    event=body.get("event","GENERAL")
    notifications.publish(event,body.get("recipients",[]),body.get("reference_type",""),body.get("reference_id",""),body.get("message",""))
    return {"queued":True,"created_by":u["id"]}

@app.post("/notify/process-one")
def notify_one(x_token:str=Header(default="")):
    auth(x_token,"dashboard.read")
    ev=notifications.process_one()
    return {"processed":ev is not None, "event": None if ev is None else ev.code}
