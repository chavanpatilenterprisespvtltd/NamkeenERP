
from dataclasses import dataclass
from queue import Queue, Empty
from time import time

@dataclass
class Event:
    code: str
    recipients: list[str]
    reference_type: str
    reference_id: str
    message: str
    created_at: float

class NotificationWorker:
    def __init__(self):
        self.queue=Queue()
        self.sent=[]

    def publish(self, code, recipients, reference_type, reference_id, message):
        self.queue.put(Event(code, recipients, reference_type, reference_id, message, time()))

    def process_one(self):
        try: ev=self.queue.get_nowait()
        except Empty: return None
        # Production: push to in-app, Android push, email/SMS/WhatsApp adapters.
        self.sent.append(ev)
        return ev
