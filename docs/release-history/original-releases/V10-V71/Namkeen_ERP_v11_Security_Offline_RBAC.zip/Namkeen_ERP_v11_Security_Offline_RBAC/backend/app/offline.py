
import sqlite3, json, time
from pathlib import Path

class OfflineQueue:
    def __init__(self, db_path: str):
        self.db_path=db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn=sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("""
          CREATE TABLE IF NOT EXISTS sync_queue(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_event_id TEXT NOT NULL UNIQUE,
            event_type TEXT NOT NULL,
            payload TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING',
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT
          )
        """)
        self.conn.commit()

    def enqueue(self, client_event_id:str, event_type:str, payload:dict):
        self.conn.execute("INSERT OR IGNORE INTO sync_queue(client_event_id,event_type,payload) VALUES(?,?,?)",
                          (client_event_id,event_type,json.dumps(payload)))
        self.conn.commit()

    def pending(self):
        rows=self.conn.execute("SELECT client_event_id,event_type,payload,attempts FROM sync_queue WHERE status='PENDING' ORDER BY id").fetchall()
        return [{"client_event_id":a,"event_type":b,"payload":json.loads(c),"attempts":d} for a,b,c,d in rows]

    def mark_synced(self, client_event_id:str):
        self.conn.execute("UPDATE sync_queue SET status='SYNCED',last_error=NULL WHERE client_event_id=?",(client_event_id,))
        self.conn.commit()

    def mark_failed(self, client_event_id:str, error:str):
        self.conn.execute("UPDATE sync_queue SET status='PENDING',attempts=attempts+1,last_error=? WHERE client_event_id=?",(error,client_event_id))
        self.conn.commit()
