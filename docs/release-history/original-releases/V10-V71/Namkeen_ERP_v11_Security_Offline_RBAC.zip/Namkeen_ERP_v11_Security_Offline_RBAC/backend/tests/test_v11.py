import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient
from app.main import app
from app.security import hash_password, verify_password, allowed

client=TestClient(app)

def h(token): return {"X-Token":token}

def test_health():
    assert client.get("/health").json()["version"]=="11.0"

def test_password_hash():
    enc=hash_password("secret")
    assert verify_password("secret",enc)
    assert not verify_password("bad",enc)

def test_role_permission_boundary():
    assert allowed("SALESPERSON","sales.order.write")
    assert not allowed("SALESPERSON","approval.decide")

def test_dashboard_permission():
    assert client.get("/secure/dashboard",headers=h("management")).status_code==200
    assert client.get("/secure/dashboard",headers=h("sales")).status_code==403

def test_price_floor_preview():
    r=client.post("/secure/price-check",headers=h("sales"),
                  json={"cost":"115","floor_price":"125","negotiated_price":"124"})
    assert r.status_code==200
    assert r.json()["approval_required"] is True

def test_offline_idempotent_enqueue():
    body={"client_event_id":"OFF-1","event_type":"ORDER_CREATE","payload":{"order_id":"SO-1"}}
    assert client.post("/offline/enqueue",headers=h("sales"),json=body).status_code==200
    assert len(client.get("/offline/pending",headers=h("sales")).json())>=1

def test_notification_worker():
    assert client.post("/notify",headers=h("management"),json={
        "event":"LOW_STOCK","recipients":["STORE"],"reference_id":"P1","message":"low"
    }).status_code==200
    assert client.post("/notify/process-one",headers=h("management")).json()["processed"] is True
