# v11 Production Checklist

Before go-live:
[ ] PostgreSQL managed instance configured
[ ] TLS everywhere
[ ] Secrets in secret manager
[ ] JWT/refresh/session policy finalized
[ ] Role/entity/location authorization matrix seeded
[ ] Object storage encryption + signed URLs
[ ] Audit table protected from normal user modification
[ ] DB transactions/row locks/load tests
[ ] Offline conflict resolver
[ ] Notification queue + retries/dead-letter
[ ] Payment/UPI/bank integration
[ ] Tally adapter
[ ] FSSAI/Maharashtra FDA requirement/version seed reviewed
[ ] Backup + restore tested
[ ] Disaster recovery tested
[ ] Penetration/security review
[ ] UAT with factory users and salespersons
[ ] Regulatory/legal review before production release
