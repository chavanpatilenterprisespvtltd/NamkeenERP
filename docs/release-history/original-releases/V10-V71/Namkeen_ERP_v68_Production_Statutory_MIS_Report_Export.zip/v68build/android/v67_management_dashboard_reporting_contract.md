# v67 Android Management Dashboard Contract

Screens:
- Dashboard overview
- Period/entity/warehouse/territory filters
- Sales and gross-margin trend
- Top/bottom SKU, customer and salesperson rankings
- Margin waterfall
- Production-vs-sales reconciliation
- Inventory risk drill-down
- Collection/outstanding drill-down
- Export/share report payload

The mobile view is read-only. Filters are validated by the server and never permit cross-organization/entity reads.
