# v66 Android / API contract

Read-only management MIS screens consume server-calculated metrics:
- management overview
- SKU profitability
- customer profitability
- salesperson performance + incentive basis
- production cost variance
- inventory ageing/expiry
- returns/discounts/collections

No mobile client is allowed to recalculate or post accounting, inventory, incentive, or tax transactions. Filters are server-authorized by organization/entity/role.
