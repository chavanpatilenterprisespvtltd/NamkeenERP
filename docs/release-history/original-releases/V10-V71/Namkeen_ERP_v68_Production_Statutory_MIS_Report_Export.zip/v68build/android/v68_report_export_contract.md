# v68 Android / Web Report Export Contract

## Export formats
- CSV: direct tabular download
- XLSX: generated through the report export adapter
- PDF: print-ready HTML/template rendered by a controlled server/PDF renderer
- JSON: machine-readable integration format

## Security
- Report visibility and export permission are role-controlled server-side.
- Entity/organization filters are server-enforced; client filter values are not trusted as authorization.
- Statutory reports are versioned/effective-dated.
- Export runs record requester, filters, row count, status and output reference.
- Sensitive documents are referenced, not embedded by the report engine unless the role is explicitly authorized.
