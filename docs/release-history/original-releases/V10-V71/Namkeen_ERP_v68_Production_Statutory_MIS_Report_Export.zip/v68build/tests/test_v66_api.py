from src.api_v66 import dashboard_payload
from src.management_mis import SalesRecord, ProductionVariance, InventoryAging


def test_dashboard_payload_has_all_sections():
    rows = [SalesRecord('I','C','S','SKU',10,2000,1200,100,1,120,1000)]
    p = dashboard_payload(
        rows,
        production=[ProductionVariance('B',1000,1100,10,100,10)],
        inventory=[InventoryAging('SKU','L',10,1200,10,20)],
    )
    assert 'kpis' in p and 'sku_profitability' in p
    assert 'customer_profitability' in p
    assert 'salesperson_performance' in p
    assert 'incentive_basis' in p
    assert 'production_variance' in p
    assert 'inventory_aging' in p
