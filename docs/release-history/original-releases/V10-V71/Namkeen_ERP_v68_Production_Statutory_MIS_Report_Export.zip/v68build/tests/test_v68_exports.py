from datetime import date
import pytest
from src.report_export import *
from src.api_v68 import list_reports, report_export

ROWS=[{'invoice_no':'INV-1','invoice_date':date(2026,9,1),'customer_id':'C1','gstin':'27ABCDE1234F1Z5','place_of_supply':'27','supply_type':'B2B','taxable_value':1000,'cgst':90,'sgst':90,'igst':0,'cess':0,'invoice_total':1180,'irn':'IRN1','eway_bill_no':'EWB1'}]

def test_registry_and_role_access():
    assert allowed('ACCOUNTS','gst_sales_register')
    assert not allowed('SALES','gst_sales_register')
    assert any(x['code']=='gst_sales_register' for x in list_reports('ACCOUNTS'))
    with pytest.raises(PermissionError): get_definition('gst_sales_register','SALES')

def test_csv_export_uses_labels_and_values():
    s=export_csv('gst_sales_register','ACCOUNTS',ROWS)
    assert 'Invoice No' in s and 'INV-1' in s and '1180.00' in s

def test_json_export_is_structured():
    s=report_export('customer_ageing','ACCOUNTS',[{'customer_id':'C1','total_outstanding':1200}], 'json')
    assert 'customer_ageing' in s and 'total_outstanding' in s and '1200.00' in s

def test_pdf_ready_export_has_print_css_and_html_table():
    s=report_export('stock_register','WAREHOUSE',[{'txn_date':date(2026,9,1),'warehouse_id':'W1','sku_id':'S1','qty':10}], 'pdf')
    assert '@media print' in s and '<table>' in s

def test_unsupported_format():
    with pytest.raises(ValueError): report_export('stock_register','WAREHOUSE',[], 'xml')

def test_statutory_flags():
    assert ROLE_REPORTS['gst_sales_register'].statutory is True
    assert ROLE_REPORTS['compliance_register'].statutory is False
