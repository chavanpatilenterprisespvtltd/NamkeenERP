import pytest
from src.management_mis import (
    SalesRecord, ProductionVariance, InventoryAging,
    management_kpis, profitability_by_sku, profitability_by_customer,
    profitability_by_salesperson, production_variance,
    inventory_aging_summary, salesperson_incentive_basis,
)


def sample_rows():
    return [
        SalesRecord('I1','C1','SP1','SKU1',100,20000,12000,500,10,1200,12000),
        SalesRecord('I2','C2','SP1','SKU2',50,9000,5500,200,0,0,5000),
        SalesRecord('I3','C1','SP2','SKU1',20,3800,2200,100,5,250,1000),
    ]


def test_management_kpis_accounts_for_returns_and_collections():
    k = management_kpis(sample_rows())
    assert k.sales_taxable == 32800
    assert k.net_sales_after_returns == 29850
    assert k.cogs_after_returns == 18250
    assert k.gross_margin == 11600
    assert k.collection_allocated == 18000
    assert k.outstanding_estimate == 11850
    assert k.return_qty_kg == 15


def test_by_dimensions():
    rows = sample_rows()
    assert set(profitability_by_sku(rows)) == {'SKU1','SKU2'}
    assert profitability_by_customer(rows)['C1']['return_qty_kg'] == 15
    assert profitability_by_salesperson(rows)['SP2']['qty_kg'] == 15


def test_production_variance():
    v = production_variance([
        ProductionVariance('B1',10000,11000,100,-0,10),
        ProductionVariance('B2',5000,4500,50,-0, -10),
    ])
    assert v['standard_cost'] == 15000
    assert v['actual_cost'] == 15500
    assert v['cost_variance'] == 500
    assert v['variance_pct'] == pytest.approx(3.3333)


def test_inventory_aging_and_expiry():
    s = inventory_aging_summary([
        InventoryAging('SKU1','L1',100,12000,95,-2),
        InventoryAging('SKU1','L2',50,6500,120,10),
        InventoryAging('SKU2','L3',25,2500,30,90),
    ])
    assert s['qty_kg'] == 175
    assert s['inventory_value'] == 21000
    assert s['expired_qty_kg'] == 100
    assert s['expiring_soon_qty_kg'] == 50
    assert s['age_90_plus_qty_kg'] == 150


def test_incentive_basis_excludes_returned_quantity():
    basis = salesperson_incentive_basis(sample_rows())
    assert basis['SP1']['eligible_kg'] == 140
    assert basis['SP1']['net_sales_value'] == 27000
    assert basis['SP1']['gross_margin_value'] == 10700
    assert basis['SP1']['collection_allocated'] == 17000
