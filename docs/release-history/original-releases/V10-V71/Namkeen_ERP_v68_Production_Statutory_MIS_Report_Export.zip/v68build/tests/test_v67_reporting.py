from datetime import date
import pytest
from src.mis_reporting import *
from src.api_v67 import dashboard, export_payload

ROWS=[
 MISRow(date(2026,9,1),'E1','W1','T1','SP1','S1','C1',100,20000,12000,500,300,15000,10000),
 MISRow(date(2026,9,2),'E1','W1','T1','SP1','S2','C2',50,9000,5500,0,200,7000,5000),
 MISRow(date(2026,8,31),'E1','W2','T2','SP2','S1','C1',30,6000,3600,500,100,3000,2500),
]

def test_filters_date_entity():
    r=apply_filters(ROWS,MISFilter(start_date=date(2026,9,1),end_date=date(2026,9,30),warehouse_id='W1'))
    assert len(r)==2
    with pytest.raises(ValueError): apply_filters(ROWS,MISFilter(start_date=date(2026,9,2),end_date=date(2026,9,1)))

def test_trend_and_rankings():
    t=trend(ROWS,'day'); assert [x['period'] for x in t]==['2026-08-31','2026-09-01','2026-09-02']
    assert rank(ROWS,'sku_id','gross_margin',2)[0]['key']=='S1'

def test_waterfall():
    w=margin_waterfall(ROWS)
    assert w[0]['value']==36000
    assert w[-1]['value']==13900

def test_production_sales_reconciliation():
    assert production_sales_reconciliation(180,190,10)['status']=='BALANCED'
    assert production_sales_reconciliation(180,170,0)['status']=='VARIANCE'

def test_dashboard_is_read_only_and_scoped():
    d=dashboard(ROWS,MISFilter(entity_id='E1'), 'month')
    assert d['kpis']['net_sales']==35000
    assert len(d['top_skus'])==2
    e=export_payload(ROWS,MISFilter(warehouse_id='W1'))
    assert len(e['rows'])==2
