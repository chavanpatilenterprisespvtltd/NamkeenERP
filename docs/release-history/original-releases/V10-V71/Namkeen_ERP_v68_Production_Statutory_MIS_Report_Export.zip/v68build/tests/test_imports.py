from src import management_mis, api_v66

def test_modules_import():
    assert management_mis and api_v66
