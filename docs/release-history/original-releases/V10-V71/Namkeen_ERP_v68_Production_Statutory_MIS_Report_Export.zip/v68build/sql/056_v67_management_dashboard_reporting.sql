-- v67 read-side reporting structures; no operational writes.
CREATE INDEX IF NOT EXISTS ix_sales_order_date_entity ON sales_order (order_date, entity_id);
CREATE INDEX IF NOT EXISTS ix_sales_order_customer_salesperson ON sales_order (customer_id, salesperson_id);
CREATE INDEX IF NOT EXISTS ix_inventory_lot_expiry_warehouse ON inventory_lot (expiry_date, warehouse_id);
CREATE INDEX IF NOT EXISTS ix_domain_changes_entity_occurred ON domain_changes (entity_id, occurred_at, change_id);

CREATE TABLE IF NOT EXISTS mis_saved_view (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    user_id UUID NOT NULL,
    name VARCHAR(120) NOT NULL,
    filter_json JSONB NOT NULL,
    dashboard_code VARCHAR(80) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_mis_saved_view_user_name ON mis_saved_view (organization_id, user_id, name);
