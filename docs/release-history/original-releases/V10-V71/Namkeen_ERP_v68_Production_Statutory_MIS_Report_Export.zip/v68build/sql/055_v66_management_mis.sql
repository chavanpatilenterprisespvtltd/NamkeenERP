-- v66 Management MIS read-model foundations
CREATE TABLE IF NOT EXISTS mis_snapshot_run (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    entity_id UUID,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    generated_by UUID,
    status VARCHAR(20) NOT NULL DEFAULT 'COMPLETED'
);
CREATE INDEX IF NOT EXISTS ix_mis_snapshot_org_period
  ON mis_snapshot_run (organization_id, entity_id, period_start, period_end);

CREATE TABLE IF NOT EXISTS mis_alert_rule (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    rule_code VARCHAR(80) NOT NULL,
    threshold_numeric NUMERIC(18,4),
    severity VARCHAR(20) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    effective_from DATE NOT NULL,
    effective_to DATE
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_mis_alert_rule_org_code_date
  ON mis_alert_rule (organization_id, rule_code, effective_from);

CREATE TABLE IF NOT EXISTS mis_saved_view (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    user_id UUID,
    name VARCHAR(150) NOT NULL,
    config_json JSONB NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_mis_saved_view_org_user
  ON mis_saved_view (organization_id, user_id);

-- Read-side reporting indexes; source transactions remain authoritative.
CREATE INDEX IF NOT EXISTS ix_sales_invoice_mis_date_entity
  ON sales_invoice (organization_id, entity_id, invoice_date);
CREATE INDEX IF NOT EXISTS ix_sales_invoice_line_mis_sku
  ON sales_invoice_line (organization_id, sku_id);
CREATE INDEX IF NOT EXISTS ix_inventory_lot_mis_expiry
  ON inventory_lot (organization_id, sku_id, expiry_date);
CREATE INDEX IF NOT EXISTS ix_customer_receivable_mis_due
  ON customer_receivable (organization_id, due_date, status);
