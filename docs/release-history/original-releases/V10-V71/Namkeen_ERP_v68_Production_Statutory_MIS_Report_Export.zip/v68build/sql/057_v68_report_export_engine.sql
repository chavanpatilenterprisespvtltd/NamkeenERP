-- v68 Report Export Engine metadata (read/reporting layer only)
CREATE TABLE IF NOT EXISTS report_definition (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NULL,
  report_code TEXT NOT NULL,
  report_name TEXT NOT NULL,
  statutory BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  version_no INTEGER NOT NULL DEFAULT 1,
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE NULL,
  allowed_formats TEXT[] NOT NULL DEFAULT ARRAY['csv','xlsx','pdf'],
  UNIQUE (organization_id, report_code, version_no)
);

CREATE TABLE IF NOT EXISTS report_role_access (
  report_definition_id BIGINT NOT NULL REFERENCES report_definition(id) ON DELETE CASCADE,
  role_code TEXT NOT NULL,
  can_view BOOLEAN NOT NULL DEFAULT TRUE,
  can_export BOOLEAN NOT NULL DEFAULT TRUE,
  PRIMARY KEY (report_definition_id, role_code)
);

CREATE TABLE IF NOT EXISTS report_export_run (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NULL,
  report_code TEXT NOT NULL,
  format_code TEXT NOT NULL,
  requested_by BIGINT NULL,
  filter_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  row_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'REQUESTED',
  output_ref TEXT NULL,
  error_code TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ NULL,
  CHECK (format_code IN ('csv','xlsx','pdf','json'))
);
CREATE INDEX IF NOT EXISTS ix_report_export_run_org_time ON report_export_run(organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_report_export_run_status ON report_export_run(status);
