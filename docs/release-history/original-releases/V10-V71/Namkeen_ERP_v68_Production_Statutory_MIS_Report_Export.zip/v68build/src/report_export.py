from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence
import csv, io, json, html

@dataclass(frozen=True)
class ReportColumn:
    key: str
    label: str
    data_type: str = 'text'

@dataclass(frozen=True)
class ReportDefinition:
    code: str
    name: str
    description: str
    columns: Sequence[ReportColumn]
    allowed_roles: Sequence[str]
    formats: Sequence[str] = ('csv','xlsx','pdf')
    statutory: bool = False

ROLE_REPORTS: Dict[str, ReportDefinition] = {}

def _cols(*items):
    return tuple(ReportColumn(*x) for x in items)

def _register(d: ReportDefinition):
    ROLE_REPORTS[d.code] = d
    return d

_register(ReportDefinition('gst_sales_register','GST Sales Register','Sales invoice register with tax breakup and supply classification.',_cols(
    ('invoice_no','Invoice No'),('invoice_date','Invoice Date','date'),('customer_id','Customer'),('gstin','GSTIN'),('place_of_supply','Place of Supply'),('supply_type','Supply Type'),('taxable_value','Taxable Value','money'),('cgst','CGST','money'),('sgst','SGST','money'),('igst','IGST','money'),('cess','Cess','money'),('invoice_total','Invoice Total','money'),('irn','IRN'),('eway_bill_no','E-Way Bill')
),('ACCOUNTS','MANAGEMENT'),statutory=True))
_register(ReportDefinition('gst_purchase_register','GST Purchase Register','Purchase invoice register with accepted GRN linkage and tax breakup.',_cols(
    ('supplier_invoice_no','Supplier Invoice No'),('invoice_date','Invoice Date','date'),('supplier_id','Supplier'),('gstin','GSTIN'),('place_of_supply','Place of Supply'),('taxable_value','Taxable Value','money'),('cgst','CGST','money'),('sgst','SGST','money'),('igst','IGST','money'),('cess','Cess','money'),('invoice_total','Invoice Total','money'),('grn_no','GRN'),('qc_status','QC Status')
),('ACCOUNTS','MANAGEMENT'),statutory=True))
_register(ReportDefinition('stock_register','Stock Register','Inventory movement register by lot, warehouse and UOM.',_cols(
    ('txn_date','Date','date'),('warehouse_id','Warehouse'),('sku_id','SKU'),('lot_no','Lot'),('movement_type','Movement'),('qty','Quantity','number'),('uom','UOM'),('qty_kg','Quantity Kg','number'),('balance_kg','Balance Kg','number'),('reference_no','Reference')
),('WAREHOUSE','FACTORY','QC','ACCOUNTS','MANAGEMENT')))
_register(ReportDefinition('production_register','Production Register','Production batch output, rejects, WIP and yield register.',_cols(
    ('batch_no','Batch No'),('production_date','Date','date'),('sku_id','SKU'),('planned_qty_kg','Planned Kg','number'),('good_qty_kg','Good Kg','number'),('reject_qty_kg','Reject Kg','number'),('wip_qty_kg','WIP Kg','number'),('yield_pct','Yield %','percent'),('qc_status','QC Status'),('cost_per_kg','Actual Cost/Kg','money')
),('FACTORY','QC','ACCOUNTS','MANAGEMENT')))
_register(ReportDefinition('batch_traceability','Batch Traceability Report','Upstream-to-downstream lot and transaction trace.',_cols(
    ('fg_lot','FG Lot'),('batch_no','Production Batch'),('rm_lot','RM Lot'),('packing_run','Packing Run'),('sku_id','SKU'),('expiry_date','Expiry','date'),('lpn','LPN'),('dispatch_ref','Dispatch'),('customer_id','Customer'),('return_ref','Return')
),('FACTORY','QC','WAREHOUSE','MANAGEMENT','ACCOUNTS')))
_register(ReportDefinition('customer_ageing','Customer Ageing','Customer receivable ageing with current and overdue buckets.',_cols(
    ('customer_id','Customer'),('current','Current','money'),('d1_30','1-30','money'),('d31_60','31-60','money'),('d61_90','61-90','money'),('d91_120','91-120','money'),('d120_plus','120+','money'),('total_outstanding','Total','money'),('credit_limit','Credit Limit','money'),('available_credit','Available Credit','money'),('status','Credit Status')
),('ACCOUNTS','MANAGEMENT','SALES_MANAGER')))
_register(ReportDefinition('supplier_ageing','Supplier Ageing','Supplier payable ageing and due amounts.',_cols(
    ('supplier_id','Supplier'),('current','Current','money'),('d1_30','1-30','money'),('d31_60','31-60','money'),('d61_90','61-90','money'),('d91_120','91-120','money'),('d120_plus','120+','money'),('total_payable','Total','money'),('due_amount','Due','money')
),('ACCOUNTS','MANAGEMENT')))
_register(ReportDefinition('profitability','Profitability Report','SKU/customer/salesperson profitability from posted sales and settled cost.',_cols(
    ('dimension','Dimension'),('dimension_id','ID'),('qty_kg','Qty Kg','number'),('net_sales','Net Sales','money'),('cogs','COGS','money'),('gross_margin','Gross Margin','money'),('gross_margin_pct','Margin %','percent'),('discount','Discount','money'),('returns_value','Returns','money'),('collections','Collections','money')
),('MANAGEMENT','ACCOUNTS','SALES_MANAGER')))
_register(ReportDefinition('audit_register','Audit Register','Immutable business/audit event register for authorized review.',_cols(
    ('event_time','Time','datetime'),('actor_id','Actor'),('role','Role'),('entity_id','Entity'),('action','Action'),('object_type','Object'),('object_id','Object ID'),('client_event_id','Client Event'),('ip_or_device','IP/Device'),('result','Result')
),('MANAGEMENT','ACCOUNTS','QC','FACTORY')))
_register(ReportDefinition('compliance_register','Compliance Register','Site compliance tasks, evidence, findings and CAPA status.',_cols(
    ('site_id','Site'),('requirement_code','Requirement'),('classification','Classification'),('task_due','Due','date'),('status','Status'),('evidence_ref','Evidence'),('finding_severity','Finding Severity'),('capa_status','CAPA Status'),('source_url','Official Source')
),('QC','FACTORY','MANAGEMENT'),statutory=False))


def allowed(role: str, report_code: str) -> bool:
    d = ROLE_REPORTS.get(report_code)
    return bool(d and role.upper() in {r.upper() for r in d.allowed_roles})


def get_definition(report_code: str, role: str) -> ReportDefinition:
    d = ROLE_REPORTS.get(report_code)
    if not d or not allowed(role, report_code):
        raise PermissionError('REPORT_ACCESS_DENIED')
    return d


def _fmt_value(v: Any, data_type: str) -> Any:
    if v is None:
        return ''
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    if data_type == 'money':
        return f'{float(v):.2f}'
    if data_type == 'percent':
        return f'{float(v):.4f}'
    return v


def normalize_rows(defn: ReportDefinition, rows: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    out=[]
    for row in rows:
        out.append({c.key: _fmt_value(row.get(c.key), c.data_type) for c in defn.columns})
    return out


def export_csv(report_code: str, role: str, rows: Iterable[Mapping[str, Any]]) -> str:
    d=get_definition(report_code, role); data=normalize_rows(d, rows)
    buf=io.StringIO(); w=csv.writer(buf); w.writerow([c.label for c in d.columns])
    for row in data: w.writerow([row[c.key] for c in d.columns])
    return buf.getvalue()


def export_json(report_code: str, role: str, rows: Iterable[Mapping[str, Any]]) -> str:
    d=get_definition(report_code, role)
    return json.dumps({'report_code':d.code,'name':d.name,'generated_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'columns':[c.__dict__ for c in d.columns],'rows':normalize_rows(d,rows)}, ensure_ascii=False)


def export_pdf_ready_html(report_code: str, role: str, rows: Iterable[Mapping[str, Any]], title: Optional[str]=None) -> str:
    d=get_definition(report_code, role); data=normalize_rows(d,rows); title=title or d.name
    head=''.join(f'<th>{html.escape(c.label)}</th>' for c in d.columns)
    body=''.join('<tr>'+''.join(f'<td>{html.escape(str(row[c.key]))}</td>' for c in d.columns)+'</tr>' for row in data)
    return f'''<!doctype html><html><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>body{{font-family:Arial,sans-serif;font-size:10px}}h1{{font-size:16px}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #999;padding:4px;text-align:left}}th{{background:#eee}}@media print{{@page{{size:A4 landscape;margin:10mm}}}}</style></head><body><h1>{html.escape(title)}</h1><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></body></html>'''


def export_xlsx_artifact(report_code: str, role: str, rows: Iterable[Mapping[str, Any]], path: str) -> str:
    """Optional XLSX adapter using artifact_tool; keeps file generation out of core reporting logic."""
    d=get_definition(report_code, role); data=normalize_rows(d,rows)
    from artifact_tool import Workbook, SpreadsheetFile
    wb=Workbook.create(); sh=wb.worksheets.add(d.code[:31])
    matrix=[[c.label for c in d.columns]]+[[row[c.key] for c in d.columns] for row in data]
    sh.get_range_by_indexes(0,0,len(matrix),len(d.columns)).values=matrix
    sh.get_range_by_indexes(0,0,1,len(d.columns)).format={'font':{'bold':True},'wrap_text':True}
    sh.get_range_by_indexes(0,0,len(matrix),len(d.columns)).format.autofit_columns()
    sh.freeze_panes.freeze_rows(1)
    SpreadsheetFile.export_xlsx(wb).save(path)
    return path
