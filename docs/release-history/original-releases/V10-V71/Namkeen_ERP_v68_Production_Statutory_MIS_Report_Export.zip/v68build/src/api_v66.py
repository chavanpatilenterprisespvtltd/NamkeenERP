from typing import Iterable
from .management_mis import *


def dashboard_payload(records: Iterable[SalesRecord], production=None, inventory=None):
    rows = list(records)
    result = {'kpis': management_kpis(rows).__dict__}
    result['sku_profitability'] = profitability_by_sku(rows)
    result['customer_profitability'] = profitability_by_customer(rows)
    result['salesperson_performance'] = profitability_by_salesperson(rows)
    result['incentive_basis'] = salesperson_incentive_basis(rows)
    if production is not None:
        result['production_variance'] = production_variance(production)
    if inventory is not None:
        result['inventory_aging'] = inventory_aging_summary(inventory)
    return result
