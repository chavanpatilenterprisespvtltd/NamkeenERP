from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional


@dataclass(frozen=True)
class SalesRecord:
    invoice_id: str
    customer_id: str
    salesperson_id: Optional[str]
    sku_id: str
    qty_kg: float
    taxable_value: float
    cogs: float
    discount: float = 0.0
    returned_qty_kg: float = 0.0
    returned_cogs: float = 0.0
    collection_allocated: float = 0.0


@dataclass(frozen=True)
class ProductionVariance:
    batch_id: str
    standard_cost: float
    actual_cost: float
    good_kg: float
    cost_variance: float
    variance_pct: float


@dataclass(frozen=True)
class InventoryAging:
    sku_id: str
    lot_id: str
    qty_kg: float
    inventory_value: float
    age_days: int
    days_to_expiry: Optional[int]


@dataclass(frozen=True)
class ManagementKPI:
    sales_taxable: float
    net_sales_after_returns: float
    cogs_after_returns: float
    gross_margin: float
    gross_margin_pct: float
    discount_value: float
    return_qty_kg: float
    collection_allocated: float
    outstanding_estimate: float
    qty_kg: float


def _money(x: float) -> float:
    return round(x, 2)


def _pct(num: float, den: float) -> float:
    return round((num / den) * 100, 4) if den else 0.0


def management_kpis(records: Iterable[SalesRecord]) -> ManagementKPI:
    rows = list(records)
    sales = _money(sum(r.taxable_value for r in rows))
    cogs = _money(sum(r.cogs for r in rows))
    returns_value = _money(sum((r.returned_qty_kg / r.qty_kg) * r.taxable_value for r in rows if r.qty_kg > 0))
    returned_cogs = _money(sum(r.returned_cogs for r in rows))
    net_sales = _money(sales - returns_value)
    net_cogs = _money(cogs - returned_cogs)
    gross = _money(net_sales - net_cogs)
    collected = _money(sum(r.collection_allocated for r in rows))
    outstanding = _money(max(net_sales - collected, 0.0))
    return ManagementKPI(
        sales_taxable=sales,
        net_sales_after_returns=net_sales,
        cogs_after_returns=net_cogs,
        gross_margin=gross,
        gross_margin_pct=_pct(gross, net_sales),
        discount_value=_money(sum(r.discount for r in rows)),
        return_qty_kg=round(sum(r.returned_qty_kg for r in rows), 6),
        collection_allocated=collected,
        outstanding_estimate=outstanding,
        qty_kg=round(sum(r.qty_kg - r.returned_qty_kg for r in rows), 6),
    )


def profitability_by_sku(records: Iterable[SalesRecord]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, List[SalesRecord]] = {}
    for row in records:
        out.setdefault(row.sku_id, []).append(row)
    return {sku: management_kpis(rows).__dict__ for sku, rows in out.items()}


def profitability_by_customer(records: Iterable[SalesRecord]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, List[SalesRecord]] = {}
    for row in records:
        out.setdefault(row.customer_id, []).append(row)
    return {customer: management_kpis(rows).__dict__ for customer, rows in out.items()}


def profitability_by_salesperson(records: Iterable[SalesRecord]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, List[SalesRecord]] = {}
    for row in records:
        if row.salesperson_id:
            out.setdefault(row.salesperson_id, []).append(row)
    return {sp: management_kpis(rows).__dict__ for sp, rows in out.items()}


def production_variance(batch_costs: Iterable[ProductionVariance]) -> Dict[str, float]:
    rows = list(batch_costs)
    standard = _money(sum(max(x.standard_cost, 0.0) for x in rows))
    actual = _money(sum(max(x.actual_cost, 0.0) for x in rows))
    variance = _money(actual - standard)
    return {
        'standard_cost': standard,
        'actual_cost': actual,
        'cost_variance': variance,
        'variance_pct': _pct(variance, standard),
        'good_kg': round(sum(x.good_kg for x in rows), 6),
    }


def inventory_aging_summary(rows: Iterable[InventoryAging], expiry_warning_days: int = 30) -> Dict[str, float]:
    data = list(rows)
    if expiry_warning_days < 0:
        raise ValueError('INVALID_EXPIRY_WARNING_DAYS')
    return {
        'qty_kg': round(sum(x.qty_kg for x in data), 6),
        'inventory_value': _money(sum(x.inventory_value for x in data)),
        'expired_qty_kg': round(sum(x.qty_kg for x in data if x.days_to_expiry is not None and x.days_to_expiry < 0), 6),
        'expiring_soon_qty_kg': round(sum(x.qty_kg for x in data if x.days_to_expiry is not None and 0 <= x.days_to_expiry <= expiry_warning_days), 6),
        'age_90_plus_qty_kg': round(sum(x.qty_kg for x in data if x.age_days >= 90), 6),
    }


def salesperson_incentive_basis(records: Iterable[SalesRecord]) -> Dict[str, Dict[str, float]]:
    rows = [r for r in records if r.salesperson_id]
    out: Dict[str, Dict[str, float]] = {}
    for sp in sorted({r.salesperson_id for r in rows}):
        data = [r for r in rows if r.salesperson_id == sp]
        k = management_kpis(data)
        out[sp] = {
            'eligible_kg': k.qty_kg,
            'net_sales_value': k.net_sales_after_returns,
            'gross_margin_value': k.gross_margin,
            'collection_allocated': k.collection_allocated,
        }
    return out
