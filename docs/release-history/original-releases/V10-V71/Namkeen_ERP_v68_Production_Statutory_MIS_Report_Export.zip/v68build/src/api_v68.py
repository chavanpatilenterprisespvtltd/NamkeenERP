from typing import Iterable, Mapping, Any
from .report_export import ROLE_REPORTS, allowed, get_definition, export_csv, export_json, export_pdf_ready_html

def list_reports(role: str):
    r=role.upper()
    return [{'code':d.code,'name':d.name,'statutory':d.statutory,'formats':list(d.formats)} for d in ROLE_REPORTS.values() if r in {x.upper() for x in d.allowed_roles}]

def report_export(report_code: str, role: str, rows: Iterable[Mapping[str,Any]], fmt: str='csv'):
    get_definition(report_code,role)
    fmt=fmt.lower()
    if fmt=='csv': return export_csv(report_code,role,rows)
    if fmt=='json': return export_json(report_code,role,rows)
    if fmt=='pdf': return export_pdf_ready_html(report_code,role,rows)
    if fmt=='xlsx': return {'adapter':'artifact_tool','report_code':report_code,'status':'AVAILABLE'}
    raise ValueError('UNSUPPORTED_EXPORT_FORMAT')
