from typing import Iterable
from .mis_reporting import MISRow, MISFilter, apply_filters, kpis, trend, rank, margin_waterfall, production_sales_reconciliation, export_rows


def dashboard(rows: Iterable[MISRow], filters: MISFilter = MISFilter(), trend_grain: str='month'):
    filtered=apply_filters(rows, filters)
    return {'filters':filters.__dict__,'kpis':kpis(filtered),'trend':trend(filtered,trend_grain),'top_skus':rank(filtered,'sku_id','gross_margin'),'top_customers':rank(filtered,'customer_id','net_sales'),'salespersons':rank(filtered,'salesperson_id','collections'),'margin_waterfall':margin_waterfall(filtered)}


def export_payload(rows: Iterable[MISRow], filters: MISFilter = MISFilter()):
    filtered=apply_filters(rows,filters)
    return {'rows':export_rows(filtered),'kpis':kpis(filtered)}
