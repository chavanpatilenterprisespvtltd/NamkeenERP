from dataclasses import dataclass
from datetime import date, datetime
from typing import Iterable, Optional, Sequence, Dict, List, Any

@dataclass(frozen=True)
class MISRow:
    txn_date: date
    entity_id: str
    warehouse_id: Optional[str]
    territory_id: Optional[str]
    salesperson_id: Optional[str]
    sku_id: Optional[str]
    customer_id: Optional[str]
    qty_kg: float
    net_sales: float
    cogs: float
    returns_value: float = 0.0
    discount: float = 0.0
    collections: float = 0.0
    inventory_value: float = 0.0

@dataclass(frozen=True)
class MISFilter:
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    entity_id: Optional[str] = None
    warehouse_id: Optional[str] = None
    territory_id: Optional[str] = None
    salesperson_id: Optional[str] = None
    sku_id: Optional[str] = None
    customer_id: Optional[str] = None


def apply_filters(rows: Iterable[MISRow], f: MISFilter = MISFilter()) -> List[MISRow]:
    if f.start_date and f.end_date and f.start_date > f.end_date:
        raise ValueError('INVALID_DATE_RANGE')
    out = []
    for r in rows:
        if f.start_date and r.txn_date < f.start_date: continue
        if f.end_date and r.txn_date > f.end_date: continue
        for attr in ('entity_id','warehouse_id','territory_id','salesperson_id','sku_id','customer_id'):
            val = getattr(f, attr)
            if val is not None and getattr(r, attr) != val:
                break
        else:
            out.append(r)
    return out


def _money(x: float) -> float: return round(x, 2)

def _pct(n: float, d: float) -> float: return round(n * 100.0 / d, 4) if d else 0.0


def kpis(rows: Iterable[MISRow]) -> Dict[str, float]:
    rs = list(rows)
    gross = sum(r.net_sales - r.cogs for r in rs)
    return {
        'qty_kg': round(sum(r.qty_kg for r in rs), 6),
        'net_sales': _money(sum(r.net_sales for r in rs)),
        'cogs': _money(sum(r.cogs for r in rs)),
        'gross_margin': _money(gross),
        'gross_margin_pct': _pct(gross, sum(r.net_sales for r in rs)),
        'returns_value': _money(sum(r.returns_value for r in rs)),
        'discount': _money(sum(r.discount for r in rs)),
        'collections': _money(sum(r.collections for r in rs)),
        'outstanding_estimate': _money(max(sum(r.net_sales for r in rs) - sum(r.collections for r in rs), 0.0)),
    }


def trend(rows: Iterable[MISRow], grain: str = 'month') -> List[Dict[str, Any]]:
    if grain not in {'day','month'}: raise ValueError('INVALID_TREND_GRAIN')
    buckets: Dict[str, List[MISRow]] = {}
    for r in rows:
        key = r.txn_date.isoformat() if grain == 'day' else f'{r.txn_date.year:04d}-{r.txn_date.month:02d}'
        buckets.setdefault(key, []).append(r)
    return [{'period': k, **kpis(buckets[k])} for k in sorted(buckets)]


def rank(rows: Iterable[MISRow], dimension: str, metric: str = 'gross_margin', limit: int = 10, descending: bool = True) -> List[Dict[str, Any]]:
    if dimension not in {'sku_id','customer_id','salesperson_id','territory_id','warehouse_id'}:
        raise ValueError('INVALID_RANK_DIMENSION')
    if metric not in {'net_sales','gross_margin','qty_kg','collections','outstanding_estimate'}:
        raise ValueError('INVALID_RANK_METRIC')
    groups: Dict[str, List[MISRow]] = {}
    for r in rows:
        key = getattr(r, dimension)
        if key is not None: groups.setdefault(key, []).append(r)
    items=[]
    for key, rs in groups.items():
        p=kpis(rs); items.append({'key': key, **p})
    items.sort(key=lambda x: x[metric], reverse=descending)
    return items[:max(1, limit)]


def margin_waterfall(rows: Iterable[MISRow]) -> List[Dict[str, float]]:
    rs=list(rows)
    gross_sales=_money(sum(r.net_sales + r.returns_value for r in rs))
    returns=_money(sum(r.returns_value for r in rs))
    discounts=_money(sum(r.discount for r in rs))
    net_sales=_money(sum(r.net_sales for r in rs))
    cogs=_money(sum(r.cogs for r in rs))
    gross_margin=_money(net_sales-cogs)
    return [
        {'label':'Gross Sales', 'value':gross_sales},
        {'label':'Returns', 'value':-returns},
        {'label':'Discounts', 'value':-discounts},
        {'label':'Net Sales', 'value':net_sales},
        {'label':'COGS', 'value':-cogs},
        {'label':'Gross Margin', 'value':gross_margin},
    ]


def production_sales_reconciliation(production_output_kg: float, sold_qty_kg: float, returned_qty_kg: float, fg_adjustment_kg: float = 0.0) -> Dict[str, float]:
    available = production_output_kg + fg_adjustment_kg
    net_sold = sold_qty_kg - returned_qty_kg
    residual = round(available - net_sold, 6)
    return {'production_output_kg':round(production_output_kg,6),'fg_adjustment_kg':round(fg_adjustment_kg,6),'net_sold_kg':round(net_sold,6),'residual_kg':residual,'status':'BALANCED' if abs(residual)<0.000001 else 'VARIANCE'}


def export_rows(rows: Iterable[MISRow]) -> List[Dict[str, Any]]:
    return [
        {'date':r.txn_date.isoformat(),'entity_id':r.entity_id,'warehouse_id':r.warehouse_id,'territory_id':r.territory_id,'salesperson_id':r.salesperson_id,'sku_id':r.sku_id,'customer_id':r.customer_id,'qty_kg':r.qty_kg,'net_sales':r.net_sales,'cogs':r.cogs,'returns_value':r.returns_value,'discount':r.discount,'collections':r.collections,'inventory_value':r.inventory_value}
        for r in rows
    ]
