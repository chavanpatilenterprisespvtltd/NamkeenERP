# Namkeen ERP v68 — Statutory/MIS Report Export Engine

v68 turns the v67 read-side management reporting layer into a controlled report catalog and export engine.

## Included report definitions
- GST Sales Register
- GST Purchase Register
- Stock Register
- Production Register
- Batch Traceability Report
- Customer Ageing
- Supplier Ageing
- Profitability Report
- Audit Register
- Compliance Register

## Formats
- CSV export
- JSON machine-readable export
- XLSX adapter using artifact_tool
- PDF-ready HTML with print CSS

## Access control
Each report declares permitted roles. The server must additionally enforce organization/entity/warehouse/territory scope from the authenticated principal.

## Versioning and audit
Report definitions are effective-dated. Export requests are stored with filters, row count, status, requester and output reference. The reporting layer is read-only and must never mutate operational transactions.

## Statutory boundary
GST/compliance reports are support/registration outputs, not a claim that the ERP alone satisfies every filing requirement. Final filing and statutory interpretation remain with the authorized Accounts/CA/compliance team.

## Validation
v68 focused tests cover role access, CSV/JSON/PDF-ready export, format rejection and statutory classification. Live PostgreSQL/actual statutory portal reconciliation remains deployment/UAT work.
