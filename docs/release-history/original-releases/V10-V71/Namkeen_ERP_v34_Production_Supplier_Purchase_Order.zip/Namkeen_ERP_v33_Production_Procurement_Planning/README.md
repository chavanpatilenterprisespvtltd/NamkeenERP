# Namkeen ERP v34 — Supplier Management + Purchase Order Workflow

v34 extends v33 procurement planning into controlled supplier and purchasing operations.

## Core capabilities
- Supplier master with GSTIN/PAN, contacts, payment terms and status
- Supplier quotations with validity, SKU price, MOQ, lead time and order multiple
- Effective-dated supplier rate history
- Supplier performance metrics: on-time %, fill rate %, acceptance %
- Purchase Order lifecycle: DRAFT -> PENDING_APPROVAL -> APPROVED -> PARTIALLY_RECEIVED -> FULLY_RECEIVED -> CLOSED
- Separate CANCELLED exception state
- Approval control with self-approval prevention in the service layer
- Price-variance guard against configured expected price/tolerance
- Partial GRN / receipt recording
- Received vs accepted vs rejected quantity tracking
- Open-PO quantity protection
- Incoming QC remains separate and authoritative for inventory release
- PostgreSQL migration `023_v34_supplier_purchase_orders.sql`
- Android supplier + purchase-order workflow contract

## Control boundary
v34 does not automatically create a PO merely from a v33 suggestion. PO approval is explicit. A GRN does not directly make stock saleable; the existing incoming-QC and inventory-posting services remain authoritative.

## Validation
Inherited v13-v33 suite plus v34 tests: **100 passed**.
Python compile validation passed.
21 non-blocking inherited warnings remain (JWT key-length and existing datetime/SQLAlchemy deprecation warnings).

A live PostgreSQL instance was not available in this build environment; migration execution remains part of deployment/UAT.
