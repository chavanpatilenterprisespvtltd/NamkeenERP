# Namkeen ERP v52 — MRP + Production Orders

v51 recipe/BOM planning is now connected to demand/inventory positions and approval-controlled production orders.

Added: MRP explosion, available/reserved/open-PO/open-production offsetting, net make/buy shortfall, production-order lifecycle, self-approval protection, PostgreSQL migration 041, API contracts, Android workflow contract.
