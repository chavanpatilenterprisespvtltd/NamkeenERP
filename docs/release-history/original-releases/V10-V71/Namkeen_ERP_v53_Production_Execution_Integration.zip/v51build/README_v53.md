# Namkeen ERP v53 — Production Execution Integration

v53 connects the approved v52 Production Order to controlled manufacturing execution: lot-level reservation, actual material issue, in-process execution, good/reject/WIP output, production-batch completion, domain events and downstream costing/traceability.

## Flow

**MRP Demand → BOM → Production Order → Release → Execution → Lot Reservation → Material Issue → In-Process → Output → Completed Batch → v26 WIP/Packing → v50 Actual Costing**

## Controls

- RELEASED/IN_PROGRESS production-order gate.
- Every planned component must be covered by explicit lot reservations before reservation is accepted.
- FEFO selection remains the inventory-service responsibility; v53 accepts explicit lot allocations so the same rule can be enforced centrally.
- Actual issue cannot exceed the reserved quantity in this stage.
- Stock and reservation quantities are locked before mutation.
- Good + reject + WIP output cannot exceed actual input.
- Completion requires a valid production batch.
- Inventory ledger entries and domain events are recorded in the same database transaction as the execution mutation.
- Historical v50 costing is not rewritten; actual issue records are the source for cost roll-up.
- v26 WIP/packing remains downstream and can consume the completed production output.

## Database

Migration: `042_v53_production_execution_integration.sql`

ORM: `app/db/models_v53.py` plus `app/db/models_v52.py` for the v52 Production Order table used by the execution FK.

## Validation

**232 tests passed, 58 non-blocking warnings.**

Python compilation: PASS.

Live PostgreSQL deployment/UAT is still required before production use.
