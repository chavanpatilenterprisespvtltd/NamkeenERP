# v53 — Production Execution Integration

v52 created an approved/released Production Order from MRP. v53 is the execution bridge that turns that plan into controlled material reservation/issue and actual output, feeding the existing v26 traceability and v50 costing layers.

Flow:

**Production Order (RELEASED) → Material Plan → FEFO/Lot Reservation → Actual Issue → In-Process → Good/Reject/WIP Output → Completed Batch → Costing/Traceability**

## Controls

- An execution cannot start from a production order that is not RELEASED/IN_PROGRESS.
- Every planned component must be fully covered by explicit lot allocations before reservation is accepted.
- Actual issue cannot exceed the reserved quantity in this stage; an explicit approved extra-issue path can be added later.
- Good + reject + WIP output cannot exceed actual production input.
- Completion requires a valid production batch reference.
- Inventory mutations remain delegated to the authoritative inventory services; this module is the production execution coordinator.
- Actual component issue records remain usable as v50 costing inputs with lot traceability.
- v26 WIP/packing remains downstream of production execution.

## Database

Migration `042_v53_production_execution_integration.sql` adds execution runs and issue records without rewriting historical production batches or costing records.
