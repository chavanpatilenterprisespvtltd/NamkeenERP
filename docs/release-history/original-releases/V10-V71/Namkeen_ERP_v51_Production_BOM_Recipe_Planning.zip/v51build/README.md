# Namkeen ERP v51 — Standard BOM/Recipe + Production Planning Integration

This stage connects versioned product recipes to production planning.

Added:
- SKU/entity-scoped, effective-dated BOM/recipe versions
- RM, packaging and intermediate component types
- Planned scrap allowance per component
- Expected yield and planned input calculation
- Planned net and gross issue quantities
- Optional standard component unit cost and planned material-cost rollup
- By-products and recovery-value fields
- Planned-vs-actual consumption variance
- Unplanned consumption protection
- Duplicate-component and invalid-yield/scrap guards
- PostgreSQL migration `040_v51_bom_production_planning.sql`
- FastAPI requirement and consumption-variance endpoints
- Android production-planning contract
- Documentation for v50 costing integration

Important boundary: v51 creates the planning baseline; it does not rewrite v50 actual batch cost. Actual lot consumption and actual batch costing remain authoritative.

Validation: 222 tests passed across the inherited suite + v51; Python test execution completed successfully. There are 58 non-blocking inherited warnings.
