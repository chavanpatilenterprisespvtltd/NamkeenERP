import os
from sqlalchemy import text
from app.db.session import engine

def main():
    print("DATABASE_URL configured:", bool(os.getenv("DATABASE_URL")))
    with engine.connect() as c:
        print("database:", c.execute(text("select current_database()" )).scalar())
        print("time:", c.execute(text("select now()" )).scalar())
    print("startup_check=PASS")
if __name__=='__main__': main()
