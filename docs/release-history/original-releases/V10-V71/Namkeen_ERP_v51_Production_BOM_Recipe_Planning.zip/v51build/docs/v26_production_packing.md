# v26 — Production Consumption, WIP, Packing and FG Traceability

## Transaction chain
RM/Packaging receipt + QC PASS → Inventory Lot → Material Issue → Production Batch → WIP Lot → Packing Run → Packaging Issue → FG Inventory Lot → Dispatch.

All stock mutations remain server-authoritative and are written in the same database transaction as their ledger/traceability records.

## Quantity conventions
- `qty_kg` is used for raw-material, WIP, production yield and FG valuation/stock balance.
- `qty_base` is used for packaging material stock because packaging can be piece/carton/kg depending on its SKU/UOM design.
- `good_pack_qty` records the physical packed unit count.
- The existing inventory layer still needs a finalized per-SKU UOM conversion master before pack/carton quantities can be treated as a universal accounting quantity.

## Controls
- No negative stock.
- Row lock is taken on source InventoryLot/WIPLot before consumption.
- Duplicate WIP and packing numbers are blocked per entity.
- Output cannot exceed WIP issued to the packing run.
- Wastage by non-managerial roles requires an explicit authorization reference.
- Every material/packing issue and finished output emits a canonical domain event for mobile sync/integrations.

## Traceability
The minimum v26 trace chain is represented by FK references across:
`InventoryLot → ProductionMaterialIssue → ProductionBatch → ProductionWipLot → PackingRun → ProductionFgOutput → InventoryLot`.

A later traceability projection can use these links to answer:
- Which RM lots went into an FG batch?
- Which FG lots were produced from a production batch?
- Which packing run consumed a particular packaging lot?
- Which production/packing records created a quantity later dispatched or returned?
