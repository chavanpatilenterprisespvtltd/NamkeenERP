# Production Security Runbook

## Authentication
1. Store passwords only as PBKDF2-HMAC-SHA256 salted hashes.
2. Access tokens are short-lived; refresh tokens are rotated and revocable.
3. Bind refresh/session records to user + device.
4. Disable users immediately when employment/access ends.
5. Never accept role/user IDs from the mobile client as authority; derive actor from token/session.

## Authorization
- Every business query must include organization scope.
- Entity scope is checked through user_entities unless the role is explicitly configured for cross-entity access.
- Management override actions must create audit events.

## Documents
- Aadhaar/PAN/shop/payment/customer photos are sensitive operational documents.
- Store object metadata in DB and bytes in object storage.
- Do not put private object URLs in invoices or API responses.
- Use short-lived signed download URLs/tokens.

## Offline sync
- Each device write carries client_event_id, device_id, entity, entity_id, client_version and event timestamp.
- Duplicate client_event_id is idempotent.
- Version mismatch becomes CONFLICT and is surfaced to user/manager; never silently last-write-wins.
- Server remains authoritative for price, credit, payment verification, stock, approval, QC and disposal.

## Deployment
- TLS everywhere outside localhost.
- Secrets from environment/secret manager, never source control.
- PostgreSQL backups + restore drills.
- Connection pool sized from load testing.
- Central service must receive only explicitly enabled sync/backup/analytics payloads.
