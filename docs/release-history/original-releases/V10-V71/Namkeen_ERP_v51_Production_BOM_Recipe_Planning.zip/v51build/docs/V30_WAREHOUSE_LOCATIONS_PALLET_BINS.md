# v30 — Warehouse Locations, Put-away, Picking and Pallet Hierarchy

## Goal
Make the physical warehouse addressable and scan-friendly: warehouse → zone/aisle/rack/shelf/bin, with controlled put-away, picking routes and pallet/container parents for cartons.

## Location hierarchy
`Warehouse → Zone → Aisle → Rack → Shelf → Bin`

Location type is configurable; staging, dispatch and quarantine locations are supported. Codes are unique per warehouse/organization.

## Pallet/LPN hierarchy
- CARTON can be a child.
- PALLET or CONTAINER can parent cartons and other child LPNs.
- Parent attachment inherits the parent's location when the parent has one.
- Cycles and invalid parent types are rejected.

## Put-away
- Each location has active/put-away/picking flags.
- Put-away rules can match SKU, product, quantity range and priority.
- The rule engine suggests a location; it does not alter stock by itself.

## Picking
Pick tasks contain source/destination location, optional LPN/SKU/lot and quantity in kg. Route ordering is deterministic by sequence, source location and task ID.

## Control boundary
Inventory ledger remains authoritative for quantities and financial stock. Location/LPN movements provide the physical warehouse view and must be posted through the relevant inventory transaction service. The API here is a workflow/reference layer until wired to the production transaction posting path.
