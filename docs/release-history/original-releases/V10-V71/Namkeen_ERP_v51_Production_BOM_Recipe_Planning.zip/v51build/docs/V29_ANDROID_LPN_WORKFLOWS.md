# v29 Android LPN workflow

1. Scan carton/LPN barcode.
2. Server resolves organization + LPN.
3. Show SKU(s), lot(s), expiry, quantity and normalized kg.
4. Operator selects Receive/Put-away/Move/Pick/Dispatch/Return/Quarantine.
5. Client queues event if offline.
6. Server validates stock, warehouse, status and role before posting.
7. Physical LPN event and inventory ledger remain linked by reference IDs.
