# v22 — Android Business Workflows

## Implemented mobile workflows
- Login shell and salesperson home navigation
- Customer onboarding form with GPS evidence hook and shop-photo hook
- Dynamic product list for the initial 15-product catalog
- Configurable pack-size list (100g through 5kg reference values; server master remains authoritative)
- Sales order capture with negotiated-price field and payment-mode selection
- Collection capture requiring counterparty-photo evidence state
- Return capture with forced QC-HOLD initial disposition
- Offline event queue through Room
- Manual sync scheduling through WorkManager
- Sync/conflict center entry point

## Authority rules
Mobile UI does not approve customer credit, bypass negotiated-price floors, verify payments, release QC returns, dispose stock, or post accounting entries. Those decisions remain server-side.

## Hardware hooks
Camera and GPS permissions are declared. Production image upload should use the v21 document queue/provider and actual device file URIs rather than local placeholder IDs.
