# Android v31 Warehouse Execution Contract

## Screens
1. Task Inbox — Put-away / Pick / Replenishment / Count
2. Scan Source — scan location/LPN/SKU/lot
3. Put-away Confirm — destination validation + evidence
4. Directed Pick — source → qty → LPN confirmation
5. Short Pick — mandatory reason
6. Replenishment — source → destination → qty
7. Bin Move — scan source and destination
8. Cycle Count — session → location → item → quantity
9. Count Variance — book vs physical vs tolerance
10. Approval — management review before variance posting

## Offline rules
- Queue execution events in Room outbox.
- Attach `client_event_id`, device ID, user ID, local timestamp and GPS where configured.
- Never locally post stock adjustments without a server-approved transaction result.
- Show `PENDING_SYNC`, `SYNCED`, `CONFLICT`, `RETRY`, and `FAILED` states.
- Photos/evidence use the v21/v22 secure document queue.
