# v23 — Role-Based Application

## Roles
SALESPERSON, MANAGER, FACTORY, QC, ACCOUNTS, MANAGEMENT, SUPER_ADMIN.

The server determines the role and entity scope. The Android app only renders the permitted surface; it cannot elevate permissions offline.

## Common runtime contract
- `/v23/me` returns role, entity scope, dashboard type, offline capabilities.
- `/v23/dashboard` returns role-scoped cards and server-authoritative metrics.
- Business mutations continue to use the existing v16/v17/v18/v20/v21 transaction and sync services.

## Offline rule
Offline writes are queued as domain events. The device may draft/capture data but cannot locally approve price exceptions, credit, payment verification, stock release, QC disposition, disposal, or accounting posting.

## Dashboard responsibility
- Salesperson: customers, orders, collections, returns, sync.
- Manager: approvals, price exceptions, stock shortages, returns/QC.
- Factory: production, RM shortage, FG, QC, dispatch.
- QC: incoming/process/return QC and lab failures.
- Accounts: payments, cash handover, cheque holds, accounting queue.
- Management: cross-company KPI, approvals, pricing, compliance.
