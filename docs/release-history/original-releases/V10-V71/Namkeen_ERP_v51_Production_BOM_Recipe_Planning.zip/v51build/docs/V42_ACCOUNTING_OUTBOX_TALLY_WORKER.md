# v42 — Accounting Outbox Worker + Tally Adapter Execution

Purpose: reliably deliver committed accounting posting intents to Tally/future accounting adapters without calling external systems inside the business transaction.

Flow:
1. v41 commits `accounting_outbox_v41` as `PENDING`.
2. Worker claims one row with a DB row lock.
3. Worker increments `attempts` and sends an idempotent request keyed by `organization_id + integration_code + idempotency_key`.
4. ACK => `POSTED`.
5. Failure before max attempts => `PENDING` with exponential backoff and jitter.
6. Max attempts => `DEAD_LETTER` for Accounts/management review.
7. Reprocessing a `POSTED` row never sends it again.

Reconciliation dashboard should show counts by status, age of oldest pending item, dead-letter count, and last error.

Tally transport remains an adapter seam. Endpoint/auth/company/voucher mappings must be configured and tested against the customer's TallyPrime deployment before production use.
