# Android sync contract

## Push command
`POST /v18/sync/push`

Fields: device_id, client_event_id, event_type, entity_type, entity_id, client_version, payload.

## Pull delta
`GET /v19/sync/pull?device_id=<id>&cursor=<n>&limit=<n>`

The cursor is an opaque server sequence for the organization. The client applies deltas transactionally to its local cache and advances the cursor only after the delta is stored successfully.

## Local state transitions
PENDING -> SENT/RETRY -> ACKED
PENDING -> CONFLICT
PENDING -> DEAD_LETTER

A conflict requires explicit user/management resolution; ACCEPT_CLIENT must replay through the domain transaction service, not bypass the server business rules.
