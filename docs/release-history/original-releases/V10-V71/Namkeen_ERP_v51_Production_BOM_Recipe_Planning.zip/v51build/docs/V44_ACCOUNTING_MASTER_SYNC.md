# v44 — Accounting Master Synchronization & Reconciliation Dashboard

## Purpose
Connect ERP customer/supplier masters to accounting ledger identities and give Accounts a controlled reconciliation queue without allowing external accounting data to overwrite source ERP transactions.

## Scope
- Customer → accounting ledger mapping
- Supplier → accounting ledger mapping
- Entity/organization isolation
- Ledger sync job queue with idempotency keys
- External ledger name/reference capture
- Accounts dashboard counters
- Reconciliation action request/approval flow
- Self-approval prevention
- Mismatch resolution actions: accept external, requeue, correct mapping, reject

## Controls
- Source master remains ERP-authoritative.
- Party mapping is scoped to organization + entity + party.
- External accounting is an adapter/integration concern.
- Reconciliation actions are audited and reason-required.
- Applying a reconciliation action changes only the reconciliation state; it does not rewrite the originating sales/purchase/payment/inventory transaction.

## APIs
- `POST /party-ledger/link`
- `POST /party-ledger/synced`
- `GET /dashboard`
- `POST /reconciliation/action`
- `POST /reconciliation/action/{action_id}/approve`

## Deployment boundary
The worker that actually creates/updates ledgers in TallyPrime remains an external integration concern. v44 provides the durable master mapping and queue contract; live Tally/company-specific ledger creation requires deployment configuration and UAT.
