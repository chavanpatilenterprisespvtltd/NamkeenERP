# v39 — Sales Pricing, Discount, Scheme & Incentive Engine

## Purpose
v39 makes bargaining configurable without allowing a salesperson to bypass management controls.

### Price calculation layers
1. Actual production/landed cost
2. Company target/base price
3. Customer-specific price, when active/effective
4. Promotion/scheme
5. Negotiated salesperson price
6. Floor/max-discount/approval checks
7. Taxable value
8. GST/tax calculation
9. Invoice total
10. Incentive basis (separate from GST)

### Pricing controls
- Target and floor prices are effective-dated.
- Maximum discount is configurable.
- Below-floor selling can require approval.
- Negative margin can force approval.
- Customer-specific rates are separate from the common target price.
- Promotions support percent, per-unit, fixed-unit, buy-X-get-Y and carton discounts.
- GST is not treated as salesperson margin.

### Incentive controls
Management owns incentive policy. A policy has an effective period, formula type, rates and approver. Supported calculation styles are ₹/kg, % sales, % margin, collection-based, target-based and combinations.

Returns and cancellations reduce the eligible basis. The server remains authoritative for posted incentive calculation; mobile values are previews.

### Governance
Pricing and incentive master data should be versioned and audited. Self-approval is prohibited by the existing approval layer. Any statutory/tax-specific treatment remains driven by the tax master and applicable rules rather than by v39 hard-coded rates.
