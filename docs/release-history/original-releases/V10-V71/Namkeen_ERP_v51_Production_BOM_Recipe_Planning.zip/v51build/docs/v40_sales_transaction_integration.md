# v40 — Sales Order → Invoice → Dispatch Commercial Integration

## Purpose
Provide one controlled commercial transaction orchestration layer connecting v39 pricing/incentives, v38 credit/payment controls, v37 customer accounts and the existing inventory/FEFO transaction services.

## Lifecycle
1. Validate payment mode/evidence.
2. Calculate each line using the effective v39 pricing policy.
3. Apply customer price and promotion rules.
4. Enforce maximum discount/floor/margin approvals.
5. Evaluate v38 customer credit controls.
6. If cleared, build a validated customer invoice.
7. Inventory reservation/dispatch is performed by the authoritative persistent inventory service; this orchestration layer accepts only confirmed allocations.
8. Build customer receivable/output-tax accounting posting intents.
9. After posting, the resulting invoice/dispatch events become the incentive basis input.

## Atomicity rule
A commercial transaction is successful only when all authoritative writes are committed in the same database transaction (or through an explicit outbox/saga boundary where external accounting is involved). No component is allowed to claim `DISPATCHED` while inventory or receivable posting is uncommitted.

## Idempotency
`organization_id + idempotency_key` is the natural retry key for mobile/offline submissions. A duplicate successful request must return the original result rather than creating another order/invoice/dispatch.

## Accounting boundary
Internal receivable/tax posting is represented as a controlled posting intent. Tally or another accounting system remains an external adapter; external success must be recorded through the existing integration idempotency layer.

## Incentive boundary
Incentive is not calculated on GST-inclusive value by default. It uses posted eligible sales/quantity/margin and then applies the management-approved v39 policy. Returns/cancellations/failed posting must remove or reverse incentive eligibility.
