# v33 — Procurement Planning & Demand / Reorder Engine

## Purpose
Converts stock position + demand + open supply + safety stock + supplier terms into **approval-controlled suggestions**. It does not automatically create a purchase order or production batch.

## Supply position
`available + open PO + open production` is treated as projected usable supply. The v32 inventory availability already nets reserved stock; reservations must not be deducted twice.

## Formula
`required = max(0, demand + safety stock - available - open PO - open production)`

Supplier quantity is then adjusted for MOQ and order multiple.

## Supplier selection
Active supplier SKU terms are ranked by priority, then lead time, then supplier id. If a term has an MOQ larger than the immediate requirement, the recommendation uses the MOQ. If no supplier term exists, the suggestion is `CRITICAL` and explicitly says `NO_ACTIVE_SUPPLIER_TERM`.

## Production requirement
For configurable make-to-stock SKUs, the same demand gap can create a `production_requirements` recommendation. This is still a planning record and requires management/factory approval before a production batch is created.

## Inputs to integrate later
- Sales orders / confirmed demand
- Sales history / forecast
- Customer/channel promotions
- Current inventory and reservations
- Open purchase orders and expected receipts
- Open production requirements / batches
- Safety stock and reorder policy (v32)
- Supplier lead time, MOQ and order multiple
- Multi-entity / warehouse scope

## Control boundary
Planning is advisory. PO creation, production order/batch creation, stock allocation, pricing, QC, payment and accounting remain separate controlled transaction services.
