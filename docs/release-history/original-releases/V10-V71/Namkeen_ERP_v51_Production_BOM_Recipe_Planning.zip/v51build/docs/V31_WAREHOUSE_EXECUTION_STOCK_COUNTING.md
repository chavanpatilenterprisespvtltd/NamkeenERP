# v31 — Warehouse Execution and Stock Counting

## Scope
v31 converts v30 warehouse-location definitions into controlled execution workflows:

- Put-away confirmation
- Directed picking: assign → confirm picked quantity
- Pick short handling with mandatory reason
- Bin-to-bin movement confirmation
- Replenishment task creation/assignment/completion
- Cycle-count sessions and count lines
- Count submission → approval → posting lifecycle
- Variance calculation and tolerance check
- Barcode/evidence fields on count lines
- Offline client_event_id support

## Control boundaries
1. **Inventory ledger remains authoritative.** A confirmed put-away, bin movement or count does not directly overwrite stock without the corresponding inventory transaction service.
2. **Stock counts create controlled variance decisions.** The count process records book quantity vs physical quantity; posting is an explicit approved action. The existing stock-adjustment service remains the correct posting authority.
3. **Directed picking cannot over-pick.** Short picks require a reason; overage is rejected.
4. **Mobile retries are idempotent** through `client_event_id`; duplicate events must be safe to replay or recognized as already applied.
5. **Warehouse movement cannot bypass QC or accounting.** Quarantine/blocked locations and downstream transaction controls remain authoritative.

## Warehouse flow
Receive/QC → Put-away task → Scan/Confirm put-away → Bin stock
→ Replenishment / Directed pick → Pick confirm → Staging → Dispatch.

## Stock-count flow
Open session → Count locations/lines → Record physical quantities → Submit → Management approval → Post approved variance through inventory adjustment authority.

## Replenishment
Replenishment suggestions should be generated from configurable minimum/reorder/target rules. The warehouse operator executes the task; the inventory service posts the actual movement.

## Offline
Each field transaction carries `client_event_id`, device/user metadata and captured-at timestamps. The server remains authoritative and conflicts remain visible rather than silently overwritten.
