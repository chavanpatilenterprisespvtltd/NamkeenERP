# v24 — Operational APIs

v24 connects role-based dashboards to persistent production operations. These APIs are intentionally server-authoritative.

## Production
`POST /v24/production/batches` creates a planned batch.
`POST /v24/production/batches/{id}/record` records good/reject quantity and moves status toward completed.
`GET /v24/production/batches` lists scoped batches.

## QC
`POST /v24/qc/inspect` records PASS/FAIL/HOLD against exactly one production batch or sales return.
`GET /v24/qc/pending` lists operational batch records awaiting QC attention.

## Pricing approvals
Sales can request a below-floor exception; manager/management approval is separate. Approval authorizes the exception record but does not silently rewrite historical order lines; order posting must consume the approved exception.

## Security
Every route validates the bearer token and entity scope. No mobile/client request can bypass role checks or mutate transaction state directly.

## Deployment
Apply migration `013_v24_operational_apis.sql` after migrations `001..012`. Run API and domain tests before production migration.
