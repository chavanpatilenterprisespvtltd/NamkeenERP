# v48 — Delivery Settlement

Connects v47 delivery/POD outcomes to controlled settlement decisions.

## Rules
- Full delivery can reconcile without an exception.
- Short/failed/returned quantities create an exception path.
- Exception approval is role-restricted and requires a reason.
- Posting requires approved reconciliation and explicit stock/receivable actions.
- Customer credit/debit adjustments are records awaiting the authoritative accounting service.
- Freight is calculated per delivered kg and remains separately approvable.
- No POD or settlement endpoint silently mutates inventory or receivables.
