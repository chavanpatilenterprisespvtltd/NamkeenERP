# v51 — Standard Recipe/BOM + Production Planning

## Purpose
Bridge the product/recipe master, production planning and v50 actual costing without changing historical recipes after use.

## Controls
- Product/SKU-specific, versioned BOM/recipe.
- Effective-from/effective-to dates.
- Expected yield drives planned input requirement.
- Each component can carry planned scrap and optional unit cost.
- RM, packaging and intermediate inputs are separately typed.
- By-products are captured separately with optional recovery value.
- Planned issue quantity includes configured component scrap.
- Actual consumption is compared with planned issue; unplanned items are rejected.
- Used BOM versions are immutable by application policy.

## Planning formulas
`Expected Input = Planned Good Output / Expected Yield`

`Net Required = Qty per Output kg × Planned Good Output`

`Planned Issue = Net Required × (1 + Scrap % / 100)`

`Planned Material Cost = Σ Planned Issue × Unit Cost`

## Integration with v50
The v51 plan supplies the expected consumption baseline. v50 actual batch costing remains authoritative for actual cost. Planned-vs-actual variance is an operational control and does not silently rewrite actual costing.
