# v50 — Production Costing & Batch Profitability

## Purpose
Connect actual material/process consumption and production yield to batch-level actual cost, cost/kg, standard-cost variance and margin preview.

## Cost components
- RM
- Oil
- Fuel/Wood
- Packaging
- Labour
- Power
- Utilities
- Rework
- Overhead
- Other

## Actual cost formula
`Actual Batch Cost = Σ actual component costs`

`Actual Cost / Good FG kg = Actual Batch Cost / Good Output kg`

`Good Yield % = Good Output kg / Input kg × 100`

Reject and rework quantities are recorded separately and remain visible to production/QC analysis. Rework can also carry a direct cost component when cost is incurred again.

## Standard variance
`Standard Cost for Actual Output = Standard Cost/kg × Actual Good Output kg`

`Total Cost Variance = Actual Batch Cost − Standard Cost for Actual Output`

Positive variance means actual cost is above standard; negative means below standard.

## Traceability
Every actual component entry may carry a lot/reference, so the batch-cost record can trace back to material issue, packaging issue, fuel/utility capture and rework records.

## Commercial use
Actual batch cost can feed the v39 pricing engine as the cost basis for realized margin preview. The accounting layer remains authoritative for final financial posting.

## Important configuration boundary
Recoverable GST is not production cost by default. Any tax or levy that is a real non-recoverable production cost must be explicitly configured by Accounts/CA policy.
