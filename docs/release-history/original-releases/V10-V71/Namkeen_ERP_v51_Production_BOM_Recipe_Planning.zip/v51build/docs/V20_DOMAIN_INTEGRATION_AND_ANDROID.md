# v20 — Domain Integration + Android Offline Skeleton

## Purpose
Turn v19's generic domain stream into the common event contract for the remaining operational modules.

## Domains wired in this stage
- Customer onboarding and approval/rejection
- Collection capture
- Collection deposit submission and verification
- Sales returns and QC disposition
- Production-batch event bridge
- Compliance-task event bridge

## Transaction rule
Each emitted event is recorded using the same SQLAlchemy transaction as the originating write. If the transaction rolls back, the domain event rolls back too. Mobile sync consumes the event stream; it never becomes the system of record.

## Stable event envelope
`change_id`, `organization_id`, `entity_scope_id`, `aggregate_type`, `aggregate_id`, `operation`, `version`, `event_name`, `payload`, `actor_user_id`, `occurred_at`.

## Android reference architecture
Room stores outbox/inbox/cursor/conflicts. WorkManager executes retryable synchronization. Every local write has a client event id. Server results are classified as accepted/duplicate/conflict/rejected. Conflicts are explicit and cannot bypass transaction services.

## Production gates still outstanding
The Android app is a skeleton, not a finished app. Before production deployment: real API client/TLS pinning decision, secure token storage, device registration, encrypted local DB policy, image/file upload queue, background constraints, telemetry, full UI, automated instrumentation tests, Play/App distribution controls, UAT, and external accounting/bank/notification adapters.
