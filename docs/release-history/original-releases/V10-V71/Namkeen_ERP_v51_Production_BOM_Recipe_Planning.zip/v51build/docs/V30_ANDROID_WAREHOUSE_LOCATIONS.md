# v30 Android workflow contract

Scanner screens should support:
1. Scan/select warehouse.
2. Scan location barcode to verify warehouse/bin.
3. Scan carton/pallet LPN.
4. Put-away: destination location scan → server validation → post movement → confirmation.
5. Pick: route list → source location scan → LPN/lot scan → quantity confirmation → destination/staging scan.
6. Cycle count: location scan → LPN/SKU scan → count capture → adjustment request (never direct book-stock overwrite).

Offline scans use `client_event_id`, device ID and timestamps. The server remains authoritative for inventory, FEFO, approvals and accounting.
