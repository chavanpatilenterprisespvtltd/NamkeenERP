# v49 — Sales Return & Reverse Logistics

## Objective
Create a controlled reverse flow from customer delivery back into the ERP without allowing a returned item to bypass QC, inventory controls or accounting.

## Flow
`Return Request → Approval → Pickup → LPN/Barcode Scan → Receipt → QC HOLD → Disposition → Credit Note Decision → Controlled Posting → Audit/Sync`

## Rules
- Return quantity is tied to an invoice line and SKU.
- Returned cartons/LPNs should be scanned where barcodes exist; lot/expiry is retained where available.
- Returned goods enter **QC HOLD**, not saleable inventory.
- QC disposition is one of: Saleable, Repack, Rework, Damage, Expired, Dispose.
- Damage/expired/dispose outcomes require reason/evidence and authorization according to policy.
- Credit note is separate from physical stock disposition and follows Accounts approval.
- Customer receivable and inventory are never silently rewritten from the mobile return screen.
- Offline events are idempotent and are replayed through server-side business services.

## Settlement mapping
- SALEABLE → controlled inventory re-entry to saleable FG lot/bin.
- REPACK → controlled movement to repack workflow/WIP.
- REWORK → controlled movement to rework WIP.
- DAMAGE / EXPIRED → controlled quarantine/damage/expired inventory.
- DISPOSE → controlled disposal transaction with authorization and audit.
- Approved credit note → accounting/tax posting through existing voucher/outbox pipeline.

## Traceability
`Customer Invoice → Invoice Line → Return Request → Return LPN/Lot → QC Result → Disposition → Credit Note → Inventory/Accounting Posting`
