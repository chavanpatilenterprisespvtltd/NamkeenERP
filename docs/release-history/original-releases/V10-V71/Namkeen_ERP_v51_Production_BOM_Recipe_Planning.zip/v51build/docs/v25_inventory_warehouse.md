# v25 — Inventory, Warehouse, GRN, QC, Transfers & Traceability

## Scope
v25 extends the transactional ERP into a controlled warehouse layer for RM, packaging, WIP and FG. Inventory remains entity scoped and server authoritative.

## Included
- Warehouse master with types (RM, PACKAGING, WIP, FG, QUARANTINE, DISPATCH) as configurable values.
- Supplier master.
- Goods Receipt / GRN-style receiving record and lines.
- Supplier lot, expiry and cost capture.
- Incoming QC with PASS / FAIL / HOLD and COA/evidence references.
- Posting only after PASS; failed/held receipts do not become saleable inventory.
- Inventory lot creation and stock movement audit trail.
- Stock transfers with management/warehouse-manager approval.
- Stock adjustments with approval and negative-stock protection.
- Barcode/QR event capture.
- Traceability links between receipt lines and lots, and transfer-origin lots.
- Warehouse/stock API views ordered by expiry and lot id to support FEFO.

## Inventory categories
The warehouse type/master is intended to support separate RM, Packaging, WIP, FG, Damaged, Expired, Rejected, Returned, Consumables, Fuel/Wood, Nitrogen and Spare Parts locations or logical warehouses.

## Important controls
- Receipt is not stock until incoming QC PASS and explicit post.
- Stock adjustment is requested first and approved by configured management roles.
- Transfers cannot move stock between the same warehouse and cannot exceed available stock.
- Transfer keeps the original batch number at the destination and records a traceability relationship.
- Barcode events are evidence/events, not an alternative to authoritative stock posting.
- Existing FEFO order reservation remains the authoritative sales allocation mechanism.

## Next integration targets
Production should consume RM/packaging lots and create WIP/FG lots; packing should consume packaging inventory; dispatch should link FG lots to sales orders; recall/complaint tracing should query traceability links.
