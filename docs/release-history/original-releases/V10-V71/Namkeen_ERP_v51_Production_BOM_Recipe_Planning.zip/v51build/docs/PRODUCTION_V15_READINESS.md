# v15 Production Readiness Gate

v15 moves the project from a foundation into a concrete PostgreSQL integration layer.

## Now wired
- PostgreSQL repository for login/device/session creation, sync-event persistence and DB notification outbox operations.
- Bearer-token API middleware using the v14 JWT model.
- Idempotent integration-run ledger for Tally/other adapters.
- Migration 005 hardening and integration-run table.
- PostgreSQL docker-compose development environment.

## Required before production go-live
- Run migrations 001→005 against the real PostgreSQL instance and confirm indexes/constraints.
- Replace any remaining demo/development endpoints with authenticated routes only.
- Configure secret management; never ship the example JWT secret/passwords.
- Add refresh-token endpoint with rotation + revocation and server-side session checks.
- Add object storage encryption, AV scanning, retention/deletion policy and access logging for sensitive evidence.
- Run concurrency/load tests for FEFO reservation and dispatch at expected peak concurrency.
- Run sync conflict tests with real mobile reconnect patterns and per-entity version storage.
- Configure actual FCM/APNs/WhatsApp/SMS provider and retry/dead-letter policy.
- Execute Tally UAT with a CA/accounting operator; map masters, GST and voucher semantics to the customer's Tally setup.
- Backups, PITR, restore drill, monitoring, alerting and disaster recovery.
