# Namkeen ERP v43 — Accounting Reconciliation & Voucher Mapping

## Scope
v43 formalizes the accounting bridge created in v42. It provides configurable ledger masters, effective-dated voucher mappings, balanced double-entry preview, and reconciliation of ERP vouchers against external-accounting acknowledgements.

## Supported source document types
SALES, PURCHASE, RECEIPT, PAYMENT, CREDIT_NOTE, DEBIT_NOTE.

## Mapping principle
The ERP transaction remains authoritative. Mapping determines how the transaction is represented for the accounting system. External posting remains outside the core business transaction, using v42's accounting outbox/worker.

## Minimum mapping controls
- Entity + organization scope
- Effective dates
- Active/inactive state
- Party ledger mapping
- Base/sales/purchase ledger mapping
- CGST / SGST / IGST / Cess ledger mapping
- Voucher type mapping
- Balanced debit/credit validation

## Reconciliation
Every externally posted voucher should be reconcilable by external reference and amount. `MATCHED`, `MISMATCH`, and `UNMATCHED` are distinct states. Mismatches are surfaced to Accounts and never auto-correct the originating business transaction.

## Tally boundary
The v43 mapper generates accounting intent/preview. The v42 worker is responsible for delivery/retry/dead-letter behavior. Customer-specific TallyPrime company, endpoint and exact XML schema remain deployment/UAT configuration.
