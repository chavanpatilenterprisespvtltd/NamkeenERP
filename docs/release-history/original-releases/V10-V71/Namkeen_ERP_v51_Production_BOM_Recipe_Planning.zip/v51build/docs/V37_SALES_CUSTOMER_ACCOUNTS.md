# v37 — Customer Sales & Accounts Design

## Scope
v37 brings the v36 Accounts discipline to sales: customer invoices, tax totals, receipts, allocation, customer ageing, adjustment notes, credit exposure, customer ledger and the incentive-calculation basis.

## Controls
1. Customer invoice totals are validated from line-level taxable/tax amounts.
2. Credit-limit checks occur before credit release; overrides are explicit and auditable.
3. Receipts must be posted before allocation and cannot allocate more than receipt or outstanding.
4. Debit/credit notes require original invoice reference, reason and arithmetic validation.
5. Incentive basis excludes returned quantity and records quantity, net sales and gross margin basis. The incentive policy itself remains management-controlled and configurable.
6. GST/tax rates are not hard-coded here; v36 tax configuration remains the source for tax determination.
7. The customer ledger is a financial record and should be posted transactionally with invoice/receipt/note events.

## Accounting boundary
This module prepares customer-side accounting facts. Final statutory accounting and filing remain under the customer's authorised Accounts/CA process and the configured accounting adapter (Tally first, future adapters later).
