# v46 — E-Invoice + E-Way Bill Integration

## Design
ERP invoice commit remains authoritative. Government API work is asynchronous through `government_api_outbox`. External calls are never made inside the ERP database transaction.

## E-Invoice
- Prepare validated document payload from posted invoice.
- Store deterministic payload hash and idempotency key.
- Worker calls an authorized IRP adapter.
- Persist IRN, ACK and signed QR data.
- Cancellation is a controlled action; current IRIS IRP guidance documents a 24-hour cancellation window and says an active EWB blocks IRN cancellation.

## E-Way Bill
- Generate from invoice or subsequently by IRN where supported.
- Keep transport mode, vehicle/transporter, distance and validity fields separate.
- Updates/cancellation/retry are asynchronous and audited.

## Security
Store IRP/EWB credentials outside the database in a secret manager. Mobile clients never receive portal credentials.

## Current-source implementation note
The e-way bill developer portal currently identifies API version 1.03 and shows that some recent enhancements (including EWB Closure and mandatory Ship-to GSTIN) were put on hold as of 30 Jul 2026; therefore those rules are not hard-coded here and are modeled as versioned configuration/validation.
