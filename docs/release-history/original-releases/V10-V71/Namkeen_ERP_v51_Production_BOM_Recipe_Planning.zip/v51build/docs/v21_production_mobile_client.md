# v21 Production Mobile Client Design

## Security
- Access/refresh tokens are kept only in Android Keystore-backed `EncryptedSharedPreferences`.
- Access token is short-lived; refresh rotation/revocation remains server authoritative.
- Device registration supports explicit revoke.
- Aadhaar/PAN/shop/payment photos are treated as private objects.
- Every upload carries a client document id and SHA-256 digest for idempotency/integrity.

## Sync
1. Persist a user action to the Room outbox.
2. WorkManager runs only when connected.
3. Push a bounded batch.
4. ACK duplicate/accepted events; retain conflicts and permanent failures for explicit action.
5. Pull server deltas from the local cursor.
6. Apply inbox entries idempotently.
7. Advance the cursor only after durable application.

## Offline boundaries
Offline mode captures requests, but pricing approval, credit approval, payment verification, stock reservation, QC disposition, disposal and accounting remain server authoritative.

## Document queue
Evidence uploads are independent and retryable. A business record may remain evidence-pending according to policy; an upload failure must not silently delete the business event.

## Conflict UI
The screen shows entity, client version, server version and snapshots. ACCEPT_CLIENT never directly overwrites a business aggregate; it must route through the domain-specific transaction endpoint after review.
