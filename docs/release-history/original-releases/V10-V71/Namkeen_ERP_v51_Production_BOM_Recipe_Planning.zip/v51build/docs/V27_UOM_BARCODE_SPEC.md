# v27 UOM / SKU / Barcode Specification

## Canonical quantity rule
All manufacturing valuation and inventory ledger quantities continue to reconcile to kilograms where the underlying material is weight-based. Count units remain explicit for pieces, packs and cartons.

## SKU hierarchy
Product + Variant + Pack Size remains the SKU identity. Each SKU has an effective-dated pack hierarchy:

`Piece -> Pack -> Carton` and `Piece -> KG` as configured for that SKU.

Example 500 g SKU:
- net_weight_kg = 0.500
- pieces_per_pack = 1
- packs_per_carton = configurable, e.g. 20
- kg_per_piece = 0.500

Example 1 kg SKU:
- net_weight_kg = 1.000
- packs_per_carton = configurable
- kg_per_piece = 1.000

Do not hard-code carton quantities.

## Effective dating
A changed carton configuration creates a new effective record; historical documents retain the old conversion. Do not mutate history silently.

## Barcode hierarchy
- SKU barcode resolves the product/pack master.
- Lot barcode resolves the lot/batch where available.
- Transaction barcode may identify carton/pallet/shipping unit when used.
- A barcode is unique within an organization.

## Reconciliation controls
For each document line the system stores both transaction quantity/UOM and normalized kg quantity where applicable. Conversions are recalculated server-side and mismatch is surfaced as an exception, not silently accepted.

## Negative / fractional rules
Each UOM can carry future precision rules. Count units can be configured as integer-only for a given SKU; kg can retain decimal precision. The transaction service must validate the rule before posting.
