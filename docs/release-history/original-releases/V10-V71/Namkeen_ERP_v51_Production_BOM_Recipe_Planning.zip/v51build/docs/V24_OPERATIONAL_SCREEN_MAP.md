# v24 Android Operational Screen Map

This is a thin workflow shell wired conceptually to the v24 API contract. It is not a finished visual product.

- Production / Batches: plan batch, enter good/reject kg, view status.
- QC Inspection: batch/return target, PASS/FAIL/HOLD, remarks and evidence.
- Price / Order Approvals: below-floor exception review with explicit decision.
- Stock Reservation / Dispatch: FEFO reservation, allocation review, dispatch posting.
- Payment Verification / Cheque: Accounts/manager controlled verification and cheque clearance.

Offline writes must enter the v21/v19 mobile outbox and server-side business services remain authoritative.
