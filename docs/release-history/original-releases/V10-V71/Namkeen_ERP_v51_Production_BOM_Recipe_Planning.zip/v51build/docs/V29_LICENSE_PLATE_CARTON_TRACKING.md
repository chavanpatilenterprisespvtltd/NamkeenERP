# v29 — License-Plate / Carton-Level Inventory Tracking

## Goal
Give each physical carton a durable identifier (license plate / LPN) and maintain its contents, lot, expiry, warehouse and movement history without replacing the normal inventory ledger.

## Hierarchy
SKU → Lot → Carton/LPN → (optional parent LPN/pallet) → Warehouse movement → Pick → Dispatch → Return/Quarantine.

## Rules
- An LPN code is unique per organization.
- Contents carry SKU, supplier/production lot, transaction UOM and normalized kg.
- LPN status is controlled: ACTIVE/SEALED/PICKED/DISPATCHED/RETURNED/QUARANTINED/VOID.
- A sealed LPN cannot accept or remove contents until an authorized open event.
- Pick requires SEALED status; dispatch requires PICKED status.
- LPN movement records the destination warehouse and an immutable event.
- FEFO remains based on lot expiry; LPN selection follows the earliest eligible expiry.
- Scanning an LPN must never bypass stock, payment, QC or approval rules.
- LPN quantities are a physical-container view of inventory; the inventory ledger remains the accounting stock authority.
- Offline scans use client_event_id for idempotent replay.
