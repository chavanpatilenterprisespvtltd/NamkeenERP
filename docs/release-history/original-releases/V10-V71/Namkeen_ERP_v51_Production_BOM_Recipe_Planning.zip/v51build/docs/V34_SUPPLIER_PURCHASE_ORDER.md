# v34 — Supplier Management + Purchase Order Workflow

v34 extends v33 procurement planning into controlled purchasing.

## Supplier master
Supplier records hold legal/display names, GSTIN/PAN, state, payment terms, contacts and status. Supplier records are organization-scoped.

## Quotations and rate history
Supplier quotations are SKU-specific and can carry validity dates, price/kg, MOQ, lead time, order multiple, tax code and attachment evidence. Rate history is append-only/effective-dated.

## Purchase order lifecycle
`DRAFT -> PENDING_APPROVAL -> APPROVED -> PARTIALLY_RECEIVED -> FULLY_RECEIVED -> CLOSED`
with `CANCELLED` as a terminal exception state. Self-approval is prohibited in the service layer.

## Price variance
Every PO line may carry an expected/target unit rate. A line that exceeds the configured tolerance is blocked from normal PO creation and requires the approval path to be used. Exact financial approval policy remains configurable.

## GRN / partial receipt
A receipt may cover any subset of the open PO quantity. Received, accepted and rejected quantities are tracked separately. Receipt quantity may never exceed the open PO line quantity. Incoming QC remains authoritative for whether received material becomes usable inventory.

## Supplier performance
The model supports receipts, on-time receipts, ordered/received/accepted quantity and average purchase rate. Derived KPIs include on-time %, fill rate % and acceptance %.

## Controls
v34 does not auto-create POs merely because v33 recommends procurement. Approval is explicit. GRN does not bypass incoming QC. Inventory creation remains in the v25 inventory/QC posting service.
