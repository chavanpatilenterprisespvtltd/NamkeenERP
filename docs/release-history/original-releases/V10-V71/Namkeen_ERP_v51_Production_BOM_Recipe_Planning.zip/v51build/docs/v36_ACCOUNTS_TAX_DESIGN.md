# v36 Accounts / Tax / Supplier Ageing Design

## Scope
v36 adds a configurable Accounts layer around v35 Purchase-to-Pay.

## Tax engine
- Effective-dated tax profiles.
- Intra-state and inter-state component sets.
- Tax-exclusive or tax-inclusive pricing.
- Per-line taxable base after discount.
- Configurable CGST/SGST/IGST/UTGST/Cess components.
- TDS and TCS are separate configurable withholding/collection amounts.
- No statutory rate is hard-coded; rates and applicability must be reviewed by the customer's CA/tax adviser and updated through the tax master.

## Supplier ageing
Ageing is computed as of an accounting date using invoice due date and outstanding amount.
Buckets: Current, 1-30, 31-60, 61-90, 91-120, 120+.

## Notes
Debit/Credit notes reference the original supplier invoice and require a reason. Total arithmetic is validated.

## Reconciliation
Bank payment references can be matched to a supplier payable. Short, over, and unmatched states remain visible; the engine does not silently write off differences.

## Accounting posting
Accounting postings use explicit debit/credit accounts, source references and idempotency keys. Export to Tally or another accounting system occurs only after posting is approved according to the customer's accounting policy.

## Compliance boundary
GST, TDS/TCS applicability, rates, HSN/SAC and return treatment are configuration and regulatory matters. The ERP provides calculation/audit support, not a legal guarantee of tax compliance.
