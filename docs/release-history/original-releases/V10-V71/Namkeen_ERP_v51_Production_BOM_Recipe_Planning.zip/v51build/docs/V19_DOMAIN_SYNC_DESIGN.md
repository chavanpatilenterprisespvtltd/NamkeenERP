# Namkeen ERP v19 — Domain Change Log & Offline Client Design

## Purpose
v18 had a generic sync stream. v19 makes domain transactions produce a canonical, append-only change stream.

## Canonical aggregates
The change log supports (and must be extended without changing the transport contract):
- CUSTOMER
- SALES_ORDER
- PAYMENT
- INVENTORY_LOT
- COLLECTION
- SALES_RETURN
- COMPLIANCE_TASK
- PRODUCT / SKU / PACK_SIZE
- PRODUCTION_BATCH (when production services are connected)

## Rules
1. A successful domain transaction and its `domain_changes` row are committed in the same database transaction.
2. `version` is per organization + aggregate, starting at 1.
3. Payload is a sync projection, not a duplicate of the entire relational row.
4. Mobile clients never write directly into operational tables.
5. Client commands are idempotent by `client_event_id`.
6. Conflicts remain explicit; sync never performs silent last-write-wins.
7. Sensitive documents remain references to secure object storage; binary files are not placed in sync payloads.

## Mobile local database
The reference `app/mobile_client/offline_store.py` models the Android Room-style responsibilities:
- outbox queue
- inbox/change cursor
- retry/dead-letter states
- conflict queue

An Android production client should implement the same contract with Room + WorkManager (or equivalent), preserving the exact server semantics.

## Remaining production integration gate
Every write service must call `record_change()` before commit. v19 demonstrates this for the core sales-order lifecycle. Remaining modules (customer profile/approval, collection/deposit, returns/disposition, production batch, QC, compliance, SKU masters) must be connected before production go-live.
