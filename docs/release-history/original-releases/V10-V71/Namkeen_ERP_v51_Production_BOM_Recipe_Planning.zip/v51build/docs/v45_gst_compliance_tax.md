# v45 — GST Compliance & Statutory Tax Engine

## Scope

v45 adds a configurable GST/tax determination and return-support layer. It is deliberately **not** a statutory filing engine and does not hard-code current tax rates.

## Core controls

1. HSN is mandatory for tax-document line validation and supports 4/6/8-character codes.
2. GSTIN format validation is provided as a structural check; master-data approval is still required.
3. Place of supply is captured explicitly.
4. Intra-state vs inter-state split is determined from supplier state and place of supply, with an explicit IGST-on-intra override field.
5. CGST/SGST/IGST/UTGST/Cess are stored separately.
6. Reverse charge is stored separately from normal forward-charge tax.
7. Supply type is explicit: B2B/B2C/export/SEZ/etc.
8. Tax rules are effective-dated and organization/entity scoped.
9. Product/SKU HSN/tax profiles are effective-dated.
10. Credit/debit notes are included as source documents for return summaries.
11. GST periods can be OPEN/LOCKED/FILED/REOPEN_PENDING.
12. Reconciliation stores local values, external values, differences, status and resolution audit.

## Return support

`build_gstr1_summary()` is a management/CA support summary based on posted documents. `build_gstr3b_summary()` provides a high-level outward-tax and RCM summary. These are **supporting calculations**, not a claim that the software alone satisfies every statutory table, amendment, filing or portal validation.

## E-invoice-ready design

The document model stores document number/date, supplier/recipient GSTIN, place of supply, HSN, quantity, tax rates and tax components so a separate IRP adapter can map them to the currently notified schema without changing the ERP transaction model.
