# v28 Barcode-Driven Warehouse Operations

## Objective
Turn the v27 barcode hierarchy into controlled warehouse transactions. A scan is an evidence/event capture and must resolve to an organization-scoped SKU, lot or transaction entity before posting.

## Supported actions
- RECEIVE — receive against a receipt/warehouse workflow
- ISSUE — issue RM/packaging/WIP from a lot
- TRANSFER — move an identified lot/carton between warehouses
- PICK — identify stock for dispatch picking
- DISPATCH — confirm picked stock at dispatch
- COUNT — capture stock-count evidence
- VERIFY_LOT — verify SKU, lot, batch, expiry and current available stock

## Barcode hierarchy
1. SKU barcode: resolves pack/SKU master.
2. Lot barcode: resolves a specific inventory lot/batch.
3. Transaction/carton/pallet barcode: may resolve a shipping unit or movement reference.

The organization is the isolation boundary; a barcode from another organization must not resolve.

## Warehouse controls
- Every scan is stored in `barcode_events` with actor, timestamp, action and reference.
- `client_event_id` makes mobile retries idempotent.
- Lot actions for issue/pick/dispatch/transfer reject missing or exhausted stock.
- Warehouse mismatch is surfaced instead of silently moving stock.
- Final stock posting still occurs through the appropriate business transaction service; the scanner cannot bypass approval, stock reservation, QC, payment, pricing or accounting controls.

## Lot/expiry
`VERIFY_LOT` returns batch number, expiry date and available/reserved quantity. FEFO remains a server-side allocation rule; a scanner cannot override FEFO simply by choosing an arbitrary lot unless the posting workflow explicitly permits a controlled override.

## Stock count
A count scan should capture physical quantity + UOM + warehouse + lot/carton identity. Reconciliation must create a stock adjustment request; it must not directly mutate the book balance.

## Cartons / UOM
Scanned quantity is supplied with UOM. The server uses the effective v27 SKU hierarchy to normalize to kg where the SKU is weight-based. Pack/carton counts remain explicit for count control.
