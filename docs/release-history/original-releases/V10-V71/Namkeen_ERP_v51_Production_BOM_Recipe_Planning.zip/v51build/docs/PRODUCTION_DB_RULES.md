# v13 Production DB Rules

1. Every write transaction must use a DB transaction boundary.
2. Inventory receipt/reservation/dispatch uses row locks and the authoritative DB state.
3. FEFO uses earliest expiry then lot id as deterministic tie-breaker.
4. Stock shortage aborts the transaction; no partial reservation remains.
5. Posted inventory cannot be edited directly; corrections are reverse/adjustment transactions.
6. Orders are blocked by customer approval, payment/cheque state, credit state and price exceptions according to configured rules.
7. Management override must create an approval record and audit event.
8. Payment proof is evidence; verification/clearance is a separate accounting event.
9. Offline client_event_id is unique per organization; duplicate replay must be idempotent.
10. Server is authoritative for stock, payment, approval, price and compliance state.
11. Sensitive evidence belongs in encrypted object storage; DB stores metadata and secure file ids.
12. Compliance requirements are versioned/effective-dated outside hard-coded business logic.
13. Entity X/Y remains configuration; single-company customers use the same schema without intercompany complexity.
