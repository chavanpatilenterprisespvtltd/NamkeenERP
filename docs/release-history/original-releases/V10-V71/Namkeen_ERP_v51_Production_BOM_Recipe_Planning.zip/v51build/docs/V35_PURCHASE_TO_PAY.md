# Namkeen ERP v35 — Purchase-to-Pay

## Scope
v35 extends v34 purchasing into Accounts/P2P while keeping inventory and accounting integration controlled.

Flow:
**PO → GRN → Incoming QC → Supplier Invoice → 3-Way Match → Exception Approval (if any) → Payable → Payment Schedule → Payment → Outstanding**

## 3-way match
The match engine checks supplier, PO state, GRN posting state, invoice lines against PO lines, accepted GRN quantity, unit-price variance and invoice taxable-total arithmetic. Tolerances are configurable; zero is the safe default in the service core.

A match exception cannot create a normal open payable unless an authorized user explicitly approves the exception with a reason. Exception approval is separate from invoice capture.

## Inventory/accounting boundary
Invoice capture does **not** post stock. GRN/QC/inventory services remain responsible for inventory. P2P creates the supplier liability/payable after Accounts approval. Accounting adapters (Tally first) consume approved events rather than allowing an invoice screen to directly alter ledger balances.

## Payment
Supplier payment supports scheduled/due/paid/failed/cancelled states in the design. A payment may be partial; outstanding is reduced only by a recorded PAID transaction. Payment mode is configurable within the supported core modes: bank transfer, UPI, cheque and cash. Actual bank/UPI integration is still an adapter/UAT task.

## Duplicate and audit controls
- Unique supplier invoice number per organization + supplier.
- Match result and exception reasons are persistable.
- Payable is one-to-one with the approved invoice.
- Payments cannot exceed outstanding.
- All approvals/payment state changes should be appended to the domain/audit stream in the persistent implementation.

## Tax
GST/tax code is carried as a configurable invoice-line field. The core does not hard-code a GST rate or tax treatment.
