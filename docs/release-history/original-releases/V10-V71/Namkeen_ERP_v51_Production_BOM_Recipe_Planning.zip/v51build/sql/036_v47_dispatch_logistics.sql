CREATE TABLE IF NOT EXISTS v47_transporter (
    transporter_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    name TEXT NOT NULL,
    gstin VARCHAR(15),
    phone TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(entity_id, name)
);
CREATE TABLE IF NOT EXISTS v47_vehicle (
    vehicle_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    vehicle_no TEXT NOT NULL,
    vehicle_no_normalized TEXT NOT NULL,
    vehicle_type TEXT NOT NULL DEFAULT 'TRUCK',
    capacity_kg NUMERIC(14,3),
    transporter_id BIGINT REFERENCES v47_transporter(transporter_id),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE(entity_id, vehicle_no_normalized)
);
CREATE TABLE IF NOT EXISTS v47_trip (
    trip_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    trip_no TEXT NOT NULL,
    transporter_id BIGINT NOT NULL REFERENCES v47_transporter(transporter_id),
    vehicle_id BIGINT NOT NULL REFERENCES v47_vehicle(vehicle_id),
    origin_warehouse_id BIGINT NOT NULL,
    ewb_no TEXT,
    status TEXT NOT NULL DEFAULT 'PLANNED',
    total_freight NUMERIC(14,2) NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ,
    delivered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(entity_id, trip_no)
);
CREATE TABLE IF NOT EXISTS v47_trip_load (
    load_id BIGSERIAL PRIMARY KEY,
    trip_id BIGINT NOT NULL REFERENCES v47_trip(trip_id),
    lpn_id BIGINT NOT NULL,
    invoice_id BIGINT NOT NULL,
    qty_kg NUMERIC(14,3) NOT NULL CHECK(qty_kg > 0),
    sequence_no INT NOT NULL,
    UNIQUE(trip_id, lpn_id)
);
CREATE TABLE IF NOT EXISTS v47_delivery (
    delivery_id BIGSERIAL PRIMARY KEY,
    trip_id BIGINT NOT NULL REFERENCES v47_trip(trip_id),
    invoice_id BIGINT NOT NULL,
    customer_id BIGINT NOT NULL,
    ordered_kg NUMERIC(14,3) NOT NULL CHECK(ordered_kg >= 0),
    delivered_kg NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK(delivered_kg >= 0),
    status TEXT NOT NULL DEFAULT 'PENDING',
    pod_type TEXT NOT NULL DEFAULT 'NONE',
    pod_ref TEXT,
    notes TEXT,
    delivered_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS v47_dispatch_events (
    event_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    trip_id BIGINT,
    delivery_id BIGINT,
    lpn_id BIGINT,
    event_type TEXT NOT NULL,
    client_event_id TEXT,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(entity_id, client_event_id)
);
CREATE TABLE IF NOT EXISTS v47_freight_charge (
    charge_id BIGSERIAL PRIMARY KEY,
    trip_id BIGINT NOT NULL REFERENCES v47_trip(trip_id),
    charge_type TEXT NOT NULL,
    amount NUMERIC(14,2) NOT NULL CHECK(amount >= 0),
    allocated_kg NUMERIC(14,3) NOT NULL DEFAULT 0,
    customer_id BIGINT,
    invoice_id BIGINT
);
CREATE INDEX IF NOT EXISTS idx_v47_trip_entity_status ON v47_trip(entity_id, status);
CREATE INDEX IF NOT EXISTS idx_v47_delivery_customer ON v47_delivery(customer_id, status);
CREATE INDEX IF NOT EXISTS idx_v47_dispatch_events_trip ON v47_dispatch_events(trip_id, created_at);
