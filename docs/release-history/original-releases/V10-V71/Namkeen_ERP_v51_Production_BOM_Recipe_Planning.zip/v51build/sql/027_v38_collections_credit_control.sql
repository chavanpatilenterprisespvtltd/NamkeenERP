-- Namkeen ERP v38: collections and credit-control extension
CREATE TABLE IF NOT EXISTS customer_credit_control (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  customer_id BIGINT NOT NULL,
  credit_limit NUMERIC(18,2) NOT NULL DEFAULT 0,
  outstanding NUMERIC(18,2) NOT NULL DEFAULT 0,
  overdue NUMERIC(18,2) NOT NULL DEFAULT 0,
  overdue_days INTEGER NOT NULL DEFAULT 0,
  credit_days INTEGER NOT NULL DEFAULT 0,
  block_threshold NUMERIC(18,2) NOT NULL DEFAULT 0,
  hard_block BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  effective_from DATE NOT NULL,
  effective_to DATE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_customer_credit_control_customer ON customer_credit_control(organization_id,entity_id,customer_id);

CREATE TABLE IF NOT EXISTS collection_target (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  salesperson_id BIGINT NOT NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  target_amount NUMERIC(18,2) NOT NULL,
  target_customers INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
);
CREATE INDEX IF NOT EXISTS ix_collection_target_salesperson_period ON collection_target(salesperson_id,period_start,period_end);

CREATE TABLE IF NOT EXISTS customer_collection_alert (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  customer_id BIGINT NOT NULL,
  level VARCHAR(20) NOT NULL,
  overdue_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  overdue_days INTEGER NOT NULL DEFAULT 0,
  triggered_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  acknowledged_at TIMESTAMPTZ,
  acknowledged_by BIGINT
);
CREATE INDEX IF NOT EXISTS ix_collection_alert_customer_level ON customer_collection_alert(organization_id,entity_id,customer_id,level,triggered_at);

CREATE TABLE IF NOT EXISTS collection_receipt_event (
  id BIGSERIAL PRIMARY KEY,
  receipt_id BIGINT NOT NULL,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  status VARCHAR(32) NOT NULL,
  actor_user_id BIGINT NOT NULL,
  evidence_document_id BIGINT,
  failure_reason TEXT,
  client_event_id UUID,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_collection_receipt_event_client ON collection_receipt_event(client_event_id) WHERE client_event_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS customer_credit_override (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  customer_id BIGINT NOT NULL,
  requested_by BIGINT NOT NULL,
  approved_by BIGINT,
  reason TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  created_on DATE NOT NULL,
  approved_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_customer_credit_override_customer ON customer_credit_override(organization_id,entity_id,customer_id,status);
