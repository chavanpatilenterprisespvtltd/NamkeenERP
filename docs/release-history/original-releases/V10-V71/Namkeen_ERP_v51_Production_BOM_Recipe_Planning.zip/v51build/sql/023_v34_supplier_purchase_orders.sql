-- v34 Supplier + Purchase Order schema (PostgreSQL)
CREATE TABLE IF NOT EXISTS suppliers (
  supplier_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  legal_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  gstin TEXT,
  pan TEXT,
  state_code TEXT,
  payment_terms_days INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE','BLOCKED')),
  contact_name TEXT, phone TEXT, email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_suppliers_org_status ON suppliers(organization_id,status);

CREATE TABLE IF NOT EXISTS supplier_quotations (
  quotation_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(supplier_id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  quoted_price_per_kg NUMERIC(18,6) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  valid_from DATE, valid_to DATE,
  moq_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  lead_time_days INTEGER NOT NULL DEFAULT 0,
  order_multiple_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  tax_code TEXT, attachment_id TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_supplier_quotes_lookup ON supplier_quotations(organization_id,supplier_id,sku_id,status);

CREATE TABLE IF NOT EXISTS supplier_rate_history (
  rate_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(supplier_id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  rate_per_kg NUMERIC(18,6) NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  source TEXT NOT NULL DEFAULT 'PURCHASE', reference_id BIGINT
);
CREATE INDEX IF NOT EXISTS ix_supplier_rate_history ON supplier_rate_history(organization_id,supplier_id,sku_id,effective_from DESC);

CREATE TABLE IF NOT EXISTS purchase_orders (
  po_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(supplier_id),
  warehouse_id BIGINT NOT NULL,
  po_number TEXT NOT NULL,
  order_date DATE NOT NULL,
  expected_date DATE,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  created_by BIGINT, approved_by BIGINT,
  client_event_id TEXT,
  rejection_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, po_number)
);
CREATE INDEX IF NOT EXISTS ix_po_supplier_status ON purchase_orders(organization_id,supplier_id,status);

CREATE TABLE IF NOT EXISTS purchase_order_lines (
  po_line_id BIGSERIAL PRIMARY KEY,
  po_id BIGINT NOT NULL REFERENCES purchase_orders(po_id) ON DELETE CASCADE,
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  ordered_qty_kg NUMERIC(18,6) NOT NULL,
  unit_price_per_kg NUMERIC(18,6) NOT NULL,
  expected_unit_price_per_kg NUMERIC(18,6),
  received_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  accepted_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  rejected_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_po_lines_po_sku ON purchase_order_lines(po_id,sku_id);

CREATE TABLE IF NOT EXISTS purchase_receipts (
  receipt_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  po_id BIGINT NOT NULL REFERENCES purchase_orders(po_id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(supplier_id),
  supplier_invoice_no TEXT,
  receipt_date DATE NOT NULL,
  qc_status TEXT NOT NULL DEFAULT 'HOLD',
  client_event_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS purchase_receipt_lines (
  receipt_line_id BIGSERIAL PRIMARY KEY,
  receipt_id BIGINT NOT NULL REFERENCES purchase_receipts(receipt_id) ON DELETE CASCADE,
  po_line_id BIGINT NOT NULL REFERENCES purchase_order_lines(po_line_id),
  received_qty_kg NUMERIC(18,6) NOT NULL,
  accepted_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  rejected_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  actual_unit_price_per_kg NUMERIC(18,6)
);

CREATE TABLE IF NOT EXISTS supplier_performance_snapshot (
  snapshot_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(supplier_id),
  snapshot_date DATE NOT NULL,
  receipts INTEGER NOT NULL DEFAULT 0,
  on_time_receipts INTEGER NOT NULL DEFAULT 0,
  ordered_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  received_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  accepted_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  avg_price_per_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  UNIQUE(organization_id,supplier_id,snapshot_date)
);
