-- v39: pricing, schemes, customer pricing and management-approved incentive policies.
CREATE TABLE IF NOT EXISTS pricing_policy (
  policy_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  sku_id BIGINT NOT NULL,
  customer_id BIGINT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE NULL,
  target_price NUMERIC(18,2) NOT NULL CHECK (target_price > 0),
  floor_price NUMERIC(18,2) NOT NULL CHECK (floor_price > 0),
  max_discount_pct NUMERIC(9,4) NOT NULL DEFAULT 0 CHECK (max_discount_pct BETWEEN 0 AND 100),
  approval_below_floor BOOLEAN NOT NULL DEFAULT TRUE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by BIGINT NOT NULL,
  approved_by BIGINT NULL,
  approved_at TIMESTAMPTZ NULL,
  version_no INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT pricing_policy_period_ck CHECK (effective_to IS NULL OR effective_to >= effective_from),
  CONSTRAINT pricing_policy_floor_ck CHECK (floor_price <= target_price)
);
CREATE INDEX IF NOT EXISTS ix_pricing_policy_effective ON pricing_policy(organization_id,entity_id,sku_id,customer_id,effective_from,effective_to,active);

CREATE TABLE IF NOT EXISTS customer_price_rule (
  rule_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  sku_id BIGINT NOT NULL,
  customer_id BIGINT NOT NULL,
  unit_price NUMERIC(18,2) NOT NULL CHECK (unit_price > 0),
  min_qty NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (min_qty >= 0),
  effective_from DATE NOT NULL,
  effective_to DATE NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  approved_by BIGINT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT customer_price_period_ck CHECK (effective_to IS NULL OR effective_to >= effective_from)
);
CREATE INDEX IF NOT EXISTS ix_customer_price_rule_lookup ON customer_price_rule(organization_id,entity_id,customer_id,sku_id,effective_from,effective_to,active);

CREATE TABLE IF NOT EXISTS sales_promotion (
  promotion_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  sku_id BIGINT NOT NULL,
  name TEXT NOT NULL,
  promo_type TEXT NOT NULL CHECK (promo_type IN ('PERCENT','AMOUNT_PER_UNIT','FIXED_UNIT_PRICE','BUY_X_GET_Y','CARTON_DISCOUNT')),
  value NUMERIC(18,6) NOT NULL DEFAULT 0,
  min_qty NUMERIC(18,6) NOT NULL DEFAULT 0,
  buy_qty NUMERIC(18,6) NOT NULL DEFAULT 0,
  get_qty NUMERIC(18,6) NOT NULL DEFAULT 0,
  max_discount_per_unit NUMERIC(18,2) NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  approved_by BIGINT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT promo_period_ck CHECK (end_date >= start_date)
);
CREATE INDEX IF NOT EXISTS ix_sales_promotion_active ON sales_promotion(organization_id,entity_id,sku_id,start_date,end_date,active);

CREATE TABLE IF NOT EXISTS incentive_policy (
  policy_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NULL,
  name TEXT NOT NULL,
  formula_type TEXT NOT NULL CHECK (formula_type IN ('PER_KG','PERCENT_SALES','PERCENT_MARGIN','COLLECTION','TARGET','COMBINED')),
  per_kg_rate NUMERIC(18,6) NOT NULL DEFAULT 0,
  sales_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
  margin_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
  collection_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
  target_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
  target_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  effective_from DATE NOT NULL,
  effective_to DATE NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  approved_by BIGINT NULL,
  approved_at TIMESTAMPTZ NULL,
  version_no INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT incentive_rates_ck CHECK (per_kg_rate >= 0 AND sales_pct >= 0 AND margin_pct >= 0 AND collection_pct >= 0 AND target_pct >= 0),
  CONSTRAINT incentive_period_ck CHECK (effective_to IS NULL OR effective_to >= effective_from)
);
CREATE INDEX IF NOT EXISTS ix_incentive_policy_effective ON incentive_policy(organization_id,entity_id,effective_from,effective_to,active);

CREATE TABLE IF NOT EXISTS incentive_run (
  run_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NULL,
  salesperson_id BIGINT NOT NULL,
  policy_id BIGINT NOT NULL REFERENCES incentive_policy(policy_id),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  eligible_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  eligible_sales NUMERIC(18,2) NOT NULL DEFAULT 0,
  eligible_margin NUMERIC(18,2) NOT NULL DEFAULT 0,
  verified_collections NUMERIC(18,2) NOT NULL DEFAULT 0,
  return_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  incentive_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'CALCULATED' CHECK (status IN ('CALCULATED','APPROVED','PAID','CANCELLED')),
  approved_by BIGINT NULL,
  approved_at TIMESTAMPTZ NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT incentive_run_period_ck CHECK (period_end >= period_start)
);
CREATE INDEX IF NOT EXISTS ix_incentive_run_salesperson_period ON incentive_run(organization_id,salesperson_id,period_start,period_end,status);

CREATE TABLE IF NOT EXISTS pricing_exception (
  exception_id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  sales_order_id BIGINT NULL,
  sku_id BIGINT NOT NULL,
  customer_id BIGINT NULL,
  requested_price NUMERIC(18,2) NOT NULL,
  floor_price NUMERIC(18,2) NOT NULL,
  reason TEXT NOT NULL,
  requested_by BIGINT NOT NULL,
  approved_by BIGINT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','EXPIRED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS ix_pricing_exception_open ON pricing_exception(organization_id,entity_id,status,created_at);
