-- Namkeen ERP v27: UOM, SKU pack/carton hierarchy and barcode master
CREATE TABLE IF NOT EXISTS uom_master (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    code VARCHAR(30) NOT NULL,
    name VARCHAR(100) NOT NULL,
    dimension VARCHAR(30) NOT NULL,
    base_code VARCHAR(30) NOT NULL,
    base_factor NUMERIC(24,9) NOT NULL CHECK (base_factor > 0),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (organization_id, code)
);
CREATE TABLE IF NOT EXISTS sku_uom_conversion (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    from_uom_code VARCHAR(30) NOT NULL,
    to_uom_code VARCHAR(30) NOT NULL,
    conversion_factor NUMERIC(24,9) NOT NULL CHECK (conversion_factor > 0),
    effective_from DATE NOT NULL,
    effective_to DATE NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (from_uom_code <> to_uom_code)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sku_uom_effective
ON sku_uom_conversion(organization_id, sku_id, from_uom_code, to_uom_code, effective_from);
CREATE TABLE IF NOT EXISTS sku_pack_hierarchy (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL UNIQUE,
    sales_uom_code VARCHAR(30) NOT NULL,
    pieces_per_pack NUMERIC(24,9) NOT NULL DEFAULT 1 CHECK (pieces_per_pack > 0),
    packs_per_carton NUMERIC(24,9) NOT NULL DEFAULT 1 CHECK (packs_per_carton > 0),
    net_weight_kg NUMERIC(24,9) NOT NULL CHECK (net_weight_kg > 0),
    kg_per_piece NUMERIC(24,9) NOT NULL CHECK (kg_per_piece > 0),
    effective_from DATE NOT NULL,
    effective_to DATE NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS barcode_master (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    barcode VARCHAR(128) NOT NULL,
    barcode_type VARCHAR(20) NOT NULL,
    entity_type VARCHAR(30) NOT NULL,
    entity_id BIGINT NOT NULL,
    sku_id BIGINT NULL,
    lot_id BIGINT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, barcode)
);
CREATE INDEX IF NOT EXISTS ix_barcode_entity ON barcode_master(organization_id, entity_type, entity_id);
CREATE INDEX IF NOT EXISTS ix_barcode_sku ON barcode_master(organization_id, sku_id);
CREATE INDEX IF NOT EXISTS ix_barcode_lot ON barcode_master(organization_id, lot_id);
