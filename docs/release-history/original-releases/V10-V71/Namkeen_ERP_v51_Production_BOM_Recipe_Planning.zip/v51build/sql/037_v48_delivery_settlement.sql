CREATE TABLE IF NOT EXISTS v48_delivery_settlement (
    settlement_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    delivery_id BIGINT NOT NULL,
    invoice_id BIGINT NOT NULL,
    ordered_kg NUMERIC(14,3) NOT NULL CHECK(ordered_kg >= 0),
    delivered_kg NUMERIC(14,3) NOT NULL CHECK(delivered_kg >= 0),
    failed_kg NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK(failed_kg >= 0),
    returned_kg NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK(returned_kg >= 0),
    status TEXT NOT NULL DEFAULT 'OPEN',
    variance_reason TEXT,
    approved_by BIGINT,
    approved_at TIMESTAMPTZ,
    posted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(entity_id, delivery_id)
);
CREATE TABLE IF NOT EXISTS v48_delivery_exception (
    exception_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    settlement_id BIGINT NOT NULL REFERENCES v48_delivery_settlement(settlement_id),
    exception_type TEXT NOT NULL,
    qty_kg NUMERIC(14,3) NOT NULL CHECK(qty_kg > 0),
    reason TEXT NOT NULL,
    evidence_ref TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS v48_customer_adjustment (
    adjustment_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    invoice_id BIGINT NOT NULL,
    customer_id BIGINT NOT NULL,
    kind TEXT NOT NULL,
    amount NUMERIC(14,2) NOT NULL CHECK(amount >= 0),
    reason TEXT NOT NULL,
    approved BOOLEAN NOT NULL DEFAULT FALSE,
    posted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS v48_freight_settlement (
    freight_settlement_id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL,
    trip_id BIGINT NOT NULL,
    freight_amount NUMERIC(14,2) NOT NULL CHECK(freight_amount >= 0),
    delivered_kg NUMERIC(14,3) NOT NULL CHECK(delivered_kg > 0),
    freight_per_kg NUMERIC(14,4) NOT NULL,
    approved BOOLEAN NOT NULL DEFAULT FALSE,
    posted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(entity_id, trip_id)
);
CREATE INDEX IF NOT EXISTS idx_v48_settlement_entity_status ON v48_delivery_settlement(entity_id,status);
CREATE INDEX IF NOT EXISTS idx_v48_adjustment_entity_invoice ON v48_customer_adjustment(entity_id,invoice_id);
