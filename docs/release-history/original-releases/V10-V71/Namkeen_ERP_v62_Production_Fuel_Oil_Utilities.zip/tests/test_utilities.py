from datetime import datetime
import sys
sys.path.insert(0, '/mnt/data/v62build/src')
from utilities import *

def test_oil_usage_and_shortfall():
    o=OilLot('O1','PALM',100,100)
    e=record_oil_usage(o,30,'B1')
    assert o.current_qty_kg==70 and e.event_type=='USED'
    try: record_oil_usage(o,80,'B2'); assert False
    except ValueError as ex: assert str(ex)=='OIL_STOCK_SHORTFALL'

def test_tpc_gate():
    o=OilLot('O2','OIL',50,50)
    record_tpc(o,24.9)
    assert validate_frying_use(o,UtilityPolicy(oil_tpc_limit_pct=25.0))==[]
    record_tpc(o,25.0)
    assert 'TPC_LIMIT_EXCEEDED' in validate_frying_use(o,UtilityPolicy(oil_tpc_limit_pct=25.0))

def test_tpc_required():
    o=OilLot('O3','OIL',20,20)
    assert 'TPC_CHECK_REQUIRED' in validate_frying_use(o,UtilityPolicy(require_tpc_before_continuing_fry=True))

def test_filter():
    o=OilLot('O4','OIL',100,100)
    e=record_filter(o,85)
    assert o.current_qty_kg==85 and o.filter_cycle_count==1 and e.event_type=='FILTERED'

def test_meter_delta():
    m=UtilityMeter('M1',UtilityType.ELECTRICITY,'S1',1000,1125,'kWh')
    assert meter_delta(m)==125

def test_meter_bad_reading():
    m=UtilityMeter('M2',UtilityType.ELECTRICITY,'S1',1000,900,'kWh')
    try: meter_delta(m); assert False
    except ValueError as ex: assert str(ex)=='METER_ROLLOVER_OR_BAD_READING'

def test_runtime_allocation():
    assert allocate_by_runtime(100,30,120)==25

def test_output_allocation():
    assert allocate_by_output(100,2000,10000)==20

def test_cost():
    r=allocate_utility_cost(UtilityType.DIESEL,50,95,'PRODUCTION_BATCH','B1',AllocationMethod.DIRECT)
    assert r.cost==4750

def test_reconcile():
    rs=[allocate_utility_cost(UtilityType.WOOD,50,5,'PRODUCTION_BATCH','B1',AllocationMethod.OUTPUT_KG), allocate_utility_cost(UtilityType.WOOD,10,5,'PRODUCTION_BATCH','B1',AllocationMethod.OUTPUT_KG)]
    x=reconcile_utility_consumption(rs,60)
    assert x['variance_qty']==0 and x['within_tolerance']

def test_batch_cost():
    rs=[allocate_utility_cost(UtilityType.ELECTRICITY,100,8,'PRODUCTION_BATCH','B1',AllocationMethod.METER_DELTA), allocate_utility_cost(UtilityType.WOOD,40,6,'PRODUCTION_BATCH','B1',AllocationMethod.OUTPUT_KG), allocate_utility_cost(UtilityType.WOOD,10,6,'PRODUCTION_BATCH','B2',AllocationMethod.OUTPUT_KG)]
    assert batch_utility_costs(rs,'B1')==1040
