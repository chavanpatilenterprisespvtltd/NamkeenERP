# Namkeen ERP v62 — Fuel, Oil, Furnace & Utilities Management

## Purpose
Connect factory fuel/oil/utilities consumption to production batches and v50 actual costing while preserving server-authoritative inventory and cost posting.

## Scope
- Fuel/wood/diesel/LPG/natural-gas receipt records
- Fuel lot and unit-cost capture
- Batch/machine fuel consumption
- Frying-oil lot lifecycle
- Oil usage, filtering and TPC history
- Configurable TPC gate (not hard-coded by law)
- Furnace/heating runtime
- Electricity/generator/utility meter readings
- Meter delta validation
- Runtime/output/meter-based batch allocation
- Utility-cost reconciliation
- Batch-level utility cost feed into v50 actual costing
- Evidence/client_event_id support for offline mobile capture
- PostgreSQL migration `051_v62_fuel_oil_utilities.sql`

## Key controls
- No negative fuel/oil consumption
- No use of quarantined/disposed oil
- Optional mandatory TPC-before-frying gate
- Configurable oil TPC limit
- Negative meter deltas rejected
- Utility consumption is allocated, not silently written into batch cost
- Final cost posting remains in the authoritative costing/transaction service

## v50 integration
v62 produces batch utility-cost records that can be included in the v50 actual-cost components. Historical posted batch cost is never rewritten merely because a new rate or allocation rule is configured.

## Validation
Focused v62 tests cover oil stock/use, TPC, filtering, meter readings, allocation methods, reconciliation and batch costing inputs.
