# Namkeen ERP v28 — Barcode-Driven Warehouse Operations

v28 extends the v27 UOM/SKU/barcode foundation into controlled scanner-based warehouse operations.

## Added
- Organization-scoped barcode resolution
- Scan actions: RECEIVE, ISSUE, TRANSFER, PICK, DISPATCH, COUNT, VERIFY_LOT
- Scan validation and normalized UOM/weight preview
- Lot/warehouse checks for outbound operations
- Scan event/audit bridge with actor and client_event_id
- PostgreSQL migration 017_v28_barcode_warehouse_operations.sql
- FastAPI endpoints:
  - GET /v28/barcodes/resolve
  - POST /v28/barcodes/scan
- Android v28 workflow contract for camera/wedge scanning and offline queueing
- Explicit boundary: scans do not bypass stock/approval/QC/accounting services

## Validation
Run:

    pytest -q

Live PostgreSQL integration is environment-dependent; unit and contract tests are included.
