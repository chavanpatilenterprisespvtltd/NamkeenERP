-- v69 Production Operations / DR / Observability
CREATE TABLE IF NOT EXISTS ops_backup (
  backup_id uuid PRIMARY KEY,
  organization_id uuid NOT NULL,
  site_id uuid,
  started_at timestamptz NOT NULL,
  completed_at timestamptz,
  status varchar(20) NOT NULL,
  object_ref text,
  sha256 char(64),
  size_bytes bigint,
  encryption_key_ref text,
  restore_verified_at timestamptz,
  retention_until timestamptz,
  created_by uuid,
  CHECK (status IN ('STARTED','SUCCEEDED','FAILED','VERIFIED'))
);
CREATE INDEX IF NOT EXISTS ix_ops_backup_org_status ON ops_backup(organization_id,status,started_at DESC);

CREATE TABLE IF NOT EXISTS ops_job_run (
  job_id uuid PRIMARY KEY,
  organization_id uuid,
  job_type varchar(80) NOT NULL,
  status varchar(20) NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  started_at timestamptz,
  completed_at timestamptz,
  last_error text,
  next_run_at timestamptz,
  CHECK (status IN ('QUEUED','RUNNING','SUCCEEDED','FAILED','DEAD_LETTER'))
);
CREATE INDEX IF NOT EXISTS ix_ops_job_status_next ON ops_job_run(status,next_run_at);

CREATE TABLE IF NOT EXISTS ops_alert (
  alert_id uuid PRIMARY KEY,
  organization_id uuid,
  severity varchar(20) NOT NULL,
  source varchar(80) NOT NULL,
  message text NOT NULL,
  created_at timestamptz NOT NULL,
  acknowledged_at timestamptz,
  acknowledged_by uuid
);
CREATE INDEX IF NOT EXISTS ix_ops_alert_open ON ops_alert(organization_id,severity,created_at DESC) WHERE acknowledged_at IS NULL;

CREATE TABLE IF NOT EXISTS ops_metric_sample (
  sample_id bigserial PRIMARY KEY,
  organization_id uuid,
  metric_name varchar(120) NOT NULL,
  metric_value numeric(20,6) NOT NULL,
  collected_at timestamptz NOT NULL,
  dimensions jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS ix_ops_metric_lookup ON ops_metric_sample(organization_id,metric_name,collected_at DESC);
