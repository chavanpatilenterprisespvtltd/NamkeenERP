# Namkeen ERP v69 — Production Operations, Backup/DR & Observability

v69 hardens the ERP for operational deployment after the functional stack through v68.

## Scope
- PostgreSQL backup metadata and retention tracking
- Encrypted/off-site backup policy
- Restore-verification status
- RPO/RTO targets and recovery runbook
- Health/readiness checks
- Structured operations metrics
- Background-job monitoring and dead-letter visibility
- Operational alert model
- Backup integrity hashing
- Role-scoped operations API contract
- PostgreSQL migration `058_v69_production_ops.sql`

## Important
This package provides the production operations control plane and contracts. Actual cloud/off-site object storage, PostgreSQL PITR/WAL archiving, SMTP/SMS/pager notifications, Prometheus scraping, and restore execution must be configured in the deployment environment.

Run tests:
`python -m unittest discover -s tests -v`
