API_V69 = {
    '/v69/health/live':'GET',
    '/v69/health/ready':'GET',
    '/v69/ops/metrics':'GET',
    '/v69/ops/backups':'GET',
    '/v69/ops/backups/{backup_id}/verify':'POST',
    '/v69/ops/jobs':'GET',
    '/v69/ops/alerts':'GET',
    '/v69/ops/alerts/{alert_id}/ack':'POST',
}

ROLE_ACCESS = {
    'MANAGEMENT': {'metrics','backups','jobs','alerts'},
    'SYSTEM_ADMIN': {'metrics','backups','jobs','alerts'},
    'ACCOUNTS': {'metrics'},
    'FACTORY': {'metrics'},
}
