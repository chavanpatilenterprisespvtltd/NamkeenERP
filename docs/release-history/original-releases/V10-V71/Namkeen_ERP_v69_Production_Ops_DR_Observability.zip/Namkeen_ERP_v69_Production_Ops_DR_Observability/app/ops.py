from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from enum import Enum
from hashlib import sha256
from pathlib import Path
from typing import Iterable
import json


def now(): return datetime.now(timezone.utc)

class BackupStatus(str, Enum):
    STARTED='STARTED'; SUCCEEDED='SUCCEEDED'; FAILED='FAILED'; VERIFIED='VERIFIED'
class JobStatus(str, Enum):
    QUEUED='QUEUED'; RUNNING='RUNNING'; SUCCEEDED='SUCCEEDED'; FAILED='FAILED'; DEAD_LETTER='DEAD_LETTER'

@dataclass
class BackupRecord:
    backup_id: str
    started_at: str
    completed_at: str|None
    status: str
    object_ref: str|None
    sha256: str|None
    size_bytes: int|None
    encryption_key_ref: str|None
    restore_verified_at: str|None = None
    retention_until: str|None = None

@dataclass
class JobRun:
    job_id: str
    job_type: str
    status: str
    attempts: int
    started_at: str|None = None
    completed_at: str|None = None
    last_error: str|None = None

@dataclass
class Alert:
    alert_id: str
    severity: str
    source: str
    message: str
    created_at: str
    acknowledged_at: str|None = None

class OpsStore:
    def __init__(self):
        self.backups:list[BackupRecord]=[]; self.jobs:list[JobRun]=[]; self.alerts:list[Alert]=[]; self.audit=[]
    def record_backup(self, rec: BackupRecord): self.backups.append(rec); self.audit.append(('backup', rec.backup_id))
    def record_job(self, job: JobRun): self.jobs.append(job); self.audit.append(('job', job.job_id))
    def alert(self, alert: Alert): self.alerts.append(alert); self.audit.append(('alert', alert.alert_id))


def hash_file(path: str|Path) -> tuple[str,int]:
    h=sha256(); n=0
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk); n += len(chunk)
    return h.hexdigest(), n

def verify_hash(path, expected):
    actual,_=hash_file(path); return actual==expected

def backup_manifest(rec: BackupRecord) -> str:
    return json.dumps(asdict(rec), sort_keys=True, separators=(',',':'))

def retention_cutoff(days:int, from_dt=None):
    from_dt = from_dt or now(); return from_dt - timedelta(days=days)

class HealthService:
    def __init__(self, db_check, storage_check, worker_check):
        self.db_check=db_check; self.storage_check=storage_check; self.worker_check=worker_check
    def live(self): return {'status':'ok','time':now().isoformat()}
    def ready(self):
        checks={'database':bool(self.db_check()),'storage':bool(self.storage_check()),'worker':bool(self.worker_check())}
        return {'status':'ready' if all(checks.values()) else 'not_ready','checks':checks,'time':now().isoformat()}

def metrics_snapshot(store: OpsStore):
    return {
        'backups_succeeded':sum(b.status in ('SUCCEEDED','VERIFIED') for b in store.backups),
        'backups_failed':sum(b.status=='FAILED' for b in store.backups),
        'jobs_running':sum(j.status=='RUNNING' for j in store.jobs),
        'jobs_failed':sum(j.status=='FAILED' for j in store.jobs),
        'jobs_dead_letter':sum(j.status=='DEAD_LETTER' for j in store.jobs),
        'unacknowledged_alerts':sum(a.acknowledged_at is None for a in store.alerts),
    }
