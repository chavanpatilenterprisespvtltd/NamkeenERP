import tempfile
from pathlib import Path
from app.ops import OpsStore, BackupRecord, JobRun, Alert, hash_file, verify_hash, HealthService, metrics_snapshot, retention_cutoff

def test_backup_hash_and_verify():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'namkeen-erp-v69')
        p=f.name
    digest,size=hash_file(p)
    assert size==16 and verify_hash(p,digest)

def test_health_and_metrics():
    store=OpsStore()
    store.record_backup(BackupRecord('b','2026-01-01',None,'SUCCEEDED',None,None,None,None))
    store.record_job(JobRun('j','outbox','DEAD_LETTER',3))
    store.alert(Alert('a','CRITICAL','backup','failed','2026-01-01'))
    hs=HealthService(lambda:1,lambda:1,lambda:1)
    assert hs.live()['status']=='ok'
    assert hs.ready()['status']=='ready'
    m=metrics_snapshot(store)
    assert m['backups_succeeded']==1 and m['jobs_dead_letter']==1 and m['unacknowledged_alerts']==1

def test_retention_cutoff():
    c=retention_cutoff(30); assert c is not None
