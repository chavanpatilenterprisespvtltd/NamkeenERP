# v69 Production Operations Runbook

## Backup
1. Execute encrypted PostgreSQL full backup nightly and incrementals/WAL every 30 minutes.
2. Record backup id, object location, SHA-256, size, encryption key reference and retention date.
3. Replicate to off-site storage.
4. Mark `VERIFIED` only after restore validation succeeds in an isolated environment.

## Recovery
- Target RPO: 30 minutes.
- Target RTO: 4 hours.
- Restore database first, then object/document storage, then re-enable workers.
- Re-run idempotent outbox/sync jobs after cutover.

## Monitoring
Track liveness, readiness, DB/storage/worker health, backup success, job latency, failed/dead-letter jobs, sync dead letters, accounting outbox failures, storage capacity and unacknowledged critical alerts.

## Security
- Encrypt backups at rest and in transit.
- Do not place DB passwords, Tally credentials, IRP credentials or object-store secrets in source control or Android clients.
- Audit backup/restore actions and alert acknowledgements.

## Drill
At least periodically, execute a restore drill and record duration, recovered point, validation checks and issues. A backup is not considered operationally valid until restore is verified.
