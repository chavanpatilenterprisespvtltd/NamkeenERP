import sys
from datetime import datetime, timedelta
sys.path.insert(0,'src')
from labour import *

def test_employee_and_shift_validation():
    e=Employee('E1','OP01','Operator','FRYER',hourly_rate=100)
    validate_employee(e)
    s=Shift('S1','SITE1','A',datetime(2026,1,1,8),datetime(2026,1,1,16))
    assert calculate_shift_hours(s)==8.0

def test_attendance_requires_times():
    a=Attendance('A1','E1','S1',AttendanceStatus.PRESENT)
    try: validate_attendance(a); assert False
    except ValueError as ex: assert str(ex)=='ATTENDANCE_TIME_REQUIRED'

def test_regular_and_overtime_hours():
    st=datetime(2026,1,1,8); en=st+timedelta(hours=10)
    assert derive_hours(st,en)==(8.0,2.0)

def test_labour_cost_requires_approval():
    e=Employee('E1','OP01','Operator','PACK',hourly_rate=100,overtime_multiplier=1.5)
    a=LabourAssignment('L1','E1','B1','PACK',datetime(2026,1,1,8))
    close_assignment(a,datetime(2026,1,1,18)); approve_assignment(a)
    c=calculate_labour_cost(a,e)
    assert c.regular_cost==800 and c.overtime_cost==300 and c.total_cost==1100

def test_productivity():
    e=Employee('E1','OP01','Operator','PACK',hourly_rate=100)
    a=LabourAssignment('L1','E1','B1','PACK',datetime(2026,1,1,8)); close_assignment(a,datetime(2026,1,1,12)); approve_assignment(a)
    c=calculate_labour_cost(a,e)
    p=batch_productivity('B1',800,[c],[a])
    assert p.labour_hours==4 and p.kg_per_labour_hour==200 and p.labour_cost_per_kg==0.5

def test_allocation():
    assert allocate_labour_cost_to_batch(1000,500,1000)==500
