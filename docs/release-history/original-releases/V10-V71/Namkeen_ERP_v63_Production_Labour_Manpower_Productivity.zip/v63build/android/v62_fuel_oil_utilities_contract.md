# v62 Android Contract — Fuel / Oil / Utilities

Offline-capable screens:
- Fuel receipt evidence
- Fuel consumption entry
- Oil lot status and usage
- TPC check capture
- Oil filtering event
- Furnace runtime
- Utility meter reading
- Batch utility allocation preview
- Reconciliation / approval queue

Server authoritative:
- Stock balance and fuel issue posting
- Oil usability/TPC gate
- Meter validation
- Cost allocation approval
- Batch costing posting

Every offline write uses `client_event_id`, device/user identity and captured timestamp. Photos/evidence are queued separately and are hashed before upload.
