# v63 Android Labour / Manpower Contract

Offline-capable factory workflows:
- employee/operator lookup
- shift open/close
- attendance capture with optional GPS/photo evidence
- batch/process-stage labour assignment
- check-in/check-out hours capture
- overtime calculation preview
- supervisor approval queue
- productivity dashboard

Rules:
- server is authoritative for employee status, rates, approval and final labour cost
- offline events carry client_event_id and are idempotent on sync
- device must not directly post v50 costing entries
- final approved labour cost is emitted as a controlled costing input
