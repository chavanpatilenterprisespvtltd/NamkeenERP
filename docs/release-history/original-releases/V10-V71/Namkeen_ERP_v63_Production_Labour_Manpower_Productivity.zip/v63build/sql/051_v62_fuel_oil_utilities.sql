-- Namkeen ERP v62: fuel, frying oil and utilities management
CREATE TABLE IF NOT EXISTS utility_meter (
  meter_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  site_id UUID NOT NULL,
  utility_type TEXT NOT NULL,
  meter_code TEXT NOT NULL,
  uom TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (organization_id, meter_code)
);

CREATE TABLE IF NOT EXISTS utility_meter_reading (
  reading_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  meter_id UUID NOT NULL REFERENCES utility_meter(meter_id),
  reading_at TIMESTAMPTZ NOT NULL,
  opening_reading NUMERIC(18,6),
  closing_reading NUMERIC(18,6) NOT NULL,
  delta_qty NUMERIC(18,6) NOT NULL,
  source TEXT NOT NULL,
  evidence_ref TEXT,
  client_event_id TEXT,
  UNIQUE (organization_id, meter_id, reading_at)
);

CREATE TABLE IF NOT EXISTS fuel_receipt (
  receipt_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  fuel_type TEXT NOT NULL,
  lot_no TEXT,
  supplier_id UUID,
  qty NUMERIC(18,6) NOT NULL,
  uom TEXT NOT NULL,
  unit_cost NUMERIC(18,6) NOT NULL,
  received_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'POSTED'
);

CREATE TABLE IF NOT EXISTS fuel_consumption (
  consumption_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  fuel_type TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_id UUID NOT NULL,
  lot_no TEXT,
  qty NUMERIC(18,6) NOT NULL,
  uom TEXT NOT NULL,
  unit_cost NUMERIC(18,6) NOT NULL,
  allocated_cost NUMERIC(18,6) NOT NULL,
  allocation_method TEXT NOT NULL,
  client_event_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS oil_lot (
  oil_lot_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  site_id UUID NOT NULL,
  oil_type TEXT NOT NULL,
  supplier_lot_no TEXT,
  opening_qty_kg NUMERIC(18,6) NOT NULL,
  current_qty_kg NUMERIC(18,6) NOT NULL,
  status TEXT NOT NULL,
  current_tpc_pct NUMERIC(8,4),
  last_tpc_at TIMESTAMPTZ,
  filter_cycle_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS oil_event (
  event_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  oil_lot_id UUID NOT NULL REFERENCES oil_lot(oil_lot_id),
  event_type TEXT NOT NULL,
  qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
  tpc_pct NUMERIC(8,4),
  source_type TEXT,
  source_id UUID,
  evidence_ref TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS furnace_run (
  run_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  site_id UUID NOT NULL,
  asset_id UUID NOT NULL,
  batch_id UUID,
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  runtime_minutes NUMERIC(18,4),
  fuel_qty NUMERIC(18,6),
  fuel_uom TEXT,
  fuel_cost NUMERIC(18,6)
);

CREATE TABLE IF NOT EXISTS batch_utility_allocation (
  allocation_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  batch_id UUID NOT NULL,
  utility_type TEXT NOT NULL,
  qty NUMERIC(18,6) NOT NULL,
  uom TEXT NOT NULL,
  unit_cost NUMERIC(18,6) NOT NULL,
  allocated_cost NUMERIC(18,6) NOT NULL,
  allocation_method TEXT NOT NULL,
  approved BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_oil_lot_site_status ON oil_lot(organization_id, site_id, status);
CREATE INDEX IF NOT EXISTS ix_oil_event_lot_time ON oil_event(organization_id, oil_lot_id, created_at);
CREATE INDEX IF NOT EXISTS ix_fuel_consumption_source ON fuel_consumption(organization_id, source_type, source_id);
CREATE INDEX IF NOT EXISTS ix_batch_utility_allocation_batch ON batch_utility_allocation(organization_id, batch_id);
