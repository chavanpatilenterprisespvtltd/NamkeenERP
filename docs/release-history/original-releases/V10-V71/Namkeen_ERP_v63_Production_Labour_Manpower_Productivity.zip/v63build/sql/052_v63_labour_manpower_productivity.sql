-- Namkeen ERP v63 — Labour, Manpower, Shifts & Productivity
CREATE TABLE IF NOT EXISTS employee_master (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    employee_code VARCHAR(50) NOT NULL,
    name VARCHAR(200) NOT NULL,
    role_code VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    home_site_id BIGINT,
    hourly_rate NUMERIC(14,4) NOT NULL DEFAULT 0,
    overtime_multiplier NUMERIC(8,4) NOT NULL DEFAULT 1.5,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (organization_id, employee_code)
);

CREATE TABLE IF NOT EXISTS shift_master (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    shift_code VARCHAR(40) NOT NULL,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    supervisor_employee_id BIGINT,
    UNIQUE (organization_id, site_id, shift_code, starts_at)
);

CREATE TABLE IF NOT EXISTS attendance_record (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    shift_id BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL,
    check_in TIMESTAMPTZ,
    check_out TIMESTAMPTZ,
    photo_ref TEXT,
    gps_lat NUMERIC(10,7),
    gps_lon NUMERIC(10,7),
    note TEXT,
    client_event_id UUID,
    UNIQUE (organization_id, client_event_id)
);

CREATE TABLE IF NOT EXISTS labour_assignment (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    shift_id BIGINT,
    production_batch_id BIGINT NOT NULL,
    process_stage VARCHAR(100) NOT NULL,
    started_at TIMESTAMPTZ NOT NULL,
    ended_at TIMESTAMPTZ,
    regular_hours NUMERIC(12,4) NOT NULL DEFAULT 0,
    overtime_hours NUMERIC(12,4) NOT NULL DEFAULT 0,
    approved BOOLEAN NOT NULL DEFAULT FALSE,
    client_event_id UUID,
    UNIQUE (organization_id, client_event_id)
);

CREATE TABLE IF NOT EXISTS labour_cost_allocation (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    labour_assignment_id BIGINT NOT NULL UNIQUE,
    production_batch_id BIGINT NOT NULL,
    regular_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
    overtime_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
    total_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
    posted_to_costing BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_labour_assignment_batch ON labour_assignment (organization_id, production_batch_id);
CREATE INDEX IF NOT EXISTS idx_attendance_employee_shift ON attendance_record (organization_id, employee_id, shift_id);
CREATE INDEX IF NOT EXISTS idx_labour_cost_batch ON labour_cost_allocation (organization_id, production_batch_id);
