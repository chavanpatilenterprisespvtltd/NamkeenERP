# Namkeen ERP v33 — Production Procurement Planning

v33 adds the demand/reorder planning layer on top of v32 warehouse intelligence.

Core capabilities:
- Demand horizon inputs
- Current available stock + safety stock
- Open PO and open-production supply offsets
- Supplier SKU lead times
- MOQ and order multiples
- Supplier ranking
- Purchase suggestions
- Make-to-stock production requirements
- Critical condition when no supplier term exists
- Approval-controlled planning records

Planning never posts a PO or production batch by itself.

Validation is run with the inherited v13-v32 suite plus v33 tests.
