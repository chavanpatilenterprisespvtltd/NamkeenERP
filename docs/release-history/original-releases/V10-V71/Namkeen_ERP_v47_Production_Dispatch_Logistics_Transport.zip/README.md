# Namkeen ERP v47 — Dispatch Logistics & Transport Management

Builds on v46 government-document integration and adds the physical dispatch execution layer.

## Scope
- Transporter and vehicle masters with entity isolation
- Trip planning and controlled trip state machine
- E-way bill reference carried into trip/departure
- Carton/LPN load scanning contract
- Delivery queue and partial/failed delivery states
- Proof-of-delivery reference with photo/signature/OTP/GPS types
- Freight charge model and per-kg calculation helper
- Dispatch event audit with offline `client_event_id` idempotency
- Android workflow contract
- PostgreSQL migration `036_v47_dispatch_logistics.sql`

## Control boundary
ERP inventory and invoices remain authoritative. A delivery/POD record cannot itself alter stock or receivables; it must invoke the existing authoritative posting services. Binary evidence is stored via the existing secure document abstraction and referenced by hash/id.

## State flow
Trip: `PLANNED → LOADING → LOADED → IN_TRANSIT → DELIVERED`

Delivery: `PENDING → OUT_FOR_DELIVERY → PARTIALLY_DELIVERED / DELIVERED / FAILED / RETURNED`

Load rule: trip must be loaded before departure. Delivery quantity cannot exceed the ordered quantity. Trip close is blocked while deliveries are open.

## Validation
Run `pytest -q` from package root. v47-specific tests validate vehicle normalization, trip lifecycle, load controls, POD evidence, open-delivery close blocking and freight calculation.

Live PostgreSQL/Tally/IRP/EWB execution remains deployment/UAT work.
