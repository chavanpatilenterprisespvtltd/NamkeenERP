# Namkeen ERP v29 — Production License-Plate / Carton Tracking

Builds on v28 barcode/UOM warehouse operations and adds carton-level LPN tracking.

## Added
- Physical carton/license-plate master
- Carton contents tied to SKU + lot + expiry + UOM + kg
- LPN status lifecycle
- Seal/open/pick/dispatch controls
- Warehouse movement support
- FEFO-aware LPN ordering
- Immutable LPN event table with offline idempotency
- Optional parent LPN for future pallet hierarchy
- Android v29 scanner workflow shell
- PostgreSQL migration 018

## Boundary
LPN tracking is a physical-container layer. Inventory ledger remains authoritative for accounting stock, and all movements continue through server-side business controls.
