# Namkeen ERP v15 — Production PostgreSQL Integration

v15 is the next step after v14. It concretely wires the production foundations to PostgreSQL instead of leaving them only as interfaces.

### Main additions
- Concrete PostgreSQL repository for authentication/device/session creation, sync-event persistence and database notification outbox.
- Authenticated FastAPI routes with bearer-token validation and organization scope checks.
- Persistent integration-run ledger with idempotency and request/response hashes for accounting adapters such as Tally.
- PostgreSQL migration `005_v15_hardening.sql`.
- PostgreSQL development compose file.
- Startup database check.
- Integration tests for idempotency/model loading.

### Important
This is not yet a claim of live production deployment. A real customer deployment still needs actual PostgreSQL, secrets, refresh-session validation, encrypted object storage, mobile sync UAT, notification provider configuration, Tally UAT, load/security testing, backup/restore and operational monitoring.
