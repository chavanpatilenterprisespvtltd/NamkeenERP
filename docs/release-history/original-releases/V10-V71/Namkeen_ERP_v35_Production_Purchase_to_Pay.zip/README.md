# Namkeen ERP v35 — Purchase-to-Pay

v35 extends v34 supplier/PO/GRN controls into Accounts and supplier payables.

## Added
- Supplier invoice master and duplicate invoice control
- PO → GRN → invoice 3-way match
- Configurable quantity, price and amount tolerances
- Explicit match exceptions with reasons
- Exception approval gate before payable release
- Supplier payable creation and due-date tracking
- Partial supplier payments and outstanding balance tracking
- Payment scheduling with configurable supported modes
- PostgreSQL migration `024_v35_purchase_to_pay.sql`
- FastAPI match endpoint `/v35/purchase-invoices/three-way-match`
- Android P2P workflow contract
- Tally/other accounting adapters remain downstream of approved payable/payment events

## Control boundaries
Invoice entry does not directly change inventory. GRN + incoming QC remain authoritative for stock. Payables and payments require Accounts/authorized approval and remain auditable.

## Validation
v35 targeted unit/API tests are added. The build also reruns the inherited suite. Live PostgreSQL execution is not claimed unless a PostgreSQL instance is available in the build environment.
