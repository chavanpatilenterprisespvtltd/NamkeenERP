-- v42: accounting delivery lifecycle, retry/dead-letter observability
ALTER TABLE accounting_outbox_v41 ADD COLUMN IF NOT EXISTS processing_started_at TIMESTAMPTZ;
ALTER TABLE accounting_outbox_v41 ADD COLUMN IF NOT EXISTS posted_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_v42_outbox_ready ON accounting_outbox_v41 (organization_id, status, available_at, id);
CREATE INDEX IF NOT EXISTS idx_v42_outbox_dead ON accounting_outbox_v41 (organization_id, status, id);
