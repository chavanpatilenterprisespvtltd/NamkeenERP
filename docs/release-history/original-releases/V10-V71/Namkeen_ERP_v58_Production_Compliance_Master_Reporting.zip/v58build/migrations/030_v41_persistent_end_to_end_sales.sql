-- v41: authoritative persistent end-to-end sales posting layer
CREATE TABLE IF NOT EXISTS persistent_sales_txn_runs (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  order_id BIGINT NOT NULL REFERENCES sales_orders(id),
  order_no VARCHAR(60) NOT NULL,
  idempotency_key VARCHAR(160),
  state VARCHAR(40) NOT NULL,
  invoice_id BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMPTZ,
  CONSTRAINT uq_v41_txn_idem UNIQUE (organization_id,idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_v41_txn_order ON persistent_sales_txn_runs(organization_id,entity_id,order_no);
CREATE INDEX IF NOT EXISTS idx_v41_txn_state ON persistent_sales_txn_runs(organization_id,state);

CREATE TABLE IF NOT EXISTS sales_invoices_v41 (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  order_id BIGINT NOT NULL REFERENCES sales_orders(id),
  customer_id BIGINT NOT NULL REFERENCES customers(id),
  invoice_no VARCHAR(60) NOT NULL,
  taxable_total NUMERIC(18,2) NOT NULL,
  tax_total NUMERIC(18,2) NOT NULL,
  grand_total NUMERIC(18,2) NOT NULL,
  status VARCHAR(30) NOT NULL,
  posted_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_v41_invoice_no UNIQUE (organization_id,invoice_no)
);
CREATE TABLE IF NOT EXISTS sales_invoice_lines_v41 (
  id BIGSERIAL PRIMARY KEY,
  invoice_id BIGINT NOT NULL REFERENCES sales_invoices_v41(id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  qty_kg NUMERIC(18,3) NOT NULL,
  unit_price NUMERIC(18,2) NOT NULL,
  taxable_value NUMERIC(18,2) NOT NULL,
  tax_amount NUMERIC(18,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS customer_receivables_v41 (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  customer_id BIGINT NOT NULL REFERENCES customers(id),
  invoice_id BIGINT NOT NULL UNIQUE REFERENCES sales_invoices_v41(id),
  original_amount NUMERIC(18,2) NOT NULL,
  outstanding_amount NUMERIC(18,2) NOT NULL,
  status VARCHAR(30) NOT NULL,
  due_date TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS receipt_allocations_v41 (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  payment_id BIGINT NOT NULL REFERENCES payments(id),
  receivable_id BIGINT NOT NULL REFERENCES customer_receivables_v41(id),
  amount NUMERIC(18,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS accounting_outbox_v41 (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  transaction_run_id BIGINT NOT NULL REFERENCES persistent_sales_txn_runs(id),
  integration_code VARCHAR(50) NOT NULL,
  idempotency_key VARCHAR(180) NOT NULL,
  payload_json TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  available_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_v41_outbox_idem UNIQUE(organization_id,integration_code,idempotency_key)
);
