-- v28: barcode-driven warehouse operations
CREATE UNIQUE INDEX IF NOT EXISTS uq_barcode_master_org_code_v28
ON barcode_master(organization_id, barcode);

CREATE INDEX IF NOT EXISTS ix_barcode_master_scope_v28
ON barcode_master(organization_id, entity_type, entity_id, active);

CREATE INDEX IF NOT EXISTS ix_barcode_master_sku_v28
ON barcode_master(organization_id, sku_id, active);

CREATE INDEX IF NOT EXISTS ix_barcode_master_lot_v28
ON barcode_master(organization_id, lot_id, active);

CREATE INDEX IF NOT EXISTS ix_barcode_events_ref_v28
ON barcode_events(organization_id, entity_id, reference_type, reference_id, captured_at);

CREATE INDEX IF NOT EXISTS ix_barcode_events_action_v28
ON barcode_events(organization_id, entity_id, event_type, captured_at);

-- Immutable scan metadata for offline/mobile replay correlation.
ALTER TABLE barcode_events ADD COLUMN IF NOT EXISTS client_event_id VARCHAR(120);
CREATE UNIQUE INDEX IF NOT EXISTS uq_barcode_events_client_event_v28
ON barcode_events(organization_id, entity_id, client_event_id)
WHERE client_event_id IS NOT NULL;
