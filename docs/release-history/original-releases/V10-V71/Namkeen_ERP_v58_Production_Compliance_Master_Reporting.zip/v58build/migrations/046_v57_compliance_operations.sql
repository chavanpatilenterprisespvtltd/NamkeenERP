-- v57: operational compliance task/evidence/inspection/CAPA integration
CREATE TABLE IF NOT EXISTS compliance_requirement (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    authority_code VARCHAR(64) NOT NULL,
    requirement_code VARCHAR(128) NOT NULL,
    title TEXT NOT NULL,
    mandatory BOOLEAN NOT NULL DEFAULT TRUE,
    frequency_days INTEGER,
    condition_expr TEXT,
    effective_from DATE NOT NULL,
    effective_to DATE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (organization_id, requirement_code, effective_from)
);

CREATE TABLE IF NOT EXISTS compliance_task (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    requirement_id BIGINT NOT NULL REFERENCES compliance_requirement(id),
    due_date DATE NOT NULL,
    status VARCHAR(32) NOT NULL,
    owner_user_id BIGINT,
    completed_at TIMESTAMPTZ,
    verified_at TIMESTAMPTZ,
    severity VARCHAR(16) NOT NULL DEFAULT 'LOW',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_compliance_task_site_due ON compliance_task(site_id, due_date, status);

CREATE TABLE IF NOT EXISTS compliance_evidence (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    evidence_type VARCHAR(32) NOT NULL,
    storage_ref TEXT NOT NULL,
    sha256 CHAR(64) NOT NULL,
    captured_at TIMESTAMPTZ NOT NULL,
    captured_by BIGINT NOT NULL,
    linked_entity_type VARCHAR(64) NOT NULL,
    linked_entity_id BIGINT NOT NULL,
    confidential BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_compliance_evidence_link ON compliance_evidence(organization_id, linked_entity_type, linked_entity_id);

CREATE TABLE IF NOT EXISTS compliance_finding (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    task_id BIGINT NOT NULL REFERENCES compliance_task(id),
    severity VARCHAR(16) NOT NULL,
    description TEXT NOT NULL,
    disposition VARCHAR(32) NOT NULL,
    capa_id BIGINT,
    closed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_compliance_finding_site_open ON compliance_finding(site_id, closed, severity);

CREATE TABLE IF NOT EXISTS compliance_snapshot (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    as_of_date DATE NOT NULL,
    mandatory_open INTEGER NOT NULL,
    mandatory_overdue INTEGER NOT NULL,
    open_findings INTEGER NOT NULL,
    critical_findings INTEGER NOT NULL,
    active_capa INTEGER NOT NULL,
    missing_evidence INTEGER NOT NULL,
    inspection_ready BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (site_id, as_of_date)
);

-- Traceability bridge: operational transaction/entity -> compliance task/evidence/CAPA is deliberately reference-based.
-- No compliance record is allowed to mutate inventory/accounting by itself.
