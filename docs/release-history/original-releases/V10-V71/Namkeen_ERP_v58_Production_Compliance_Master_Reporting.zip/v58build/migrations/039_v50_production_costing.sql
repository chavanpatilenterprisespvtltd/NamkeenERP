-- v50: production costing and batch profitability

CREATE TABLE IF NOT EXISTS standard_cost (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    total_cost_per_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    approved_by BIGINT,
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (total_cost_per_kg >= 0),
    CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE TABLE IF NOT EXISTS standard_cost_component (
    id BIGSERIAL PRIMARY KEY,
    standard_cost_id BIGINT NOT NULL REFERENCES standard_cost(id) ON DELETE CASCADE,
    component_code VARCHAR(30) NOT NULL,
    cost_per_kg_output NUMERIC(18,6) NOT NULL DEFAULT 0,
    expected_input_kg_per_kg_output NUMERIC(18,6) NOT NULL DEFAULT 0,
    CHECK (cost_per_kg_output >= 0),
    CHECK (expected_input_kg_per_kg_output >= 0)
);

CREATE TABLE IF NOT EXISTS production_batch_cost (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    batch_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    input_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    good_output_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    reject_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    rework_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    yield_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
    total_actual_cost NUMERIC(18,2) NOT NULL DEFAULT 0,
    actual_cost_per_good_kg NUMERIC(18,2) NOT NULL DEFAULT 0,
    standard_cost_per_kg NUMERIC(18,2),
    standard_cost_for_actual_output NUMERIC(18,2),
    total_cost_variance NUMERIC(18,2),
    cost_variance_pct NUMERIC(9,4),
    status VARCHAR(20) NOT NULL DEFAULT 'CALCULATED',
    approved_by BIGINT,
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, entity_id, batch_id),
    CHECK (input_kg >= 0 AND good_output_kg >= 0 AND reject_kg >= 0 AND rework_kg >= 0),
    CHECK (good_output_kg + reject_kg + rework_kg <= input_kg + 0.000001)
);

CREATE TABLE IF NOT EXISTS production_batch_cost_component (
    id BIGSERIAL PRIMARY KEY,
    production_batch_cost_id BIGINT NOT NULL REFERENCES production_batch_cost(id) ON DELETE CASCADE,
    component_code VARCHAR(30) NOT NULL,
    quantity NUMERIC(18,6) NOT NULL DEFAULT 0,
    unit_cost NUMERIC(18,2) NOT NULL DEFAULT 0,
    amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    lot_id BIGINT,
    reference_code VARCHAR(120),
    CHECK (quantity >= 0 AND unit_cost >= 0 AND amount >= 0)
);

CREATE TABLE IF NOT EXISTS production_cost_variance (
    id BIGSERIAL PRIMARY KEY,
    production_batch_cost_id BIGINT NOT NULL REFERENCES production_batch_cost(id) ON DELETE CASCADE,
    variance_type VARCHAR(30) NOT NULL,
    component_code VARCHAR(30),
    expected_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    actual_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    variance_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    variance_pct NUMERIC(9,4),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_standard_cost_lookup ON standard_cost(organization_id, entity_id, sku_id, effective_from, effective_to, status);
CREATE INDEX IF NOT EXISTS ix_batch_cost_lookup ON production_batch_cost(organization_id, entity_id, sku_id, created_at);
CREATE INDEX IF NOT EXISTS ix_batch_cost_variance ON production_cost_variance(production_batch_cost_id, variance_type, component_code);
