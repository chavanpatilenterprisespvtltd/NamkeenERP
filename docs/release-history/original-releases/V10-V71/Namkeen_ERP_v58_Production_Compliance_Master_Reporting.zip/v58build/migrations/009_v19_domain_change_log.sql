CREATE TABLE IF NOT EXISTS domain_changes (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_scope_id BIGINT NULL REFERENCES entities(id),
    aggregate_type VARCHAR(80) NOT NULL,
    aggregate_id VARCHAR(120) NOT NULL,
    operation VARCHAR(20) NOT NULL,
    version INTEGER NOT NULL,
    event_name VARCHAR(100) NOT NULL,
    payload_json TEXT NOT NULL,
    actor_user_id BIGINT NULL REFERENCES users(id),
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_domain_change_version UNIQUE(organization_id, aggregate_type, aggregate_id, version)
);
CREATE INDEX IF NOT EXISTS idx_domain_change_org_seq ON domain_changes(organization_id, id);
CREATE INDEX IF NOT EXISTS idx_domain_change_aggregate ON domain_changes(organization_id, aggregate_type, aggregate_id, version);
COMMENT ON TABLE domain_changes IS 'Canonical append-only business change stream used by mobile sync, integrations and audit projections.';
