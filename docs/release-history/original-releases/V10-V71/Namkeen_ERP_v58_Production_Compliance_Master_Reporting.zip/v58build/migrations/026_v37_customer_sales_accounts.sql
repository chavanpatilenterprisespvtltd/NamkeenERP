BEGIN;

CREATE TABLE IF NOT EXISTS customer_invoices(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 customer_id BIGINT NOT NULL REFERENCES customers(id),
 salesperson_id BIGINT REFERENCES users(id),
 invoice_no VARCHAR(80) NOT NULL,
 invoice_date DATE NOT NULL,
 taxable_total NUMERIC(16,2) NOT NULL,
 tax_total NUMERIC(16,2) NOT NULL,
 grand_total NUMERIC(16,2) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
 UNIQUE(organization_id,invoice_no)
);
CREATE TABLE IF NOT EXISTS customer_invoice_lines(
 id BIGSERIAL PRIMARY KEY,
 invoice_id BIGINT NOT NULL REFERENCES customer_invoices(id),
 sku_id BIGINT NOT NULL REFERENCES skus(id),
 quantity_kg NUMERIC(16,3) NOT NULL,
 unit_price NUMERIC(14,2) NOT NULL,
 taxable_value NUMERIC(16,2) NOT NULL,
 tax_amount NUMERIC(16,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS customer_receipts(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 customer_id BIGINT NOT NULL REFERENCES customers(id),
 receipt_date DATE NOT NULL,
 amount NUMERIC(16,2) NOT NULL,
 mode VARCHAR(30) NOT NULL,
 reference_no VARCHAR(160),
 status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
 collected_by BIGINT REFERENCES users(id),
 verified_by BIGINT REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS customer_receipt_allocations(
 id BIGSERIAL PRIMARY KEY,
 receipt_id BIGINT NOT NULL REFERENCES customer_receipts(id),
 invoice_id BIGINT NOT NULL REFERENCES customer_invoices(id),
 allocated_amount NUMERIC(16,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS customer_adjustment_notes(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 customer_id BIGINT NOT NULL REFERENCES customers(id),
 original_invoice_id BIGINT NOT NULL REFERENCES customer_invoices(id),
 note_type VARCHAR(20) NOT NULL,
 taxable_amount NUMERIC(16,2) NOT NULL,
 tax_amount NUMERIC(16,2) NOT NULL,
 grand_amount NUMERIC(16,2) NOT NULL,
 reason TEXT NOT NULL,
 note_date DATE NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'DRAFT'
);
CREATE TABLE IF NOT EXISTS customer_ledger_entries(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 customer_id BIGINT NOT NULL REFERENCES customers(id),
 entry_date DATE NOT NULL,
 source_type VARCHAR(40) NOT NULL,
 source_id VARCHAR(100) NOT NULL,
 debit_amount NUMERIC(16,2) NOT NULL DEFAULT 0,
 credit_amount NUMERIC(16,2) NOT NULL DEFAULT 0,
 narration TEXT,
 UNIQUE(organization_id,source_type,source_id)
);
CREATE TABLE IF NOT EXISTS salesperson_incentive_basis(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 salesperson_id BIGINT NOT NULL REFERENCES users(id),
 invoice_id BIGINT NOT NULL REFERENCES customer_invoices(id),
 eligible_qty_kg NUMERIC(16,3) NOT NULL,
 net_sales_value NUMERIC(16,2) NOT NULL,
 gross_margin_value NUMERIC(16,2) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'ELIGIBLE',
 UNIQUE(organization_id,invoice_id)
);
CREATE INDEX IF NOT EXISTS idx_customer_invoice_customer_date ON customer_invoices(customer_id,invoice_date,status);
CREATE INDEX IF NOT EXISTS idx_customer_receipt_customer_date ON customer_receipts(customer_id,receipt_date,status);
CREATE INDEX IF NOT EXISTS idx_customer_ledger_customer_date ON customer_ledger_entries(customer_id,entry_date,id);
CREATE INDEX IF NOT EXISTS idx_incentive_salesperson_status ON salesperson_incentive_basis(salesperson_id,status);
COMMIT;
