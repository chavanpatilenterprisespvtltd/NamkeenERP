-- v20 does not replace the v19 stream. It strengthens constraints/indexing needed
-- as more domain modules emit events in the same transaction.
CREATE INDEX IF NOT EXISTS idx_domain_change_entity_scope
    ON domain_changes(organization_id, entity_scope_id, id);
CREATE INDEX IF NOT EXISTS idx_domain_change_event_name
    ON domain_changes(organization_id, event_name, id);
CREATE INDEX IF NOT EXISTS idx_domain_change_actor
    ON domain_changes(organization_id, actor_user_id, id);

COMMENT ON INDEX idx_domain_change_entity_scope IS 'Efficient entity-scoped mobile/integration delta reads.';
COMMENT ON INDEX idx_domain_change_event_name IS 'Event-type projection and monitoring index.';
COMMENT ON INDEX idx_domain_change_actor IS 'Audit/integration trace index.';
