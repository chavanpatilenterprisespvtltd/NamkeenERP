-- v31: warehouse execution, directed picking, replenishment, bin movements, cycle counting
CREATE TABLE IF NOT EXISTS warehouse_putaway_confirmation_v31 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    pick_task_id BIGINT NULL REFERENCES warehouse_pick_task(id),
    lpn_id BIGINT NOT NULL REFERENCES license_plate(id),
    destination_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    actor_user_id BIGINT NOT NULL,
    client_event_id VARCHAR(120),
    confirmed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, client_event_id)
);

CREATE TABLE IF NOT EXISTS warehouse_pick_execution_v31 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    pick_task_id BIGINT NOT NULL REFERENCES warehouse_pick_task(id),
    operator_user_id BIGINT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    expected_qty_kg NUMERIC(24,9) NULL CHECK (expected_qty_kg IS NULL OR expected_qty_kg >= 0),
    actual_qty_kg NUMERIC(24,9) NOT NULL DEFAULT 0 CHECK (actual_qty_kg >= 0),
    short_reason VARCHAR(200),
    picked_lpn_id BIGINT NULL REFERENCES license_plate(id),
    confirmed_by BIGINT NULL,
    client_event_id VARCHAR(120),
    confirmed_at TIMESTAMPTZ NULL,
    UNIQUE (organization_id, pick_task_id),
    UNIQUE (organization_id, client_event_id)
);
CREATE INDEX IF NOT EXISTS ix_pick_exec_route_v31 ON warehouse_pick_execution_v31(organization_id, warehouse_id, status, operator_user_id);

CREATE TABLE IF NOT EXISTS warehouse_stock_count_session_v31 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    reason VARCHAR(50) NOT NULL DEFAULT 'CYCLE_COUNT',
    tolerance_kg NUMERIC(24,9) NOT NULL DEFAULT 0 CHECK (tolerance_kg >= 0),
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    opened_by BIGINT NULL,
    submitted_by BIGINT NULL,
    approved_by BIGINT NULL,
    posted_by BIGINT NULL,
    opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    submitted_at TIMESTAMPTZ NULL,
    approved_at TIMESTAMPTZ NULL,
    posted_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS ix_count_session_v31 ON warehouse_stock_count_session_v31(organization_id, warehouse_id, status);

CREATE TABLE IF NOT EXISTS warehouse_stock_count_location_v31 (
    id BIGSERIAL PRIMARY KEY,
    count_session_id BIGINT NOT NULL REFERENCES warehouse_stock_count_session_v31(id),
    location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    UNIQUE (count_session_id, location_id)
);

CREATE TABLE IF NOT EXISTS warehouse_stock_count_line_v31 (
    id BIGSERIAL PRIMARY KEY,
    count_session_id BIGINT NOT NULL REFERENCES warehouse_stock_count_session_v31(id),
    location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    sku_id BIGINT NOT NULL,
    lot_id BIGINT NULL REFERENCES inventory_lots(id),
    book_qty_kg NUMERIC(24,9) NOT NULL CHECK (book_qty_kg >= 0),
    counted_qty_kg NUMERIC(24,9) NULL CHECK (counted_qty_kg IS NULL OR counted_qty_kg >= 0),
    variance_qty_kg NUMERIC(24,9) NULL,
    count_uom VARCHAR(30) NOT NULL DEFAULT 'KG',
    barcode VARCHAR(200),
    evidence_file_id VARCHAR(200),
    recount_required BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (count_session_id, location_id, sku_id, lot_id)
);
CREATE INDEX IF NOT EXISTS ix_count_lines_variance_v31 ON warehouse_stock_count_line_v31(count_session_id, recount_required, variance_qty_kg);

CREATE TABLE IF NOT EXISTS warehouse_replenishment_task_v31 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    lot_id BIGINT NULL REFERENCES inventory_lots(id),
    source_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    destination_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    qty_kg NUMERIC(24,9) NOT NULL CHECK (qty_kg > 0),
    priority INTEGER NOT NULL DEFAULT 100,
    reason VARCHAR(50) NOT NULL DEFAULT 'MIN_STOCK',
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    assigned_to BIGINT NULL,
    confirmed_by BIGINT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confirmed_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS ix_replenish_v31 ON warehouse_replenishment_task_v31(organization_id, warehouse_id, status, priority, destination_location_id);

CREATE TABLE IF NOT EXISTS warehouse_bin_movement_v31 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    source_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    destination_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    lpn_id BIGINT NULL REFERENCES license_plate(id),
    sku_id BIGINT NULL,
    lot_id BIGINT NULL REFERENCES inventory_lots(id),
    qty_kg NUMERIC(24,9) NOT NULL CHECK (qty_kg > 0),
    reason VARCHAR(50) NOT NULL DEFAULT 'BIN_TRANSFER',
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    created_by BIGINT NULL,
    confirmed_by BIGINT NULL,
    client_event_id VARCHAR(120),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confirmed_at TIMESTAMPTZ NULL,
    UNIQUE (organization_id, client_event_id)
);
CREATE INDEX IF NOT EXISTS ix_bin_move_v31 ON warehouse_bin_movement_v31(organization_id, warehouse_id, status, source_location_id, destination_location_id);
