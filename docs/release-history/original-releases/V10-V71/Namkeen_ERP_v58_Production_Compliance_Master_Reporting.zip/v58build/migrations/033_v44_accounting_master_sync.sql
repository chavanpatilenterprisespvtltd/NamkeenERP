CREATE TABLE IF NOT EXISTS party_ledger_links_v44 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  party_type VARCHAR(20) NOT NULL, party_id BIGINT NOT NULL, ledger_code VARCHAR(80) NOT NULL, external_name VARCHAR(180), status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  last_synced_at TIMESTAMPTZ, sync_error TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_v44_party_ledger UNIQUE(organization_id, entity_id, party_type, party_id)
);
CREATE INDEX IF NOT EXISTS idx_v44_party_ledger_status ON party_ledger_links_v44(organization_id, entity_id, party_type, status);
CREATE TABLE IF NOT EXISTS ledger_sync_jobs_v44 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), ledger_code VARCHAR(80) NOT NULL,
  direction VARCHAR(20) NOT NULL DEFAULT 'PUSH', status VARCHAR(20) NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0, available_at TIMESTAMPTZ,
  external_reference VARCHAR(180), last_error TEXT, idempotency_key VARCHAR(160) NOT NULL UNIQUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_v44_ledger_job_queue ON ledger_sync_jobs_v44(organization_id, entity_id, status, available_at);
CREATE TABLE IF NOT EXISTS accounting_reconciliation_actions_v44 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  reconciliation_id BIGINT NOT NULL REFERENCES accounting_reconciliations_v43(id), action VARCHAR(40) NOT NULL, reason TEXT NOT NULL,
  requested_by BIGINT NOT NULL REFERENCES users(id), approved_by BIGINT REFERENCES users(id), status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), approved_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_v44_recon_action_status ON accounting_reconciliation_actions_v44(organization_id, entity_id, status);
