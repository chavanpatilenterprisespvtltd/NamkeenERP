-- v33 procurement planning / demand engine.
-- This is planning data only; posting a PO or production order remains an approval-controlled transaction.
CREATE TABLE IF NOT EXISTS supplier_sku_terms (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  lead_time_days INTEGER NOT NULL DEFAULT 0,
  moq_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  order_multiple_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 100,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ck_v33_supplier_terms CHECK (lead_time_days >= 0 AND moq_kg >= 0 AND order_multiple_kg >= 0)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_v33_supplier_terms ON supplier_sku_terms(organization_id,entity_id,supplier_id,sku_id,effective_from);
CREATE INDEX IF NOT EXISTS idx_v33_supplier_terms_lookup ON supplier_sku_terms(organization_id,entity_id,sku_id,active,priority,lead_time_days);

CREATE TABLE IF NOT EXISTS procurement_plans (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  warehouse_id BIGINT NOT NULL REFERENCES warehouses(id),
  plan_date DATE NOT NULL,
  horizon_days INTEGER NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ck_v33_plan_horizon CHECK (horizon_days >= 0)
);
CREATE INDEX IF NOT EXISTS idx_v33_procurement_plans ON procurement_plans(organization_id,entity_id,warehouse_id,plan_date,status);

CREATE TABLE IF NOT EXISTS procurement_suggestions (
  id BIGSERIAL PRIMARY KEY,
  plan_id BIGINT NOT NULL REFERENCES procurement_plans(id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  supplier_id BIGINT REFERENCES suppliers(id),
  suggested_qty_kg NUMERIC(16,3) NOT NULL,
  lead_time_days INTEGER NOT NULL DEFAULT 0,
  severity VARCHAR(20) NOT NULL,
  reason TEXT NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING_APPROVAL',
  approved_by BIGINT REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  reference_type VARCHAR(40),
  reference_id VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ck_v33_suggestion_qty CHECK (suggested_qty_kg > 0),
  CONSTRAINT ck_v33_suggestion_lead CHECK (lead_time_days >= 0)
);
CREATE INDEX IF NOT EXISTS idx_v33_suggestions_plan_status ON procurement_suggestions(plan_id,status,severity);

CREATE TABLE IF NOT EXISTS production_requirements (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  warehouse_id BIGINT NOT NULL REFERENCES warehouses(id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  required_qty_kg NUMERIC(16,3) NOT NULL,
  reason TEXT NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING_APPROVAL',
  approved_by BIGINT REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  production_batch_id BIGINT REFERENCES production_batches(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ck_v33_prod_req_qty CHECK (required_qty_kg > 0)
);
CREATE INDEX IF NOT EXISTS idx_v33_prod_req_status ON production_requirements(organization_id,entity_id,warehouse_id,status,sku_id);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  supplier_id BIGINT NOT NULL REFERENCES suppliers(id),
  po_no VARCHAR(80) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  expected_date DATE,
  created_by BIGINT REFERENCES users(id),
  approved_by BIGINT REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_v33_po_no ON purchase_orders(organization_id,entity_id,po_no);
CREATE INDEX IF NOT EXISTS idx_v33_po_supplier_status ON purchase_orders(organization_id,entity_id,supplier_id,status,expected_date);
