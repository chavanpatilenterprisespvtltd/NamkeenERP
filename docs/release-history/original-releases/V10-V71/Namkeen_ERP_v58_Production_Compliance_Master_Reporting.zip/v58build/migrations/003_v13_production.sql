
-- Production migration for v13 transactional core.
-- Run after the prior core/compliance migrations with your migration runner.

BEGIN;

CREATE TABLE IF NOT EXISTS customers(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 code VARCHAR(60) NOT NULL,
 name VARCHAR(200) NOT NULL,
 mobile VARCHAR(30),
 gps_lat NUMERIC(10,7), gps_lng NUMERIC(10,7),
 approval_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
 credit_limit NUMERIC(16,2) NOT NULL DEFAULT 0,
 credit_days INTEGER NOT NULL DEFAULT 0,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(organization_id,code)
);

CREATE TABLE IF NOT EXISTS payments(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT NOT NULL REFERENCES entities(id),
 order_id BIGINT REFERENCES sales_orders(id),
 customer_id BIGINT REFERENCES customers(id),
 mode VARCHAR(30) NOT NULL,
 status VARCHAR(40) NOT NULL,
 amount NUMERIC(16,2) NOT NULL,
 reference VARCHAR(120),
 proof_file_id VARCHAR(120),
 collected_by BIGINT REFERENCES users(id),
 verified_by BIGINT REFERENCES users(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sync_events(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 device_id VARCHAR(120) NOT NULL,
 client_event_id VARCHAR(120) NOT NULL,
 event_type VARCHAR(60) NOT NULL,
 payload_json TEXT NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
 received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(organization_id,client_event_id)
);

CREATE INDEX IF NOT EXISTS idx_sales_order_customer ON sales_orders(customer_id,created_at);
CREATE INDEX IF NOT EXISTS idx_payment_status ON payments(organization_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_sync_pending ON sync_events(organization_id,status,received_at);

COMMIT;
