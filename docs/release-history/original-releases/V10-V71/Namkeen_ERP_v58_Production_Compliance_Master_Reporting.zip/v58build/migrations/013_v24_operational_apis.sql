-- v24 operational tables. Run after migrations 001..012.
CREATE TABLE IF NOT EXISTS production_batches (
  id BIGINT PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  batch_no VARCHAR(80) NOT NULL, product_id BIGINT NOT NULL REFERENCES products(id),
  planned_qty_kg NUMERIC(16,3) NOT NULL, actual_qty_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  status VARCHAR(30) NOT NULL DEFAULT 'PLANNED', production_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by BIGINT NOT NULL REFERENCES users(id), UNIQUE(organization_id,batch_no)
);
CREATE INDEX IF NOT EXISTS idx_prod_batch_org_status ON production_batches(organization_id,entity_id,status);
CREATE TABLE IF NOT EXISTS production_records (
  id BIGINT PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  batch_id BIGINT NOT NULL REFERENCES production_batches(id), good_qty_kg NUMERIC(16,3) NOT NULL,
  reject_qty_kg NUMERIC(16,3) NOT NULL DEFAULT 0, note TEXT, recorded_by BIGINT NOT NULL REFERENCES users(id), recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS qc_inspections (
  id BIGINT PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  batch_id BIGINT REFERENCES production_batches(id), return_id BIGINT REFERENCES sales_returns(id), result VARCHAR(30) NOT NULL,
  remarks TEXT, evidence_file_id VARCHAR(160), inspected_by BIGINT NOT NULL REFERENCES users(id), inspected_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_qc_inspection_scope ON qc_inspections(organization_id,entity_id,result);
CREATE TABLE IF NOT EXISTS dispatch_notes (
  id BIGINT PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  order_id BIGINT NOT NULL UNIQUE REFERENCES sales_orders(id), dispatch_no VARCHAR(80) NOT NULL UNIQUE,
  vehicle_no VARCHAR(40), transporter VARCHAR(160), status VARCHAR(30) NOT NULL DEFAULT 'CREATED',
  dispatched_by BIGINT NOT NULL REFERENCES users(id), dispatched_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS price_exceptions (
  id BIGINT PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  order_id BIGINT NOT NULL REFERENCES sales_orders(id), line_id BIGINT NOT NULL REFERENCES sales_order_lines(id),
  negotiated_price NUMERIC(14,2) NOT NULL, floor_price NUMERIC(14,2) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  requested_by BIGINT NOT NULL REFERENCES users(id), decided_by BIGINT REFERENCES users(id), reason TEXT, decided_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_price_exception_pending ON price_exceptions(organization_id,entity_id,status);
