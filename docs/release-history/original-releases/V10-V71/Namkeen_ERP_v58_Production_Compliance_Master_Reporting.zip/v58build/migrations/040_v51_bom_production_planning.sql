-- v51: versioned BOM/recipe and production planning foundation
CREATE TABLE IF NOT EXISTS production_bom (
    bom_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    version_no VARCHAR(50) NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    expected_yield_pct NUMERIC(8,3) NOT NULL CHECK (expected_yield_pct > 0 AND expected_yield_pct <= 100),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(entity_id, sku_id, version_no),
    CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE TABLE IF NOT EXISTS production_bom_component (
    bom_component_id BIGSERIAL PRIMARY KEY,
    bom_id BIGINT NOT NULL REFERENCES production_bom(bom_id) ON DELETE CASCADE,
    item_id BIGINT NOT NULL,
    item_type VARCHAR(30) NOT NULL,
    qty_per_output_kg NUMERIC(18,6) NOT NULL CHECK (qty_per_output_kg > 0),
    scrap_pct NUMERIC(8,4) NOT NULL DEFAULT 0 CHECK (scrap_pct >= 0 AND scrap_pct < 100),
    unit_cost NUMERIC(18,6),
    UNIQUE(bom_id, item_id),
    CHECK (unit_cost IS NULL OR unit_cost >= 0)
);

CREATE TABLE IF NOT EXISTS production_bom_byproduct (
    bom_byproduct_id BIGSERIAL PRIMARY KEY,
    bom_id BIGINT NOT NULL REFERENCES production_bom(bom_id) ON DELETE CASCADE,
    item_id BIGINT NOT NULL,
    qty_per_output_kg NUMERIC(18,6) NOT NULL CHECK (qty_per_output_kg > 0),
    recovery_value_per_kg NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (recovery_value_per_kg >= 0),
    UNIQUE(bom_id, item_id)
);

CREATE TABLE IF NOT EXISTS production_plan_material (
    plan_material_id BIGSERIAL PRIMARY KEY,
    production_plan_id BIGINT NOT NULL,
    item_id BIGINT NOT NULL,
    planned_net_qty NUMERIC(18,6) NOT NULL CHECK (planned_net_qty >= 0),
    planned_issue_qty NUMERIC(18,6) NOT NULL CHECK (planned_issue_qty >= 0),
    actual_issue_qty NUMERIC(18,6),
    variance_qty NUMERIC(18,6),
    variance_pct NUMERIC(12,4),
    UNIQUE(production_plan_id, item_id)
);

CREATE INDEX IF NOT EXISTS ix_production_bom_effective
    ON production_bom(entity_id, sku_id, effective_from, effective_to, active);
CREATE INDEX IF NOT EXISTS ix_production_plan_material_item
    ON production_plan_material(item_id);

-- Historical BOM versions remain immutable by application policy once used by a production batch.
