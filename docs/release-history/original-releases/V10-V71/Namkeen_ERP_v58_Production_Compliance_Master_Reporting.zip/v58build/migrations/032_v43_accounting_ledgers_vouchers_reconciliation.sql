-- v43: configurable accounting ledgers, voucher mappings and reconciliation
CREATE TABLE IF NOT EXISTS accounting_ledgers_v43 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    code VARCHAR(80) NOT NULL,
    name VARCHAR(180) NOT NULL,
    ledger_group VARCHAR(80) NOT NULL,
    tax_role VARCHAR(40),
    external_name VARCHAR(180),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_v43_ledger_code UNIQUE(organization_id, entity_id, code)
);
CREATE INDEX IF NOT EXISTS idx_v43_ledger_lookup ON accounting_ledgers_v43(organization_id, entity_id, ledger_group, is_active);
CREATE TABLE IF NOT EXISTS voucher_mappings_v43 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    document_type VARCHAR(50) NOT NULL,
    voucher_type VARCHAR(80) NOT NULL,
    party_ledger_code VARCHAR(80),
    base_ledger_code VARCHAR(80),
    cgst_ledger_code VARCHAR(80),
    sgst_ledger_code VARCHAR(80),
    igst_ledger_code VARCHAR(80),
    cess_ledger_code VARCHAR(80),
    effective_from TIMESTAMPTZ,
    effective_to TIMESTAMPTZ,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_v43_voucher_mapping UNIQUE(organization_id, entity_id, document_type, effective_from)
);
CREATE INDEX IF NOT EXISTS idx_v43_mapping_lookup ON voucher_mappings_v43(organization_id, entity_id, document_type, is_active);
CREATE TABLE IF NOT EXISTS accounting_vouchers_v43 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    source_type VARCHAR(50) NOT NULL,
    source_id BIGINT NOT NULL,
    source_number VARCHAR(100) NOT NULL,
    voucher_type VARCHAR(80) NOT NULL,
    voucher_date TIMESTAMPTZ NOT NULL,
    amount NUMERIC(18,2) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    external_reference VARCHAR(180),
    payload_hash VARCHAR(64),
    response_hash VARCHAR(64),
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_v43_voucher_source UNIQUE(organization_id, entity_id, source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_v43_voucher_status ON accounting_vouchers_v43(organization_id, entity_id, status, voucher_date);
CREATE TABLE IF NOT EXISTS accounting_reconciliations_v43 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    voucher_id BIGINT NOT NULL REFERENCES accounting_vouchers_v43(id),
    internal_amount NUMERIC(18,2) NOT NULL,
    external_amount NUMERIC(18,2),
    amount_difference NUMERIC(18,2),
    external_reference VARCHAR(180),
    status VARCHAR(30) NOT NULL,
    mismatch_reason TEXT,
    reconciled_by BIGINT REFERENCES users(id),
    reconciled_at TIMESTAMPTZ,
    CONSTRAINT uq_v43_recon_ref UNIQUE(voucher_id, external_reference)
);
CREATE INDEX IF NOT EXISTS idx_v43_recon_status ON accounting_reconciliations_v43(organization_id, entity_id, status);
