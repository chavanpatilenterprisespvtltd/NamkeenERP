BEGIN;
CREATE TABLE IF NOT EXISTS order_allocations(
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  order_id BIGINT NOT NULL REFERENCES sales_orders(id),
  order_line_id BIGINT NOT NULL REFERENCES sales_order_lines(id),
  lot_id BIGINT NOT NULL REFERENCES inventory_lots(id),
  qty NUMERIC(16,3) NOT NULL CHECK(qty>0),
  status VARCHAR(20) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(order_line_id,lot_id)
);
CREATE INDEX IF NOT EXISTS idx_order_alloc_order_status ON order_allocations(order_id,status);
CREATE TABLE IF NOT EXISTS refresh_replay_guards(
  id BIGSERIAL PRIMARY KEY,
  session_id VARCHAR(120) NOT NULL,
  token_hash VARCHAR(64) NOT NULL,
  used_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(session_id,token_hash)
);
COMMIT;
