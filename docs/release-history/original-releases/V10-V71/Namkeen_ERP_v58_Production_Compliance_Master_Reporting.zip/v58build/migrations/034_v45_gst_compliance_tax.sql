CREATE TABLE IF NOT EXISTS gst_tax_rate_rules_v45 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  tax_code VARCHAR(20) NOT NULL, rate_pct NUMERIC(10,3) NOT NULL, effective_from DATE NOT NULL, effective_to DATE,
  taxable BOOLEAN NOT NULL DEFAULT TRUE, rcm_allowed BOOLEAN NOT NULL DEFAULT FALSE, active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE INDEX IF NOT EXISTS idx_v45_tax_rule_lookup ON gst_tax_rate_rules_v45(organization_id, entity_id, tax_code, effective_from);
CREATE TABLE IF NOT EXISTS gst_product_tax_profiles_v45 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  sku_id BIGINT NOT NULL, tax_code VARCHAR(40) NOT NULL, hsn VARCHAR(20) NOT NULL, rate_rule_key VARCHAR(80) NOT NULL,
  exempt BOOLEAN NOT NULL DEFAULT FALSE, nil_rated BOOLEAN NOT NULL DEFAULT FALSE, zero_rated BOOLEAN NOT NULL DEFAULT FALSE,
  effective_from DATE NOT NULL, effective_to DATE,
  CONSTRAINT uq_v45_product_tax_effective UNIQUE(organization_id,entity_id,sku_id,effective_from)
);
CREATE INDEX IF NOT EXISTS idx_v45_product_hsn ON gst_product_tax_profiles_v45(organization_id,entity_id,hsn);
CREATE TABLE IF NOT EXISTS gst_document_tax_v45 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
  source_type VARCHAR(40) NOT NULL, source_id BIGINT NOT NULL, doc_type VARCHAR(30) NOT NULL, document_no VARCHAR(60) NOT NULL, document_date DATE NOT NULL,
  supplier_gstin VARCHAR(20), recipient_gstin VARCHAR(20), place_of_supply VARCHAR(80) NOT NULL, supply_type VARCHAR(30) NOT NULL,
  reverse_charge BOOLEAN NOT NULL DEFAULT FALSE, taxable_value NUMERIC(18,2) NOT NULL DEFAULT 0, cgst NUMERIC(18,2) NOT NULL DEFAULT 0,
  sgst NUMERIC(18,2) NOT NULL DEFAULT 0, igst NUMERIC(18,2) NOT NULL DEFAULT 0, utgst NUMERIC(18,2) NOT NULL DEFAULT 0, cess NUMERIC(18,2) NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'POSTED', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_v45_gst_doc UNIQUE(organization_id,entity_id,doc_type,document_no)
);
CREATE INDEX IF NOT EXISTS idx_v45_gst_period ON gst_document_tax_v45(organization_id,entity_id,document_date,status);
CREATE INDEX IF NOT EXISTS idx_v45_gst_pos_rcm ON gst_document_tax_v45(organization_id,entity_id,place_of_supply,reverse_charge);
CREATE TABLE IF NOT EXISTS gst_return_periods_v45 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), period_key VARCHAR(20) NOT NULL,
  start_date DATE NOT NULL, end_date DATE NOT NULL, state VARCHAR(24) NOT NULL DEFAULT 'OPEN', locked_by BIGINT REFERENCES users(id), locked_at TIMESTAMPTZ, filed_at TIMESTAMPTZ,
  CONSTRAINT uq_v45_gst_period UNIQUE(organization_id,entity_id,period_key)
);
CREATE TABLE IF NOT EXISTS gst_reconciliations_v45 (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), period_key VARCHAR(20) NOT NULL,
  source VARCHAR(50) NOT NULL, local_taxable NUMERIC(18,2) NOT NULL, external_taxable NUMERIC(18,2) NOT NULL, local_tax NUMERIC(18,2) NOT NULL, external_tax NUMERIC(18,2) NOT NULL,
  taxable_difference NUMERIC(18,2) NOT NULL, tax_difference NUMERIC(18,2) NOT NULL, status VARCHAR(20) NOT NULL,
  resolved_by BIGINT REFERENCES users(id), resolution_reason TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_v45_gst_recon_status ON gst_reconciliations_v45(organization_id,entity_id,period_key,status);
