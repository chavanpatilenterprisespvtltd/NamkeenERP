-- v52: approval-controlled MRP and production-order execution foundation
CREATE TABLE IF NOT EXISTS mrp_run (
    mrp_run_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    as_of_date DATE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'CALCULATED',
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS mrp_requirement (
    mrp_requirement_id BIGSERIAL PRIMARY KEY,
    mrp_run_id BIGINT NOT NULL REFERENCES mrp_run(mrp_run_id) ON DELETE CASCADE,
    item_id BIGINT NOT NULL,
    item_type VARCHAR(30) NOT NULL,
    gross_required_qty_kg NUMERIC(18,6) NOT NULL CHECK (gross_required_qty_kg >= 0),
    planned_available_qty_kg NUMERIC(18,6) NOT NULL CHECK (planned_available_qty_kg >= 0),
    net_to_make_or_buy_qty_kg NUMERIC(18,6) NOT NULL CHECK (net_to_make_or_buy_qty_kg >= 0)
);
CREATE TABLE IF NOT EXISTS production_order (
    production_order_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    bom_version VARCHAR(50) NOT NULL,
    planned_good_output_kg NUMERIC(18,6) NOT NULL CHECK (planned_good_output_kg > 0),
    due_date DATE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    created_by BIGINT,
    approved_by BIGINT,
    release_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(entity_id, production_order_id),
    CHECK (status IN ('DRAFT','PENDING_APPROVAL','RELEASED','IN_PROGRESS','COMPLETED','CANCELLED'))
);
CREATE TABLE IF NOT EXISTS production_order_demand (
    production_order_id BIGINT NOT NULL REFERENCES production_order(production_order_id) ON DELETE CASCADE,
    demand_id BIGINT NOT NULL,
    PRIMARY KEY (production_order_id,demand_id)
);
CREATE INDEX IF NOT EXISTS ix_mrp_requirement_item ON mrp_requirement(item_id);
CREATE INDEX IF NOT EXISTS ix_production_order_entity_status_due ON production_order(entity_id,status,due_date);
