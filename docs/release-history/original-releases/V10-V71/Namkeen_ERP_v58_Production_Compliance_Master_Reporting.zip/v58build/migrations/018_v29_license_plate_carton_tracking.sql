-- v29: license-plate / carton-level inventory tracking
CREATE TABLE IF NOT EXISTS license_plate (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    code VARCHAR(120) NOT NULL,
    lpn_type VARCHAR(30) NOT NULL DEFAULT 'CARTON',
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    warehouse_id BIGINT NULL,
    parent_lpn_id BIGINT NULL REFERENCES license_plate(id),
    sealed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, code)
);
CREATE TABLE IF NOT EXISTS license_plate_content (
    id BIGSERIAL PRIMARY KEY,
    lpn_id BIGINT NOT NULL REFERENCES license_plate(id),
    organization_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL,
    lot_id BIGINT NOT NULL,
    quantity NUMERIC(24,9) NOT NULL CHECK (quantity > 0),
    quantity_uom VARCHAR(30) NOT NULL,
    normalized_kg NUMERIC(24,9) NOT NULL CHECK (normalized_kg > 0),
    expiry_date DATE NULL,
    source_ref VARCHAR(120) NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS license_plate_event (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    lpn_id BIGINT NOT NULL REFERENCES license_plate(id),
    event_type VARCHAR(30) NOT NULL,
    warehouse_id BIGINT NULL,
    reference_type VARCHAR(50) NULL,
    reference_id BIGINT NULL,
    client_event_id VARCHAR(120) NULL,
    actor_user_id BIGINT NULL,
    event_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    payload JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_lpn_event_client_v29
ON license_plate_event(organization_id, lpn_id, client_event_id)
WHERE client_event_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_lpn_org_status_v29 ON license_plate(organization_id, status, warehouse_id);
CREATE INDEX IF NOT EXISTS ix_lpn_content_lot_v29 ON license_plate_content(organization_id, lot_id, lpn_id);
CREATE INDEX IF NOT EXISTS ix_lpn_content_sku_v29 ON license_plate_content(organization_id, sku_id, expiry_date);
CREATE INDEX IF NOT EXISTS ix_lpn_event_lpn_v29 ON license_plate_event(organization_id, lpn_id, event_at);
