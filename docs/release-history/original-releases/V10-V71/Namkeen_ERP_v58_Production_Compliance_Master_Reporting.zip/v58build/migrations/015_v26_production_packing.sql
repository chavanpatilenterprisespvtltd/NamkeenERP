-- v26: production material issue -> WIP -> packing -> FG traceability.
CREATE TABLE IF NOT EXISTS production_material_issues (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
 batch_id BIGINT NOT NULL REFERENCES production_batches(id), sku_id BIGINT NOT NULL REFERENCES skus(id), lot_id BIGINT NOT NULL REFERENCES inventory_lots(id),
 warehouse_code VARCHAR(50) NOT NULL, qty_kg NUMERIC(16,3) NOT NULL CHECK(qty_kg>0), issue_type VARCHAR(30) NOT NULL DEFAULT 'RM',
 created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_prod_issue_batch ON production_material_issues(organization_id,entity_id,batch_id);
CREATE TABLE IF NOT EXISTS production_wip_lots (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
 batch_id BIGINT NOT NULL REFERENCES production_batches(id), product_id BIGINT NOT NULL REFERENCES products(id), warehouse_code VARCHAR(50) NOT NULL,
 wip_batch_no VARCHAR(100) NOT NULL, qty_kg NUMERIC(16,3) NOT NULL CHECK(qty_kg>0), qty_available_kg NUMERIC(16,3) NOT NULL CHECK(qty_available_kg>=0),
 created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(entity_id,wip_batch_no)
);
CREATE INDEX IF NOT EXISTS idx_wip_available ON production_wip_lots(entity_id,warehouse_code,product_id,qty_available_kg);
CREATE TABLE IF NOT EXISTS production_wip_movements (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), wip_lot_id BIGINT NOT NULL REFERENCES production_wip_lots(id),
 qty_kg NUMERIC(16,3) NOT NULL, movement_type VARCHAR(30) NOT NULL, reference_type VARCHAR(50) NOT NULL, reference_id VARCHAR(100) NOT NULL,
 created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS packing_runs (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), batch_id BIGINT NOT NULL REFERENCES production_batches(id),
 wip_lot_id BIGINT NOT NULL REFERENCES production_wip_lots(id), sku_id BIGINT NOT NULL REFERENCES skus(id), fg_warehouse_code VARCHAR(50) NOT NULL,
 planned_qty_kg NUMERIC(16,3) NOT NULL CHECK(planned_qty_kg>0), actual_good_qty_kg NUMERIC(16,3) NOT NULL DEFAULT 0, reject_qty_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
 status VARCHAR(30) NOT NULL DEFAULT 'PLANNED', packing_no VARCHAR(100) NOT NULL, created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(entity_id,packing_no)
);
CREATE INDEX IF NOT EXISTS idx_packing_batch ON packing_runs(organization_id,entity_id,batch_id);
CREATE TABLE IF NOT EXISTS packing_material_issues (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), packing_run_id BIGINT NOT NULL REFERENCES packing_runs(id),
 sku_id BIGINT NOT NULL REFERENCES skus(id), lot_id BIGINT NOT NULL REFERENCES inventory_lots(id), warehouse_code VARCHAR(50) NOT NULL, qty_base NUMERIC(16,3) NOT NULL CHECK(qty_base>0),
 issue_type VARCHAR(30) NOT NULL DEFAULT 'PACKAGING', created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS production_fg_outputs (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), packing_run_id BIGINT NOT NULL REFERENCES packing_runs(id),
 sku_id BIGINT NOT NULL REFERENCES skus(id), lot_id BIGINT NOT NULL REFERENCES inventory_lots(id), batch_no VARCHAR(100) NOT NULL, good_qty_kg NUMERIC(16,3) NOT NULL CHECK(good_qty_kg>0),
 good_pack_qty NUMERIC(16,3) NOT NULL CHECK(good_pack_qty>0), reject_qty_kg NUMERIC(16,3) NOT NULL DEFAULT 0, expiry_date DATE, created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_fg_output_batch ON production_fg_outputs(organization_id,entity_id,batch_no);
CREATE INDEX IF NOT EXISTS idx_fg_output_lot ON production_fg_outputs(lot_id);
CREATE TABLE IF NOT EXISTS production_wastage (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), batch_id BIGINT NOT NULL REFERENCES production_batches(id), packing_run_id BIGINT REFERENCES packing_runs(id),
 qty_kg NUMERIC(16,3) NOT NULL CHECK(qty_kg>0), reason_code VARCHAR(50) NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'RECORDED', authorized_by BIGINT REFERENCES users(id), created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- Extend the canonical change-stream vocabulary via application code. These indexes support traceability and reconciliation.
CREATE INDEX IF NOT EXISTS idx_inv_ledger_ref_prod ON inventory_ledger(reference_type,reference_id);
