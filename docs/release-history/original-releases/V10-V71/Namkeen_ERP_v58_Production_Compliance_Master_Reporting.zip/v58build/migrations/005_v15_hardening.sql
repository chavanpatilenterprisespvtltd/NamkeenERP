BEGIN;

-- Production hardening: uniqueness, session/device indexes, notification retry fields, sync status checks.
CREATE UNIQUE INDEX IF NOT EXISTS uq_user_devices_user_device ON user_devices(user_id, device_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_device ON user_sessions(device_id, revoked_at, expires_at);
CREATE INDEX IF NOT EXISTS idx_notification_claim ON notification_outbox(status, available_at, id);

ALTER TABLE notification_outbox ADD COLUMN IF NOT EXISTS last_error TEXT;
ALTER TABLE notification_outbox ADD COLUMN IF NOT EXISTS available_at TIMESTAMPTZ NOT NULL DEFAULT now();

ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS applied_at TIMESTAMPTZ;
ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS processed_by VARCHAR(80);

CREATE TABLE IF NOT EXISTS integration_runs(
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  integration_code VARCHAR(60) NOT NULL,
  direction VARCHAR(20) NOT NULL,
  idempotency_key VARCHAR(160) NOT NULL,
  status VARCHAR(30) NOT NULL,
  request_hash VARCHAR(64),
  response_hash VARCHAR(64),
  error_message TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  UNIQUE(organization_id,integration_code,idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_integration_runs_status ON integration_runs(organization_id,integration_code,status,started_at);

COMMIT;
