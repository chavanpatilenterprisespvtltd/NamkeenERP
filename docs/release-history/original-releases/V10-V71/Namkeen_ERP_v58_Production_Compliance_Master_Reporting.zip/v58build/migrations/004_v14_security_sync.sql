BEGIN;

CREATE TABLE IF NOT EXISTS user_devices(
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id),
 device_id VARCHAR(120) NOT NULL,
 device_name VARCHAR(150),
 platform VARCHAR(40),
 app_version VARCHAR(40),
 active BOOLEAN NOT NULL DEFAULT TRUE,
 last_seen_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(user_id,device_id)
);

CREATE TABLE IF NOT EXISTS user_sessions(
 id VARCHAR(120) PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id),
 device_id VARCHAR(120) NOT NULL,
 refresh_token_hash VARCHAR(64) NOT NULL,
 expires_at TIMESTAMPTZ NOT NULL,
 revoked_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 last_used_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_active ON user_sessions(user_id,revoked_at,expires_at);

CREATE TABLE IF NOT EXISTS documents(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 entity_id BIGINT REFERENCES entities(id),
 object_id VARCHAR(120) NOT NULL UNIQUE,
 storage_key TEXT NOT NULL,
 category VARCHAR(60) NOT NULL,
 original_name VARCHAR(255),
 content_type VARCHAR(120),
 size_bytes BIGINT NOT NULL,
 sha256 VARCHAR(64) NOT NULL,
 sensitivity VARCHAR(30) NOT NULL DEFAULT 'PRIVATE',
 uploaded_by BIGINT NOT NULL REFERENCES users(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_documents_org_cat ON documents(organization_id,category,created_at);

CREATE TABLE IF NOT EXISTS notification_outbox(
 id BIGSERIAL PRIMARY KEY,
 organization_id BIGINT NOT NULL REFERENCES organizations(id),
 user_id BIGINT REFERENCES users(id),
 role VARCHAR(50),
 notification_type VARCHAR(60) NOT NULL,
 title VARCHAR(200) NOT NULL,
 body TEXT NOT NULL,
 data_json TEXT NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
 attempts INTEGER NOT NULL DEFAULT 0,
 available_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 sent_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notification_pending ON notification_outbox(status,available_at,id);

ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS entity_type VARCHAR(80);
ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS entity_id VARCHAR(100);
ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS client_version BIGINT;
ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS server_version BIGINT;
ALTER TABLE sync_events ADD COLUMN IF NOT EXISTS conflict_code VARCHAR(60);
CREATE INDEX IF NOT EXISTS idx_sync_entity ON sync_events(organization_id,entity_type,entity_id,status);

COMMIT;
