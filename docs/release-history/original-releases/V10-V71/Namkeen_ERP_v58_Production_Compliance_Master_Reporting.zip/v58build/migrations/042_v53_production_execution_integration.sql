-- v53 Production Execution Integration
CREATE TABLE IF NOT EXISTS production_execution_runs (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    production_order_id BIGINT NOT NULL,
    sku_id BIGINT NOT NULL REFERENCES skus(id),
    bom_version VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL,
    planned_output_kg NUMERIC(16,6) NOT NULL,
    actual_input_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    good_output_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    reject_output_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    wip_qty_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    completed_batch_id BIGINT NULL REFERENCES production_batches(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ NULL,
    UNIQUE (organization_id, production_order_id)
);

CREATE TABLE IF NOT EXISTS production_execution_issues (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    execution_id BIGINT NOT NULL REFERENCES production_execution_runs(id),
    item_id BIGINT NOT NULL,
    lot_id BIGINT NOT NULL REFERENCES inventory_lots(id),
    issue_type VARCHAR(30) NOT NULL,
    planned_qty_kg NUMERIC(16,6) NOT NULL,
    reserved_qty_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    actual_qty_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prod_exec_status ON production_execution_runs(organization_id, entity_id, status);
CREATE INDEX IF NOT EXISTS idx_prod_exec_issue_exec ON production_execution_issues(execution_id);
-- v53 ORM-backed deployment schema is compatible with this migration; add FK to the v52 Production Order.
ALTER TABLE production_execution_runs
    DROP CONSTRAINT IF EXISTS fk_prod_exec_order;
ALTER TABLE production_execution_runs
    ADD CONSTRAINT fk_prod_exec_order FOREIGN KEY (production_order_id)
    REFERENCES production_order(production_order_id);
