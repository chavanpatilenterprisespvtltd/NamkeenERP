-- v56: QC -> production/inventory/compliance integration
CREATE TABLE IF NOT EXISTS qc_batch_gate (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    batch_id BIGINT NOT NULL,
    qc_status VARCHAR(30) NOT NULL,
    outcome VARCHAR(30) NOT NULL,
    can_complete_batch BOOLEAN NOT NULL DEFAULT FALSE,
    requires_capa BOOLEAN NOT NULL DEFAULT FALSE,
    decided_by BIGINT,
    decided_at TIMESTAMPTZ,
    UNIQUE (organization_id, entity_id, batch_id)
);

CREATE TABLE IF NOT EXISTS qc_inventory_actions (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    batch_id BIGINT NOT NULL,
    action VARCHAR(40) NOT NULL,
    warehouse_code VARCHAR(80) NOT NULL,
    qty_kg NUMERIC(16,6) NOT NULL CHECK (qty_kg > 0),
    reason VARCHAR(200) NOT NULL,
    posted_inventory_ledger_id BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_qc_inv_actions_batch ON qc_inventory_actions(organization_id, entity_id, batch_id);

CREATE TABLE IF NOT EXISTS qc_compliance_links (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    batch_id BIGINT NOT NULL,
    requirement_code VARCHAR(100) NOT NULL,
    reference_type VARCHAR(50) NOT NULL,
    reference_id VARCHAR(100) NOT NULL,
    result VARCHAR(30) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_qc_compliance_batch ON qc_compliance_links(organization_id, entity_id, batch_id);

COMMENT ON TABLE qc_batch_gate IS 'Server-authoritative production completion/release gate derived from QC results.';
COMMENT ON TABLE qc_inventory_actions IS 'Intent/audit bridge; actual stock mutation must use the authoritative inventory posting service.';
COMMENT ON TABLE qc_compliance_links IS 'Trace link from batch QC decision to FSMS/FSSAI compliance requirement record.';
