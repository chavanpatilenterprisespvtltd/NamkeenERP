-- v49 Sales Return & Reverse Logistics schema (PostgreSQL)
CREATE TABLE IF NOT EXISTS sales_return (
    return_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    customer_id BIGINT NOT NULL,
    invoice_id BIGINT NOT NULL,
    status VARCHAR(32) NOT NULL,
    return_reason VARCHAR(64) NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    approved_by_user_id BIGINT NULL,
    approval_reason TEXT NULL,
    pickup_trip_id BIGINT NULL,
    delivery_return_reference VARCHAR(128) NULL,
    credit_note_status VARCHAR(32) NOT NULL DEFAULT 'NOT_REQUIRED',
    client_event_id UUID NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_sales_return_client_event ON sales_return(organization_id, client_event_id) WHERE client_event_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_sales_return_customer_status ON sales_return(organization_id, customer_id, status);
CREATE INDEX IF NOT EXISTS ix_sales_return_invoice ON sales_return(entity_id, invoice_id);

CREATE TABLE IF NOT EXISTS sales_return_line (
    return_line_id BIGSERIAL PRIMARY KEY,
    return_id BIGINT NOT NULL REFERENCES sales_return(return_id),
    sku_id BIGINT NOT NULL,
    invoice_line_id BIGINT NOT NULL,
    lpn_id BIGINT NULL,
    lot_id BIGINT NULL,
    requested_qty_kg NUMERIC(18,6) NOT NULL CHECK (requested_qty_kg > 0),
    received_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (received_qty_kg >= 0),
    reason VARCHAR(64) NOT NULL,
    UNIQUE(return_id, invoice_line_id, sku_id, lpn_id, lot_id)
);

CREATE TABLE IF NOT EXISTS return_qc (
    return_qc_id BIGSERIAL PRIMARY KEY,
    return_line_id BIGINT NOT NULL REFERENCES sales_return_line(return_line_id),
    disposition VARCHAR(32) NOT NULL,
    accepted_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (accepted_qty_kg >= 0),
    rejected_qty_kg NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (rejected_qty_kg >= 0),
    reason TEXT NOT NULL,
    evidence_ref TEXT NULL,
    inspected_by_user_id BIGINT NULL,
    inspected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (accepted_qty_kg + rejected_qty_kg >= 0)
);
CREATE INDEX IF NOT EXISTS ix_return_qc_line ON return_qc(return_line_id, disposition);

CREATE TABLE IF NOT EXISTS return_settlement (
    return_settlement_id BIGSERIAL PRIMARY KEY,
    return_id BIGINT NOT NULL UNIQUE REFERENCES sales_return(return_id),
    saleable_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    repack_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    rework_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    damage_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    expired_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    dispose_kg NUMERIC(18,6) NOT NULL DEFAULT 0,
    credit_note_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    inventory_action VARCHAR(64) NULL,
    credit_note_action VARCHAR(64) NULL,
    posted_at TIMESTAMPTZ NULL,
    posted_by_user_id BIGINT NULL
);

CREATE TABLE IF NOT EXISTS reverse_logistics_scan (
    scan_id BIGSERIAL PRIMARY KEY,
    return_id BIGINT NOT NULL REFERENCES sales_return(return_id),
    lpn_id BIGINT NULL,
    barcode VARCHAR(128) NOT NULL,
    action VARCHAR(32) NOT NULL,
    client_event_id UUID NOT NULL UNIQUE,
    scanned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    gps_lat NUMERIC(10,7) NULL,
    gps_lon NUMERIC(10,7) NULL,
    evidence_ref TEXT NULL
);

CREATE TABLE IF NOT EXISTS return_exception (
    exception_id BIGSERIAL PRIMARY KEY,
    return_id BIGINT NOT NULL REFERENCES sales_return(return_id),
    exception_type VARCHAR(64) NOT NULL,
    reason TEXT NOT NULL,
    evidence_ref TEXT NULL,
    approved_by_user_id BIGINT NULL,
    approved_at TIMESTAMPTZ NULL
);
