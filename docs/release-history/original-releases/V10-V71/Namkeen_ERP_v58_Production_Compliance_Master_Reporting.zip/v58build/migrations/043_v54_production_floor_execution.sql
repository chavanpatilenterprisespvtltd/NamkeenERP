-- v54 Production Floor Execution
CREATE TABLE IF NOT EXISTS production_floor_runs (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    production_order_id BIGINT NOT NULL,
    batch_id BIGINT NOT NULL REFERENCES production_batches(id),
    sku_id BIGINT NOT NULL REFERENCES skus(id),
    planned_output_kg NUMERIC(16,6) NOT NULL,
    good_output_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    reject_output_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    wip_output_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    oil_qty_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    fuel_qty_kg NUMERIC(16,6) NOT NULL DEFAULT 0,
    downtime_minutes NUMERIC(16,3) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'PLANNED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ NULL,
    UNIQUE (organization_id, entity_id, production_order_id)
);
CREATE TABLE IF NOT EXISTS production_floor_shifts (
    id BIGSERIAL PRIMARY KEY,
    floor_run_id BIGINT NOT NULL REFERENCES production_floor_runs(id),
    operator_id BIGINT NOT NULL REFERENCES users(id),
    shift_code VARCHAR(30) NOT NULL,
    hours NUMERIC(10,3) NOT NULL,
    headcount INTEGER NOT NULL DEFAULT 1,
    notes TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS production_floor_stages (
    id BIGSERIAL PRIMARY KEY,
    floor_run_id BIGINT NOT NULL REFERENCES production_floor_runs(id),
    sequence_no INTEGER NOT NULL,
    stage_code VARCHAR(50) NOT NULL,
    machine_id BIGINT NULL,
    target_minutes NUMERIC(10,2) NULL,
    actual_minutes NUMERIC(10,2) NULL,
    downtime_minutes NUMERIC(10,2) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'PLANNED',
    operator_id BIGINT NULL REFERENCES users(id),
    UNIQUE (floor_run_id, sequence_no)
);
CREATE TABLE IF NOT EXISTS production_floor_consumptions (
    id BIGSERIAL PRIMARY KEY,
    floor_run_id BIGINT NOT NULL REFERENCES production_floor_runs(id),
    component_code VARCHAR(50) NOT NULL,
    lot_id BIGINT NULL REFERENCES inventory_lots(id),
    quantity_kg NUMERIC(16,6) NOT NULL,
    unit_cost NUMERIC(16,4) NOT NULL DEFAULT 0,
    reference VARCHAR(100) NULL
);
CREATE TABLE IF NOT EXISTS production_floor_qc (
    id BIGSERIAL PRIMARY KEY,
    floor_run_id BIGINT NOT NULL REFERENCES production_floor_runs(id),
    checkpoint_code VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,
    parameter_values JSONB NOT NULL DEFAULT '{}'::jsonb,
    result_notes TEXT NULL,
    evidence_ref VARCHAR(255) NULL,
    checked_by BIGINT NULL REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS production_floor_wastage (
    id BIGSERIAL PRIMARY KEY,
    floor_run_id BIGINT NOT NULL REFERENCES production_floor_runs(id),
    qty_kg NUMERIC(16,6) NOT NULL,
    reason_code VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'RECORDED',
    authorized_by BIGINT NULL REFERENCES users(id),
    evidence_ref VARCHAR(255) NULL
);
CREATE TABLE IF NOT EXISTS production_floor_downtime (
    id BIGSERIAL PRIMARY KEY,
    floor_run_id BIGINT NOT NULL REFERENCES production_floor_runs(id),
    stage_id BIGINT NULL REFERENCES production_floor_stages(id),
    minutes NUMERIC(10,2) NOT NULL,
    reason_code VARCHAR(50) NOT NULL,
    created_by BIGINT NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_floor_run_status ON production_floor_runs(organization_id, entity_id, status);
CREATE INDEX IF NOT EXISTS idx_floor_stage_run ON production_floor_stages(floor_run_id, sequence_no);
CREATE INDEX IF NOT EXISTS idx_floor_qc_run ON production_floor_qc(floor_run_id, status);
CREATE INDEX IF NOT EXISTS idx_floor_consumption_run ON production_floor_consumptions(floor_run_id);
