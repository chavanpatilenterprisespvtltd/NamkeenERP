-- v25 inventory/warehouse layer. Run after migrations 001..013.
CREATE TABLE IF NOT EXISTS warehouses (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
 code VARCHAR(50) NOT NULL, name VARCHAR(160) NOT NULL, warehouse_type VARCHAR(40) NOT NULL DEFAULT 'FG', active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(entity_id,code)
);
CREATE INDEX IF NOT EXISTS idx_warehouse_scope ON warehouses(organization_id,entity_id,active);
CREATE TABLE IF NOT EXISTS suppliers (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id),
 code VARCHAR(60) NOT NULL, name VARCHAR(200) NOT NULL, gstin VARCHAR(20), active BOOLEAN NOT NULL DEFAULT TRUE, UNIQUE(organization_id,code)
);
CREATE TABLE IF NOT EXISTS inventory_receipts (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), warehouse_id BIGINT NOT NULL REFERENCES warehouses(id), supplier_id BIGINT REFERENCES suppliers(id),
 receipt_no VARCHAR(80) NOT NULL, receipt_type VARCHAR(30) NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'DRAFT', received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), qc_status VARCHAR(30) NOT NULL DEFAULT 'PENDING', evidence_file_id VARCHAR(160), created_by BIGINT NOT NULL REFERENCES users(id), UNIQUE(entity_id,receipt_no)
);
CREATE INDEX IF NOT EXISTS idx_receipt_scope_status ON inventory_receipts(organization_id,entity_id,status,qc_status);
CREATE TABLE IF NOT EXISTS inventory_receipt_lines (
 id BIGSERIAL PRIMARY KEY, receipt_id BIGINT NOT NULL REFERENCES inventory_receipts(id), sku_id BIGINT NOT NULL REFERENCES skus(id), supplier_lot_no VARCHAR(100), qty_received NUMERIC(16,3) NOT NULL, qty_accepted NUMERIC(16,3) NOT NULL DEFAULT 0, qty_rejected NUMERIC(16,3) NOT NULL DEFAULT 0, expiry_date DATE, unit_cost NUMERIC(14,4), qc_result VARCHAR(30) NOT NULL DEFAULT 'PENDING'
);
CREATE TABLE IF NOT EXISTS inventory_qc (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), receipt_id BIGINT REFERENCES inventory_receipts(id), receipt_line_id BIGINT REFERENCES inventory_receipt_lines(id), lot_id BIGINT REFERENCES inventory_lots(id), result VARCHAR(30) NOT NULL, remarks TEXT, coa_reference VARCHAR(160), evidence_file_id VARCHAR(160), checked_by BIGINT NOT NULL REFERENCES users(id), checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS stock_movements (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), sku_id BIGINT NOT NULL REFERENCES skus(id), from_warehouse_id BIGINT REFERENCES warehouses(id), to_warehouse_id BIGINT REFERENCES warehouses(id), lot_id BIGINT REFERENCES inventory_lots(id), qty NUMERIC(16,3) NOT NULL, movement_type VARCHAR(40) NOT NULL, reference_type VARCHAR(50) NOT NULL, reference_id VARCHAR(100) NOT NULL, barcode VARCHAR(140), created_by BIGINT NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_stock_movement_scope ON stock_movements(organization_id,entity_id,created_at);
CREATE INDEX IF NOT EXISTS idx_stock_movement_ref ON stock_movements(reference_type,reference_id);
CREATE TABLE IF NOT EXISTS stock_transfers (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), transfer_no VARCHAR(80) NOT NULL,
 from_warehouse_id BIGINT NOT NULL REFERENCES warehouses(id), to_warehouse_id BIGINT NOT NULL REFERENCES warehouses(id), status VARCHAR(30) NOT NULL DEFAULT 'DRAFT', created_by BIGINT NOT NULL REFERENCES users(id), approved_by BIGINT REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(entity_id,transfer_no)
);
CREATE INDEX IF NOT EXISTS idx_transfer_scope_status ON stock_transfers(organization_id,entity_id,status);
CREATE TABLE IF NOT EXISTS stock_transfer_lines (
 id BIGSERIAL PRIMARY KEY, transfer_id BIGINT NOT NULL REFERENCES stock_transfers(id), sku_id BIGINT NOT NULL REFERENCES skus(id), lot_id BIGINT REFERENCES inventory_lots(id), qty NUMERIC(16,3) NOT NULL
);
CREATE TABLE IF NOT EXISTS stock_adjustments (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), warehouse_id BIGINT NOT NULL REFERENCES warehouses(id), sku_id BIGINT NOT NULL REFERENCES skus(id), lot_id BIGINT REFERENCES inventory_lots(id), qty_delta NUMERIC(16,3) NOT NULL, reason TEXT NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'PENDING', requested_by BIGINT NOT NULL REFERENCES users(id), approved_by BIGINT REFERENCES users(id), approved_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS barcode_events (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), barcode VARCHAR(140) NOT NULL, code_type VARCHAR(30) NOT NULL DEFAULT 'QR', event_type VARCHAR(40) NOT NULL, reference_type VARCHAR(50) NOT NULL, reference_id VARCHAR(100) NOT NULL, captured_by BIGINT NOT NULL REFERENCES users(id), captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_barcode_scope_code ON barcode_events(organization_id,entity_id,barcode);
CREATE TABLE IF NOT EXISTS traceability_links (
 id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), source_type VARCHAR(50) NOT NULL, source_id VARCHAR(100) NOT NULL, target_type VARCHAR(50) NOT NULL, target_id VARCHAR(100) NOT NULL, relationship VARCHAR(50) NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_trace_source ON traceability_links(organization_id,entity_id,source_type,source_id);
CREATE INDEX IF NOT EXISTS idx_trace_target ON traceability_links(organization_id,entity_id,target_type,target_id);
