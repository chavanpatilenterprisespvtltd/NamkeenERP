-- v55 Factory QC + Process Control
CREATE TABLE IF NOT EXISTS qc_specifications (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    sku_id BIGINT NOT NULL REFERENCES skus(id),
    spec_code VARCHAR(80) NOT NULL,
    version VARCHAR(40) NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, entity_id, sku_id, spec_code, version)
);
CREATE TABLE IF NOT EXISTS qc_spec_parameters (
    id BIGSERIAL PRIMARY KEY,
    specification_id BIGINT NOT NULL REFERENCES qc_specifications(id) ON DELETE CASCADE,
    parameter_code VARCHAR(80) NOT NULL,
    min_value NUMERIC(16,6) NULL,
    max_value NUMERIC(16,6) NULL,
    target_value NUMERIC(16,6) NULL,
    unit VARCHAR(30) NULL,
    severity VARCHAR(20) NOT NULL DEFAULT 'MAJOR',
    UNIQUE (specification_id, parameter_code)
);
CREATE TABLE IF NOT EXISTS qc_sampling_plans (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    plan_code VARCHAR(80) NOT NULL,
    sample_count INTEGER NOT NULL,
    min_pass_count INTEGER NOT NULL,
    critical_all_must_pass BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (organization_id, entity_id, plan_code)
);
CREATE TABLE IF NOT EXISTS qc_inspections (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    inspection_no VARCHAR(80) NOT NULL,
    batch_id BIGINT NOT NULL REFERENCES production_batches(id),
    sku_id BIGINT NOT NULL REFERENCES skus(id),
    stage_code VARCHAR(80) NOT NULL,
    specification_id BIGINT NOT NULL REFERENCES qc_specifications(id),
    sampling_plan_id BIGINT NOT NULL REFERENCES qc_sampling_plans(id),
    status VARCHAR(30) NOT NULL DEFAULT 'NOT_CHECKED',
    disposition VARCHAR(30) NULL,
    capa_required BOOLEAN NOT NULL DEFAULT FALSE,
    created_by BIGINT NOT NULL REFERENCES users(id),
    released_by BIGINT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, entity_id, inspection_no)
);
CREATE TABLE IF NOT EXISTS qc_measurements (
    id BIGSERIAL PRIMARY KEY,
    inspection_id BIGINT NOT NULL REFERENCES qc_inspections(id) ON DELETE CASCADE,
    parameter_code VARCHAR(80) NOT NULL,
    sample_no INTEGER NOT NULL DEFAULT 1,
    value NUMERIC(16,6) NOT NULL,
    status VARCHAR(20) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    evidence_ref VARCHAR(255) NULL,
    note TEXT NULL,
    checked_by BIGINT NULL REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS qc_oil_tpc_checks (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    batch_id BIGINT NOT NULL REFERENCES production_batches(id),
    reading_pct NUMERIC(10,4) NOT NULL,
    limit_pct NUMERIC(10,4) NOT NULL,
    status VARCHAR(20) NOT NULL,
    checked_by BIGINT NULL REFERENCES users(id),
    evidence_ref VARCHAR(255) NULL,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS qc_process_deviations (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    batch_id BIGINT NOT NULL REFERENCES production_batches(id),
    stage_code VARCHAR(80) NOT NULL,
    parameter_code VARCHAR(80) NOT NULL,
    actual_value NUMERIC(16,6) NOT NULL,
    reason TEXT NOT NULL,
    severity VARCHAR(20) NOT NULL,
    capa_required BOOLEAN NOT NULL DEFAULT TRUE,
    evidence_ref VARCHAR(255) NULL,
    created_by BIGINT NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS qc_capa (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    capa_no VARCHAR(80) NOT NULL,
    source_type VARCHAR(40) NOT NULL,
    source_id VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    owner_id BIGINT NULL REFERENCES users(id),
    due_date DATE NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    root_cause TEXT NULL,
    corrective_action TEXT NULL,
    preventive_action TEXT NULL,
    closed_by BIGINT NULL REFERENCES users(id),
    closed_at TIMESTAMPTZ NULL,
    UNIQUE (organization_id, entity_id, capa_no)
);
CREATE TABLE IF NOT EXISTS qc_water_tests (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    test_no VARCHAR(80) NOT NULL,
    source_code VARCHAR(80) NOT NULL,
    test_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL,
    lab_report_ref VARCHAR(255) NULL,
    UNIQUE (organization_id, entity_id, test_no)
);
CREATE INDEX IF NOT EXISTS idx_qc_inspection_batch ON qc_inspections(organization_id, entity_id, batch_id, status);
CREATE INDEX IF NOT EXISTS idx_qc_measurements_inspection ON qc_measurements(inspection_id, parameter_code);
CREATE INDEX IF NOT EXISTS idx_qc_tpc_batch ON qc_oil_tpc_checks(organization_id, entity_id, batch_id, checked_at);
CREATE INDEX IF NOT EXISTS idx_qc_deviation_batch ON qc_process_deviations(organization_id, entity_id, batch_id, severity);
CREATE INDEX IF NOT EXISTS idx_qc_capa_status ON qc_capa(organization_id, entity_id, status, due_date);
