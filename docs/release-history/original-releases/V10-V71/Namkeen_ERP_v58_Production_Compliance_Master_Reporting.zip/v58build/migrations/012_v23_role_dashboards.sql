-- v23 operational indexes for role-scoped dashboard reads.
CREATE INDEX IF NOT EXISTS idx_sales_orders_org_entity_created ON sales_orders(organization_id, entity_id, created_at);
CREATE INDEX IF NOT EXISTS idx_customers_org_entity_approval ON customers(organization_id, entity_id, approval_status);
CREATE INDEX IF NOT EXISTS idx_payments_org_entity_status ON payments(organization_id, entity_id, status);
CREATE INDEX IF NOT EXISTS idx_inventory_lot_org_entity_sku ON inventory_lots(organization_id, entity_id, sku_id);
