-- v35 Purchase-to-Pay migration (PostgreSQL)
CREATE TABLE IF NOT EXISTS supplier_invoices (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    supplier_id BIGINT NOT NULL,
    invoice_no VARCHAR(100) NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    taxable_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    tax_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    grand_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
    document_file_id VARCHAR(160),
    created_by BIGINT REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (organization_id, supplier_id, invoice_no)
);
CREATE TABLE IF NOT EXISTS supplier_invoice_lines (
    id BIGSERIAL PRIMARY KEY,
    invoice_id BIGINT NOT NULL REFERENCES supplier_invoices(id) ON DELETE CASCADE,
    po_line_id BIGINT NOT NULL,
    quantity_kg NUMERIC(18,3) NOT NULL,
    unit_price NUMERIC(18,4) NOT NULL,
    tax_code VARCHAR(50),
    UNIQUE (invoice_id, po_line_id)
);
CREATE TABLE IF NOT EXISTS p2p_match_runs (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    invoice_id BIGINT NOT NULL REFERENCES supplier_invoices(id),
    po_id BIGINT NOT NULL,
    status VARCHAR(24) NOT NULL,
    qty_tolerance_kg NUMERIC(18,3) NOT NULL DEFAULT 0,
    price_tolerance NUMERIC(18,4) NOT NULL DEFAULT 0,
    amount_tolerance NUMERIC(18,2) NOT NULL DEFAULT 0.01,
    exception_reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS supplier_payables (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_id BIGINT NOT NULL REFERENCES entities(id),
    supplier_id BIGINT NOT NULL,
    invoice_id BIGINT NOT NULL UNIQUE REFERENCES supplier_invoices(id),
    due_date DATE NOT NULL,
    original_amount NUMERIC(18,2) NOT NULL,
    outstanding_amount NUMERIC(18,2) NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'OPEN',
    approved_by BIGINT REFERENCES users(id),
    approved_at TIMESTAMPTZ,
    on_hold_reason TEXT
);
CREATE TABLE IF NOT EXISTS supplier_payments (
    id BIGSERIAL PRIMARY KEY,
    payable_id BIGINT NOT NULL REFERENCES supplier_payables(id),
    payment_date DATE NOT NULL,
    amount NUMERIC(18,2) NOT NULL,
    mode VARCHAR(32) NOT NULL,
    reference_no VARCHAR(120),
    status VARCHAR(24) NOT NULL DEFAULT 'SCHEDULED',
    paid_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_supplier_invoice_due ON supplier_invoices(organization_id, supplier_id, due_date, status);
CREATE INDEX IF NOT EXISTS idx_payable_outstanding ON supplier_payables(organization_id, entity_id, supplier_id, status, due_date);
CREATE INDEX IF NOT EXISTS idx_supplier_payment_status ON supplier_payments(status, payment_date);
