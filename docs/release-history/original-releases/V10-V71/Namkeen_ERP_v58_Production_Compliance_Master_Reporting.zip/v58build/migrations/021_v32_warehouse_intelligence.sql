-- v32 warehouse intelligence. Read models keep inventory ledger authoritative.
CREATE TABLE IF NOT EXISTS inventory_reorder_policies (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id),
  entity_id BIGINT NOT NULL REFERENCES entities(id),
  warehouse_id BIGINT NOT NULL REFERENCES warehouses(id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  minimum_stock_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  reorder_level_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  target_stock_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  safety_stock_kg NUMERIC(16,3) NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ck_v32_reorder_values CHECK (minimum_stock_kg >= 0 AND reorder_level_kg >= minimum_stock_kg AND target_stock_kg >= reorder_level_kg AND safety_stock_kg >= 0),
  CONSTRAINT uq_v32_reorder_policy UNIQUE (organization_id, entity_id, warehouse_id, sku_id, effective_from)
);
CREATE INDEX IF NOT EXISTS idx_v32_reorder_scope ON inventory_reorder_policies(organization_id,entity_id,warehouse_id,active,sku_id);

-- Operational read views are intentionally views, not second sources of stock truth.
CREATE OR REPLACE VIEW v32_warehouse_summary AS
SELECT w.organization_id, w.entity_id, w.id AS warehouse_id,
       COALESCE(SUM(il.qty_available),0)::NUMERIC(18,3) AS total_stock_kg,
       COALESCE(SUM(GREATEST(il.qty_available-il.qty_reserved,0)),0)::NUMERIC(18,3) AS available_stock_kg,
       COALESCE(SUM(GREATEST(il.qty_reserved,0)),0)::NUMERIC(18,3) AS reserved_stock_kg,
       COALESCE(SUM(CASE WHEN il.expiry_date < CURRENT_DATE THEN GREATEST(il.qty_available-il.qty_reserved,0) ELSE 0 END),0)::NUMERIC(18,3) AS expired_kg,
       COALESCE(SUM(CASE WHEN il.expiry_date BETWEEN CURRENT_DATE AND CURRENT_DATE+7 THEN GREATEST(il.qty_available-il.qty_reserved,0) ELSE 0 END),0)::NUMERIC(18,3) AS expiring_7d_kg,
       COALESCE(SUM(CASE WHEN il.expiry_date > CURRENT_DATE+7 AND il.expiry_date <= CURRENT_DATE+30 THEN GREATEST(il.qty_available-il.qty_reserved,0) ELSE 0 END),0)::NUMERIC(18,3) AS expiring_30d_kg,
       0::BIGINT AS bin_count, 0::BIGINT AS occupied_bin_count, 0::NUMERIC(8,2) AS occupancy_pct
FROM warehouses w LEFT JOIN inventory_lots il ON il.organization_id=w.organization_id AND il.entity_id=w.entity_id AND il.warehouse_code=w.code
GROUP BY w.organization_id,w.entity_id,w.id;

CREATE OR REPLACE VIEW v32_replenishment_alerts AS
SELECT p.organization_id,p.entity_id,p.warehouse_id,p.sku_id,
       COALESCE(SUM(GREATEST(il.qty_available-il.qty_reserved,0)),0)::NUMERIC(18,3) AS available_kg,
       p.minimum_stock_kg,p.reorder_level_kg,p.target_stock_kg,
       GREATEST(p.target_stock_kg-COALESCE(SUM(GREATEST(il.qty_available-il.qty_reserved,0)),0),0)::NUMERIC(18,3) AS suggested_qty_kg,
       CASE WHEN COALESCE(SUM(GREATEST(il.qty_available-il.qty_reserved,0)),0) <= p.minimum_stock_kg THEN 'CRITICAL' ELSE 'REORDER' END AS severity,
       CASE WHEN COALESCE(SUM(GREATEST(il.qty_available-il.qty_reserved,0)),0) <= p.minimum_stock_kg THEN 0 ELSE 1 END AS severity_order
FROM inventory_reorder_policies p LEFT JOIN warehouses w ON w.id=p.warehouse_id LEFT JOIN inventory_lots il ON il.organization_id=p.organization_id AND il.entity_id=p.entity_id AND il.warehouse_code=w.code AND il.sku_id=p.sku_id
WHERE p.active=TRUE GROUP BY p.organization_id,p.entity_id,p.warehouse_id,p.sku_id,p.minimum_stock_kg,p.reorder_level_kg,p.target_stock_kg;

CREATE OR REPLACE VIEW v32_fefo_availability AS
SELECT il.organization_id, il.entity_id, w.id AS warehouse_id, il.sku_id, il.id AS lot_id, il.batch_no, il.expiry_date,
       il.qty_available AS qty_available_kg, il.qty_reserved AS qty_reserved_kg,
       GREATEST(il.qty_available-il.qty_reserved,0)::NUMERIC(18,3) AS available_kg,
       CASE WHEN il.expiry_date IS NULL THEN DATE '9999-12-31' ELSE il.expiry_date END AS expiry_sort
FROM inventory_lots il JOIN warehouses w ON w.organization_id=il.organization_id AND w.entity_id=il.entity_id AND w.code=il.warehouse_code
WHERE il.qty_available > il.qty_reserved;

CREATE OR REPLACE VIEW v32_picking_kpis AS
SELECT organization_id,entity_id,warehouse_id,
  COUNT(*) FILTER (WHERE status='OPEN') AS open_tasks,
  COUNT(*) FILTER (WHERE status='ASSIGNED') AS assigned_tasks,
  COUNT(*) FILTER (WHERE status='PICKED') AS picked_tasks,
  0::BIGINT AS short_picks,
  CASE WHEN COUNT(*)=0 THEN 0::NUMERIC(8,2) ELSE ROUND((COUNT(*) FILTER (WHERE status='PICKED'))::NUMERIC*100/COUNT(*),2) END AS completion_pct,
  0::NUMERIC(18,3) AS picked_qty_kg
FROM pick_tasks GROUP BY organization_id,entity_id,warehouse_id;

CREATE OR REPLACE VIEW v32_count_kpis AS
SELECT organization_id,entity_id,warehouse_id,
  COUNT(*) FILTER (WHERE status='OPEN') AS open_sessions,
  COUNT(*) FILTER (WHERE status='PENDING_APPROVAL') AS pending_approval,
  COUNT(*) FILTER (WHERE status='APPROVED') AS approved,
  COALESCE(SUM(variance_kg),0)::NUMERIC(18,3) AS variance_kg
FROM cycle_count_sessions GROUP BY organization_id,entity_id,warehouse_id;
