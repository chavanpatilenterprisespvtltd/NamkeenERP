-- Namkeen ERP v18: two-way mobile sync, cursors, conflicts and dead letters.
CREATE TABLE IF NOT EXISTS sync_change_log (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    entity_type VARCHAR(80) NOT NULL,
    entity_id VARCHAR(120) NOT NULL,
    operation VARCHAR(20) NOT NULL,
    version INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sync_change_org_id ON sync_change_log(organization_id,id);
CREATE INDEX IF NOT EXISTS idx_sync_change_entity ON sync_change_log(organization_id,entity_type,entity_id);

CREATE TABLE IF NOT EXISTS sync_cursors (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    device_id VARCHAR(120) NOT NULL,
    cursor BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_sync_cursor_device UNIQUE(organization_id,device_id)
);

CREATE TABLE IF NOT EXISTS sync_conflicts (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    device_id VARCHAR(120) NOT NULL,
    client_event_id VARCHAR(120) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id VARCHAR(120) NOT NULL,
    client_version INTEGER,
    server_version INTEGER,
    client_payload_json TEXT NOT NULL,
    server_payload_json TEXT,
    resolution_status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    resolution_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ,
    resolved_by BIGINT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_sync_conflict_open ON sync_conflicts(organization_id,resolution_status,created_at);

CREATE TABLE IF NOT EXISTS sync_dead_letters (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    device_id VARCHAR(120) NOT NULL,
    client_event_id VARCHAR(120) NOT NULL,
    event_type VARCHAR(60) NOT NULL,
    payload_json TEXT NOT NULL,
    error_code VARCHAR(60) NOT NULL,
    error_message TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
