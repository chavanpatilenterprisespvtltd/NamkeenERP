-- v21: server-side mobile device lifecycle and document upload idempotency.
CREATE TABLE IF NOT EXISTS device_registrations (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    user_id BIGINT NOT NULL REFERENCES users(id),
    device_id VARCHAR(120) NOT NULL,
    platform VARCHAR(30) NOT NULL,
    app_version VARCHAR(40),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at TIMESTAMPTZ,
    UNIQUE(organization_id, device_id)
);
CREATE INDEX IF NOT EXISTS idx_device_reg_org_user ON device_registrations(organization_id, user_id);
CREATE INDEX IF NOT EXISTS idx_device_reg_active ON device_registrations(organization_id, device_id) WHERE revoked_at IS NULL;
CREATE TABLE IF NOT EXISTS mobile_documents (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    device_id VARCHAR(120) NOT NULL,
    client_document_id VARCHAR(160) NOT NULL,
    object_id VARCHAR(180),
    sha256 CHAR(64) NOT NULL,
    content_type VARCHAR(120) NOT NULL,
    size_bytes BIGINT NOT NULL,
    upload_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(organization_id, client_document_id)
);
CREATE INDEX IF NOT EXISTS idx_mobile_docs_status ON mobile_documents(organization_id, upload_status, created_at);
