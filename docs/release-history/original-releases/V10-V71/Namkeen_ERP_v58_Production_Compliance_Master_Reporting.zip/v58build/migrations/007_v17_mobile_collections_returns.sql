CREATE TABLE IF NOT EXISTS customer_profiles (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id), customer_id BIGINT NOT NULL UNIQUE REFERENCES customers(id),
  address_text TEXT, shop_photo_file_id VARCHAR(160), aadhaar_file_id VARCHAR(160), pan_file_id VARCHAR(160), extra_docs_json TEXT,
  captured_by BIGINT NOT NULL REFERENCES users(id), captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS customer_approvals (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), customer_id BIGINT NOT NULL REFERENCES customers(id),
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING', decided_by BIGINT REFERENCES users(id), reason TEXT, decided_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_customer_approval_lookup ON customer_approvals(organization_id, customer_id, status);
CREATE TABLE IF NOT EXISTS collection_evidence (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), payment_id BIGINT NOT NULL UNIQUE REFERENCES payments(id),
  counterparty_photo_file_id VARCHAR(160) NOT NULL, captured_lat NUMERIC(10,7), captured_lng NUMERIC(10,7), collected_by BIGINT NOT NULL REFERENCES users(id), submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS collection_deposits (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), payment_id BIGINT NOT NULL UNIQUE REFERENCES payments(id),
  mode VARCHAR(30) NOT NULL, deposit_ref VARCHAR(160), deposited_by BIGINT NOT NULL REFERENCES users(id), verified_by BIGINT REFERENCES users(id), status VARCHAR(30) NOT NULL DEFAULT 'SUBMITTED', deposited_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS sales_returns (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), customer_id BIGINT NOT NULL REFERENCES customers(id), order_id BIGINT REFERENCES sales_orders(id),
  return_no VARCHAR(80) NOT NULL UNIQUE, status VARCHAR(30) NOT NULL DEFAULT 'QC_HOLD', reason_code VARCHAR(50) NOT NULL, initiated_by BIGINT NOT NULL REFERENCES users(id), evidence_file_id VARCHAR(160), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_returns_customer_status ON sales_returns(organization_id, customer_id, status);
CREATE TABLE IF NOT EXISTS sales_return_lines (
  id BIGSERIAL PRIMARY KEY, return_id BIGINT NOT NULL REFERENCES sales_returns(id), sku_id BIGINT NOT NULL REFERENCES skus(id), qty NUMERIC(16,3) NOT NULL, batch_no VARCHAR(80)
);
CREATE TABLE IF NOT EXISTS return_dispositions (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), entity_id BIGINT NOT NULL REFERENCES entities(id), return_id BIGINT NOT NULL UNIQUE REFERENCES sales_returns(id),
  disposition VARCHAR(30) NOT NULL, reason TEXT, authorized_by BIGINT NOT NULL REFERENCES users(id), authorized_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS notification_deliveries (
  id BIGSERIAL PRIMARY KEY, organization_id BIGINT NOT NULL REFERENCES organizations(id), outbox_id BIGINT NOT NULL REFERENCES notification_outbox(id), channel VARCHAR(30) NOT NULL,
  destination VARCHAR(240) NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, delivered_at TIMESTAMPTZ,
  UNIQUE(outbox_id, channel, destination)
);
CREATE INDEX IF NOT EXISTS idx_notification_delivery_status ON notification_deliveries(status);
