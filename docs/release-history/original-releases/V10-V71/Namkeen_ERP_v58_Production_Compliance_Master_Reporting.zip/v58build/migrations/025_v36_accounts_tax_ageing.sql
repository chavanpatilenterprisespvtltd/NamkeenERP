-- v36 Accounts, tax and supplier ageing extension
CREATE TABLE IF NOT EXISTS tax_profile (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  tax_code TEXT NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  inclusive BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE (organization_id, tax_code, effective_from)
);
CREATE TABLE IF NOT EXISTS tax_profile_component (
  id BIGSERIAL PRIMARY KEY,
  tax_profile_id BIGINT NOT NULL REFERENCES tax_profile(id),
  component_code TEXT NOT NULL,
  rate_pct NUMERIC(9,4) NOT NULL,
  UNIQUE (tax_profile_id, component_code)
);
CREATE TABLE IF NOT EXISTS tax_transaction (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  source_type TEXT NOT NULL,
  source_id BIGINT NOT NULL,
  taxable_value NUMERIC(18,2) NOT NULL,
  tax_total NUMERIC(18,2) NOT NULL,
  tds_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  tcs_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  grand_total NUMERIC(18,2) NOT NULL,
  net_payable NUMERIC(18,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'POSTED',
  posted_at TIMESTAMPTZ,
  UNIQUE (organization_id, source_type, source_id)
);
CREATE TABLE IF NOT EXISTS tax_transaction_component (
  id BIGSERIAL PRIMARY KEY,
  tax_transaction_id BIGINT NOT NULL REFERENCES tax_transaction(id),
  component_code TEXT NOT NULL,
  rate_pct NUMERIC(9,4) NOT NULL,
  amount NUMERIC(18,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS supplier_adjustment_note (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  supplier_id BIGINT NOT NULL,
  note_type TEXT NOT NULL CHECK(note_type IN ('DEBIT','CREDIT')),
  original_invoice_id BIGINT NOT NULL,
  note_date DATE NOT NULL,
  taxable_amount NUMERIC(18,2) NOT NULL,
  tax_amount NUMERIC(18,2) NOT NULL,
  grand_amount NUMERIC(18,2) NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT'
);
CREATE TABLE IF NOT EXISTS payment_reconciliation (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  payment_id BIGINT NOT NULL,
  supplier_id BIGINT NOT NULL,
  bank_reference TEXT NOT NULL,
  value_date DATE NOT NULL,
  matched_payable_id BIGINT,
  matched_amount NUMERIC(18,2),
  difference NUMERIC(18,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  UNIQUE (organization_id, payment_id)
);
CREATE TABLE IF NOT EXISTS accounting_posting (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL,
  entity_id BIGINT NOT NULL,
  source_type TEXT NOT NULL,
  source_id BIGINT NOT NULL,
  debit_account TEXT NOT NULL,
  credit_account TEXT NOT NULL,
  amount NUMERIC(18,2) NOT NULL,
  posting_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  external_reference TEXT,
  UNIQUE (organization_id, source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_tax_txn_source ON tax_transaction(organization_id, source_type, source_id);
CREATE INDEX IF NOT EXISTS idx_payable_ageing ON supplier_invoice(entity_id, due_date, status);
CREATE INDEX IF NOT EXISTS idx_payable_supplier_due ON supplier_invoice(supplier_id, due_date, status);
CREATE INDEX IF NOT EXISTS idx_payment_recon_supplier ON payment_reconciliation(supplier_id, value_date, status);
CREATE INDEX IF NOT EXISTS idx_accounting_posting_status ON accounting_posting(organization_id, entity_id, posting_date, status);
