-- v58: compliance master data, source references, documents and inspection/reporting support
CREATE TABLE IF NOT EXISTS compliance_source_reference (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    source_code VARCHAR(128) NOT NULL,
    authority VARCHAR(128) NOT NULL,
    title TEXT NOT NULL,
    official_url TEXT NOT NULL,
    issued_on DATE,
    effective_from DATE,
    notes TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (organization_id, source_code)
);

CREATE TABLE IF NOT EXISTS compliance_control_master (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    control_code VARCHAR(128) NOT NULL,
    title TEXT NOT NULL,
    requirement_class VARCHAR(32) NOT NULL,
    authority VARCHAR(128) NOT NULL,
    evidence_type VARCHAR(64) NOT NULL,
    frequency_days INTEGER,
    condition_expr TEXT,
    active_from DATE NOT NULL,
    active_to DATE,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    UNIQUE (organization_id, control_code, active_from)
);

CREATE INDEX IF NOT EXISTS idx_compliance_control_active
ON compliance_control_master(organization_id, status, active_from, active_to);

CREATE TABLE IF NOT EXISTS compliance_control_source (
    control_id BIGINT NOT NULL REFERENCES compliance_control_master(id) ON DELETE CASCADE,
    source_id BIGINT NOT NULL REFERENCES compliance_source_reference(id) ON DELETE RESTRICT,
    PRIMARY KEY (control_id, source_id)
);

CREATE TABLE IF NOT EXISTS site_document_register (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    document_type VARCHAR(64) NOT NULL,
    title TEXT NOT NULL,
    document_number VARCHAR(128),
    issued_on DATE,
    valid_from DATE,
    valid_to DATE,
    perpetual BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    storage_ref TEXT,
    sha256 CHAR(64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_site_document_expiry
ON site_document_register(site_id, status, valid_to);

CREATE TABLE IF NOT EXISTS inspection_checklist_master (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    checklist_code VARCHAR(128) NOT NULL,
    title TEXT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (organization_id, checklist_code)
);

CREATE TABLE IF NOT EXISTS inspection_checklist_item (
    id BIGSERIAL PRIMARY KEY,
    checklist_id BIGINT NOT NULL REFERENCES inspection_checklist_master(id) ON DELETE CASCADE,
    control_code VARCHAR(128) NOT NULL,
    prompt TEXT NOT NULL,
    critical BOOLEAN NOT NULL DEFAULT FALSE,
    expected_evidence VARCHAR(64),
    fail_action VARCHAR(32) NOT NULL DEFAULT 'FINDING'
);

CREATE TABLE IF NOT EXISTS compliance_register_export_run (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    site_id BIGINT NOT NULL,
    register_name VARCHAR(128) NOT NULL,
    requested_by BIGINT NOT NULL,
    as_of_date DATE NOT NULL,
    row_count INTEGER NOT NULL DEFAULT 0,
    export_ref TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_compliance_export_run_site_date
ON compliance_register_export_run(site_id, as_of_date, register_name);

-- Current official references are stored as data, not application constants.
-- Legal classification/applicability must still be reviewed by the responsible compliance team.
