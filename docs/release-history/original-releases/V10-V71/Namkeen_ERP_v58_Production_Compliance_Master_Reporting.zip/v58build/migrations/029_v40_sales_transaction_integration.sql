-- v40: commercial transaction integration layer
-- Final authoritative mutations must execute inside the existing transaction/posting service.

CREATE TABLE IF NOT EXISTS sales_transaction_runs (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    entity_id BIGINT NOT NULL,
    order_no VARCHAR(100) NOT NULL,
    idempotency_key VARCHAR(160),
    state VARCHAR(40) NOT NULL,
    customer_id BIGINT NOT NULL,
    payment_mode VARCHAR(30) NOT NULL,
    payment_state VARCHAR(30) NOT NULL,
    credit_state VARCHAR(30) NOT NULL,
    taxable_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    tax_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    invoice_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    gross_margin_value NUMERIC(18,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (organization_id, idempotency_key)
);

CREATE TABLE IF NOT EXISTS sales_transaction_postings (
    id BIGSERIAL PRIMARY KEY,
    transaction_run_id BIGINT NOT NULL REFERENCES sales_transaction_runs(id),
    posting_type VARCHAR(40) NOT NULL,
    reference_no VARCHAR(100) NOT NULL,
    debit_account VARCHAR(120) NOT NULL,
    credit_account VARCHAR(120) NOT NULL,
    amount NUMERIC(18,2) NOT NULL,
    tax_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    posted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sales_txn_runs_customer_state ON sales_transaction_runs (organization_id, customer_id, state);
CREATE INDEX IF NOT EXISTS idx_sales_txn_runs_order ON sales_transaction_runs (organization_id, entity_id, order_no);
CREATE INDEX IF NOT EXISTS idx_sales_txn_postings_ref ON sales_transaction_postings (reference_no, posted);
