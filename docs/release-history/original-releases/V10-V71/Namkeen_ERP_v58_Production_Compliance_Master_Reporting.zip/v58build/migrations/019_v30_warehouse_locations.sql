-- v30: warehouse location/bin management + pallet/container hierarchy
CREATE TABLE IF NOT EXISTS warehouse_location (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    parent_location_id BIGINT NULL REFERENCES warehouse_location(id),
    code VARCHAR(80) NOT NULL,
    name VARCHAR(160) NOT NULL,
    location_type VARCHAR(30) NOT NULL DEFAULT 'BIN',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    capacity_kg NUMERIC(24,9) NULL CHECK (capacity_kg IS NULL OR capacity_kg >= 0),
    sequence_no INTEGER NOT NULL DEFAULT 0,
    allow_putaway BOOLEAN NOT NULL DEFAULT TRUE,
    allow_picking BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, warehouse_id, code)
);
CREATE INDEX IF NOT EXISTS ix_warehouse_location_parent_v30 ON warehouse_location(organization_id, parent_location_id);
CREATE INDEX IF NOT EXISTS ix_warehouse_location_wh_type_v30 ON warehouse_location(organization_id, warehouse_id, location_type, active);

CREATE TABLE IF NOT EXISTS warehouse_putaway_rule (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    sku_id BIGINT NULL,
    product_id BIGINT NULL,
    location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    priority INTEGER NOT NULL DEFAULT 100,
    min_qty_kg NUMERIC(24,9) NULL,
    max_qty_kg NUMERIC(24,9) NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (min_qty_kg IS NULL OR min_qty_kg >= 0),
    CHECK (max_qty_kg IS NULL OR max_qty_kg >= 0)
);
CREATE INDEX IF NOT EXISTS ix_putaway_rule_match_v30 ON warehouse_putaway_rule(organization_id, warehouse_id, sku_id, product_id, priority, active);

CREATE TABLE IF NOT EXISTS warehouse_pick_task (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    warehouse_id BIGINT NOT NULL,
    source_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    destination_location_id BIGINT NOT NULL REFERENCES warehouse_location(id),
    lpn_id BIGINT NULL REFERENCES license_plate(id),
    sku_id BIGINT NULL,
    lot_id BIGINT NULL,
    qty_kg NUMERIC(24,9) NOT NULL CHECK (qty_kg > 0),
    sequence_no INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_pick_task_route_v30 ON warehouse_pick_task(organization_id, warehouse_id, status, sequence_no, source_location_id);

CREATE TABLE IF NOT EXISTS license_plate_hierarchy_event_v30 (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    parent_lpn_id BIGINT NOT NULL REFERENCES license_plate(id),
    child_lpn_id BIGINT NOT NULL REFERENCES license_plate(id),
    event_type VARCHAR(30) NOT NULL DEFAULT 'PARENT_ATTACH',
    actor_user_id BIGINT NULL,
    client_event_id VARCHAR(120) NULL,
    event_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, parent_lpn_id, child_lpn_id, event_type, client_event_id)
);
