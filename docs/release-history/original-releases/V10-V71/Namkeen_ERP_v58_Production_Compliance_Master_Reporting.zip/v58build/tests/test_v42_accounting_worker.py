import json
from datetime import datetime, timezone, timedelta
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.model_registry import *
from app.db.models_v41 import AccountingOutboxV41
from app.v42.tally_worker import TallyWorker, outbox_reconciliation

class Transport:
    def __init__(self, failures=0): self.failures=failures; self.calls=0
    def send(self, **kw):
        self.calls+=1
        if self.calls<=self.failures: raise RuntimeError('TEMP_FAIL')
        return {'ack':True,'reference':kw['idempotency_key']}

def setup():
    e=create_engine('sqlite+pysqlite:///:memory:',future=True); Base.metadata.create_all(e); s=sessionmaker(bind=e)()
    s.add_all([__import__('app.db.models',fromlist=['Organization']).Organization(id=1,name='O'),__import__('app.db.models',fromlist=['Entity']).Entity(id=1,organization_id=1,code='X',legal_name='X')]); s.commit(); return s

def add(s,status='PENDING',attempts=0,available_at=None):
    r=AccountingOutboxV41(id=1,organization_id=1,entity_id=1,transaction_run_id=1,integration_code='TALLY',idempotency_key='K1',payload_json=json.dumps({'invoice_no':'INV1','taxable_total':'100','tax_total':'18','grand_total':'118','customer_id':99,'doc_date':'2026-09-04'}),status=status,attempts=attempts,available_at=available_at or datetime.now(timezone.utc)); s.add(r); s.commit(); return r

def test_success_posting_is_idempotent():
    s=setup(); add(s); t=Transport(); w=TallyWorker(t)
    r=w.process_one(s,organization_id=1,outbox_id=1,config={}); s.commit(); assert r.status=='POSTED' and t.calls==1
    r2=w.process_one(s,organization_id=1,outbox_id=1,config={}); assert r2.status=='DUPLICATE' and t.calls==1

def test_retry_then_post():
    s=setup(); add(s); t=Transport(1); w=TallyWorker(t); w._backoff=lambda *a,**k: 0
    r=w.process_one(s,organization_id=1,outbox_id=1,config={'max_attempts':3}); assert r.status=='RETRY'; s.commit()
    r=w.process_one(s,organization_id=1,outbox_id=1,config={'max_attempts':3}); assert r.status=='POSTED'; assert t.calls==2

def test_dead_letter_after_max_attempts():
    s=setup(); add(s); t=Transport(9); w=TallyWorker(t); r=w.process_one(s,organization_id=1,outbox_id=1,config={'max_attempts':1}); assert r.status=='DEAD_LETTER'

def test_future_available_waits():
    s=setup(); add(s,available_at=datetime.now(timezone.utc)+timedelta(hours=1)); t=Transport(); w=TallyWorker(t); r=w.process_one(s,organization_id=1,outbox_id=1,config={}); assert r.status=='WAITING' and t.calls==0

def test_reconciliation_counts():
    s=setup();
    for i,st in enumerate(['PENDING','POSTED','POSTED','DEAD_LETTER'],1):
        s.add(AccountingOutboxV41(id=i,organization_id=1,entity_id=1,transaction_run_id=1,integration_code='TALLY',idempotency_key=f'K{i}',payload_json='{}',status=st,available_at=datetime.now(timezone.utc)))
    s.commit(); r=outbox_reconciliation(s,organization_id=1); assert r['PENDING']==1 and r['POSTED']==2 and r['DEAD_LETTER']==1
