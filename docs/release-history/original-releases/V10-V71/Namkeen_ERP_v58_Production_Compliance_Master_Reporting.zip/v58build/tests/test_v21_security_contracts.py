from pathlib import Path
def test_gradle_has_secure_storage_and_transport():
    text=Path('android/v21/app/build.gradle.kts').read_text(); assert 'security-crypto' in text and 'retrofit2:retrofit' in text and 'okhttp' in text
def test_sql_has_unique_device_and_document_ids():
    text=Path('migrations/011_v21_mobile_client.sql').read_text(); assert 'UNIQUE(organization_id, device_id)' in text and 'UNIQUE(organization_id, client_document_id)' in text
