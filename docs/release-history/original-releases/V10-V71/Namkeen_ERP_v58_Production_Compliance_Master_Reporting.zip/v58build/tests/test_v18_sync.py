import json
from datetime import datetime, timezone
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.models_v18 import SyncChangeLog, SyncConflict, SyncCursor, SyncDeadLetter
from app.db.models import Organization, User
from app.sync.twoway import get_deltas, compare_version


def db():
    e=create_engine("sqlite:///:memory:", future=True)
    # only create tables needed for test, with FK-less subset behavior
    SyncChangeLog.__table__.create(e)
    SyncCursor.__table__.create(e)
    SyncConflict.__table__.create(e)
    SyncDeadLetter.__table__.create(e)
    return sessionmaker(bind=e)()


def test_delta_cursor_and_versions():
    s=db()
    s.add_all([
        SyncChangeLog(id=1,organization_id=1,entity_type="CUSTOMER",entity_id="10",operation="UPDATE",version=1,payload_json='{"name":"A"}',occurred_at=datetime.now(timezone.utc)),
        SyncChangeLog(id=2,organization_id=1,entity_type="CUSTOMER",entity_id="10",operation="UPDATE",version=2,payload_json='{"name":"B"}',occurred_at=datetime.now(timezone.utc)),
    ]); s.commit()
    deltas,next_cursor=get_deltas(s,change_log_model=SyncChangeLog,org_id=1,cursor=0,limit=1)
    assert len(deltas)==1 and next_cursor==1 and deltas[0]["version"]==1
    assert compare_version(client_version=2,server_version=2)=="ACCEPTED"
    assert compare_version(client_version=1,server_version=2)=="CONFLICT"
    assert compare_version(client_version=3,server_version=2)=="REJECTED"


def test_conflict_and_dead_letter_records():
    s=db()
    c=SyncConflict(organization_id=1,device_id="d1",client_event_id="e1",entity_type="ORDER",entity_id="99",client_version=1,server_version=2,client_payload_json='{}',server_payload_json='{}')
    d=SyncDeadLetter(organization_id=1,device_id="d1",client_event_id="e2",event_type="UPDATE",payload_json='{}',error_code="X",error_message="bad")
    s.add_all([c,d]); s.commit()
    assert s.query(SyncConflict).count()==1 and s.query(SyncDeadLetter).count()==1
