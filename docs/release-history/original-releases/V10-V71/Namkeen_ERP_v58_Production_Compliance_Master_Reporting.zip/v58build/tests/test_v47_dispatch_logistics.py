from decimal import Decimal
from app.v47_logistics import *

def make_trip():
    return DeliveryTrip(1,1,'TRIP-1',10,20,30)

def test_vehicle_normalization_and_validation():
    assert normalize_vehicle_no('MH-12 AB 1234')=='MH12AB1234'
    assert validate_vehicle_no('MH-12 AB 1234')
    assert not validate_vehicle_no('12')

def test_trip_loading_state():
    t=make_trip(); start_loading(t)
    add_load(t,TripLoad(1,1,101,500,Decimal('100'),1))
    assert t.status==TransportStatus.LOADING and t.destination_count==1
    confirm_loaded(t); assert t.status==TransportStatus.LOADED
    depart_trip(t,'EWB123'); assert t.status==TransportStatus.IN_TRANSIT and t.ewb_no=='EWB123'

def test_load_must_match_trip_and_positive_qty():
    t=make_trip(); start_loading(t)
    try: add_load(t,TripLoad(1,999,101,500,Decimal('10'),1)); assert False
    except ValueError as e: assert str(e)=='TRIP_MISMATCH'
    try: add_load(t,TripLoad(2,1,102,501,Decimal('0'),2)); assert False
    except ValueError as e: assert str(e)=='INVALID_LOAD_QTY'

def test_pod_and_partial_delivery():
    d=Delivery(1,1,500,900,Decimal('100'))
    record_delivery(d,Decimal('80'),PODType.PHOTO,'doc://pod1')
    assert d.status==DeliveryStatus.PARTIALLY_DELIVERED and d.balance_kg==Decimal('20')
    try: record_delivery(d,Decimal('110'),PODType.PHOTO,'doc://pod2'); assert False
    except ValueError as e: assert str(e)=='INVALID_DELIVERED_QTY'

def test_pod_reference_required_for_evidence():
    d=Delivery(1,1,500,900,Decimal('100'))
    try: record_delivery(d,Decimal('100'),PODType.SIGNATURE,None); assert False
    except ValueError as e: assert str(e)=='POD_REFERENCE_REQUIRED'

def test_trip_cannot_finish_with_open_delivery():
    t=make_trip(); t.status=TransportStatus.IN_TRANSIT
    d=Delivery(1,1,500,900,Decimal('100'))
    try: finish_trip(t,[d]); assert False
    except ValueError as e: assert str(e)=='OPEN_DELIVERIES'

def test_freight_rate():
    assert freight_per_kg(Decimal('2500'),Decimal('1000'))==Decimal('2.5000')
