from pathlib import Path
ROOT=Path(__file__).parents[1]
A=ROOT/'android'/'v22'/'app'/'src'/'main'/'java'
ACT=list(A.rglob('MainActivity.kt'))[0].read_text()
API=list(A.rglob('ErpApi.kt'))[0].read_text()
DB=list(A.rglob('ErpSyncDatabase.kt'))[0].read_text()
MAN=(ROOT/'android'/'v22'/'app'/'src'/'main'/'AndroidManifest.xml').read_text()
BUILD=(ROOT/'android'/'v22'/'app'/'build.gradle.kts').read_text()

def test_mobile_business_navigation_exists():
    for label in ['New Customer','New Sales Order','Collect Payment','Sales Return / QC','Sync / Conflicts']:
        assert label in ACT

def test_server_sensitive_controls_explicit():
    assert 'server enforces floor, margin, approval and GST rules' in ACT
    assert 'server-authoritative' in ACT
    assert 'QC HOLD' in ACT

def test_auth_and_domain_api_contracts_exist():
    for route in ['auth/login','auth/refresh','v17/customers','v17/collections/capture','v17/returns','orders']:
        assert route in API

def test_device_evidence_permissions_declared():
    assert 'android.permission.CAMERA' in MAN
    assert 'android.permission.ACCESS_FINE_LOCATION' in MAN

def test_android_dependencies_for_real_client():
    for dep in ['converter-kotlinx-serialization','kotlinx-coroutines-android','com.google.devtools.ksp']:
        assert dep in BUILD or dep in (ROOT/'android'/'v22'/'build.gradle.kts').read_text()

def test_room_version_advanced():
    assert 'version=22' in DB
