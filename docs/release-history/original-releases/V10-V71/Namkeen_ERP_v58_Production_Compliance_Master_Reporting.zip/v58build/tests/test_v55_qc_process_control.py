from decimal import Decimal
import pytest
from app.v55.qc_control import *

def spec():
    return ProductSpecification('NAM-STD', 10, 'v1', '2026-01-01', None, (
        SpecificationLimit('TEMP', Decimal('150'), Decimal('190'), Decimal('175'), 'C', ControlSeverity.CRITICAL),
        SpecificationLimit('TIME', Decimal('3'), Decimal('8'), Decimal('5'), 'min', ControlSeverity.MAJOR),
    ))

def insp():
    return QCInspection('I-1', 100, 10, 'FRY', spec(), SamplingPlan('S1',2,2))

def test_spec_pass_fail():
    assert spec().parameter('TEMP').evaluate(175) == CheckStatus.PASS
    assert spec().parameter('TEMP').evaluate(195) == CheckStatus.FAIL

def test_sampling_requires_all_samples():
    x=insp(); x.record_measurement('TEMP',175)
    with pytest.raises(QCControlError, match='INSPECTION_SAMPLES_INCOMPLETE'): x.finalize()

def test_fail_requires_reason_context_and_requires_capa():
    x=insp(); x.record_measurement('TEMP',195, note='too hot'); x.record_measurement('TIME',5)
    assert x.finalize()==CheckStatus.FAIL; assert x.capa_required is True
    with pytest.raises(QCControlError, match='RELEASE_REQUIRES_QC_PASS'): x.apply_disposition(Disposition.RELEASE, 9)

def test_pass_can_release():
    x=insp(); x.record_measurement('TEMP',175); x.record_measurement('TIME',5)
    assert x.finalize()==CheckStatus.PASS
    x.apply_disposition(Disposition.RELEASE, 9); assert x.disposition==Disposition.RELEASE

def test_nonrelease_needs_reason():
    x=insp(); x.record_measurement('TEMP',175); x.record_measurement('TIME',5); x.finalize()
    with pytest.raises(QCControlError, match='DISPOSITION_REASON_REQUIRED'): x.apply_disposition(Disposition.REWORK,9)

def test_tpc_limit():
    assert OilTPCReading(1,24.9).status==CheckStatus.PASS
    assert OilTPCReading(1,25.1).status==CheckStatus.FAIL

def test_finalize_factory_qc():
    x=insp(); x.record_measurement('TEMP',175); x.record_measurement('TIME',5)
    result=finalize_production_qc(inspections=[x], oil_reading=OilTPCReading(100,24.9))
    assert result['status']=='PASS' and result['capa_required'] is False

def test_finalize_factory_qc_fail():
    x=insp(); x.record_measurement('TEMP',195, note='high'); x.record_measurement('TIME',5)
    result=finalize_production_qc(inspections=[x], oil_reading=OilTPCReading(100,24.9))
    assert result['status']=='FAIL' and result['capa_required'] is True

def test_hold_overrides_pass():
    x=insp(); x.record_measurement('TEMP',175); x.record_measurement('TIME',5); x.finalize(); x.apply_disposition(Disposition.HOLD,9,evidence_ref='photo://1',reason='investigation')
    result=finalize_production_qc(inspections=[x]); assert result['status']=='HOLD'

def test_capa_cannot_close_without_actions():
    c=CAPARecord('C1','QC','I-1','Temperature excursion')
    with pytest.raises(QCControlError): c.close()
    c.root_cause='heater control'; c.corrective_action='recalibrate'; c.close(); assert c.status=='CLOSED'
