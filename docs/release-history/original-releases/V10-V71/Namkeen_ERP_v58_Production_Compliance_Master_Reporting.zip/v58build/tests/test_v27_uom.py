from decimal import Decimal
import pytest
from app.uom.service_v27 import UOMRegistry, PackHierarchy, SKUHierarchy, UOM, UOMError, validate_barcode

def test_weight_conversion():
    r=UOMRegistry()
    assert r.convert(500,'G','KG') == Decimal('0.500000')
    assert r.convert(1,'KG','G') == Decimal('1000.000000')

def test_incompatible_uom_rejected():
    r=UOMRegistry()
    with pytest.raises(UOMError, match='INCOMPATIBLE_UOM'): r.convert(1,'PACK','KG')

def test_sku_pack_carton_to_kg():
    h=SKUHierarchy(sku_id=1,product_id=1,pack_size_code='500G',net_weight_kg=Decimal('0.5'),pieces_per_pack=Decimal(1),packs_per_carton=Decimal(20),kg_per_piece=Decimal('0.5'))
    p=PackHierarchy()
    assert p.to_kg(h,2,'CARTON') == Decimal('20.0')
    assert p.carton_to_piece(h,2) == Decimal('40')
    assert p.from_kg(h,10,'PACK') == Decimal('20.000000')

def test_fractional_carton_is_allowed_only_if_policy_is_explicit_else_service_can_reject_later():
    h=SKUHierarchy(sku_id=2,product_id=1,pack_size_code='1KG',net_weight_kg=Decimal('1'),pieces_per_pack=Decimal(1),packs_per_carton=Decimal(10),kg_per_piece=Decimal(1))
    assert PackHierarchy().to_kg(h, Decimal('0.5'), 'CARTON') == Decimal('5.0')

def test_ean13_checksum():
    assert validate_barcode('8901234567890','EAN13') == '8901234567890'
    with pytest.raises(UOMError, match='INVALID_EAN13_CHECKSUM'): validate_barcode('8901234567891','EAN13')
