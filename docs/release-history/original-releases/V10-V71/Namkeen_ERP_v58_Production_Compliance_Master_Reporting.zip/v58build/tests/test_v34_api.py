from fastapi.testclient import TestClient
from app.v34.api import app


def test_v34_health():
    c=TestClient(app)
    r=c.get('/v34/health')
    assert r.status_code==200 and r.json()['version']=='34.0'
