from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.models import Organization, Entity, User
from app.db.models_v19 import DomainChange
from app.sync.domain_integration_v20 import emit


def session():
    e=create_engine('sqlite:///:memory:', future=True)
    Base.metadata.create_all(e)
    from app.db.models_v18 import SyncChangeLog, SyncCursor, SyncConflict, SyncDeadLetter
    from app.db.models_v19 import DomainChange
    from app.db.models_v17 import CustomerProfile, CustomerApproval, CollectionEvidence, CollectionDeposit, SalesReturn, SalesReturnLine, ReturnDisposition
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); s=S()
    s.add_all([Organization(id=1,name='Org'), Entity(id=1,organization_id=1,code='X',legal_name='X'), User(id=1,organization_id=1,username='u',password_hash='x',role='MANAGEMENT')]); s.commit()
    return s


def test_event_contract_and_versioning():
    s=session()
    one=emit(s,org_id=1,entity_id=1,aggregate_type='CUSTOMER',aggregate_id='10',event_name='CUSTOMER_CREATED',operation='CREATE',payload={'id':10},actor_user_id=1)
    two=emit(s,org_id=1,entity_id=1,aggregate_type='CUSTOMER',aggregate_id='10',event_name='CUSTOMER_APPROVED',operation='UPDATE',payload={'id':10},actor_user_id=1)
    assert (one.version,two.version)==(1,2)
    rows=s.execute(select(DomainChange).order_by(DomainChange.id)).scalars().all()
    assert [r.event_name for r in rows]==['CUSTOMER_CREATED','CUSTOMER_APPROVED']


def test_unsupported_event_rejected():
    s=session()
    try:
        emit(s,org_id=1,entity_id=1,aggregate_type='X',aggregate_id='1',event_name='NOT_ALLOWED',operation='UPDATE',payload={})
    except ValueError as e:
        assert 'UNSUPPORTED_V20_EVENT' in str(e)
    else:
        raise AssertionError('unsupported event accepted')
