from datetime import datetime, timezone, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.models import User, UserEntity, Entity, Organization
from app.db.models_v15 import UserDevice, UserSession
from app.auth.security import hash_password, verify_password
from app.auth.refresh import rotate_refresh, RefreshError
from app.auth.security import issue_refresh_token

def make_db(tmp_path):
    e=create_engine(f"sqlite:///{tmp_path/'r.db'}", future=True)
    for t in [Organization.__table__,Entity.__table__,User.__table__,UserEntity.__table__,UserDevice.__table__,UserSession.__table__]: t.create(e, checkfirst=True)
    return e

def test_refresh_rotates_and_rejects_old(tmp_path):
    e=make_db(tmp_path); S=sessionmaker(bind=e)
    now=datetime.now(timezone.utc)
    with S.begin() as db:
        db.add(Organization(id=1,name='O')); db.add(Entity(id=1,organization_id=1,code='E',legal_name='E'))
        db.add(User(id=1,organization_id=1,username='u',password_hash=hash_password('p'),role='SALESPERSON',active=True)); db.add(UserEntity(id=1,user_id=1,entity_id=1))
        db.add(UserDevice(id=1,user_id=1,device_id='d',active=True)); raw,h=issue_refresh_token(1,'s'); db.add(UserSession(id='s',user_id=1,device_id='d',refresh_token_hash=h,expires_at=now+timedelta(days=1)))
    with S.begin() as db:
        out=rotate_refresh(db,session_id='s',refresh_token=raw); assert out['session_id']=='s' and out['access_token'] and out['refresh_token']!=raw
        new=out['refresh_token']
    with S.begin() as db:
        try: rotate_refresh(db,session_id='s',refresh_token=raw); assert False
        except RefreshError as e: assert str(e)=='REFRESH_REPLAY_OR_INVALID_TOKEN'
    with S.begin() as db: assert db.get(UserSession,'s').revoked_at is not None
