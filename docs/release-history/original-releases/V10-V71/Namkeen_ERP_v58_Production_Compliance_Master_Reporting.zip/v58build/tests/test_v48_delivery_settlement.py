from decimal import Decimal
from app.v48.settlement import *

def test_full_delivery_reconciles():
    s=build_settlement(1,10,Decimal('100'),Decimal('100'))
    assert s.status==SettlementStatus.RECONCILED and s.undelivered_kg==0

def test_short_delivery_creates_exception_path():
    s=build_settlement(1,10,Decimal('100'),Decimal('80'),failed_kg=Decimal('20'))
    assert s.status==SettlementStatus.RECONCILED

def test_return_qty_cannot_exceed_undelivered():
    try: build_settlement(1,10,Decimal('100'),Decimal('80'),returned_kg=Decimal('25')); assert False
    except ValueError as e: assert str(e)=='EXCEPTION_QTY_EXCEEDS_UNDELIVERED'

def test_exception_requires_authorized_approver_and_reason():
    s=build_settlement(1,10,Decimal('100'),Decimal('80'))
    try: approve_exception(s,'SALESPERSON','x'); assert False
    except ValueError as e: assert str(e)=='APPROVER_NOT_AUTHORIZED'
    approve_exception(s,'MANAGER','approved short delivery')
    assert s.status==SettlementStatus.APPROVED

def test_post_requires_controlled_actions():
    s=build_settlement(1,10,Decimal('100'),Decimal('100'))
    post_settlement(s,stock_action='RETAIN',receivable_action='NO_CHANGE')
    assert s.status==SettlementStatus.POSTED

def test_freight_settlement_rate():
    f=freight_settlement(1,Decimal('2500'),Decimal('1000'))
    assert f.freight_per_kg==Decimal('2.5000')
