from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.model_registry import *
from app.db.models import Organization, Entity, User, Customer, SKU, Product, PackSize, InventoryLot
from app.db.models_v41 import PersistentSalesTxnRun, SalesInvoiceV41, CustomerReceivableV41, AccountingOutboxV41
from app.v39.pricing import PricingPolicy
from app.v38.collections_credit import CreditControlProfile
from app.v40.transaction import SalesTransactionRequest, SalesLineInput
from app.v41.transaction import post_persistent_sales_transaction, PersistentTransactionError

def setup():
    engine=create_engine('sqlite+pysqlite:///:memory:', future=True)
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine)
    s=Session()
    s.add_all([Organization(id=1,name='Org'), Entity(id=1,organization_id=1,code='X',legal_name='Entity X'), User(id=5,organization_id=1,username='store',password_hash='x',role='STORE',active=True),
               Product(id=10,organization_id=1,code='P10',name='Shev'), PackSize(id=10,organization_id=1,name='1kg',net_weight_g=1000), SKU(id=10,organization_id=1,product_id=10,pack_size_id=10),
               Customer(id=99,organization_id=1,entity_id=1,code='C99',name='Shop',approval_status='APPROVED',credit_limit=50000,credit_days=30,active=True)])
    s.add(InventoryLot(id=1,organization_id=1,entity_id=1,warehouse_code='FG01',sku_id=10,batch_no='B1',expiry_date=date(2026,12,31),qty_available=100,qty_reserved=0))
    s.commit(); return s

def req(idem='K1',order='SO-41'):
    p=PricingPolicy(1,10,1,None,date(2026,9,1),None,Decimal('125'),Decimal('120'),Decimal('4'))
    line=SalesLineInput(10,Decimal('10'),Decimal('125'),Decimal('115'),p)
    return SalesTransactionRequest(1,1,99,5,order,date(2026,9,4),'UPI','VERIFIED',CreditControlProfile(99,Decimal('50000'),Decimal('0'),Decimal('0'),0,30),(line,),'FG01',idempotency_key=idem)

class Actor:
    id=5; role='STORE'

def test_atomic_persistent_posting():
    s=setup()
    with s.begin():
        r=post_persistent_sales_transaction(s,req=req('K1'),actor_user=Actor())
    assert r.state=='COMMITTED' and r.dispatched_qty_kg==Decimal('10')
    inv=s.execute(select(SalesInvoiceV41)).scalar_one(); run=s.execute(select(PersistentSalesTxnRun)).scalar_one(); ar=s.execute(select(CustomerReceivableV41)).scalar_one(); out=s.execute(select(AccountingOutboxV41)).scalar_one()
    lot=s.get(InventoryLot,1)
    assert inv.grand_total==Decimal('1250.00'); assert ar.outstanding_amount==Decimal('0.00'); assert out.status=='PENDING'; assert lot.qty_available==Decimal('90'); assert lot.qty_reserved==Decimal('0')

def test_idempotent_retry_does_not_duplicate():
    s=setup();
    with s.begin(): post_persistent_sales_transaction(s,req=req('K2','SO-42'),actor_user=Actor())
    with s.begin(): r=post_persistent_sales_transaction(s,req=req('K2','SO-42'),actor_user=Actor())
    assert r.duplicate is True
    assert len(s.execute(select(SalesInvoiceV41)).scalars().all())==1

def test_different_order_reusing_idempotency_fails():
    s=setup();
    with s.begin(): post_persistent_sales_transaction(s,req=req('K3','SO-43'),actor_user=Actor())
    try:
        with s.begin(): post_persistent_sales_transaction(s,req=req('K3','SO-44'),actor_user=Actor())
    except PersistentTransactionError as e: assert str(e)=='IDEMPOTENCY_KEY_REUSED_FOR_DIFFERENT_ORDER'
    else: assert False

def test_failure_rolls_back_order_and_inventory():
    s=setup()
    # 200kg demand exceeds the 100kg lot, so the same transaction must roll back.
    p=PricingPolicy(1,10,1,None,date(2026,9,1),None,Decimal('125'),Decimal('120'),Decimal('4'))
    cp=CreditControlProfile(99,Decimal('50000'),Decimal('0'),Decimal('0'),0,30)
    bad=SalesTransactionRequest(1,1,99,5,'SO-45',date(2026,9,4),'UPI','VERIFIED',cp,(SalesLineInput(10,Decimal('200'),Decimal('125'),Decimal('115'),p),),'FG01',idempotency_key='K5')
    try:
        with s.begin(): post_persistent_sales_transaction(s,req=bad,actor_user=Actor())
    except Exception: pass
    assert s.execute(select(PersistentSalesTxnRun)).scalar_one_or_none() is None
    assert s.execute(select(SalesInvoiceV41)).scalar_one_or_none() is None
    assert s.get(InventoryLot,1).qty_available==Decimal('100')
