from app.v23.role_policy import role_definition, dashboard_cards

def test_all_roles_have_dashboard_and_offline_caps():
    for role in ["SALESPERSON","MANAGER","FACTORY","QC","ACCOUNTS","MANAGEMENT","SUPER_ADMIN"]:
        d=role_definition(role)
        assert d["dashboard"]
        assert "sync" in d["offline"]

def test_salesperson_cards_are_field_actions():
    cards=dashboard_cards("SALESPERSON", {"today_orders":4,"pending_customers":2,"pending_collections":1,"sync_pending":3})
    assert {c.key for c in cards} == {"today_orders","pending_customers","pending_collections","sync"}
    assert any(c.severity=="ATTENTION" and c.key=="sync" for c in cards)

def test_factory_card_exposes_production_and_stock():
    cards=dashboard_cards("FACTORY", {"production_plan_kg":2000,"rm_shortage":1,"fg_ready_kg":750,"qc_pending":2})
    assert cards[0].value == "2000 kg"
    assert any(c.key=="rm_shortage" and c.severity=="CRITICAL" for c in cards)

def test_accounts_card_protects_unverified_payments():
    cards=dashboard_cards("ACCOUNTS", {"unverified_payments":3,"cash_with_sales":2,"cheques_hold":4,"accounting_sync":1})
    assert any(c.key=="unverified_payments" and c.severity=="ATTENTION" for c in cards)
    assert any(c.key=="cash_with_sales" and c.severity=="CRITICAL" for c in cards)

def test_management_has_cross_function_cards():
    cards=dashboard_cards("MANAGEMENT", {"sales_today":100,"production_today":1800,"receivables":50000,"compliance_alerts":2})
    assert {c.key for c in cards} == {"sales_today","production_today","receivables","compliance_alerts"}
