from app.sync.conflict import ConflictResolver, SyncCommand, SyncStatus

def test_duplicate_safe_contract_marker():
    r=ConflictResolver().check(SyncCommand("e1","d1","customer","c1",4,{}),4)
    assert r.status==SyncStatus.ACCEPTED

def test_conflict_visible():
    r=ConflictResolver().check(SyncCommand("e2","d1","customer","c1",4,{}),5)
    assert r.status==SyncStatus.CONFLICT
    assert "Version mismatch" in r.message
