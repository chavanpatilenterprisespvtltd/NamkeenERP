from datetime import date, timedelta
from decimal import Decimal
import pytest

from app.v57.compliance_operations import *
from app.v57.api import compliance_dashboard


def test_recurring_tasks_generate_due_and_overdue():
    req = Requirement('CLEAN-DAILY','FSSAI','Cleaning',True,1,active_from=date(2026,1,1))
    tasks = generate_recurring_tasks([req], site_id=10, last_completed={'CLEAN-DAILY': date(2026,9,3)}, as_of=date(2026,9,5))
    assert tasks[0].due_date == date(2026,9,4)
    assert tasks[0].status == TaskStatus.OVERDUE


def test_task_requires_evidence_before_submit():
    t = ComplianceTask(1, 10, 'REQ', date(2026,9,5))
    with pytest.raises(ComplianceError, match='EVIDENCE_REQUIRED'):
        t.submit()


def test_task_submits_and_verifies_without_findings():
    t = ComplianceTask(1,10,'REQ',date(2026,9,5), evidence_ids=[99])
    t.submit()
    assert t.status == TaskStatus.SUBMITTED
    t.verify()
    assert t.status == TaskStatus.VERIFIED


def test_verification_blocked_by_findings():
    t = ComplianceTask(1,10,'REQ',date(2026,9,5), evidence_ids=[99], finding_count=1)
    t.submit()
    with pytest.raises(ComplianceError, match='OPEN_FINDINGS_REQUIRE_DISPOSITION'):
        t.verify()


def test_snapshot_not_ready_with_overdue_or_capa():
    t = ComplianceTask(1,10,'REQ',date(2026,9,1), status=TaskStatus.OVERDUE)
    f = InspectionFinding(1,1,'MAJOR','dirty drain',Disposition.CAPA,capa_id=7,closed=False)
    s = build_snapshot(10,[t],[f],active_capa=1,as_of=date(2026,9,5))
    assert s.mandatory_overdue == 1
    assert s.open_findings == 1
    assert not s.inspection_ready


def test_oil_tpc_limit_default_and_configurable():
    assert validate_oil_tpc(Decimal('25'))
    assert not validate_oil_tpc(Decimal('25.01'))
    assert validate_oil_tpc(Decimal('30'), Decimal('30'))


def test_negative_tpc_rejected():
    with pytest.raises(ComplianceError, match='NEGATIVE_TPC'):
        validate_oil_tpc(Decimal('-0.1'))


def test_test_result_limits():
    assert validate_test_result(Decimal('10'), minimum=Decimal('5'), maximum=Decimal('15'))
    assert not validate_test_result(Decimal('3'), minimum=Decimal('5'))


def test_dashboard_is_derived():
    data = compliance_dashboard(10, [], [], 0, date(2026,9,5))
    assert data['inspection_ready'] is True
    assert data['site_id'] == 10


def test_evidence_is_referenced_not_embedded():
    e = Evidence(1,10,EvidenceType.LAB_REPORT,None or __import__('datetime').datetime.now(),'private://e1','a'*64,5,'water_test',55)
    assert e.storage_ref.startswith('private://')
    assert len(e.sha256) == 64
