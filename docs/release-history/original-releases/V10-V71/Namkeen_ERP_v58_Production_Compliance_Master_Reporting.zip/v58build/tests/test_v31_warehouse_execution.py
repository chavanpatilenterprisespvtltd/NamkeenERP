from decimal import Decimal
from app.v31.execution import *


def test_putaway_confirmation_enforces_destination_and_returns_event():
    c = confirm_putaway(task_id=10, lpn_id=20, destination_location_id=30,
                        destination_allow_putaway=True, destination_active=True,
                        actor_user_id=7, task_status="OPEN", task_destination_location_id=30,
                        client_event_id="evt-1", confirmation_id=99)
    assert c.confirmation_id == 99 and c.destination_location_id == 30

    try:
        confirm_putaway(task_id=10, lpn_id=20, destination_location_id=31,
                        destination_allow_putaway=True, destination_active=True,
                        actor_user_id=7, task_status="OPEN", task_destination_location_id=30)
        assert False
    except WarehouseExecutionError as e:
        assert str(e) == "PUTAWAY_DESTINATION_MISMATCH"


def test_directed_pick_full_and_short():
    t = DirectedPick(1)
    start_pick(t, 8)
    confirm_pick(t, actual_qty_kg=Decimal("10"), expected_qty_kg=Decimal("10"), confirmed_by=8, picked_lpn_id=44)
    assert t.status == "PICKED" and t.actual_qty_kg == Decimal("10")

    s = DirectedPick(2)
    start_pick(s, 8)
    try:
        confirm_pick(s, actual_qty_kg=Decimal("8"), expected_qty_kg=Decimal("10"), confirmed_by=8)
        assert False
    except WarehouseExecutionError as e:
        assert str(e) == "SHORT_REASON_REQUIRED"
    confirm_pick(s, actual_qty_kg=Decimal("8"), expected_qty_kg=Decimal("10"), confirmed_by=8, short_reason="BIN SHORT")
    assert s.status == "SHORT" and s.short_reason == "BIN SHORT"


def test_stock_count_requires_complete_count_then_approval_then_post():
    s = StockCountSession(1, 10, 5, [100], tolerance_kg=Decimal("0.5"), opened_by=3)
    begin_count(s)
    l = StockCountLine(1, 1, 100, 501, 900, Decimal("10"))
    s.lines.append(l)
    l.record_count(Decimal("10.8"))
    assert l.variance_qty_kg == Decimal("0.8")
    assert variance_exceeds_tolerance(l, s.tolerance_kg)
    submit_count(s, 3)
    approve_count(s, 4)
    post_count(s, 5)
    assert s.status == "POSTED"


def test_replenishment_and_bin_movement_confirmation():
    r = make_replenishment(task_id=1, organization_id=10, warehouse_id=5, sku_id=501,
                           lot_id=9, source_location_id=100, destination_location_id=200,
                           qty_kg=Decimal("25"), priority=10)
    r.assigned_to = 6; r.status = "ASSIGNED"
    confirm_replenishment(r, 6)
    assert r.status == "COMPLETED"

    m = create_bin_movement(movement_id=1, organization_id=10, warehouse_id=5,
                            source_location_id=100, destination_location_id=200,
                            qty_kg=Decimal("5"), lpn_id=11, sku_id=501, lot_id=9, created_by=6)
    confirm_bin_movement(m, actor_id=6, client_event_id="move-1")
    assert m.status == "CONFIRMED" and m.client_event_id == "move-1"


def test_reject_over_pick_and_negative_count():
    t = DirectedPick(9); start_pick(t, 1)
    try:
        confirm_pick(t, actual_qty_kg=Decimal("11"), expected_qty_kg=Decimal("10"), confirmed_by=1)
        assert False
    except WarehouseExecutionError as e:
        assert str(e) == "PICK_OVERAGE_NOT_ALLOWED"
    l = StockCountLine(1, 1, 10, 2, None, Decimal("3"))
    try:
        l.record_count(Decimal("-1"))
        assert False
    except WarehouseExecutionError as e:
        assert str(e) == "COUNT_QTY_NEGATIVE"
