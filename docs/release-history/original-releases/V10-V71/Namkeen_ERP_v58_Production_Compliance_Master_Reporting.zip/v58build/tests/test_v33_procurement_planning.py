from decimal import Decimal
from app.v33.planning import DemandSignal, SupplyPosition, SupplierTerm, procurement_plan, production_plan


def test_moq_multiple_and_open_supply_reduce_requirement():
    signals=[DemandSignal(101,10,Decimal('120'),30,'CONFIRMED_ORDERS')]
    supplies=[SupplyPosition(101,10,available_kg=Decimal('40'),open_po_kg=Decimal('20'),open_production_kg=Decimal('10'),safety_stock_kg=Decimal('15'))]
    terms=[SupplierTerm(501,101,lead_time_days=7,moq_kg=Decimal('50'),order_multiple_kg=Decimal('25'),priority=1)]
    out=procurement_plan(signals,supplies,terms)
    assert len(out)==1
    assert out[0].suggested_qty_kg==Decimal('75')
    assert out[0].supplier_id==501 and out[0].severity=='REORDER'


def test_critical_when_no_supplier_term():
    signals=[DemandSignal(102,10,Decimal('80'),30)]
    supplies=[SupplyPosition(102,10,available_kg=Decimal('5'),safety_stock_kg=Decimal('10'))]
    out=procurement_plan(signals,supplies,[])
    assert out[0].severity=='CRITICAL'
    assert out[0].supplier_id is None
    assert out[0].reason=='NO_ACTIVE_SUPPLIER_TERM'


def test_supplier_priority_then_lead_time():
    signals=[DemandSignal(103,10,Decimal('100'),30)]
    supplies=[SupplyPosition(103,10,available_kg=Decimal('10'))]
    terms=[SupplierTerm(10,103,lead_time_days=10,priority=2),SupplierTerm(11,103,lead_time_days=5,priority=1),SupplierTerm(12,103,lead_time_days=2,priority=1)]
    out=procurement_plan(signals,supplies,terms)
    assert out[0].supplier_id==12


def test_make_to_stock_production_requirement():
    signals=[DemandSignal(104,20,Decimal('200'),15)]
    supplies=[SupplyPosition(104,20,available_kg=Decimal('100'),open_po_kg=Decimal('20'),safety_stock_kg=Decimal('30'))]
    out=production_plan(signals,supplies,make_skus={104})
    assert out[0].required_qty_kg==Decimal('110')
    assert out[0].approval_required is True
