from decimal import Decimal
from datetime import date
from types import SimpleNamespace
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import event
from app.db.base import Base
from app.db.models import Organization, Entity, User, Customer, Product, PackSize, SKU, SalesOrder, SalesOrderLine, InventoryLot, InventoryLedger, AuditEvent, ApprovalRequest
from app.db.models_v16 import OrderAllocation
from app.transactions.persistent_order import reserve_order_persistent, dispatch_order_persistent


@event.listens_for(AuditEvent, "before_insert")
def _audit_sqlite_id(mapper, connection, target):
    if target.id is None:
        target.id = 1 if connection.dialect.name == "sqlite" and not connection.execute(AuditEvent.__table__.select().limit(1)).first() else 2

@event.listens_for(OrderAllocation, "before_insert")
def _alloc_sqlite_id(mapper, connection, target):
    if target.id is None and connection.dialect.name == "sqlite":
        target.id = (connection.execute(OrderAllocation.__table__.select().with_only_columns(OrderAllocation.id).order_by(OrderAllocation.id.desc()).limit(1)).scalar() or 0) + 1

@event.listens_for(InventoryLedger, "before_insert")
def _ledger_sqlite_id(mapper, connection, target):
    if target.id is None and connection.dialect.name == "sqlite":
        target.id = (connection.execute(InventoryLedger.__table__.select().with_only_columns(InventoryLedger.id).order_by(InventoryLedger.id.desc()).limit(1)).scalar() or 0) + 1

def test_reserve_and_dispatch_persists_allocations(tmp_path):
    e=create_engine(f"sqlite:///{tmp_path/'i.db'}", future=True)
    Base.metadata.create_all(e); S=sessionmaker(bind=e)
    with S.begin() as db:
        db.add_all([Organization(id=1,name='O'),Entity(id=1,organization_id=1,code='E',legal_name='E'),User(id=1,organization_id=1,username='s',password_hash='x',role='STORE',active=True),Product(id=1,organization_id=1,code='P',name='P'),PackSize(id=1,organization_id=1,name='500g',net_weight_g=500),SKU(id=1,organization_id=1,product_id=1,pack_size_id=1),Customer(id=1,organization_id=1,entity_id=1,code='C',name='C',approval_status='APPROVED'),SalesOrder(id=1,organization_id=1,entity_id=1,customer_id=1,salesperson_id=1,order_no='SO1',status='READY_FOR_STOCK_CHECK',payment_mode='UPI',payment_state='VERIFIED',credit_state='OK'),SalesOrderLine(id=1,order_id=1,sku_id=1,qty=Decimal('8'),negotiated_price=Decimal('120'),floor_price=Decimal('115'),company_cost=Decimal('110')),InventoryLot(id=1,organization_id=1,entity_id=1,warehouse_code='FG',sku_id=1,batch_no='B1',expiry_date=date(2026,12,31),qty_available=Decimal('10'),qty_reserved=Decimal('0'))])
        a=SimpleNamespace(id=1,role='STORE')
        o=reserve_order_persistent(db,order_id=1,warehouse_code='FG',actor_user=a); assert o.status=='STOCK_RESERVED'
        alloc=db.query(OrderAllocation).filter_by(order_id=1,status='RESERVED').all(); assert len(alloc)==1 and Decimal(alloc[0].qty)==Decimal('8')
        o,total=dispatch_order_persistent(db,order_id=1,actor_user=a); assert o.status=='DISPATCHED' and total==Decimal('8')
        lot=db.get(InventoryLot,1); assert lot.qty_available==Decimal('2') and lot.qty_reserved==Decimal('0')
