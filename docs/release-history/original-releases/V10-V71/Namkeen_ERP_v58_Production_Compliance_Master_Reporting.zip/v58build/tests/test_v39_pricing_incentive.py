from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from app.v39.pricing import *
from app.v39.incentive import *
from app.v39.api import app

def policy(**kw):
    d=dict(policy_id=1,sku_id=10,entity_id=1,customer_id=None,effective_from=date(2026,9,1),effective_to=None,target_price=Decimal('125'),floor_price=Decimal('120'),max_discount_pct=Decimal('4'))
    d.update(kw); return PricingPolicy(**d)

def test_floor_and_discount_approval():
    p=policy()
    r=calculate_price(PricingRequest(10,None,Decimal('10'),Decimal('121'),Decimal('115'),date(2026,9,4),p,gst_pct=Decimal('18')))
    assert r.approval_required is False and r.gross_margin_value==Decimal('60.00')
    r2=calculate_price(PricingRequest(10,None,Decimal('10'),Decimal('118'),Decimal('115'),date(2026,9,4),p))
    assert r2.approval_required and r2.reason=='BELOW_FLOOR_APPROVAL_REQUIRED'

def test_customer_specific_price_and_promo():
    p=policy(customer_id=99)
    rule=CustomerPriceRule(2,10,99,Decimal('123'),date(2026,9,1),min_qty=5)
    r=calculate_price(PricingRequest(10,99,Decimal('5'),Decimal('123'),Decimal('115'),date(2026,9,4),p,rule))
    assert r.list_unit_price==Decimal('123.00') and r.taxable_value==Decimal('615.00')

def test_tax_inclusive_separation():
    p=policy()
    r=calculate_price(PricingRequest(10,None,Decimal('1'),Decimal('118'),Decimal('100'),date(2026,9,4),p,gst_pct=Decimal('18'),tax_inclusive=True))
    assert r.invoice_total==Decimal('118.00') and r.gst_amount==Decimal('18.00')

def test_incentive_return_reduces_eligible_basis():
    p=IncentivePolicy(1,'kg','PER_KG',per_kg_rate=Decimal('2'),approved_by=7)
    r=calculate_incentive(p,IncentiveInput(eligible_kg=100,net_sales=20000,gross_margin=3000,verified_collections=15000,target_achievement_pct=80,returned_kg=10))
    assert r.eligible_kg==Decimal('90.00') and r.incentive==Decimal('180.00')

def test_incentive_combined():
    p=IncentivePolicy(1,'combined','COMBINED',per_kg_rate=Decimal('1'),sales_pct=Decimal('1'),margin_pct=Decimal('2'),collection_pct=Decimal('0.5'),target_pct=Decimal('1'),target_amount=Decimal('100000'),approved_by=7)
    r=calculate_incentive(p,IncentiveInput(100,50000,10000,30000,80))
    assert r.incentive==Decimal('1350.00')

def test_unapproved_active_policy_rejected():
    try: IncentivePolicy(1,'x','PER_KG',per_kg_rate=Decimal('1'))
    except IncentiveError as e: assert str(e)=='MANAGEMENT_APPROVAL_REQUIRED'
    else: assert False

def test_api():
    c=TestClient(app)
    r=c.post('/v39/pricing/calculate',json={'sku_id':10,'customer_id':None,'quantity':'10','negotiated_unit_price':'121','actual_cost_per_unit':'115','order_date':'2026-09-04','policy':{'policy_id':1,'sku_id':10,'entity_id':1,'customer_id':None,'effective_from':'2026-09-01','effective_to':None,'target_price':'125','floor_price':'120','max_discount_pct':'4','approval_below_floor':True,'active':True},'gst_pct':'18'})
    assert r.status_code==200 and r.json()['state']=='ACTIVE'

def test_api_incentive():
    c=TestClient(app)
    r=c.post('/v39/incentive/calculate',json={'policy':{'policy_id':1,'name':'kg','formula_type':'PER_KG','per_kg_rate':'2','effective_from':'2026-09-01','approved_by':7,'active':True},'input':{'eligible_kg':'100','net_sales':'20000','gross_margin':'3000','verified_collections':'0','target_achievement_pct':'0','returned_kg':'25','cancelled_sales':'0'}})
    assert r.status_code==200 and r.json()['incentive']=='150.00'
