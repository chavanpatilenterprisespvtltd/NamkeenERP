from app.auth.security import hash_password, verify_password, issue_access_token, decode_access
from app.auth.authorization import can

def test_password_hash_roundtrip():
    h=hash_password("secret-123")
    assert h != "secret-123" and verify_password("secret-123",h)
    assert not verify_password("wrong",h)

def test_access_token_roundtrip(monkeypatch):
    tok=issue_access_token(7,3,"SALESPERSON",[9],"s1")
    c=decode_access(tok)
    assert c["sub"]=="7" and c["org"]==3 and c["role"]=="SALESPERSON"

def test_rbac():
    assert can("SALESPERSON","order.create").allowed
    assert not can("SALESPERSON","payment.verify").allowed
    assert can("MANAGEMENT","anything").allowed
