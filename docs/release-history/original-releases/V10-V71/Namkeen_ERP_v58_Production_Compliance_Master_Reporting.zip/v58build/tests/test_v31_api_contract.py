from app.v31.api import router

def test_v31_router_contract():
    assert router.prefix == "/v31/warehouse"
    paths = {r.path for r in router.routes}
    assert "/v31/warehouse/counts" in paths
    assert "/v31/warehouse/counts/{session_id}/post" in paths
    assert "/v31/warehouse/pick-tasks/{task_id}/confirm" in paths
    assert "/v31/warehouse/replenishments/{task_id}/confirm" in paths
    assert "/v31/warehouse/bin-movements/{movement_id}/confirm" in paths
