import tempfile
from pathlib import Path
from types import SimpleNamespace
from app.v21.sync_engine import SyncEngine, Backoff
from app.v21.document_queue import DocumentQueue
from app.v21.contracts import PushResult

class Store:
    def __init__(self): self.q=[]; self.results=[]; self.inbox=[]; self.c=0
    def pending(self,limit): return self.q[:limit]
    def mark_result(self,eid,**kw): self.results.append((eid,kw))
    def cursor(self): return self.c
    def apply_delta(self,d): self.inbox.append(d)
    def ack_cursor(self,c): self.c=c
class API:
    def push(self,item): return PushResult(item.client_event_id,"ACCEPTED",event_id=1)
    def pull(self,cursor,limit): return ([{"change_id":2,"entity_type":"CUSTOMER","entity_id":"7","operation":"UPDATE","version":2,"event_name":"CUSTOMER_APPROVED","payload":{},"occurred_at":None}],2,False)
def test_engine_push_pull_and_cursor():
    s=Store(); s.q=[SimpleNamespace(client_event_id='e1',attempts=0)]
    st=SyncEngine(s,API()).run_once()
    assert st.pushed==1 and st.pulled==1 and s.c==2 and len(s.inbox)==1
def test_backoff_is_capped(): assert Backoff(base_seconds=2,cap_seconds=5,jitter=0,rand=lambda:0).delay(4)==5
def test_document_queue_hash_and_retry():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'x.jpg'; p.write_bytes(b'abc'); q=DocumentQueue(); item=q.enqueue('doc-1',str(p),'image/jpeg')
        assert len(item.sha256)==64 and len(q.pending())==1; q.mark('doc-1','RETRY','timeout'); assert q.items['doc-1'].attempts==1
