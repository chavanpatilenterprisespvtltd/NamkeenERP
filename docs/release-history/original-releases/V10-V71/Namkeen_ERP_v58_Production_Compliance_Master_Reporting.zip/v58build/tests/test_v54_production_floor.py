from decimal import Decimal
import pytest
from app.v54.production_floor import *

def run():
    return build_floor_run(production_order_id=1,batch_id=2,sku_id=3,planned_output_kg=Decimal('100'),stages=[ProcessStage('MIX',1,machine_id=10,target_minutes=30),ProcessStage('FRY',2,machine_id=11,target_minutes=60),ProcessStage('SEASON',3,target_minutes=15)])

def start_run():
    r=run(); r.start(); return r

def test_stage_sequence_required():
    with pytest.raises(FloorError, match='STAGES_NOT_SEQUENTIAL'):
        build_floor_run(production_order_id=1,batch_id=2,sku_id=3,planned_output_kg=100,stages=[ProcessStage('B',2),ProcessStage('A',1)])

def test_operator_and_stage_lifecycle():
    r=start_run(); r.start_stage(1,7); r.complete_stage(1,31); assert r.stages[0].status==StageStatus.COMPLETED

def test_stage_requires_operator():
    r=start_run();
    with pytest.raises(FloorError, match='INVALID_OPERATOR'): r.start_stage(1,0)

def test_downtime_is_recorded():
    r=start_run(); r.start_stage(1,7); r.add_downtime(12,'CLEANING'); assert r.downtime_minutes==Decimal('12.000000')

def test_consumption_and_cost():
    r=start_run(); r.add_consumption(ConsumptionEntry('RM',Decimal('70'),Decimal('100'))); r.add_consumption(ConsumptionEntry('PACK',Decimal('5'),Decimal('20'))); assert r.total_material_cost()==Decimal('7100.00')

def test_oil_fuel():
    r=start_run(); r.record_oil(2.5); r.record_fuel(10); assert r.oil_qty_kg==Decimal('2.500000'); assert r.fuel_qty_kg==Decimal('10.000000')

def test_qc_fail_puts_run_on_hold():
    r=start_run(); r.add_qc(QCCheckpoint('TEMP',QCStatus.FAIL,result_notes='too hot')); assert r.status==StageStatus.HOLD

def test_fail_requires_reason():
    with pytest.raises(FloorError, match='QC_FAIL_REASON_REQUIRED'): QCCheckpoint('TEMP',QCStatus.FAIL)

def test_wastage_requires_authorizer():
    r=start_run()
    r.wastage.append(WastageRecord(Decimal('2'),'BURN',WastageStatus.RECORDED))
    with pytest.raises(FloorError, match='WASTAGE_ALREADY_PENDING'): r.authorize_wastage(1,'BURN',9)

def test_authorized_wastage():
    r=start_run(); r.authorize_wastage(2,'TRIM',9,'photo://1'); assert r.wastage[0].status==WastageStatus.AUTHORIZED

def test_output_cannot_exceed_input():
    r=start_run(); r.add_consumption(ConsumptionEntry('RM',100,1));
    with pytest.raises(FloorError, match='OUTPUT_EXCEEDS_ACTUAL_INPUT'): r.record_output(101)

def test_complete_requires_all_stages_and_qc():
    r=start_run(); r.add_consumption(ConsumptionEntry('RM',100,1))
    for s in (1,2,3): r.start_stage(s,7); r.complete_stage(s,10)
    r.add_qc(QCCheckpoint('FINAL',QCStatus.PASS,checked_by=8)); r.record_output(90,5,2); r.complete(); assert r.status==StageStatus.COMPLETED
