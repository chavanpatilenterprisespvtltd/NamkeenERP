from decimal import Decimal
from app.v51.bom import BomVersion,BomComponent,BomComponentType
from app.v52_mrp import *

def bom():
    return BomVersion(1,10,20,'B1','2026-01-01',None,80,(
        BomComponent(100,BomComponentType.RM,Decimal('1.25'),Decimal('4'),Decimal('100')),
        BomComponent(101,BomComponentType.PACKAGING,Decimal('0.02'),Decimal('0'),Decimal('10')),
    ))

def test_mrp_consumes_stock_po_and_open_production_before_shortfall():
    r=explode_mrp(bom(),Decimal('1000'),[
        InventoryPosition(100,Decimal('1000'),Decimal('100'),Decimal('200'),Decimal('50')),
        InventoryPosition(101,Decimal('30')),
    ])
    assert r.requirements[0].gross_required_qty_kg == Decimal('1300.000000')
    assert r.requirements[0].planned_available_qty_kg == Decimal('1150.000000')
    assert r.requirements[0].net_to_make_or_buy_qty_kg == Decimal('150.000000')

def test_production_order_requires_approval_and_no_self_approval():
    po=create_production_order(production_order_id=1,organization_id=1,entity_id=2,sku_id=10,bom_version='B1',planned_good_output_kg=100,due_date='2026-09-15',created_by=7,source_demand_ids=[99])
    assert po.status==ProductionOrderStatus.PENDING_APPROVAL
    try: approve_production_order(po,7); assert False
    except MRPError as e: assert str(e)=='SELF_APPROVAL_NOT_ALLOWED'
    approve_production_order(po,8); assert po.status==ProductionOrderStatus.RELEASED

def test_execution_lifecycle():
    po=create_production_order(production_order_id=2,organization_id=1,entity_id=2,sku_id=10,bom_version='B1',planned_good_output_kg=100,due_date='2026-09-15',created_by=7)
    approve_production_order(po,8); start_production(po); complete_production(po,95)
    assert po.status==ProductionOrderStatus.COMPLETED
