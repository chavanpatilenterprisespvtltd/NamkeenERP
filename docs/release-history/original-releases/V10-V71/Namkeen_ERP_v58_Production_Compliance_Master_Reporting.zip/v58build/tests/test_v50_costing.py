from decimal import Decimal
import pytest
from app.v50.costing import CostComponent, CostComponentEntry, StandardCost, StandardCostComponent, calculate_batch_cost


def c(component, q, uc):
    return CostComponentEntry.build(component, Decimal(str(q)), Decimal(str(uc)))


def test_actual_cost_per_good_kg_includes_all_components_and_yield():
    result = calculate_batch_cost(
        batch_id=1, sku_id=10, input_kg=Decimal('1000'), good_output_kg=Decimal('900'), reject_kg=Decimal('50'), rework_kg=Decimal('50'),
        components=[c(CostComponent.RM, 1000, 80), c(CostComponent.OIL, 900, 12), c(CostComponent.FUEL_WOOD, 900, 1.5), c(CostComponent.PACKAGING, 900, 5), c(CostComponent.LABOUR, 900, 3), c(CostComponent.POWER, 900, 1.5)],
    )
    assert result.total_actual_cost == Decimal('100700.00')
    assert result.actual_cost_per_good_kg == Decimal('111.89')
    assert result.yield_pct == Decimal('90.00')


def test_standard_variance_and_component_variance():
    standard = StandardCost(1, 10, 1, '2026-01-01', None, (
        StandardCostComponent(CostComponent.RM, Decimal('82')),
        StandardCostComponent(CostComponent.PACKAGING, Decimal('5')),
        StandardCostComponent(CostComponent.LABOUR, Decimal('3')),
    ))
    result = calculate_batch_cost(
        batch_id=2, sku_id=10, input_kg=Decimal('500'), good_output_kg=Decimal('450'),
        components=[c(CostComponent.RM, 500, 80), c(CostComponent.PACKAGING, 450, 5), c(CostComponent.LABOUR, 450, 3)], standard=standard,
    )
    assert result.standard_cost_per_kg == Decimal('90.00')
    assert result.standard_cost_for_actual_output == Decimal('40500.00')
    assert result.total_actual_cost == Decimal('43600.00')
    assert result.total_cost_variance == Decimal('3100.00')
    assert ('RM', Decimal('3100.00')) in result.component_variances


def test_negative_component_rejected():
    with pytest.raises(ValueError, match='NEGATIVE_COMPONENT_INPUT'):
        c(CostComponent.RM, -1, 10)


def test_output_cannot_exceed_input():
    with pytest.raises(ValueError, match='OUTPUT_EXCEEDS_INPUT'):
        calculate_batch_cost(batch_id=3, sku_id=10, input_kg=Decimal('100'), good_output_kg=Decimal('101'), components=[c(CostComponent.RM, 100, 10)])


def test_cost_can_be_used_for_margin_preview():
    result = calculate_batch_cost(batch_id=4, sku_id=10, input_kg=Decimal('100'), good_output_kg=Decimal('90'), components=[c(CostComponent.RM, 100, 50)])
    margin_per_kg, margin_pct = result.selling_margin(Decimal('75'))
    assert margin_per_kg == Decimal('19.44')
    assert margin_pct == Decimal('25.92')
