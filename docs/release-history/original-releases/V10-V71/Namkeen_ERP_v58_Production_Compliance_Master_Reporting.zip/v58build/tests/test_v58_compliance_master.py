from datetime import date, timedelta
import pytest
from app.v58.compliance_master import *
from app.v58.api import document_register, inspection_checklist, statutory_register, compliance_score


def official_source():
    return SourceReference('FSSAI-2026','FSSAI','2026 licensing FAQ','https://fssai.gov.in/official-source.pdf')


def test_official_source_url_required():
    with pytest.raises(MasterDataError, match='OFFICIAL_SOURCE_REQUIRED'):
        validate_source_url('https://example.com/rule')
    assert validate_source_url('https://fssai.gov.in/rule.pdf')


def test_control_must_reference_known_source():
    c = ComplianceControl('LIC-STATUS','Licence status review',RequirementClass.MANDATORY,'FSSAI','DOCUMENT',source_ids=('S1',),active_from=date(2026,4,1))
    with pytest.raises(MasterDataError, match='SOURCE_REFERENCE_NOT_FOUND'):
        validate_control(c, {})


def test_document_expiry_states():
    today = date(2026,9,5)
    assert document_expiry_state(SiteDocument(1,1,'LIC','Licence',valid_to=today+timedelta(days=60)), today) == 'VALID'
    assert document_expiry_state(SiteDocument(2,1,'LIC','Licence',valid_to=today+timedelta(days=5)), today) == 'EXPIRING_SOON'
    assert document_expiry_state(SiteDocument(3,1,'LIC','Licence',valid_to=today-timedelta(days=1)), today) == 'EXPIRED'
    assert document_expiry_state(SiteDocument(4,1,'LIC','Licence',perpetual=True), today) == 'VALID_PERPETUAL'


def test_document_register_api():
    docs = [SiteDocument(1,10,'LICENCE','FSSAI','X',valid_to=date(2026,9,20))]
    assert document_register(docs, date(2026,9,5))[0]['expiry_state'] == 'EXPIRING_SOON'


def test_inspection_checklist_uses_active_controls():
    controls = [
        ComplianceControl('A','Clean surfaces',RequirementClass.MANDATORY,'FSSAI','PHOTO',active_from=date(2026,1,1)),
        ComplianceControl('B','Optional improvement',RequirementClass.INTERNAL_RECOMMENDED,'INTERNAL','PHOTO',active_from=date(2026,1,1)),
        ComplianceControl('C','Old control',RequirementClass.MANDATORY,'FSSAI','PHOTO',active_from=date(2025,1,1),active_to=date(2026,1,1)),
    ]
    items = inspection_checklist(controls,'FSSC-01',date(2026,9,5))
    assert [x['control_code'] for x in items] == ['A']


def test_register_export_is_deterministic():
    rows = [
        RegisterExportRow('WATER',2,10,date(2026,9,5),'WT-2','PASS'),
        RegisterExportRow('WATER',1,10,date(2026,9,1),'WT-1','PASS'),
    ]
    out = statutory_register(rows,'WATER')
    assert [x['record_id'] for x in out] == [1,2]


def test_management_score_bands():
    assert compliance_score(mandatory_overdue=0,critical_findings=0,active_capa=0,expiring_documents=0,missing_evidence=0)['band'] == 'GREEN'
    assert compliance_score(mandatory_overdue=1,critical_findings=0,active_capa=0,expiring_documents=1,missing_evidence=1)['band'] in {'GREEN','AMBER'}
    assert compliance_score(mandatory_overdue=4,critical_findings=2,active_capa=3,expiring_documents=4,missing_evidence=5)['band'] == 'RED'
