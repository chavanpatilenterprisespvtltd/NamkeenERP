from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from app.v38.collections_credit import *
from app.v38.api import app


def test_credit_limit_and_overdue_block():
    p=CreditControlProfile(1,Decimal('10000'),Decimal('7000'),Decimal('0'),0,30)
    assert evaluate_credit_control(p,Decimal('2000')).state=='CLEAR'
    assert evaluate_credit_control(p,Decimal('4000')).state=='SOFT_BLOCK'
    p2=CreditControlProfile(1,Decimal('10000'),Decimal('4000'),Decimal('3000'),45,30)
    assert evaluate_credit_control(p2,Decimal('100')).reason=='OVERDUE_BEYOND_CREDIT_DAYS'


def test_collection_progress():
    r=calculate_collection_progress(CollectionTarget(5,date(2026,9,1),date(2026,9,30),Decimal('100000'),20),Decimal('75000'),15)
    assert r.achievement_pct==Decimal('75.00') and r.active_customers==15


def test_cash_requires_evidence_and_privileged_verification():
    r=ReceiptEvidence(1,'CASH',Decimal('500'),'PENDING_VERIFICATION',evidence_photo_ref=None)
    try: validate_receipt_transition(r,'PENDING_VERIFICATION',actor_role='SALESPERSON')
    except CollectionsError as e: assert str(e)=='CASH_EVIDENCE_REQUIRED'
    else: assert False
    r2=ReceiptEvidence(1,'CASH',Decimal('500'),'PENDING_VERIFICATION',evidence_photo_ref='photo://1')
    validate_receipt_transition(r2,'VERIFIED',actor_role='ACCOUNTS')


def test_bounce_reason_required():
    r=ReceiptEvidence(1,'CHEQUE',Decimal('500'),'PENDING_VERIFICATION')
    try: validate_receipt_transition(r,'BOUNCED',actor_role='ACCOUNTS')
    except CollectionsError as e: assert str(e)=='BOUNCE_REASON_REQUIRED'
    else: assert False


def test_allocation_protection():
    validate_allocation(receipt_amount=Decimal('1000'),already_allocated=Decimal('200'),allocation=Decimal('500'),invoice_outstanding=Decimal('700'))
    for kwargs,msg in [
        ({'receipt_amount':1000,'already_allocated':600,'allocation':500,'invoice_outstanding':900},'ALLOCATION_EXCEEDS_RECEIPT'),
        ({'receipt_amount':1000,'already_allocated':0,'allocation':1100,'invoice_outstanding':1200},'ALLOCATION_EXCEEDS_RECEIPT'),
        ({'receipt_amount':1000,'already_allocated':0,'allocation':800,'invoice_outstanding':700},'ALLOCATION_EXCEEDS_INVOICE_OUTSTANDING')]:
        try: validate_allocation(**kwargs)
        except CollectionsError as e: assert str(e)==msg
        else: assert False


def test_alert_levels():
    assert collection_alert_level(overdue=0,overdue_days=0)=='CLEAR'
    assert collection_alert_level(overdue=100,overdue_days=15)=='MEDIUM'
    assert collection_alert_level(overdue=100,overdue_days=45)=='HIGH'
    assert collection_alert_level(overdue=100,overdue_days=120)=='CRITICAL'


def test_override_self_approval_rejected():
    o=ManagementOverride(1,10,5,5,'credit hold override',date(2026,9,4),'APPROVED')
    try: validate_override(o,actor_id=5)
    except CollectionsError as e: assert str(e)=='SELF_APPROVAL_NOT_ALLOWED'
    else: assert False


def test_api_credit_and_collection():
    c=TestClient(app)
    r=c.post('/v38/credit/evaluate',json={'customer_id':1,'credit_limit':'10000','outstanding':'8000','overdue':'0','overdue_days':0,'credit_days':30,'order_value':'1500'})
    assert r.status_code==200 and r.json()['state']=='CLEAR'
    r=c.post('/v38/collections/progress',json={'salesperson_id':5,'period_start':'2026-09-01','period_end':'2026-09-30','target_amount':'100000','target_customers':20,'verified_amount':'50000','active_customers':12})
    assert r.status_code==200 and r.json()['achievement_pct']=='50.00'


def test_api_receipt_and_override():
    c=TestClient(app)
    r=c.post('/v38/receipts/transition',json={'receipt_id':1,'mode':'CASH','amount':'500','status':'PENDING_VERIFICATION','evidence_photo_ref':'photo://1','new_status':'VERIFIED','actor_role':'ACCOUNTS'})
    assert r.status_code==200
    r=c.post('/v38/override/validate',json={'override_id':1,'customer_id':1,'requested_by':5,'approved_by':6,'reason':'temporary approved credit','created_on':'2026-09-04','status':'APPROVED','actor_id':6})
    assert r.status_code==200
