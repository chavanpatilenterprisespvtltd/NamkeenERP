from decimal import Decimal
from app.storage.documents import LocalDocumentStore
from app.notifications.outbox import InMemoryNotificationOutbox, Notification
from app.accounting.tally import TallyXmlAdapter, AccountingDocument

def test_document_sign_and_verify(tmp_path):
    s=LocalDocumentStore(str(tmp_path),"secret")
    meta=s.put(b"abc","image/jpeg",object_id="o1")
    token=s.sign("o1",300)
    assert meta.sha256 and s.verify_token(token,"o1")
    assert not s.verify_token(token,"o2")

def test_notification_outbox():
    q=InMemoryNotificationOutbox(); q.enqueue(Notification("A",1,None,"MANAGEMENT","T","B",{})); seen=[]
    assert q.drain(seen.append)==1 and seen[0].title=="T"

def test_tally_preview_and_export():
    d=AccountingDocument("SALES","S1","2026-09-04","C",Decimal("100"),Decimal("18"),Decimal("118"))
    a=TallyXmlAdapter(); assert a.preview([d])[0]["total"]=="118"; assert "<DOCUMENT>" in a.export([d])
