from decimal import Decimal
import pytest
from app.v34.procurement import Supplier, SupplierQuotation, POLine, ProcurementError, create_purchase_order, approve_purchase_order, record_partial_receipt, GRNReceipt, choose_quotation, SupplierPerformance


def supplier():
    return Supplier(1, 10, 'ABC Foods Pvt Ltd', 'ABC Foods', gstin='27ABCDE1234F1Z5', payment_terms_days=7)


def test_supplier_quotation_chooses_lowest_price_then_lead_time():
    qs=[SupplierQuotation(1,1,101,Decimal('120'),lead_time_days=7),SupplierQuotation(2,1,101,Decimal('118'),lead_time_days=10),SupplierQuotation(3,1,101,Decimal('118'),lead_time_days=5)]
    assert choose_quotation(qs,supplier_id=1,sku_id=101,qty_kg=100).quotation_id==3


def test_po_requires_approval_and_blocks_self_approval():
    po=create_purchase_order(po_id=1,organization_id=10,entity_id=10,supplier=supplier(),warehouse_id=2,order_date='2026-09-04',expected_date='2026-09-11',lines=[POLine(1,101,Decimal('100'),Decimal('120'))],created_by=50)
    assert po.status=='PENDING_APPROVAL'
    with pytest.raises(ProcurementError, match='SELF_APPROVAL_NOT_ALLOWED'):
        approve_purchase_order(po,50)
    assert approve_purchase_order(po,51).status=='APPROVED'


def test_price_variance_requires_control():
    with pytest.raises(ProcurementError, match='PRICE_VARIANCE_APPROVAL_REQUIRED'):
        create_purchase_order(po_id=2,organization_id=10,entity_id=10,supplier=supplier(),warehouse_id=2,order_date='2026-09-04',expected_date=None,lines=[POLine(1,101,Decimal('100'),Decimal('125'),expected_unit_price_per_kg=Decimal('120'))],created_by=50,below_policy_tolerance=Decimal('2'))


def test_partial_grn_updates_open_quantity_and_status():
    po=create_purchase_order(po_id=3,organization_id=10,entity_id=10,supplier=supplier(),warehouse_id=2,order_date='2026-09-04',expected_date=None,lines=[POLine(1,101,Decimal('100'),Decimal('120'))],created_by=50)
    approve_purchase_order(po,51)
    receipt=GRNReceipt(100,3,1,'2026-09-06',{1:Decimal('40')},{1:Decimal('38')},{1:Decimal('2')},{1:Decimal('121')},qc_status='PASS')
    record_partial_receipt(po,receipt)
    assert po.status=='PARTIALLY_RECEIVED'
    assert po.lines[0].open_qty_kg==Decimal('60')
    assert po.lines[0].accepted_qty_kg==Decimal('38')


def test_receipt_cannot_exceed_open_po():
    po=create_purchase_order(po_id=4,organization_id=10,entity_id=10,supplier=supplier(),warehouse_id=2,order_date='2026-09-04',expected_date=None,lines=[POLine(1,101,Decimal('10'),Decimal('120'))],created_by=50)
    approve_purchase_order(po,51)
    with pytest.raises(ProcurementError, match='RECEIPT_EXCEEDS_OPEN_PO'):
        record_partial_receipt(po, GRNReceipt(101,4,1,'2026-09-06',{1:Decimal('11')},{1:Decimal('11')},{1:Decimal('0')},{1:Decimal('120')}))


def test_supplier_performance_percentages():
    p=SupplierPerformance(1,10,8,Decimal('1000'),Decimal('950'),Decimal('940'),Decimal('120'))
    assert p.on_time_pct==Decimal('80.00')
    assert p.fill_rate_pct==Decimal('95.00')
    assert p.acceptance_pct==Decimal('98.95')
