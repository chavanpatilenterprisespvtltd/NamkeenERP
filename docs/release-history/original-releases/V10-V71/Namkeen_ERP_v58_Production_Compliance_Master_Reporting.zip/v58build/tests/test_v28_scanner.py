from decimal import Decimal
import pytest
from app.v28.scanner import ScanContext, ScanError, validate_scan_context, normalize_sku_quantity, scan_preview, ResolvedScan
from app.uom.service_v27 import SKUHierarchy

def test_scan_context_accepts_positive_scan():
    ctx = ScanContext(1, 10, 20, 'RECEIVE', 'INT-500G', quantity=Decimal('2'), quantity_uom='PACK')
    validate_scan_context(ctx)

def test_scan_context_rejects_unknown_action():
    with pytest.raises(ScanError, match='UNSUPPORTED_SCAN_ACTION'):
        validate_scan_context(ScanContext(1, 10, 20, 'DELETE', 'INT-500G'))

def test_scan_context_rejects_zero_quantity():
    with pytest.raises(ScanError, match='SCAN_QUANTITY_MUST_BE_POSITIVE'):
        validate_scan_context(ScanContext(1, 10, 20, 'COUNT', 'INT-500G', quantity=Decimal('0')))

def test_500g_carton_normalizes_to_kg():
    h = SKUHierarchy(sku_id=1, product_id=1, pack_size_code='500G', net_weight_kg=Decimal('0.5'), pieces_per_pack=Decimal('1'), packs_per_carton=Decimal('20'), kg_per_piece=Decimal('0.5'))
    assert normalize_sku_quantity(h, Decimal('2'), 'CARTON') == Decimal('20.0')

def test_scan_preview_keeps_count_uom_and_converted_kg():
    h = SKUHierarchy(sku_id=1, product_id=1, pack_size_code='1KG', net_weight_kg=Decimal('1'), pieces_per_pack=Decimal('1'), packs_per_carton=Decimal('10'), kg_per_piece=Decimal('1'))
    r = ResolvedScan('INT-1KG','INTERNAL','SKU',1,1,None)
    p = scan_preview(hierarchy=h, resolved=r, quantity=Decimal('3'), quantity_uom='PACK')
    assert p['quantity'] == '3'
    assert p['quantity_uom'] == 'PACK'
    assert p['normalized_kg'] == '3'
