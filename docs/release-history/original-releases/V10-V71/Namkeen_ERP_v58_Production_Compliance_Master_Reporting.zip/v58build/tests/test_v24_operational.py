from decimal import Decimal
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.v24.operational import create_batch, record_production, record_qc, request_price_exception, decide_price_exception
from app.db.models import Organization, Entity, User, Product
from app.db.models_v17 import SalesReturn
from app.db.models_v24 import ProductionBatch, PriceException

def db():
    e=create_engine("sqlite+pysqlite:///:memory:",connect_args={"check_same_thread":False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()

def setup(d):
    org=Organization(id=1,name="O"); ent=Entity(id=1,organization_id=1,code="X",legal_name="X"); user=User(id=1,organization_id=1,username="factory",password_hash="x",role="FACTORY"); product=Product(id=1,organization_id=1,code="P",name="Product")
    d.add_all([org,ent,user,product]); d.commit(); return org,ent,user,product

def test_production_batch_and_record_state():
    d=db(); _,_,u,p=setup(d)
    b=create_batch(d,org_id=1,entity_id=1,actor_id=u.id,actor_role=u.role,batch_no="B1",product_id=p.id,planned_qty_kg=100)
    assert b.status=="PLANNED"
    b=record_production(d,org_id=1,entity_id=1,actor_id=u.id,actor_role=u.role,batch_id=b.id,good_qty_kg=60,reject_qty_kg=2)
    assert b.status=="IN_PROGRESS" and Decimal(b.actual_qty_kg)==Decimal("60")
    b=record_production(d,org_id=1,entity_id=1,actor_id=u.id,actor_role=u.role,batch_id=b.id,good_qty_kg=40)
    assert b.status=="COMPLETED"

def test_production_cannot_exceed_plan():
    d=db(); _,_,u,p=setup(d); b=create_batch(d,org_id=1,entity_id=1,actor_id=u.id,actor_role=u.role,batch_no="B2",product_id=p.id,planned_qty_kg=10)
    with pytest.raises(ValueError,match="GOOD_QTY_EXCEEDS_PLAN"): record_production(d,org_id=1,entity_id=1,actor_id=u.id,actor_role=u.role,batch_id=b.id,good_qty_kg=11)

def test_qc_requires_exactly_one_target():
    d=db(); _,_,u,p=setup(d)
    b=create_batch(d,org_id=1,entity_id=1,actor_id=u.id,actor_role="FACTORY",batch_no="B3",product_id=p.id,planned_qty_kg=10)
    with pytest.raises(ValueError,match="EXACTLY_ONE_QC_TARGET_REQUIRED"): record_qc(d,org_id=1,entity_id=1,actor_id=u.id,actor_role="QC",batch_id=b.id,return_id=1)

def test_price_exception_requires_below_floor_and_is_approved_separately():
    d=db(); _,_,u,p=setup(d)
    x=request_price_exception(d,org_id=1,entity_id=1,actor_id=u.id,order_id=10,line_id=20,negotiated_price=124,floor_price=125,reason="bargain")
    assert x.status=="PENDING"
    x=decide_price_exception(d,org_id=1,entity_id=1,actor_id=u.id,actor_role="MANAGER",exception_id=x.id,approve=True)
    assert x.status=="APPROVED"

def test_non_qc_cannot_inspect():
    d=db(); _,_,u,p=setup(d); b=create_batch(d,org_id=1,entity_id=1,actor_id=u.id,actor_role="FACTORY",batch_no="B4",product_id=p.id,planned_qty_kg=10)
    with pytest.raises(PermissionError): record_qc(d,org_id=1,entity_id=1,actor_id=u.id,actor_role="FACTORY",batch_id=b.id,result="PASS")
