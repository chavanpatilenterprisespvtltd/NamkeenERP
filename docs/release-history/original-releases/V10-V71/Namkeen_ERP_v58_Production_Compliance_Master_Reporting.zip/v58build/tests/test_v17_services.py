from decimal import Decimal
from sqlalchemy import create_engine, event, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.models import Organization, Entity, User, Customer, Payment
from app.db.models_v17 import CustomerProfile, CustomerApproval, CollectionEvidence, CollectionDeposit, SalesReturn, SalesReturnLine, ReturnDisposition
from app.customer.service import onboard_customer, decide_customer
from app.collections.service import capture_collection, submit_deposit, verify_deposit
from app.returns.service import create_return, dispose_return
from app.sync.processor import accept_sync_event

engine=create_engine("sqlite:///:memory:",connect_args={"check_same_thread":False})
Session=sessionmaker(bind=engine)
Base.metadata.create_all(engine)
@event.listens_for(Base, "before_insert", propagate=True)
def _sqlite_bigint_id(mapper, connection, target):
    if connection.dialect.name != "sqlite": return
    pk = list(mapper.primary_key)[0]
    if getattr(target, pk.name, None) is not None: return
    current = connection.execute(select(pk).select_from(mapper.local_table).order_by(pk.desc()).limit(1)).scalar_one_or_none()
    setattr(target, pk.name, (current or 0) + 1)

def fresh():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    db=Session(); seed(db); return db

def seed(db):
    o=Organization(id=1,name="Org"); e=Entity(id=1,organization_id=1,code="X",legal_name="X Pvt")
    u=User(id=1,organization_id=1,username="sp",password_hash="x",role="SALESPERSON",active=True)
    m=User(id=2,organization_id=1,username="mgr",password_hash="x",role="MANAGER",active=True)
    db.add_all([o,e,u,m]); db.flush(); return o,e,u,m

def test_customer_and_approval():
    db=fresh()
    c=onboard_customer(db,org_id=1,entity_id=1,actor_id=1,code="C1",name="Shop",mobile="999",address="A",shop_photo_file_id="shop1")
    assert c.approval_status=="PENDING"
    out=decide_customer(db,customer_id=c.id,org_id=1,actor=type("A",(),{"id":2,"role":"MANAGER"})(),approve=True)
    assert out.approval_status=="APPROVED"

def test_collection_lifecycle():
    db=fresh()
    c=Customer(id=1,organization_id=1,entity_id=1,code="C1",name="Shop",approval_status="APPROVED",active=True); db.add(c); db.flush()
    p=Payment(id=1,organization_id=1,entity_id=1,customer_id=1,mode="CASH",status="RECEIVED",amount=Decimal("100")); db.add(p); db.flush()
    capture_collection(db,org_id=1,entity_id=1,actor_id=1,payment_id=1,photo_file_id="party1")
    d=submit_deposit(db,org_id=1,entity_id=1,actor_id=1,payment_id=1,mode="COMPANY_ACCOUNT",deposit_ref="UTR1")
    assert d.status=="SUBMITTED"
    assert verify_deposit(db,org_id=1,entity_id=1,actor_id=2,actor_role="ACCOUNTS",deposit_id=d.id).status=="VERIFIED"

def test_return_qc_flow():
    db=fresh()
    c=Customer(id=2,organization_id=1,entity_id=1,code="C2",name="Shop2",approval_status="APPROVED",active=True); db.add(c); db.flush()
    r=create_return(db,org_id=1,entity_id=1,customer_id=2,order_id=None,actor_id=1,return_no="RET-1",reason_code="DAMAGE",evidence_file_id="retpic",lines=[{"sku_id":10,"qty":Decimal("2") }])
    assert r.status=="QC_HOLD"
    out=dispose_return(db,org_id=1,entity_id=1,actor_id=2,actor_role="MANAGER",return_id=r.id,disposition="DAMAGE",reason="inspection")
    assert out.status=="DAMAGE"

def test_sync_idempotency():
    db=fresh()
    e1,s1=accept_sync_event(db,org_id=1,device_id="D1",client_event_id="EV1",event_type="CREATE_CUSTOMER",payload={"code":"C1"})
    e2,s2=accept_sync_event(db,org_id=1,device_id="D1",client_event_id="EV1",event_type="CREATE_CUSTOMER",payload={"code":"C1"})
    assert s1=="PENDING" and s2=="DUPLICATE" and e1.id==e2.id
