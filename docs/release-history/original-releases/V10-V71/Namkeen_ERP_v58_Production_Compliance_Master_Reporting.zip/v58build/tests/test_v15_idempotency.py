from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.integration_models import IntegrationRun
from app.accounting.integration import run_idempotent


def test_idempotent_integration(tmp_path):
    e=create_engine(f"sqlite:///{tmp_path/'t.db'}")
    IntegrationRun.__table__.create(e)
    S=sessionmaker(bind=e)
    calls=[]
    with S.begin() as db:
        r=run_idempotent(db,organization_id=1,integration_code='TALLY',idempotency_key='K1',payload={'a':1},handler=lambda p: calls.append(p) or {'ok':1})
        assert r.status=='SUCCESS'
    with S.begin() as db:
        r=run_idempotent(db,organization_id=1,integration_code='TALLY',idempotency_key='K1',payload={'a':1},handler=lambda p: calls.append(p) or {'ok':1})
        assert r.status=='DUPLICATE'
    assert len(calls)==1
