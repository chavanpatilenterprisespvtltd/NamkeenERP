from decimal import Decimal
from datetime import datetime, timezone
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
import app.db.model_registry
from app.db.models import Organization, Entity, Customer
from app.db.models_v43 import AccountingVoucherV43, AccountingReconciliationV43
from app.db.models_v44 import PartyLedgerLinkV44, LedgerSyncJobV44, AccountingReconciliationActionV44
from app.v44.master_sync import ensure_party_link, validate_party_exists, mark_synced
from app.v44.dashboard import dashboard
from app.v44.reconciliation_actions import request_action, approve_action

def setup():
    e=create_engine('sqlite+pysqlite:///:memory:',future=True); Base.metadata.create_all(e); S=sessionmaker(bind=e); s=S()
    s.add_all([Organization(id=1,name='O'),Entity(id=1,organization_id=1,code='X',legal_name='X'),Customer(id=1,organization_id=1,entity_id=1,code='C1',name='Customer 1',credit_limit=0,credit_days=0)])
    s.commit(); return s

def test_customer_link_creates_job():
    s=setup(); r=ensure_party_link(s,organization_id=1,entity_id=1,party_type='CUSTOMER',party_id=1,ledger_code='CUST-001'); assert r['status']=='PENDING'; assert s.execute(select(LedgerSyncJobV44)).scalar_one().idempotency_key.startswith('LEDGER_MASTER:')

def test_party_validation_and_sync():
    s=setup(); validate_party_exists(s,organization_id=1,entity_id=1,party_type='CUSTOMER',party_id=1); r=ensure_party_link(s,organization_id=1,entity_id=1,party_type='CUSTOMER',party_id=1,ledger_code='CUST-001'); out=mark_synced(s,link_id=r and s.execute(select(PartyLedgerLinkV44)).scalar_one().id,external_name='Customer Ledger'); assert out['status']=='SYNCED'

def test_invalid_party_fails():
    s=setup()
    try: validate_party_exists(s,organization_id=1,entity_id=1,party_type='CUSTOMER',party_id=999)
    except ValueError as e: assert str(e)=='PARTY_NOT_FOUND'
    else: assert False

def test_reconciliation_action_and_self_approval_guard():
    s=setup(); s.add(AccountingVoucherV43(organization_id=1,entity_id=1,source_type='SALES',source_id=1,source_number='INV1',voucher_type='Sales',voucher_date=datetime(2026,9,5,tzinfo=timezone.utc),amount=Decimal('100'),status='POSTED')); s.flush(); v=s.execute(select(AccountingVoucherV43)).scalar_one(); s.add(AccountingReconciliationV43(organization_id=1,entity_id=1,voucher_id=v.id,internal_amount=Decimal('100'),external_amount=Decimal('98'),amount_difference=Decimal('-2'),status='MISMATCH',mismatch_reason='AMOUNT_MISMATCH')); s.commit(); rec=s.execute(select(AccountingReconciliationV43)).scalar_one(); a=request_action(s,organization_id=1,entity_id=1,reconciliation_id=rec.id,action='ACCEPT_EXTERNAL',reason='Approved after bank confirmation',requested_by=10); assert a['status']=='PENDING'; aid=a['action_id']
    try: approve_action(s,organization_id=1,entity_id=1,action_id=aid,approved_by=10)
    except ValueError as e: assert str(e)=='SELF_APPROVAL_NOT_ALLOWED'
    else: assert False

def test_reconciliation_action_apply_changes_only_recon():
    s=setup(); s.add(AccountingVoucherV43(organization_id=1,entity_id=1,source_type='SALES',source_id=1,source_number='INV1',voucher_type='Sales',voucher_date=datetime(2026,9,5,tzinfo=timezone.utc),amount=Decimal('100'),status='POSTED')); s.flush(); v=s.execute(select(AccountingVoucherV43)).scalar_one(); s.add(AccountingReconciliationV43(organization_id=1,entity_id=1,voucher_id=v.id,internal_amount=Decimal('100'),external_amount=Decimal('100'),status='UNMATCHED')); s.commit(); rec=s.execute(select(AccountingReconciliationV43)).scalar_one(); a=request_action(s,organization_id=1,entity_id=1,reconciliation_id=rec.id,action='ACCEPT_EXTERNAL',reason='Bank statement matched',requested_by=10); approve_action(s,organization_id=1,entity_id=1,action_id=a['action_id'],approved_by=11,apply=True); assert s.execute(select(AccountingReconciliationV43)).scalar_one().status=='MATCHED'; assert s.execute(select(AccountingVoucherV43)).scalar_one().amount==100

def test_dashboard():
    s=setup(); d=dashboard(s,organization_id=1,entity_id=1); assert d['ledger_links']['PENDING']==0 and 'reconciliations' in d and 'vouchers' in d

def test_duplicate_link_updates_not_duplicates():
    s=setup(); ensure_party_link(s,organization_id=1,entity_id=1,party_type='CUSTOMER',party_id=1,ledger_code='A'); ensure_party_link(s,organization_id=1,entity_id=1,party_type='CUSTOMER',party_id=1,ledger_code='B'); assert len(s.execute(select(PartyLedgerLinkV44)).scalars().all())==1; assert s.execute(select(PartyLedgerLinkV44)).scalar_one().ledger_code=='B'
