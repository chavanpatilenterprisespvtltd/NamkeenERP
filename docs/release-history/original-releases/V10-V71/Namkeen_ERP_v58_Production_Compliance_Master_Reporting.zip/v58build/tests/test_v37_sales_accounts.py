from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from app.v37.sales_accounts import *
from app.v37.api import app

def test_invoice_validation_and_total():
    inv=SalesInvoice(1,1,1,10,'INV-1',date(2026,9,4),(SalesInvoiceLine(1,10,100,1000,180),),1000,180,1180,'POSTED',5)
    validate_sales_invoice(inv)
    assert inv.grand_total==1180

def test_invoice_mismatch_rejected():
    inv=SalesInvoice(1,1,1,10,'INV-1',date(2026,9,4),(SalesInvoiceLine(1,10,100,1000,180),),1000,180,1179,'POSTED',5)
    try: validate_sales_invoice(inv)
    except SalesAccountsError as e: assert str(e)=='INVOICE_GRAND_TOTAL_MISMATCH'
    else: assert False

def test_credit_limit():
    a=CustomerAccount(1,1,Decimal('10000'),Decimal('7000'))
    assert customer_credit_check(a,Decimal('2000'))=='WITHIN_LIMIT'
    try: customer_credit_check(a,Decimal('4000'))
    except SalesAccountsError as e: assert str(e)=='CREDIT_LIMIT_EXCEEDED'
    else: assert False

def test_receipt_allocation():
    r=CustomerReceipt(1,1,1,10,date(2026,9,4),Decimal('5000'),'UPI','UTR','POSTED',7)
    out,un=allocate_customer_receipt(receipt=r,outstanding_before=Decimal('8000'),allocation=Decimal('4500'))
    assert out==Decimal('3500.00') and un==Decimal('500.00')

def test_returned_quantity_reduces_incentive_basis():
    x=build_incentive_basis(salesperson_id=5,invoice_id=9,lines=[(Decimal('100'),Decimal('130'),Decimal('115'))],returns_qty_kg=Decimal('20'))
    assert x.eligible_qty_kg==80 and x.net_sales_value==10400 and x.gross_margin_value==1200

def test_customer_ageing():
    rows=[(date(2026,9,4),Decimal('1000')),(date(2026,8,1),Decimal('2000')),(date(2026,6,1),Decimal('3000')),(date(2026,1,1),Decimal('4000'))]
    a=customer_ageing(rows,date(2026,9,4))
    assert [(x['label'],x['amount']) for x in a]==[('CURRENT',Decimal('1000.00')),('1-30',Decimal('0.00')),('31-60',Decimal('2000.00')),('61-90',Decimal('0.00')),('91-120',Decimal('3000.00')),('120+',Decimal('4000.00'))]

def test_api_invoice_and_credit():
    c=TestClient(app)
    body={'invoice_id':1,'organization_id':1,'entity_id':1,'customer_id':10,'invoice_no':'INV-1','invoice_date':'2026-09-04','status':'POSTED','salesperson_id':5,'taxable_total':'1000','tax_total':'180','grand_total':'1180','lines':[{'sku_id':1,'quantity_kg':'10','unit_price':'100','taxable_value':'1000','tax_amount':'180'}]}
    assert c.post('/v37/invoices/validate',json=body).status_code==200
    r=c.post('/v37/credit/check',json={'customer_id':10,'entity_id':1,'credit_limit':'10000','outstanding':'7000','credit_days':30,'active':True,'new_amount':'2000'})
    assert r.status_code==200 and r.json()['state']=='WITHIN_LIMIT'

def test_api_incentive_basis():
    c=TestClient(app); r=c.post('/v37/incentive/basis',json={'salesperson_id':5,'invoice_id':9,'returns_qty_kg':'20','lines':[{'qty_kg':'100','selling_price_per_kg':'130','company_cost_per_kg':'115'}]})
    assert r.status_code==200 and r.json()['eligible_qty_kg']=='80' and r.json()['gross_margin_value']=='1200.00'
