from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from app.v39.pricing import PricingPolicy
from app.v38.collections_credit import CreditControlProfile
from app.v40.transaction import *
from app.v40.api import app


def policy(**kw):
    d=dict(policy_id=1,sku_id=10,entity_id=1,customer_id=None,effective_from=date(2026,9,1),effective_to=None,target_price=Decimal('125'),floor_price=Decimal('120'),max_discount_pct=Decimal('4'))
    d.update(kw); return PricingPolicy(**d)


def req(lines, **kw):
    base=dict(organization_id=1,entity_id=1,customer_id=99,salesperson_id=5,order_no='SO-40-1',transaction_date=date(2026,9,4),payment_mode='UPI',payment_state='VERIFIED',credit_profile=CreditControlProfile(99,Decimal('50000'),Decimal('0'),Decimal('0'),0,30),lines=tuple(lines),warehouse_code='FG01')
    base.update(kw); return SalesTransactionRequest(**base)


def line(price='125', cost='115', qty='10'):
    return SalesLineInput(10,Decimal(qty),Decimal(price),Decimal(cost),policy())


def test_ready_transaction_builds_invoice_and_posting_intents():
    r=orchestrate_transaction(req([line()]))
    assert r.state=='INVOICED'
    assert r.invoice and r.invoice.grand_total==Decimal('1250.00')
    assert len(r.postings)==2


def test_price_exception_stops_before_invoice():
    r=orchestrate_transaction(req([line(price='118')]))
    assert r.state=='PRICE_APPROVAL' and r.invoice is None


def test_credit_block_stops_before_invoice():
    r=orchestrate_transaction(req([line(price='125')], credit_profile=CreditControlProfile(99,Decimal('1000'),Decimal('950'),Decimal('0'),0,30)))
    assert r.state=='CREDIT_BLOCK' and r.invoice is None


def test_cheque_requires_clearance():
    r=orchestrate_transaction(req([line()], payment_mode='CHEQUE', payment_state='PENDING', cheque_ref='CHQ-1'))
    assert r.state=='PAYMENT_VERIFICATION'


def test_cheque_clearance_can_invoice():
    r=orchestrate_transaction(req([line()], payment_mode='CHEQUE', payment_state='CLEARED', cheque_ref='CHQ-1'))
    assert r.state=='INVOICED'


def test_cash_verified_requires_evidence():
    try: orchestrate_transaction(req([line()], payment_mode='CASH', payment_state='VERIFIED'))
    except SalesTransactionError as e: assert str(e)=='CASH_EVIDENCE_REQUIRED'
    else: assert False


def test_cash_with_evidence_can_invoice():
    r=orchestrate_transaction(req([line()], payment_mode='CASH', payment_state='VERIFIED', cash_evidence_ref='photo://1'))
    assert r.state=='INVOICED'


def test_margin_rolls_up_from_lines():
    r=orchestrate_transaction(req([line(cost='115',qty='10'), line(cost='110',price='125',qty='5')], order_no='SO-40-2'))
    assert r.gross_margin_value==Decimal('175.00')


def test_incentive_only_after_invoice():
    r=orchestrate_transaction(req([line()]))
    p=IncentivePolicy(1,'kg','PER_KG',per_kg_rate=Decimal('2'),approved_by=7)
    i=build_incentive_result(req([line()]),r,p,verified_collections=Decimal('1000'))
    assert i.incentive==Decimal('20.00')


def test_invoice_and_taxable_totals_separate_from_gst():
    r=orchestrate_transaction(req([line(price='118',cost='100')], credit_profile=CreditControlProfile(99,Decimal('50000'),Decimal('0'),Decimal('0'),0,30), order_no='SO-40-3'))
    # price is below floor, so no invoice
    assert r.state=='PRICE_APPROVAL'


def test_idempotency_key_is_carried():
    r=orchestrate_transaction(req([line()], idempotency_key='evt-123'))
    assert r.idempotency_key=='evt-123'


def test_api_happy_path():
    c=TestClient(app)
    body={
      'organization_id':1,'entity_id':1,'customer_id':99,'salesperson_id':5,'order_no':'SO-API-40','transaction_date':'2026-09-04','payment_mode':'UPI','payment_state':'VERIFIED',
      'credit_limit':'50000','outstanding':'0','overdue':'0','overdue_days':0,'credit_days':30,'warehouse_code':'FG01','idempotency_key':'api-40-1',
      'lines':[{'sku_id':10,'quantity_kg':'10','negotiated_unit_price':'125','actual_cost_per_unit':'115','gst_pct':'0','tax_inclusive':False,'policy':{'policy_id':1,'sku_id':10,'entity_id':1,'customer_id':None,'effective_from':'2026-09-01','effective_to':None,'target_price':'125','floor_price':'120','max_discount_pct':'4','approval_below_floor':True,'active':True}}]
    }
    r=c.post('/v40/sales/quote-and-post',json=body)
    assert r.status_code==200 and r.json()['state']=='INVOICED'


def test_api_credit_block():
    c=TestClient(app)
    body={
      'organization_id':1,'entity_id':1,'customer_id':99,'salesperson_id':5,'order_no':'SO-API-40-B','transaction_date':'2026-09-04','payment_mode':'UPI','payment_state':'VERIFIED',
      'credit_limit':'1000','outstanding':'950','warehouse_code':'FG01',
      'lines':[{'sku_id':10,'quantity_kg':'10','negotiated_unit_price':'125','actual_cost_per_unit':'115','policy':{'policy_id':1,'sku_id':10,'entity_id':1,'customer_id':None,'effective_from':'2026-09-01','effective_to':None,'target_price':'125','floor_price':'120','max_discount_pct':'4','approval_below_floor':True,'active':True}}]
    }
    r=c.post('/v40/sales/quote-and-post',json=body)
    assert r.status_code==200 and r.json()['state']=='CREDIT_BLOCK'
