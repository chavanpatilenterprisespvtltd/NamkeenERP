from datetime import datetime, timezone, timedelta
from decimal import Decimal
from app.v46.einvoice import *

def mkdoc():
 return EInvoiceDoc(1,10,'TAX_INVOICE','INV/10','2026-09-04','27ABCDE1234F1Z5','29ABCDE1234F1Z5','29','B2B',Decimal('1000'),Decimal('1180'),'19059090')

def test_einvoice_validation_and_hash():
 d=mkdoc(); assert validate_einvoice_document(d)==[]; assert len(canonical_hash(d.payload()))==64

def test_mock_irp_generate_is_deterministic():
 d=mkdoc(); a=MockIRPClient().generate_irn(d.payload()); b=MockIRPClient().generate_irn(d.payload()); assert a.irn==b.irn and a.success

def test_irn_cancel_window_and_active_ewb_block():
 g=datetime(2026,9,4,10,tzinfo=timezone.utc); assert can_cancel_irn(g,g+timedelta(hours=23),False); assert not can_cancel_irn(g,g+timedelta(hours=25),False); assert not can_cancel_irn(g,g+timedelta(hours=1),True)

def test_ewaybill_validation_transport_rules():
 d=EWayBillData(1,'INV-1','2026-09-04','27','29',Decimal('1180'),'ROAD')
 assert 'VEHICLE_REQUIRED_FOR_ROAD' in validate_eway_bill(d)
 d2=EWayBillData(1,'INV-1','2026-09-04','27','29',Decimal('1180'),'RAIL',trans_doc_no='LR1')
 assert validate_eway_bill(d2)==[]

def test_mock_ewaybill_generation():
 d=EWayBillData(1,'INV-1','2026-09-04','27','29',Decimal('1180'),'ROAD',vehicle_no='MH12AB1234',distance_km=Decimal('125'))
 r=MockEWayBillClient().generate(d); assert r['success'] and r['ewb_no']

def test_retry_backoff_cap():
 assert next_retry_delay(1)==30; assert next_retry_delay(7)==1920; assert next_retry_delay(20)==3600

def test_integration_state_constants():
 assert 'DEAD_LETTER' in OUTBOX_STATES and 'GENERATED' in IRN_STATES
