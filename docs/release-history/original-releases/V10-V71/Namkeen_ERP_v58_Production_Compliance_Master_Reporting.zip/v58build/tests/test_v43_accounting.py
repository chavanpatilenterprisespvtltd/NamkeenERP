from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.model_registry import *
from app.db.models_v43 import VoucherMappingV43, AccountingVoucherV43
from app.v43.mapping import map_document
from app.v43.reconciliation import compare_amounts


def setup():
    e=create_engine('sqlite+pysqlite:///:memory:',future=True)
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); s=S()
    s.add_all([__import__('app.db.models',fromlist=['Organization']).Organization(id=1,name='O'),
               __import__('app.db.models',fromlist=['Entity']).Entity(id=1,organization_id=1,code='X',legal_name='X')])
    s.commit(); return s

def add_mapping(s, typ='SALES'):
    s.add(VoucherMappingV43(organization_id=1,entity_id=1,document_type=typ,voucher_type=typ.title(),party_ledger_code='CUST',base_ledger_code='SALES',cgst_ledger_code='CGST',sgst_ledger_code='SGST',igst_ledger_code='IGST',cess_ledger_code='CESS',is_active=True)); s.commit()

def test_sales_mapping_balances():
    s=setup(); add_mapping(s)
    m=map_document(s,organization_id=1,entity_id=1,payload={'document_type':'SALES','invoice_no':'INV1','date':'2026-09-05','total':'118','taxable_total':'100','cgst':'9','sgst':'9'})
    assert m.voucher_type=='Sales' and len(m.lines)==4
    assert sum((l.amount if l.side=='DEBIT' else -l.amount) for l in m.lines)==Decimal('0')

def test_purchase_mapping_balances():
    s=setup(); add_mapping(s,'PURCHASE')
    m=map_document(s,organization_id=1,entity_id=1,payload={'document_type':'PURCHASE','document_no':'P1','total':'118','taxable_total':'100','igst':'18'})
    assert any(l.side=='DEBIT' and l.ledger_code=='IGST' for l in m.lines)
    assert sum((l.amount if l.side=='DEBIT' else -l.amount) for l in m.lines)==0

def test_missing_mapping_fails():
    s=setup()
    try: map_document(s,organization_id=1,entity_id=1,payload={'document_type':'SALES','invoice_no':'X','total':'1','taxable_total':'1'})
    except ValueError as e: assert str(e)=='VOUCHER_MAPPING_NOT_FOUND'
    else: assert False

def test_missing_tax_ledger_fails():
    s=setup(); s.add(VoucherMappingV43(organization_id=1,entity_id=1,document_type='SALES',voucher_type='Sales',party_ledger_code='CUST',base_ledger_code='SALES',cgst_ledger_code=None,is_active=True)); s.commit()
    try: map_document(s,organization_id=1,entity_id=1,payload={'document_type':'SALES','invoice_no':'X','total':'109','taxable_total':'100','cgst':'9'})
    except ValueError as e: assert str(e)=='LEDGER_MAPPING_MISSING:CGST'
    else: assert False

def test_reconciliation_exact(): assert compare_amounts(Decimal('118'),Decimal('118'))==('MATCHED',Decimal('0.00'),None)
def test_reconciliation_tolerance(): assert compare_amounts(Decimal('118'),Decimal('118.005'),Decimal('0.01'))[0]=='MATCHED'
def test_reconciliation_mismatch():
    r=compare_amounts(Decimal('118'),Decimal('120'),Decimal('0.01')); assert r[0]=='MISMATCH' and r[2]=='AMOUNT_MISMATCH'
def test_reconciliation_missing_external():
    r=compare_amounts(Decimal('118'),None); assert r[0]=='UNMATCHED'

def test_voucher_source_unique_model():
    s=setup(); v=AccountingVoucherV43(organization_id=1,entity_id=1,source_type='SALES',source_id=1,source_number='INV1',voucher_type='Sales',voucher_date=datetime.now(timezone.utc),amount=Decimal('118'),status='DRAFT'); s.add(v); s.commit(); assert s.execute(select(AccountingVoucherV43)).scalar_one().source_number=='INV1'
