from decimal import Decimal
from app.db.base import Base
from app.db.session import engine, SessionLocal
from app.db.models import Organization, Entity, User, Product, PackSize, SKU, InventoryLot
from app.db.models_v25 import Warehouse
from app.inventory.service_v25 import create_warehouse, request_adjustment, create_transfer
from app.auth.security import hash_password


def setup_module(module):
    Base.metadata.create_all(engine)

def test_warehouse_and_adjustment_request():
    with SessionLocal() as db:
        o=Organization(id=9301,name="v25 org"); e=Entity(id=9302,organization_id=o.id,code="E25",legal_name="E25"); u=User(id=9303,organization_id=o.id,username="v25u",password_hash=hash_password("pw"),role="WAREHOUSE",active=True)
        p=Product(id=9304,organization_id=o.id,code="P25",name="P25",active=True); ps=PackSize(id=9305,organization_id=o.id,name="1kg",net_weight_g=1000); s=SKU(id=9306,organization_id=o.id,product_id=p.id,pack_size_id=ps.id,active=True)
        db.add_all([o,e,u,p,ps,s]); db.commit()
        w=create_warehouse(db,org_id=o.id,entity_id=e.id,code="RM01",name="RM Store",warehouse_type="RM",warehouse_id=9390); db.commit()
        a=request_adjustment(db,org_id=o.id,entity_id=e.id,warehouse_id=w.id,sku_id=s.id,lot_id=None,qty_delta=Decimal('10'),reason='count correction',actor_id=u.id,adjustment_id=9392); db.commit()
        assert w.code=="RM01" and a.status=="PENDING"

def test_transfer_rejects_same_warehouse():
    with SessionLocal() as db:
        o=Organization(id=9311,name="v25b"); e=Entity(id=9312,organization_id=o.id,code="E25B",legal_name="E25B"); u=User(id=9313,organization_id=o.id,username="v25b",password_hash=hash_password("pw"),role="MANAGER",active=True)
        db.add_all([o,e,u]); db.commit(); w=create_warehouse(db,org_id=o.id,entity_id=e.id,code="FG01",name="FG",warehouse_type="FG",warehouse_id=9391); db.commit()
        try: create_transfer(db,org_id=o.id,entity_id=e.id,transfer_no="T1",from_warehouse_id=w.id,to_warehouse_id=w.id,actor_id=u.id)
        except ValueError as ex: assert str(ex)=="TRANSFER_SAME_WAREHOUSE"
        else: raise AssertionError('expected same warehouse rejection')
