import json
from types import SimpleNamespace
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.models import Organization, Entity, User, Customer
from app.db.models_v19 import DomainChange
from app.sync.domain_events import record_change
from app.mobile_client.offline_store import OfflineStore


def db():
    e=create_engine('sqlite:///:memory:', future=True)
    Base.metadata.create_all(e)
    # add v18/v19 tables because they are not imported by Base itself in some test environments
    from app.db.models_v18 import SyncChangeLog, SyncCursor, SyncConflict, SyncDeadLetter
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e)
    s=S()
    s.add(Organization(id=1,name='Org'))
    s.add(Entity(id=1,organization_id=1,code='X',legal_name='X'))
    s.add(User(id=1,organization_id=1,username='u',password_hash='x',role='MANAGEMENT'))
    s.commit(); return s


def test_domain_versions_are_per_aggregate():
    s=db()
    a=record_change(s,org_id=1,aggregate_type='SALES_ORDER',aggregate_id='SO1',operation='CREATE',event_name='CREATED',payload={'status':'NEW'})
    b=record_change(s,org_id=1,aggregate_type='SALES_ORDER',aggregate_id='SO1',operation='UPDATE',event_name='APPROVED',payload={'status':'READY'})
    c=record_change(s,org_id=1,aggregate_type='SALES_ORDER',aggregate_id='SO2',operation='CREATE',event_name='CREATED',payload={'status':'NEW'})
    assert (a.version,b.version,c.version)==(1,2,1)


def test_offline_outbox_and_ack():
    st=OfflineStore()
    eid=st.enqueue(device_id='D1',event_type='CREATE_ORDER',entity_type='SALES_ORDER',entity_id='SO1',payload={'x':1})
    assert st.pending()[0].client_event_id==eid
    st.mark_result(eid,status='ACCEPTED')
    assert st.pending()==[]
    st.close()


def test_offline_delta_is_idempotent_and_cursor_advances():
    st=OfflineStore()
    d={'change_id':10,'entity_type':'CUSTOMER','entity_id':'C1','version':1,'operation':'CREATE','payload':{'name':'A'},'occurred_at':'2026-01-01T00:00:00+00:00'}
    assert st.apply_delta(d) is True
    assert st.apply_delta(d) is False
    assert st.cursor()==10
    st.close()


def test_conflict_is_stored_locally():
    st=OfflineStore()
    st.record_conflict(client_event_id='E1',entity_type='SALES_ORDER',entity_id='SO1',client_version=1,server_version=2,client_payload={'p':1},server_payload={'p':2})
    row=st.db.execute('select * from conflicts').fetchone()
    assert row['state']=='OPEN' and row['server_version']==2
    st.close()
