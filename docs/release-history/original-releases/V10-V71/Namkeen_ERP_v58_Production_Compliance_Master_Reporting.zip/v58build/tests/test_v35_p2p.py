from datetime import date
from decimal import Decimal
from app.v35_p2p import *
from fastapi.testclient import TestClient
from app.v35.api import app


def sample():
    po = PurchaseOrderRef(10, 20, 30, "APPROVED", (
        POItem(1,101,Decimal('100'),Decimal('50')),
        POItem(2,102,Decimal('20'),Decimal('80')),
    ))
    grn = GRNRef(100,10,20,'POSTED',(
        GRNItem(1,Decimal('100'),Decimal('100')),
        GRNItem(2,Decimal('20'),Decimal('20')),
    ),date(2026,9,1))
    inv = SupplierInvoice(500,20,'INV-1',date(2026,9,2),date(2026,10,2),(
        SupplierInvoiceLine(1,Decimal('100'),Decimal('50')),
        SupplierInvoiceLine(2,Decimal('20'),Decimal('80')),
    ),Decimal('6600'),Decimal('1188'),Decimal('7788'))
    return po,grn,inv


def test_three_way_match_passes():
    po,grn,inv=sample()
    r=three_way_match(inv,po,[grn],MatchTolerance())
    assert r.matched and r.exception_reasons==[]


def test_three_way_match_catches_price():
    po,grn,inv=sample()
    bad=SupplierInvoice(inv.invoice_id,inv.supplier_id,inv.invoice_no,inv.invoice_date,inv.due_date,
        (SupplierInvoiceLine(1,Decimal('100'),Decimal('52')),SupplierInvoiceLine(2,Decimal('20'),Decimal('80'))),
        Decimal('6800'),Decimal('1224'),Decimal('8024'))
    r=three_way_match(bad,po,[grn],MatchTolerance())
    assert r.status=='EXCEPTION' and 'LINE:1:PRICE_VARIANCE' in r.exception_reasons


def test_payable_requires_exception_approval():
    po,grn,inv=sample(); r=three_way_match(inv,po,[grn],MatchTolerance())
    payable=approve_payable(payable_id=1,organization_id=1,entity_id=30,invoice=inv,match=r,approver_id=99)
    assert payable.status=='OPEN' and payable.outstanding_amount==Decimal('7788.00')


def test_payment_changes_outstanding():
    po,grn,inv=sample(); r=three_way_match(inv,po,[grn],MatchTolerance())
    payable=approve_payable(payable_id=1,organization_id=1,entity_id=30,invoice=inv,match=r,approver_id=99)
    sp=schedule_supplier_payment(payment_id=1,payable=payable,payment_date=date(2026,10,2),amount=Decimal('3000'),mode='BANK_TRANSFER')
    sp=SupplierPayment(sp.payment_id,sp.payable_id,sp.payment_date,sp.amount,sp.mode,sp.reference_no,'PAID')
    apply_payment(payable,sp)
    assert payable.status=='PARTIALLY_PAID' and payable.outstanding_amount==Decimal('4788.00')


def test_api_match():
    c=TestClient(app)
    body={'po':{'po_id':10,'supplier_id':20,'entity_id':30,'status':'APPROVED','items':[{'po_line_id':1,'sku_id':101,'ordered_qty_kg':'100','unit_price':'50'}]},
          'grns':[{'grn_id':100,'po_id':10,'supplier_id':20,'status':'POSTED','receipt_date':'2026-09-01','items':[{'po_line_id':1,'received_qty_kg':'100','accepted_qty_kg':'100'}]}],
          'invoice':{'invoice_id':500,'supplier_id':20,'invoice_no':'INV-1','invoice_date':'2026-09-02','due_date':'2026-10-02','lines':[{'po_line_id':1,'quantity_kg':'100','unit_price':'50'}],'taxable_total':'5000','tax_total':'900','grand_total':'5900'}}
    r=c.post('/v35/purchase-invoices/three-way-match',json=body)
    assert r.status_code==200 and r.json()['match']['status']=='MATCHED'
