from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.base import Base
from app.db.model_registry import *
from app.db.models import Organization, Entity, User, Product, PackSize, SKU, InventoryLot
from app.db.models_v24 import ProductionBatch

def test_v53_models_create_and_persist():
    engine=create_engine('sqlite+pysqlite:///:memory:', future=True)
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine); s=Session()
    s.add_all([Organization(id=1,name='Org'),Entity(id=1,organization_id=1,code='X',legal_name='X'),User(id=1,organization_id=1,username='factory',password_hash='x',role='FACTORY',active=True),Product(id=10,organization_id=1,code='P10',name='P'),PackSize(id=1,organization_id=1,name='1kg',net_weight_g=1000),SKU(id=10,organization_id=1,product_id=10,pack_size_id=1)])
    s.commit()
    assert 'production_execution_runs' in Base.metadata.tables
    assert 'production_execution_issues' in Base.metadata.tables
