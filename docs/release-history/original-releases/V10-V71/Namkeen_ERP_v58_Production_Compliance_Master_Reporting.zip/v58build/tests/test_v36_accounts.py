from datetime import date
from decimal import Decimal
from fastapi.testclient import TestClient
from app.v36.accounts import *
from app.v36.api import app


def profiles():
    p=TaxProfile('GST-A',date(2026,4,1),None,
        (TaxComponent('CGST',Decimal('9'),Decimal('0')),TaxComponent('SGST',Decimal('9'),Decimal('0'))),
        (TaxComponent('IGST',Decimal('18'),Decimal('0')),),False)
    return {'GST-A':p}


def test_intra_state_tax_split_and_withholding():
    r=calculate_tax([TaxableLine(1,Decimal('10'),Decimal('100'),'GST-A')],profiles(),date(2026,9,1),interstate=False,tds_rate_pct=Decimal('1'))
    assert r.taxable_value==Decimal('1000.00')
    assert r.tax_total==Decimal('180.00')
    assert r.grand_total==Decimal('1180.00')
    assert r.withholding_tds==Decimal('10.00')
    assert r.net_payable==Decimal('1170.00')
    assert [x.code for x in r.tax_components]==['CGST','SGST']


def test_interstate_tax():
    r=calculate_tax([TaxableLine(1,Decimal('10'),Decimal('100'),'GST-A')],profiles(),date(2026,9,1),interstate=True)
    assert r.tax_total==Decimal('180.00') and r.tax_components[0].code=='IGST'


def test_inclusive_tax():
    p=TaxProfile('GST-I',date(2026,1,1),None,(),(TaxComponent('IGST',Decimal('18'),Decimal('0')),),True)
    r=calculate_tax([TaxableLine(1,Decimal('1'),Decimal('118'),'GST-I')],{'GST-I':p},date(2026,9,1),interstate=True)
    assert r.taxable_value==Decimal('100.00') and r.tax_total==Decimal('18.00') and r.grand_total==Decimal('118.00')


def test_tax_profile_must_be_effective():
    p=TaxProfile('GST-X',date(2027,1,1),None,(),(),False)
    try: calculate_tax([TaxableLine(1,Decimal('1'),Decimal('100'),'GST-X')],{'GST-X':p},date(2026,9,1),interstate=True)
    except AccountsError as e: assert str(e)=='TAX_PROFILE_NOT_ACTIVE:GST-X'
    else: assert False


def test_note_total_and_reason():
    n=AdjustmentNote(1,2,'CREDIT',5,Decimal('100'),Decimal('18'),Decimal('118'),'Rate correction',date(2026,9,2))
    validate_note(n,5)
    bad=AdjustmentNote(1,2,'CREDIT',5,Decimal('100'),Decimal('18'),Decimal('117'),'Rate correction',date(2026,9,2))
    try: validate_note(bad,5)
    except AccountsError as e: assert str(e)=='NOTE_TOTAL_MISMATCH'
    else: assert False


def test_supplier_ageing_buckets():
    ps=[
      PayableRef(1,2,'A',date(2026,8,1),date(2026,9,4),Decimal('1000'),Decimal('1000'),'OPEN',10),
      PayableRef(2,2,'B',date(2026,7,1),date(2026,8,1),Decimal('2000'),Decimal('500'),'OPEN',10),
      PayableRef(3,2,'C',date(2026,3,1),date(2026,3,1),Decimal('3000'),Decimal('0'),'PAID',10),
      PayableRef(4,3,'D',date(2026,1,1),date(2026,1,1),Decimal('4000'),Decimal('4000'),'OPEN',10),
    ]
    a=supplier_ageing(ps,date(2026,9,4))
    assert [(x.label,x.amount) for x in a]==[('CURRENT',Decimal('1000.00')),('1-30',Decimal('0')),('31-60',Decimal('500.00')),('61-90',Decimal('0')),('91-120',Decimal('0')),('120+',Decimal('4000.00'))]


def test_reconcile_payment_states():
    p=PayableRef(10,2,'A',date(2026,8,1),date(2026,9,1),Decimal('1000'),Decimal('1000'),'OPEN',10)
    assert reconcile_payment(payment_id=1,supplier_id=2,amount=Decimal('1000'),bank_reference='UTR1',value_date=date(2026,9,4),payable=p).status=='MATCHED'
    assert reconcile_payment(payment_id=2,supplier_id=2,amount=Decimal('900'),bank_reference='UTR2',value_date=date(2026,9,4),payable=p).status=='SHORT'
    assert reconcile_payment(payment_id=3,supplier_id=2,amount=Decimal('1200'),bank_reference='UTR3',value_date=date(2026,9,4),payable=p).status=='OVER'
    assert reconcile_payment(payment_id=4,supplier_id=2,amount=Decimal('300'),bank_reference='UTR4',value_date=date(2026,9,4),payable=None).status=='UNMATCHED'


def test_api_tax_and_ageing():
    c=TestClient(app)
    body={'on_date':'2026-09-04','interstate':False,'tds_rate_pct':'1','tcs_rate_pct':'0','profiles':[{'tax_code':'GST-A','effective_from':'2026-04-01','effective_to':None,'inclusive':False,'intra_state':[{'code':'CGST','rate_pct':'9'},{'code':'SGST','rate_pct':'9'}],'inter_state':[{'code':'IGST','rate_pct':'18'}]}], 'lines':[{'sku_id':1,'quantity_kg':'10','unit_price':'100','tax_code':'GST-A','discount':'0'}]}
    r=c.post('/v36/tax/calculate',json=body)
    assert r.status_code==200 and r.json()['grand_total']=='1180.00' and r.json()['tds']=='10.00'
    a=c.post('/v36/supplier-ageing',json={'as_of':'2026-09-04','payables':[{'payable_id':1,'supplier_id':2,'invoice_no':'A','invoice_date':'2026-08-01','due_date':'2026-09-01','original_amount':'1000','outstanding_amount':'1000','status':'OPEN','entity_id':1}]})
    assert a.status_code==200 and a.json()['buckets'][0]['amount']=='0.00' and a.json()['buckets'][1]['amount']=='1000.00'
