from decimal import Decimal
import pytest
from app.v29.license_plate import *

def make():
    return LicensePlate(1, 10, 'CARTON-0001', warehouse_id=5)

def test_add_seal_pick_dispatch():
    l=make(); add_content(l, LPNContent(1,101,501,Decimal('20'),'PACK',Decimal('10'),'2026-12-01')); seal_lpn(l); pick_lpn(l); dispatch_lpn(l)
    assert l.status == 'DISPATCHED' and l.total_kg == Decimal('10.000000000')

def test_empty_carton_cannot_seal():
    with pytest.raises(LPNError, match='EMPTY_LPN_CANNOT_BE_SEALED'): seal_lpn(make())

def test_sealed_carton_rejects_content():
    l=make(); add_content(l, LPNContent(1,101,501,Decimal('20'),'PACK',Decimal('10'))); seal_lpn(l)
    with pytest.raises(LPNError, match='LPN_NOT_OPEN_FOR_CONTENT'): add_content(l, LPNContent(1,102,502,Decimal('1'),'PACK',Decimal('1')))

def test_pick_requires_sealed():
    with pytest.raises(LPNError, match='ONLY_SEALED_LPN_CAN_BE_PICKED'): pick_lpn(make())

def test_dispatch_requires_picked():
    l=make(); add_content(l, LPNContent(1,101,501,Decimal('20'),'PACK',Decimal('10'))); seal_lpn(l)
    with pytest.raises(LPNError, match='ONLY_PICKED_LPN_CAN_BE_DISPATCHED'): dispatch_lpn(l)

def test_move_changes_warehouse():
    l=make(); move_lpn(l, 9); assert l.warehouse_id == 9

def test_fefo_carton_order():
    a=make(); b=LicensePlate(2,10,'CARTON-0002',warehouse_id=5)
    for l,d in [(a,'2026-12-20'),(b,'2026-11-15')]:
        add_content(l,LPNContent(l.lpn_id,101,501,Decimal('1'),'PACK',Decimal('1'),d)); seal_lpn(l)
    assert [x.code for x in fefo_lpn_order([a,b])] == ['CARTON-0002','CARTON-0001']
