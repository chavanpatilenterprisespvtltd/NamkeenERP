import os
os.environ["DATABASE_URL"]="sqlite:///:memory:"

def test_v16_api_imports():
    from app.api_v16 import app
    assert app.version=='16.0'
    from app.db.models_v16 import OrderAllocation, RefreshReplayGuard
    assert OrderAllocation.__tablename__=='order_allocations'
    assert RefreshReplayGuard.__tablename__=='refresh_replay_guards'
