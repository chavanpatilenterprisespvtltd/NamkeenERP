from app.uom.barcode_v27 import BarcodeRegistry, BarcodeIdentity

def test_barcode_unique_and_resolvable():
    r=BarcodeRegistry(); b=BarcodeIdentity('8901234567890','EAN13','SKU',101,sku_id=101)
    r.register(b); assert r.resolve(b.barcode).sku_id==101

def test_barcode_cannot_be_assigned_twice():
    r=BarcodeRegistry(); b=BarcodeIdentity('INT-500G-01','INTERNAL','SKU',1,sku_id=1); r.register(b)
    try: r.register(BarcodeIdentity('INT-500G-01','INTERNAL','SKU',2,sku_id=2))
    except ValueError as e: assert str(e)=='BARCODE_ALREADY_ASSIGNED'
    else: raise AssertionError('expected duplicate barcode rejection')
