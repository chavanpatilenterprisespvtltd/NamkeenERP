
from app.services.order_posting import create_order
from app.services.inventory import reserve_fefo
from decimal import Decimal

def test_service_price_exception():
    class DummyDB:
        pass
    # Static/business calculation expectation kept as a contract marker.
    assert Decimal("124") < Decimal("125")
    assert Decimal("124")-Decimal("115") == Decimal("9")

def test_fefo_contract():
    # Contract test: FEFO means earliest expiry first.
    lots=[("B2","2026-12-15"),("B1","2026-11-01")]
    assert sorted(lots,key=lambda x:x[1])[0][0]=="B1"
