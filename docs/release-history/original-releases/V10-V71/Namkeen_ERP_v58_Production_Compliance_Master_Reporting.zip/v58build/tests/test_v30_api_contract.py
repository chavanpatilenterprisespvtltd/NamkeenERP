from app.v30.api import router

def test_router_exists():
    assert router.prefix == '/v30/warehouse'
    assert any(r.path.endswith('/putaway/suggest') for r in router.routes)
