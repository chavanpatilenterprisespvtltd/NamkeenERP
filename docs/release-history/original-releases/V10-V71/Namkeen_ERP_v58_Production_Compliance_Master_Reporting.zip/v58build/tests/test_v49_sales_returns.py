from decimal import Decimal
from app.v49.returns import *

def test_return_request_and_approval():
    r,line=create_return(1,20,100,reason=ReturnReason.DAMAGED,requested_qty_kg=Decimal('10'),invoice_line_id=8,sku_id=55,lpn_id=900)
    assert r.status==ReturnStatus.REQUESTED and line.lpn_id==900
    approve_return(r,'MANAGER','customer damage return approved')
    assert r.status==ReturnStatus.APPROVED

def test_unauthorized_return_approval_fails():
    r,_=create_return(2,20,100,reason=ReturnReason.QUALITY,requested_qty_kg=Decimal('4'),invoice_line_id=9,sku_id=56)
    try: approve_return(r,'SALESPERSON','x'); assert False
    except ValueError as e: assert str(e)=='APPROVER_NOT_AUTHORIZED'

def test_reverse_pickup_receive_and_qc_hold():
    r,_=create_return(3,20,101,reason=ReturnReason.TRANSIT_DAMAGE,requested_qty_kg=Decimal('6'),invoice_line_id=2,sku_id=57,lpn_id=901)
    approve_return(r,'MANAGEMENT','approved')
    assign_pickup(r,77)
    receive_return(r,reference='RET-77',scanned_qty_kg=Decimal('6'))
    move_to_qc_hold(r)
    assert r.status==ReturnStatus.QC_HOLD

def test_qc_cannot_bypass_quantity():
    x=ReturnQCResult(1,Disposition.DAMAGE,Decimal('4'),Decimal('1'),'damage','photo://1')
    try: validate_qc_result(x,Decimal('6')); assert False
    except ValueError as e: assert str(e)=='QC_QTY_MISMATCH'

def test_damage_requires_reason():
    x=ReturnQCResult(1,Disposition.DAMAGE,Decimal('0'),Decimal('2'),'','photo://1')
    try: validate_qc_result(x,Decimal('2')); assert False
    except ValueError as e: assert str(e)=='REASON_REQUIRED'

def test_disposition_and_credit_note_approval():
    r,_=create_return(4,20,102,reason=ReturnReason.EXPIRED,requested_qty_kg=Decimal('5'),invoice_line_id=3,sku_id=58)
    approve_return(r,'MANAGER','expired stock return')
    assign_pickup(r,80); receive_return(r,reference='RET-80',scanned_qty_kg=Decimal('5')); move_to_qc_hold(r)
    settlement=disposition_return(r,[ReturnQCResult(1,Disposition.EXPIRED,Decimal('0'),Decimal('5'),'expired evidence')],credit_note_amount=Decimal('700'))
    assert settlement.expired_kg==Decimal('0')
    # accepted quantity may still be zero for rejected disposition in this simplified contract
    assert r.credit_note_status==CreditNoteStatus.DRAFT
    approve_credit_note(r,'ACCOUNTS','credit note reviewed')
    assert r.credit_note_status==CreditNoteStatus.APPROVED

def test_post_requires_credit_note_approval():
    r,_=create_return(5,20,103,reason=ReturnReason.CUSTOMER_REJECTION,requested_qty_kg=Decimal('3'),invoice_line_id=4,sku_id=59)
    approve_return(r,'MANAGER','approved'); assign_pickup(r,81); receive_return(r,reference='RET-81',scanned_qty_kg=Decimal('3')); move_to_qc_hold(r)
    disposition_return(r,[ReturnQCResult(1,Disposition.SALEABLE,Decimal('3'),Decimal('0'),'qc passed')],credit_note_amount=Decimal('300'))
    try: post_return_settlement(r,inventory_action='REENTER_SALEABLE',credit_note_action='POST_APPROVED_CREDIT_NOTE'); assert False
    except ValueError as e: assert str(e)=='CREDIT_NOTE_NOT_APPROVED'

def test_post_after_credit_note_approval():
    r,_=create_return(6,20,104,reason=ReturnReason.WRONG_ITEM,requested_qty_kg=Decimal('2'),invoice_line_id=5,sku_id=60)
    approve_return(r,'MANAGEMENT','approved'); assign_pickup(r,82); receive_return(r,reference='RET-82',scanned_qty_kg=Decimal('2')); move_to_qc_hold(r)
    s=disposition_return(r,[ReturnQCResult(1,Disposition.SALEABLE,Decimal('2'),Decimal('0'),'qc saleable')],credit_note_amount=Decimal('200'))
    approve_credit_note(r,'ACCOUNTS','approved by accounts')
    post_return_settlement(r,inventory_action='REENTER_SALEABLE',credit_note_action='POST_APPROVED_CREDIT_NOTE')
    assert r.status==ReturnStatus.SETTLED and s.saleable_kg==Decimal('2')
