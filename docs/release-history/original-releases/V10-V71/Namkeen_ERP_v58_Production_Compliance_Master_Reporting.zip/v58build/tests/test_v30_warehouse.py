from app.v30.warehouse import *


def test_location_path_and_lpn_move():
    locs={
      1: Location(1,10,5,'A','Zone','ZONE'),
      2: Location(2,10,5,'R1','Rack','RACK',1),
      3: Location(3,10,5,'B01','Bin','BIN',2),
    }
    assert locs[3].path_key(locs)=='A/R1/B01'
    l=LPNNode(20,'CARTON-20')
    attach_lpn(l,locs[3],locs)
    assert l.location_id==3
    e=move_lpn(l,locs[2],locs)
    assert e.from_location_id==3 and l.location_id==2


def test_putaway_rule_specificity():
    rules=[
      PutawayRule(1,10,5,None,100,50,100),
      PutawayRule(2,10,5,501,None,60,100),
      PutawayRule(3,10,5,501,None,70,10),
    ]
    # lower priority wins when otherwise applicable; SKU-specific ties outrank generic
    assert choose_putaway_location(rules,sku_id=501,product_id=100,qty_kg=25).rule_id==3


def test_pick_route_and_lpn_source_guard():
    s=Location(1,10,5,'PICK','Pick','BIN',allow_picking=True)
    d=Location(2,10,5,'STAGE','Stage','STAGING')
    l=LPNNode(9,'CARTON-9',location_id=1)
    t=create_pick_task(task_id=1,organization_id=10,warehouse_id=5,source=s,destination=d,lpn=l,qty_kg=5,sequence_no=2)
    t2=create_pick_task(task_id=2,organization_id=10,warehouse_id=5,source=s,destination=d,qty_kg=3,sequence_no=1)
    assert [x.task_id for x in pick_route([t,t2])]==[2,1]
