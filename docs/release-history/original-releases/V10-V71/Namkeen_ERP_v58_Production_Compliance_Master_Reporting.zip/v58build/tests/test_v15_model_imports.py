def test_v15_imports():
    from app.db.models_v15 import UserDevice,UserSession,NotificationOutbox
    from app.db.integration_models import IntegrationRun
    assert UserDevice.__tablename__=='user_devices'
    assert UserSession.__tablename__=='user_sessions'
    assert NotificationOutbox.__tablename__=='notification_outbox'
    assert IntegrationRun.__tablename__=='integration_runs'
