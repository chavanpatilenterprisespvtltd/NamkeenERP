from decimal import Decimal
import pytest
from app.v55.qc_control import *
from app.v56.qc_integration import *

def make_pass():
    s = ProductSpecification('NAM',10,'v1','2026-01-01',None,(SpecificationLimit('TEMP',150,190,175,'C',ControlSeverity.CRITICAL), SpecificationLimit('TIME',3,8,5,'min',ControlSeverity.MAJOR)))
    x = QCInspection('I1',100,10,'FRY',s,SamplingPlan('S',2,2))
    x.record_measurement('TEMP',175); x.record_measurement('TIME',5); x.finalize()
    return x

def make_fail():
    s = ProductSpecification('NAM',10,'v1','2026-01-01',None,(SpecificationLimit('TEMP',150,190,175,'C',ControlSeverity.CRITICAL), SpecificationLimit('TIME',3,8,5,'min',ControlSeverity.MAJOR)))
    x = QCInspection('I1',100,10,'FRY',s,SamplingPlan('S',2,2))
    x.record_measurement('TEMP',195); x.record_measurement('TIME',5); x.finalize()
    return x

def test_pass_allows_completion_and_release():
    s=build_settlement(batch_id=100, inspections=[make_pass()], good_output_kg=950)
    assert s.can_complete_batch is True and s.outcome==Outcome.RELEASE
    assert_batch_can_complete(s)

def test_pass_without_output_is_blocked():
    with pytest.raises(IntegrationError, match='QC_PASS_REQUIRES_GOOD_OUTPUT'):
        build_settlement(batch_id=100, inspections=[make_pass()])

def test_fail_requires_rework_or_reject_path():
    s=build_settlement(batch_id=100, inspections=[make_fail()], reject_output_kg=20)
    assert s.can_complete_batch is False and s.outcome==Outcome.REJECT
    with pytest.raises(IntegrationError, match='QC_RELEASE_GATE_FAILED'): assert_batch_can_complete(s)

def test_fail_with_rework_creates_rework_action():
    s=build_settlement(batch_id=100, inspections=[make_fail()], rework_output_kg=10)
    assert s.outcome==Outcome.REWORK
    assert s.inventory_actions[0].action=='MOVE_TO_REWORK'

def test_reject_action_uses_quarantine():
    s=build_settlement(batch_id=100, inspections=[make_fail()], reject_output_kg=12)
    assert s.inventory_actions[0].warehouse_code=='QC_REJECT'

def test_compliance_link_is_created_for_every_settlement():
    s=build_settlement(batch_id=100, inspections=[make_pass()], good_output_kg=100)
    assert s.compliance_links[0].reference_id=='100'
    assert s.compliance_links[0].requirement_code=='FSMS_PROCESS_QC'

def test_critical_fail_requires_capa():
    s=build_settlement(batch_id=100, inspections=[make_fail()], reject_output_kg=1)
    assert s.requires_capa is True

def test_hold_never_completes_batch():
    x=make_pass(); x.apply_disposition(Disposition.HOLD, 9, reason='investigate')
    s=build_settlement(batch_id=100, inspections=[x], good_output_kg=100)
    assert s.outcome==Outcome.HOLD and not s.can_complete_batch

def test_negative_output_rejected():
    with pytest.raises(IntegrationError, match='NEGATIVE_OUTPUT_QTY'):
        build_settlement(batch_id=100, inspections=[make_pass()], good_output_kg=100, reject_output_kg=-1)

def test_inventory_actions_are_non_posting_intents():
    s=build_settlement(batch_id=100, inspections=[make_fail()], reject_output_kg=5)
    assert s.inventory_actions[0].action.startswith('MOVE_TO_')
