import json
from app.sync.domain_events import record_change

def test_payload_is_json_serializable():
    class Dummy:
        pass
    from unittest.mock import Mock
    class FakeDB:
        def execute(self, *args, **kwargs):
            class R:
                def scalar_one(self): return 0
            return R()
        def add(self,row): self.row=row
        def flush(self): pass
    db=FakeDB()
    row=record_change(db,org_id=1,aggregate_type='PAYMENT',aggregate_id='5',operation='UPDATE',event_name='VERIFIED',payload={'amount': 125, 'nested': {'ok': True}})
    assert json.loads(row.payload_json)['nested']['ok'] is True
