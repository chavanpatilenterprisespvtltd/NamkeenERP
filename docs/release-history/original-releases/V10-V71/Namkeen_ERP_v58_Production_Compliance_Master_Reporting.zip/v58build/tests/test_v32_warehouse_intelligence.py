from datetime import date, timedelta
from decimal import Decimal
from app.v32.dashboard import StockRow, ReorderPolicy, warehouse_kpis, replenishment_suggestions, fefo_available, pick_kpis, count_kpis

def test_warehouse_kpis_and_expiry():
    rows=[StockRow(1,10,1,Decimal('100'),Decimal('20'),date.today()+timedelta(days=5)), StockRow(1,10,2,Decimal('50'),Decimal('0'),date.today()-timedelta(days=1)), StockRow(1,11,3,Decimal('30'),Decimal('5'),date.today()+timedelta(days=20))]
    k=warehouse_kpis(rows,occupied_bins=3,bin_count=5,today=date.today())
    assert k.total_stock_kg==Decimal('180')
    assert k.available_stock_kg==Decimal('155')
    assert k.expired_kg==Decimal('50')
    assert k.expiring_7d_kg==Decimal('80')
    assert k.occupancy_pct==Decimal('60.00')

def test_replenishment_severity_and_quantity():
    rows=[StockRow(1,10,1,Decimal('30'),Decimal('5'))]
    policies=[ReorderPolicy(10,1,Decimal('20'),Decimal('40'),Decimal('100'))]
    out=replenishment_suggestions(rows,policies)
    assert out[0].severity=='REORDER'
    assert out[0].suggested_qty_kg==Decimal('75')
    rows2=[StockRow(1,10,1,Decimal('30'),Decimal('15'))]
    out2=replenishment_suggestions(rows2,policies)
    assert out2[0].severity=='CRITICAL'

def test_fefo_orders_expiry_then_lot():
    rows=[StockRow(1,10,2,Decimal('10'),Decimal('0'),date(2026,12,1)),StockRow(1,10,1,Decimal('8'),Decimal('0'),date(2026,11,1)),StockRow(1,10,3,Decimal('7'),Decimal('7'),date(2026,10,1))]
    r=fefo_available(rows,10,1)
    assert [x.lot_id for x in r]==[1,2]

def test_picking_and_count_kpis():
    p=pick_kpis([{'status':'OPEN'},{'status':'ASSIGNED'},{'status':'PICKED','picked_qty_kg':'25'},{'status':'PICKED','picked_qty_kg':'10','short_pick_reason':'DAMAGED'}])
    assert p.picked_tasks==2 and p.short_picks==1 and p.picked_qty_kg==Decimal('35')
    c=count_kpis([{'status':'OPEN','variance_kg':'1.5'},{'status':'PENDING_APPROVAL','variance_kg':'-2.0'},{'status':'APPROVED','variance_kg':'0.5'}])
    assert c.open_sessions==1 and c.pending_approval==1 and c.approved==1 and c.variance_kg==Decimal('0.0')
