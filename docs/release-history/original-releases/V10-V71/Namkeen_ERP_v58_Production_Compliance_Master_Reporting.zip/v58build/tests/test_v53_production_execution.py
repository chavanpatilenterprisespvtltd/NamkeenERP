from decimal import Decimal
import pytest
from app.v52_mrp import ProductionOrder, ProductionOrderStatus, MRPResult, MRPComponentRequirement
from app.v53.production_execution import *

def plan():
    return MRPResult(10, Decimal('100'), 'B1', (
        MRPComponentRequirement(100,'RM',Decimal('70'),Decimal('70'),Decimal('70')),
        MRPComponentRequirement(101,'PACKAGING',Decimal('10'),Decimal('10'),Decimal('10')),
    ))

def po():
    return ProductionOrder(1,1,2,10,'B1',Decimal('100'),'2026-09-20',ProductionOrderStatus.RELEASED,[],7,8)

def test_build_execution_requires_released_order():
    x=po(); x.status=ProductionOrderStatus.PENDING_APPROVAL
    with pytest.raises(ExecutionError, match='PRODUCTION_ORDER_NOT_RELEASED'):
        build_execution_from_plan(x,plan())

def test_reservation_requires_full_lot_coverage():
    ex=build_execution_from_plan(po(),plan())
    with pytest.raises(ExecutionError, match='MATERIAL_SHORTFALL:101'):
        reserve_allocations(ex,{100:[LotAllocation(100,11,'L1',Decimal('70'))]})

def test_reserve_then_issue_then_output_then_complete():
    ex=build_execution_from_plan(po(),plan())
    reserve_allocations(ex,{100:[LotAllocation(100,11,'L1',Decimal('70'))],101:[LotAllocation(101,12,'P1',Decimal('10'))]})
    assert ex.status==ExecutionStatus.MATERIALS_RESERVED
    issue_reserved_material(ex,{100:Decimal('68'),101:Decimal('10')})
    assert ex.status==ExecutionStatus.IN_PROGRESS
    record_output(ex,good_output_kg=Decimal('75'),reject_output_kg=Decimal('2'),wip_qty_kg=Decimal('1'))
    complete_execution(ex,batch_id=55)
    assert ex.status==ExecutionStatus.COMPLETED and ex.completed_batch_id==55

def test_issue_cannot_exceed_reservation():
    ex=build_execution_from_plan(po(),plan())
    reserve_allocations(ex,{100:[LotAllocation(100,11,'L1',Decimal('70'))],101:[LotAllocation(101,12,'P1',Decimal('10'))]})
    with pytest.raises(ExecutionError, match='ACTUAL_ISSUE_EXCEEDS_RESERVATION:100'):
        issue_reserved_material(ex,{100:Decimal('71'),101:Decimal('10')})

def test_output_cannot_exceed_actual_input():
    ex=build_execution_from_plan(po(),plan())
    reserve_allocations(ex,{100:[LotAllocation(100,11,'L1',Decimal('70'))],101:[LotAllocation(101,12,'P1',Decimal('10'))]})
    issue_reserved_material(ex)
    with pytest.raises(ExecutionError, match='OUTPUT_EXCEEDS_ACTUAL_INPUT'):
        record_output(ex,good_output_kg=Decimal('80'),reject_output_kg=Decimal('10'),wip_qty_kg=Decimal('1'))

def test_completion_yield():
    ex=build_execution_from_plan(po(),plan())
    reserve_allocations(ex,{100:[LotAllocation(100,11,'L1',Decimal('70'))],101:[LotAllocation(101,12,'P1',Decimal('10'))]})
    issue_reserved_material(ex)
    record_output(ex,good_output_kg=Decimal('72'),reject_output_kg=Decimal('4'))
    assert ex.completion_yield_pct()==Decimal('90.00')
