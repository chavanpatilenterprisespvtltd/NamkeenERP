from decimal import Decimal
import pytest
from app.v51.bom import BomComponent, BomComponentType, BomByproduct, BomVersion, calculate_requirements, compare_consumption, BomError


def sample_bom():
    return BomVersion(
        1, 10, 1, '2026.01', '2026-01-01', None, Decimal('90'),
        (
            BomComponent(101, BomComponentType.RM, Decimal('1.05'), Decimal('2'), Decimal('80')),
            BomComponent(102, BomComponentType.PACKAGING, Decimal('0.01'), Decimal('0'), Decimal('5')),
        ),
        (BomByproduct(201, Decimal('0.02'), Decimal('10')),)
    )


def test_versioned_bom_requirement_and_yield_input():
    plan = calculate_requirements(sample_bom(), Decimal('900'))
    assert plan.expected_input_kg == Decimal('1000.000000')
    assert plan.requirements[0].net_required_qty == Decimal('945.000000')
    assert plan.requirements[0].gross_issue_qty == Decimal('963.900000')
    assert plan.planned_material_cost == Decimal('77157.00')
    assert plan.byproduct_qty == ((201, Decimal('18.000000')) ,)


def test_unpriced_bom_returns_no_planned_cost():
    bom = BomVersion(2, 10, 1, '2026.02', '2026-02-01', None, Decimal('95'), (BomComponent(101, BomComponentType.RM, Decimal('1.0')),))
    assert calculate_requirements(bom, Decimal('100')).planned_material_cost is None


def test_consumption_variance_and_unknown_item_guard():
    plan = calculate_requirements(sample_bom(), Decimal('900'))
    v = compare_consumption(plan, [(101, Decimal('970')), (102, Decimal('9'))])
    assert v[0].variance_qty == Decimal('6.100000')
    assert v[0].variance_pct == Decimal('0.63')
    with pytest.raises(BomError, match='UNPLANNED_ITEM_CONSUMPTION'):
        compare_consumption(plan, [(999, Decimal('1'))])


def test_duplicate_component_rejected():
    with pytest.raises(BomError, match='DUPLICATE_BOM_COMPONENT'):
        BomVersion(1, 1, 1, 'x', '2026-01-01', None, Decimal('90'), (BomComponent(2, BomComponentType.RM, Decimal('1')), BomComponent(2, BomComponentType.RM, Decimal('1'))))


def test_scrap_and_yield_validation():
    with pytest.raises(BomError, match='INVALID_SCRAP_PCT'):
        BomComponent(2, BomComponentType.RM, Decimal('1'), Decimal('100'))
    with pytest.raises(BomError, match='INVALID_EXPECTED_YIELD'):
        BomVersion(1, 1, 1, 'x', '2026-01-01', None, Decimal('0'), (BomComponent(2, BomComponentType.RM, Decimal('1')),))
