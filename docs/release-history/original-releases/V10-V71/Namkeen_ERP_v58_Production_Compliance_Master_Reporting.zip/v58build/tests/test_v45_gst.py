from datetime import date
from decimal import Decimal
from app.v45.gst import *

def test_hsn_and_gstin_validation():
    assert normalize_hsn('07-13-10') == '071310'
    assert validate_gstin('27ABCDE1234F1Z5')
    assert not validate_gstin('BAD')

def test_intrastate_split_and_tax_total():
    lines=[GSTLine(1,'namkeen','19059090',Decimal('10'),Decimal('1000'),Decimal('18'))]
    ctx=TaxRuleContext('27',PartyTaxContext(None,'27',False,'27'),'B2C')
    r=calculate_gst(lines,ctx)
    assert r.cgst == Decimal('90.00') and r.sgst == Decimal('90.00')
    assert r.igst == Decimal('0.00') and r.invoice_total == Decimal('1180.00')

def test_interstate_and_export_use_igst():
    lines=[GSTLine(1,'namkeen','19059090',Decimal('1'),Decimal('500'),Decimal('18'))]
    ctx=TaxRuleContext('27',PartyTaxContext(None,'29',False,'29'),'B2C')
    r=calculate_gst(lines,ctx)
    assert r.igst == Decimal('90.00') and r.cgst == Decimal('0.00')
    exp=TaxRuleContext('27',PartyTaxContext(None,'27',False,'27'),'EXPORT')
    assert calculate_gst(lines,exp).igst == Decimal('90.00')

def test_invoice_validation_catches_hsn_and_gstin():
    errs=validate_invoice_requirements(doc_type='TAX_INVOICE',doc_no='INV-1',supplier_gstin='BAD',recipient_gstin='BAD',supplier_state='27',place_of_supply='Maharashtra',reverse_charge=False,supply_type='B2B',lines=[GSTLine(1,'x','123',Decimal('1'),Decimal('10'),Decimal('5'))])
    assert 'INVALID_SUPPLIER_GSTIN' in errs and 'INVALID_RECIPIENT_GSTIN' in errs and any(x.startswith('HSN:') for x in errs)

def test_gstr_summaries():
    docs=[
      ReturnDocument(1,1,'TAX_INVOICE',date(2026,9,1),Decimal('100'),Decimal('9'),Decimal('9'),Decimal('0'),Decimal('0'),'B2B','27ABCDE1234F1Z5','27','19059090',False),
      ReturnDocument(2,1,'TAX_INVOICE',date(2026,9,1),Decimal('50'),Decimal('0'),Decimal('0'),Decimal('9'),Decimal('0'),'B2C',None,'29','19059090',False),
      ReturnDocument(3,1,'CREDIT_NOTE',date(2026,9,1),Decimal('10'),Decimal('0'),Decimal('0'),Decimal('0'),Decimal('0'),'B2B','27ABCDE1234F1Z5','27','19059090',False),
      ReturnDocument(4,1,'TAX_INVOICE',date(2026,9,1),Decimal('20'),Decimal('0'),Decimal('0'),Decimal('3.6'),Decimal('0'),'B2B','27ABCDE1234F1Z5','27','19059090',True),
    ]
    a=build_gstr1_summary(docs); b=build_gstr3b_summary(docs)
    assert a.b2b_taxable==Decimal('100.00') and a.b2c_taxable==Decimal('50.00') and a.credit_notes_taxable==Decimal('10.00')
    assert b.inward_rcm_taxable==Decimal('20.00') and b.inward_rcm_tax==Decimal('3.60')

def test_reconciliation():
    r=reconcile_tax(reconciliation_id=1,period_key='2026-09',source='GST_PORTAL',local_taxable=1000,external_taxable=1000.50,local_tax=180,external_tax=180.40,tolerance=1)
    assert r.status=='MATCHED'
    r2=reconcile_tax(reconciliation_id=2,period_key='2026-09',source='GST_PORTAL',local_taxable=1000,external_taxable=1005,local_tax=180,external_tax=181,tolerance=1)
    assert r2.status=='MISMATCH'

def test_effective_tax_rule():
    r=TaxRateRule('GST',Decimal('18'),date(2026,1,1),date(2026,12,31))
    assert r.active_on(date(2026,9,4)) and not r.active_on(date(2027,1,1))

def test_reverse_charge_flag_is_preserved():
    lines=[GSTLine(1,'service','99859999',Decimal('1'),Decimal('100'),Decimal('18'))]
    ctx=TaxRuleContext('27',PartyTaxContext('29ABCDE1234F1Z5','29',True,'29'),'B2B',reverse_charge=True)
    r=calculate_gst(lines,ctx)
    assert r.igst==Decimal('18.00')
