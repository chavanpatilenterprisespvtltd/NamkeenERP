import os
os.environ['DATABASE_URL']='sqlite:///./v26_test.db'
from decimal import Decimal
from app.db.base import Base
import app.db.model_registry  # register all inherited tables for SQLite metadata
from app.db.session import engine, SessionLocal
from app.db.models import Organization, Entity, User, Product, PackSize, SKU, InventoryLot, InventoryLedger
from app.db.models_v24 import ProductionBatch
from app.v26.production_packing import issue_material, create_wip_output, create_packing_run, complete_packing, record_wastage
from app.auth.security import hash_password


def setup_module(_): Base.metadata.create_all(engine)

def seed(suffix):
    with SessionLocal() as db:
        o=Organization(id=260000+suffix*100,name=f'o{suffix}'); e=Entity(id=261000+suffix*100,organization_id=o.id,code=f'E{suffix}',legal_name=f'E{suffix}'); u=User(id=262000+suffix*100,organization_id=o.id,username=f'u{suffix}',password_hash=hash_password('pw'),role='FACTORY',active=True)
        p=Product(id=263000+suffix*100,organization_id=o.id,code=f'P{suffix}',name='Namkeen',active=True); ps=PackSize(id=264000+suffix*100,organization_id=o.id,name='1kg',net_weight_g=1000); sku=SKU(id=265000+suffix*100,organization_id=o.id,product_id=p.id,pack_size_id=ps.id,active=True)
        lot=InventoryLot(id=266000+suffix*100,organization_id=o.id,entity_id=e.id,warehouse_code='RM01',sku_id=sku.id,batch_no=f'RMLOT{suffix}',qty_available=100,qty_reserved=0)
        b=ProductionBatch(id=267000+suffix*100,organization_id=o.id,entity_id=e.id,batch_no=f'B{suffix}',product_id=p.id,planned_qty_kg=80,actual_qty_kg=0,status='PLANNED',created_by=u.id)
        db.add_all([o,e,u,p,ps,sku,lot,b]); db.commit(); return o.id,e.id,u.id,sku.id,lot.id,b.id

def test_issue_and_wip():
    ids=seed(1); org,ent,user,sku,lot,batch=ids
    with SessionLocal() as db:
        r=issue_material(db,org_id=org,entity_id=ent,batch_id=batch,warehouse_code='RM01',sku_id=sku,lot_id=lot,qty_kg=20,actor_id=user,actor_role='FACTORY')
        w=create_wip_output(db,org_id=org,entity_id=ent,batch_id=batch,warehouse_code='WIP01',good_qty_kg=20,actor_id=user,actor_role='FACTORY',wip_batch_no='WIP1')
        db.commit(); assert str(r.qty_kg)=='20.000' and str(w.qty_available_kg)=='20.000'
        lotrow=db.get(InventoryLot,lot); assert str(lotrow.qty_available)=='80.000'

def test_pack_complete_creates_fg_lot():
    org,ent,user,sku,lot,batch=seed(2)
    with SessionLocal() as db:
        issue_material(db,org_id=org,entity_id=ent,batch_id=batch,warehouse_code='RM01',sku_id=sku,lot_id=lot,qty_kg=30,actor_id=user,actor_role='FACTORY')
        w=create_wip_output(db,org_id=org,entity_id=ent,batch_id=batch,warehouse_code='WIP01',good_qty_kg=30,actor_id=user,actor_role='FACTORY',wip_batch_no='WIP2')
        p=create_packing_run(db,org_id=org,entity_id=ent,batch_id=batch,wip_lot_id=w.id,sku_id=sku,fg_warehouse_code='FG01',planned_qty_kg=25,packing_no='PK2',actor_id=user,actor_role='FACTORY')
        out=complete_packing(db,org_id=org,entity_id=ent,packing_run_id=p.id,good_qty_kg=24,pack_qty=24,reject_qty_kg=1,expiry_date=None,actor_id=user,actor_role='FACTORY',batch_no='FG2')
        db.commit(); assert out.lot_id and str(out.good_qty_kg)=='24.000'
        fg=db.get(InventoryLot,out.lot_id); assert fg.warehouse_code=='FG01' and str(fg.qty_available)=='24.000'

def test_wastage_requires_authorization_for_factory():
    org,ent,user,sku,lot,batch=seed(3)
    with SessionLocal() as db:
        try: record_wastage(db,org_id=org,entity_id=ent,batch_id=batch,packing_run_id=None,qty_kg=1,reason_code='DAMAGE',actor_id=user,actor_role='FACTORY')
        except PermissionError as ex: assert str(ex)=='WASTAGE_AUTHORIZATION_REQUIRED'
        else: raise AssertionError('expected authorization requirement')
