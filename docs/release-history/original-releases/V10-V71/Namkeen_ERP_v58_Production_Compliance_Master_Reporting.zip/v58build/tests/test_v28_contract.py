from pathlib import Path

def test_v28_migration_contains_idempotent_client_event_constraint():
    sql = Path('migrations/017_v28_barcode_warehouse_operations.sql').read_text()
    assert 'client_event_id' in sql
    assert 'uq_barcode_events_client_event_v28' in sql
    assert 'WHERE client_event_id IS NOT NULL' in sql

def test_v28_docs_cover_fefo_and_count_adjustment_boundary():
    text = Path('docs/V28_BARCODE_WAREHOUSE_OPERATIONS.md').read_text()
    assert 'FEFO' in text
    assert 'stock adjustment request' in text
