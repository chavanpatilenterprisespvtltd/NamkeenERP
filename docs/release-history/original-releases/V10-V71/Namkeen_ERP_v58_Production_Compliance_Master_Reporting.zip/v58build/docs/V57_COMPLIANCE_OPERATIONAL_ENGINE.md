# v57 — FSSAI / Maharashtra FDA Operational Compliance Engine

## Purpose
v57 turns the existing compliance data model into an operational, site-level workflow. It does not claim that software itself guarantees statutory compliance.

## Covered operational records
- licence/requirement references
- FSMS/GMP/GHP check tasks
- cleaning and sanitation
- pest control
- water testing
- calibration
- hygiene/food-safety training
- medical fitness
- supplier/COA evidence
- incoming/process/product testing
- frying-oil checks
- retention samples
- complaints and CAPA
- inspections and authority correspondence
- recall traceability

## Control model
1. Requirements are effective-dated and condition-aware.
2. Mandatory tasks generate due dates.
3. Evidence is attached to a task/entity using private storage references and hashes.
4. Findings create controlled dispositions and can require CAPA.
5. Site dashboard derives overdue, open-findings and evidence-gap status.
6. Inspection-ready is a derived readiness indicator, not a legal certification.
7. Operational compliance cannot mutate inventory, accounting or tax by itself.

## Integration bridges
- GRN -> incoming QC -> supplier/COA evidence
- production batch -> process QC -> compliance trace
- packing -> label/packaging review
- frying -> TPC/oil record
- complaint -> investigation -> CAPA
- recall -> affected lots/customers -> evidence
- inspection -> findings -> CAPA -> closure

## Data retention / audit
Evidence should be immutable by reference; replacements create new evidence versions. Status changes require actor/time/reason in the existing audit framework.
