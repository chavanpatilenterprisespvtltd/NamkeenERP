# Namkeen ERP v58 — Compliance Master Data + Inspection-Ready Reporting

## Purpose
v58 makes the compliance layer maintainable as versioned master data instead of embedding legal rules in code.

## Requirement classification
Every control is classified as one of:
- MANDATORY
- CONDITION_DEPENDENT
- INSPECTION_SUPPORTING
- INTERNAL_RECOMMENDED

Controls are effective-dated and linked to source references. A source reference is stored as data and must point to an official government domain.

## Document register
The site document register supports:
- document number/title/type
- issue and validity dates
- perpetual-validity flag
- storage reference and SHA-256 integrity hash
- expiry states: VALID / EXPIRING_SOON / EXPIRED / VALID_PERPETUAL / NO_EXPIRY_RECORDED / INACTIVE

Important: a perpetual-validity flag is data-driven. It must not be interpreted as an automatic legal conclusion for every document type.

## Inspection checklist
Inspection checklists are generated from active controls and can be exported or printed. Checklist failure produces an inspection finding rather than silently changing operational records.

## Statutory-register support
The export layer provides a stable tabular representation for management/inspection use. It is not a substitute for a regulator portal submission format unless that format is separately implemented and validated.

## Current official-source notes reviewed for v58
The 2026 FSSAI licensing FAQ states that from 1 April 2026 the revised turnover thresholds are Registration up to ₹1.5 crore, State Licence above ₹1.5 crore to ₹50 crore, and Central Licence above ₹50 crore. It also states that FSSAI registrations/licenses have perpetual validity unless suspended, cancelled or surrendered. The ERP therefore tracks licence status/conditions rather than assuming annual renewal. [FSSAI 2026 FAQ / order]

FSSAI's 18 March 2026 order implemented Food Recall functionality in FoSCoS, including recall actions by FBOs and enforcement authorities. The ERP therefore treats recall records and FoSCoS references as versioned operational data. [FSSAI 18 March 2026 order]

## Source policy
Do not hard-code changeable legal thresholds in business logic. Create a new effective-dated control/source record when a rule changes, preserve historical records, and require responsible compliance review before activation.
