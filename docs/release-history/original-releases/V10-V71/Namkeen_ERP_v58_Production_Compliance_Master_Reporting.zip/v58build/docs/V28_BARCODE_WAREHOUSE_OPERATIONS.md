# v28 Barcode Warehouse Operations

FEFO remains server-controlled for lot selection and outbound availability. Scanner workflows validate the organization, warehouse, SKU, lot, expiry and UOM conversion before posting warehouse actions.

Stock counting creates a **stock adjustment request**; physical counts never directly overwrite book stock. Approved variances are posted only through the authoritative inventory transaction service.
