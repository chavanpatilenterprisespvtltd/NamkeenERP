-- v58 seed template. Execute per organization/site; values are deliberately source-referenced and condition-aware.
-- Do not treat this file as legal advice or a complete statutory register.
-- Source references below are official-source records reviewed for the v58 design.

INSERT INTO compliance_source_reference
(organization_id, source_code, authority, title, official_url, issued_on, effective_from, notes)
VALUES
(0, 'FSSAI-LIC-2026', 'FSSAI', 'Food Safety and Standards (Licensing and Registration of Food Businesses) Amendment Regulations, 2026 — FAQ/order',
 'https://www.fssai.gov.in/upload/advisories/2026/03/69c6a23234827order_27032026.pdf', DATE '2026-03-27', DATE '2026-04-01',
 'Replace organization_id 0 with the target organization. Validate category/threshold applicability.'),
(0, 'FSSAI-RECALL-2026', 'FSSAI', 'Implementation of Food Recall functionality under FoSCoS',
 'https://www.fssai.gov.in/upload/advisories/2026/03/69bbb3b762053Order%20dt.%2018.03.2026_Implementation%20of%20Food%20Recall%20functionality%20in%20FoSCoS.pdf', DATE '2026-03-18', DATE '2026-03-18',
 'Recall controls should link to FoSCoS references where applicable.')
ON CONFLICT DO NOTHING;

-- Example control seed; duplicate/condition-specific controls should be added through UAT after responsible review.
