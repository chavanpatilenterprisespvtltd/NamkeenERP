from dataclasses import dataclass
from datetime import datetime, timezone
from queue import Queue, Empty

@dataclass(frozen=True)
class Notification:
    notification_type: str
    organization_id: int
    user_id: int|None
    role: str|None
    title: str
    body: str
    data: dict

class InMemoryNotificationOutbox:
    def __init__(self): self.q=Queue()
    def enqueue(self, n: Notification): self.q.put(n)
    def drain(self, handler, limit=100):
        count=0
        while count<limit:
            try: n=self.q.get_nowait()
            except Empty: break
            handler(n); count+=1
        return count
