from datetime import datetime, timezone
from app.db.models_v15 import NotificationOutbox
from app.db.models_v17 import NotificationDelivery

class DeliveryProvider:
    def send(self, channel: str, destination: str, message: str):
        raise NotImplementedError

class NullDeliveryProvider(DeliveryProvider):
    def send(self, channel, destination, message):
        return {"accepted": True, "provider": "null", "channel": channel}

def deliver_one(db, *, outbox_id, organization_id, destination, channel, provider=None):
    provider = provider or NullDeliveryProvider()
    out = db.query(NotificationOutbox).filter(NotificationOutbox.id==outbox_id, NotificationOutbox.organization_id==organization_id).one()
    d = db.query(NotificationDelivery).filter(NotificationDelivery.outbox_id==outbox_id, NotificationDelivery.channel==channel, NotificationDelivery.destination==destination).one_or_none()
    if not d:
        d = NotificationDelivery(organization_id=organization_id, outbox_id=outbox_id, channel=channel, destination=destination)
        db.add(d); db.flush()
    d.attempts += 1
    try:
        provider.send(channel, destination, out.payload_json)
        d.status = "DELIVERED"; d.delivered_at = datetime.now(timezone.utc); d.last_error = None
        return d
    except Exception as exc:
        d.status = "FAILED"; d.last_error = str(exc)
        return d
