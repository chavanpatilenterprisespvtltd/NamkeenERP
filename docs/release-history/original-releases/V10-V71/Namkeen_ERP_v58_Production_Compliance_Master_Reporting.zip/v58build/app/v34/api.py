from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .procurement import Supplier, POLine, SupplierQuotation, create_purchase_order, approve_purchase_order, record_partial_receipt, GRNReceipt, ProcurementError

app = FastAPI(title="Namkeen ERP API v34 — Supplier & Purchase Orders", version="34.0")

class SupplierIn(BaseModel):
    supplier_id:int; organization_id:int; legal_name:str; display_name:str; gstin:str|None=None; pan:str|None=None; state_code:str|None=None; payment_terms_days:int=0; status:str="ACTIVE"; contact_name:str|None=None; phone:str|None=None; email:str|None=None
class POLineIn(BaseModel):
    line_id:int; sku_id:int; ordered_qty_kg:Decimal; unit_price_per_kg:Decimal; expected_unit_price_per_kg:Decimal|None=None
class POIn(BaseModel):
    po_id:int; organization_id:int; entity_id:int; supplier:SupplierIn; warehouse_id:int; order_date:str; expected_date:str|None=None; lines:list[POLineIn]; created_by:int; approval_tolerance_kg:Decimal=0
class GRNIn(BaseModel):
    grn_id:int; po_id:int; supplier_id:int; receipt_date:str; line_quantities_kg:dict[int,Decimal]; accepted_line_quantities_kg:dict[int,Decimal]={}; rejected_line_quantities_kg:dict[int,Decimal]={}; actual_unit_prices:dict[int,Decimal]={}; qc_status:str="HOLD"; supplier_invoice_no:str|None=None

@app.get('/v34/health')
def health(): return {'version':'34.0','service':'supplier-purchase-orders'}

@app.post('/v34/purchase-orders')
def create_po(body:POIn):
    try:
        supplier=Supplier(**body.supplier.model_dump())
        lines=[POLine(**x.model_dump()) for x in body.lines]
        po=create_purchase_order(po_id=body.po_id,organization_id=body.organization_id,entity_id=body.entity_id,supplier=supplier,warehouse_id=body.warehouse_id,order_date=body.order_date,expected_date=body.expected_date,lines=lines,created_by=body.created_by,below_policy_tolerance=body.approval_tolerance_kg)
        return {'po':po.__dict__}
    except ProcurementError as e: raise HTTPException(status_code=400,detail=str(e))

@app.post('/v34/purchase-orders/{po_id}/approve')
def approve_po(po_id:int, approved_by:int):
    return {'po_id':po_id,'status':'APPROVED','approved_by':approved_by}

@app.post('/v34/purchase-orders/{po_id}/grn')
def grn(po_id:int, body:GRNIn):
    return {'po_id':po_id,'grn':body.model_dump()}
