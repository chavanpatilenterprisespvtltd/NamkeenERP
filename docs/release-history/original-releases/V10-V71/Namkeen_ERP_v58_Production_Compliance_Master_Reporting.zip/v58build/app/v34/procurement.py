from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional, Iterable

class ProcurementError(ValueError):
    pass

SUPPLIER_STATES = {"ACTIVE", "INACTIVE", "BLOCKED"}
PO_STATES = {"DRAFT", "PENDING_APPROVAL", "APPROVED", "PARTIALLY_RECEIVED", "FULLY_RECEIVED", "CANCELLED", "CLOSED"}

@dataclass(frozen=True)
class Supplier:
    supplier_id: int
    organization_id: int
    legal_name: str
    display_name: str
    gstin: Optional[str] = None
    pan: Optional[str] = None
    state_code: Optional[str] = None
    payment_terms_days: int = 0
    status: str = "ACTIVE"
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None

@dataclass(frozen=True)
class SupplierQuotation:
    quotation_id: int
    supplier_id: int
    sku_id: int
    quoted_price_per_kg: Decimal
    currency: str = "INR"
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None
    moq_kg: Decimal = Decimal("0")
    lead_time_days: int = 0
    order_multiple_kg: Decimal = Decimal("0")
    tax_code: Optional[str] = None
    attachment_id: Optional[str] = None
    status: str = "ACTIVE"

@dataclass(frozen=True)
class SupplierRateHistory:
    rate_id: int
    supplier_id: int
    sku_id: int
    rate_per_kg: Decimal
    effective_from: str
    effective_to: Optional[str] = None
    source: str = "PURCHASE"
    reference_id: Optional[int] = None

@dataclass(frozen=True)
class SupplierPerformance:
    supplier_id: int
    receipts: int
    on_time_receipts: int
    ordered_qty_kg: Decimal
    received_qty_kg: Decimal
    accepted_qty_kg: Decimal
    avg_price_per_kg: Decimal

    @property
    def on_time_pct(self) -> Decimal:
        if self.receipts <= 0:
            return Decimal("0")
        return (Decimal(self.on_time_receipts) * Decimal("100") / Decimal(self.receipts)).quantize(Decimal("0.01"))

    @property
    def fill_rate_pct(self) -> Decimal:
        if self.ordered_qty_kg <= 0:
            return Decimal("0")
        return (self.received_qty_kg * Decimal("100") / self.ordered_qty_kg).quantize(Decimal("0.01"))

    @property
    def acceptance_pct(self) -> Decimal:
        if self.received_qty_kg <= 0:
            return Decimal("0")
        return (self.accepted_qty_kg * Decimal("100") / self.received_qty_kg).quantize(Decimal("0.01"))

@dataclass
class POLine:
    line_id: int
    sku_id: int
    ordered_qty_kg: Decimal
    unit_price_per_kg: Decimal
    received_qty_kg: Decimal = Decimal("0")
    accepted_qty_kg: Decimal = Decimal("0")
    rejected_qty_kg: Decimal = Decimal("0")
    expected_unit_price_per_kg: Optional[Decimal] = None

    @property
    def open_qty_kg(self) -> Decimal:
        return max(Decimal("0"), self.ordered_qty_kg - self.received_qty_kg)

    @property
    def price_variance_per_kg(self) -> Decimal:
        if self.expected_unit_price_per_kg is None:
            return Decimal("0")
        return self.unit_price_per_kg - self.expected_unit_price_per_kg

@dataclass
class PurchaseOrder:
    po_id: int
    organization_id: int
    entity_id: int
    supplier_id: int
    warehouse_id: int
    order_date: str
    expected_date: Optional[str]
    status: str = "DRAFT"
    created_by: Optional[int] = None
    approved_by: Optional[int] = None
    approval_required: bool = True
    lines: list[POLine] = field(default_factory=list)
    receipt_references: list[int] = field(default_factory=list)
    rejection_reason: Optional[str] = None
    client_event_id: Optional[str] = None

    @property
    def ordered_total_kg(self) -> Decimal:
        return sum((x.ordered_qty_kg for x in self.lines), Decimal("0"))

    @property
    def received_total_kg(self) -> Decimal:
        return sum((x.received_qty_kg for x in self.lines), Decimal("0"))

@dataclass(frozen=True)
class GRNReceipt:
    grn_id: int
    po_id: int
    supplier_id: int
    receipt_date: str
    line_quantities_kg: dict[int, Decimal]
    accepted_line_quantities_kg: dict[int, Decimal]
    rejected_line_quantities_kg: dict[int, Decimal]
    actual_unit_prices: dict[int, Decimal]
    qc_status: str = "HOLD"
    supplier_invoice_no: Optional[str] = None
    client_event_id: Optional[str] = None


def validate_supplier(supplier: Supplier) -> None:
    if supplier.status not in SUPPLIER_STATES:
        raise ProcurementError("INVALID_SUPPLIER_STATUS")
    if supplier.organization_id <= 0 or supplier.supplier_id <= 0:
        raise ProcurementError("SUPPLIER_IDENTITY_REQUIRED")
    if supplier.status == "ACTIVE" and not supplier.legal_name.strip():
        raise ProcurementError("SUPPLIER_LEGAL_NAME_REQUIRED")
    if supplier.payment_terms_days < 0:
        raise ProcurementError("INVALID_PAYMENT_TERMS")


def choose_quotation(quotations: Iterable[SupplierQuotation], *, supplier_id: int, sku_id: int, qty_kg: Decimal) -> Optional[SupplierQuotation]:
    eligible = [q for q in quotations if q.status == "ACTIVE" and q.supplier_id == supplier_id and q.sku_id == sku_id and q.moq_kg <= qty_kg]
    if not eligible:
        eligible = [q for q in quotations if q.status == "ACTIVE" and q.supplier_id == supplier_id and q.sku_id == sku_id]
    return min(eligible, key=lambda q: (q.quoted_price_per_kg, q.lead_time_days, q.quotation_id), default=None)


def create_purchase_order(*, po_id: int, organization_id: int, entity_id: int, supplier: Supplier, warehouse_id: int,
                          order_date: str, expected_date: Optional[str], lines: list[POLine], created_by: int,
                          below_policy_tolerance: Decimal = Decimal("0"), client_event_id: Optional[str] = None) -> PurchaseOrder:
    validate_supplier(supplier)
    if supplier.status != "ACTIVE":
        raise ProcurementError("SUPPLIER_NOT_ACTIVE")
    if not lines:
        raise ProcurementError("PO_LINES_REQUIRED")
    if created_by <= 0:
        raise ProcurementError("CREATOR_REQUIRED")
    for line in lines:
        if line.ordered_qty_kg <= 0 or line.unit_price_per_kg < 0:
            raise ProcurementError("INVALID_PO_LINE")
        if line.expected_unit_price_per_kg is not None and line.unit_price_per_kg > line.expected_unit_price_per_kg + Decimal(below_policy_tolerance):
            raise ProcurementError("PRICE_VARIANCE_APPROVAL_REQUIRED")
    return PurchaseOrder(po_id, organization_id, entity_id, supplier.supplier_id, warehouse_id, order_date, expected_date,
                         status="PENDING_APPROVAL", created_by=created_by, approval_required=True,
                         lines=lines, client_event_id=client_event_id)


def approve_purchase_order(po: PurchaseOrder, approved_by: int) -> PurchaseOrder:
    if po.status != "PENDING_APPROVAL":
        raise ProcurementError("PO_NOT_PENDING_APPROVAL")
    if approved_by <= 0:
        raise ProcurementError("APPROVER_REQUIRED")
    if po.created_by == approved_by:
        raise ProcurementError("SELF_APPROVAL_NOT_ALLOWED")
    po.approved_by = approved_by
    po.status = "APPROVED"
    return po


def reject_purchase_order(po: PurchaseOrder, rejected_by: int, reason: str) -> PurchaseOrder:
    if po.status != "PENDING_APPROVAL":
        raise ProcurementError("PO_NOT_PENDING_APPROVAL")
    if rejected_by <= 0 or not reason.strip():
        raise ProcurementError("REJECTION_REASON_REQUIRED")
    po.status = "DRAFT"
    po.rejection_reason = reason.strip()
    return po


def record_partial_receipt(po: PurchaseOrder, receipt: GRNReceipt) -> PurchaseOrder:
    if po.status not in {"APPROVED", "PARTIALLY_RECEIVED"}:
        raise ProcurementError("PO_NOT_RECEIVABLE")
    if receipt.po_id != po.po_id or receipt.supplier_id != po.supplier_id:
        raise ProcurementError("GRN_PO_SUPPLIER_MISMATCH")
    by_line = {x.line_id: x for x in po.lines}
    for line_id, qty in receipt.line_quantities_kg.items():
        if qty < 0 or line_id not in by_line:
            raise ProcurementError("INVALID_RECEIPT_LINE")
        if qty > by_line[line_id].open_qty_kg:
            raise ProcurementError("RECEIPT_EXCEEDS_OPEN_PO")
        accepted = Decimal(receipt.accepted_line_quantities_kg.get(line_id, Decimal("0")))
        rejected = Decimal(receipt.rejected_line_quantities_kg.get(line_id, Decimal("0")))
        if accepted < 0 or rejected < 0 or accepted + rejected > qty:
            raise ProcurementError("INVALID_QC_RECEIPT_QTY")
        actual_price = receipt.actual_unit_prices.get(line_id)
        if actual_price is not None and actual_price < 0:
            raise ProcurementError("INVALID_ACTUAL_PRICE")
        by_line[line_id].received_qty_kg += qty
        by_line[line_id].accepted_qty_kg += accepted
        by_line[line_id].rejected_qty_kg += rejected
    po.receipt_references.append(receipt.grn_id)
    po.status = "FULLY_RECEIVED" if all(l.open_qty_kg == 0 for l in po.lines) else "PARTIALLY_RECEIVED"
    return po
