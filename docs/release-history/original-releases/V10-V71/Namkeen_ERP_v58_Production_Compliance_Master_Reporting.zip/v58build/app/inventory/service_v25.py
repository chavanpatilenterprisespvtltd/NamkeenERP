from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models_v25 import Warehouse, Supplier, Receipt, ReceiptLine, InventoryQc, StockTransfer, StockTransferLine, StockAdjustment, StockMovement, TraceabilityLink, BarcodeEvent
from app.db.models import InventoryLot
from app.sync.domain_integration_v20 import emit

MANAGER_ROLES={"MANAGER","MANAGEMENT","ADMIN","FACTORY_MANAGER","WAREHOUSE_MANAGER"}

def create_warehouse(db:Session, *, org_id:int, entity_id:int, code:str, name:str, warehouse_type:str="FG", warehouse_id:int|None=None):
    if db.execute(select(Warehouse).where(Warehouse.entity_id==entity_id, Warehouse.code==code)).scalar_one_or_none():
        raise ValueError("WAREHOUSE_CODE_EXISTS")
    row=Warehouse(id=warehouse_id,organization_id=org_id,entity_id=entity_id,code=code,name=name,warehouse_type=warehouse_type,active=True)
    db.add(row); db.flush(); return row

def create_supplier(db:Session, *, org_id:int, entity_id:int, code:str, name:str, gstin=None):
    if db.execute(select(Supplier).where(Supplier.organization_id==org_id, Supplier.code==code)).scalar_one_or_none():
        raise ValueError("SUPPLIER_CODE_EXISTS")
    row=Supplier(organization_id=org_id,entity_id=entity_id,code=code,name=name,gstin=gstin,active=True)
    db.add(row); db.flush(); return row

def create_receipt(db:Session, *, org_id:int, entity_id:int, warehouse_id:int, supplier_id:int|None, receipt_no:str, receipt_type:str, actor_id:int):
    if not db.get(Warehouse, warehouse_id): raise ValueError("WAREHOUSE_NOT_FOUND")
    if db.execute(select(Receipt).where(Receipt.entity_id==entity_id, Receipt.receipt_no==receipt_no)).scalar_one_or_none(): raise ValueError("RECEIPT_NO_EXISTS")
    row=Receipt(organization_id=org_id,entity_id=entity_id,warehouse_id=warehouse_id,supplier_id=supplier_id,receipt_no=receipt_no,receipt_type=receipt_type,status="RECEIVED",qc_status="PENDING",created_by=actor_id)
    db.add(row); db.flush(); emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="INVENTORY_RECEIPT",aggregate_id=row.id,event_name="INVENTORY_RECEIPT_CREATED",operation="CREATE",payload={"receipt_no":receipt_no,"receipt_type":receipt_type},actor_user_id=actor_id); return row

def add_receipt_line(db:Session, *, receipt:Receipt, sku_id:int, qty:Decimal, supplier_lot_no=None, expiry_date=None, unit_cost=None):
    if qty<=0: raise ValueError("RECEIPT_QTY_MUST_BE_POSITIVE")
    line=ReceiptLine(receipt_id=receipt.id,sku_id=sku_id,supplier_lot_no=supplier_lot_no,qty_received=qty,qty_accepted=0,qty_rejected=0,expiry_date=expiry_date,unit_cost=unit_cost,qc_result="PENDING")
    db.add(line); db.flush(); return line

def inspect_receipt(db:Session, *, org_id:int, entity_id:int, receipt_line_id:int, result:str, actor_id:int, remarks=None, coa_reference=None, evidence_file_id=None):
    if result not in {"PASS","FAIL","HOLD"}: raise ValueError("INVALID_QC_RESULT")
    line=db.get(ReceiptLine,receipt_line_id)
    if not line: raise ValueError("RECEIPT_LINE_NOT_FOUND")
    receipt=db.get(Receipt,line.receipt_id)
    if not receipt or receipt.organization_id!=org_id or receipt.entity_id!=entity_id: raise PermissionError("ENTITY_SCOPE_DENIED")
    if receipt.status=="POSTED": raise ValueError("RECEIPT_ALREADY_POSTED")
    line.qc_result=result
    line.qty_accepted=line.qty_received if result=="PASS" else Decimal("0")
    line.qty_rejected=line.qty_received if result=="FAIL" else Decimal("0")
    qc=InventoryQc(organization_id=org_id,entity_id=entity_id,receipt_id=receipt.id,receipt_line_id=line.id,result=result,remarks=remarks,coa_reference=coa_reference,evidence_file_id=evidence_file_id,checked_by=actor_id)
    db.add(qc); db.flush()
    receipt.qc_status=result
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="INVENTORY_RECEIPT",aggregate_id=receipt.id,event_name="INVENTORY_RECEIPT_QC_RECORDED",operation="UPDATE",payload={"line_id":line.id,"result":result},actor_user_id=actor_id)
    return qc

def post_accepted_receipt(db:Session, *, org_id:int, entity_id:int, receipt_line_id:int, actor_id:int):
    line=db.get(ReceiptLine,receipt_line_id); receipt=db.get(Receipt,line.receipt_id) if line else None
    if not line or not receipt: raise ValueError("RECEIPT_LINE_NOT_FOUND")
    if receipt.organization_id!=org_id or receipt.entity_id!=entity_id: raise PermissionError("ENTITY_SCOPE_DENIED")
    if line.qc_result!="PASS": raise ValueError("RECEIPT_QC_NOT_PASSED")
    if receipt.status=="POSTED": raise ValueError("RECEIPT_ALREADY_POSTED")
    wh=db.get(Warehouse,receipt.warehouse_id)
    lot_no=line.supplier_lot_no or f"GRN-{receipt.id}-{line.id}"
    lot=db.execute(select(InventoryLot).where(InventoryLot.entity_id==entity_id,InventoryLot.warehouse_code==wh.code,InventoryLot.sku_id==line.sku_id,InventoryLot.batch_no==lot_no)).scalar_one_or_none()
    if lot: lot.qty_available += line.qty_accepted
    else:
        lot=InventoryLot(organization_id=org_id,entity_id=entity_id,warehouse_code=wh.code,sku_id=line.sku_id,batch_no=lot_no,expiry_date=line.expiry_date,qty_available=line.qty_accepted,qty_reserved=0)
        db.add(lot); db.flush()
    db.add(StockMovement(organization_id=org_id,entity_id=entity_id,sku_id=line.sku_id,to_warehouse_id=wh.id,lot_id=lot.id,qty=line.qty_accepted,movement_type="RECEIPT",reference_type="RECEIPT_LINE",reference_id=str(line.id),created_by=actor_id))
    db.add(TraceabilityLink(organization_id=org_id,entity_id=entity_id,source_type="RECEIPT_LINE",source_id=str(line.id),target_type="INVENTORY_LOT",target_id=str(lot.id),relationship="CREATES_LOT"))
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="INVENTORY_LOT",aggregate_id=lot.id,event_name="INVENTORY_RECEIPT_POSTED",operation="CREATE",payload={"receipt_line_id":line.id,"qty":str(line.qty_accepted),"batch_no":lot.batch_no},actor_user_id=actor_id)
    receipt.status="POSTED"
    return lot

def request_adjustment(db:Session, *, org_id:int, entity_id:int, warehouse_id:int, sku_id:int, lot_id:int|None, qty_delta:Decimal, reason:str, actor_id:int, adjustment_id:int|None=None):
    if qty_delta==0: raise ValueError("ZERO_ADJUSTMENT")
    return_row=StockAdjustment(id=adjustment_id,organization_id=org_id,entity_id=entity_id,warehouse_id=warehouse_id,sku_id=sku_id,lot_id=lot_id,qty_delta=qty_delta,reason=reason,status="PENDING",requested_by=actor_id)
    db.add(return_row); db.flush(); return return_row

def decide_adjustment(db:Session, *, org_id:int, entity_id:int, adjustment_id:int, actor_id:int, actor_role:str, approve:bool):
    if actor_role not in MANAGER_ROLES: raise PermissionError("ADJUSTMENT_APPROVAL_REQUIRED")
    row=db.get(StockAdjustment,adjustment_id)
    if not row or row.organization_id!=org_id or row.entity_id!=entity_id: raise ValueError("ADJUSTMENT_NOT_FOUND")
    if row.status!="PENDING": raise ValueError("ADJUSTMENT_NOT_PENDING")
    if approve:
        if row.lot_id is None: raise ValueError("LOT_REQUIRED_FOR_POSTING")
        lot=db.get(InventoryLot,row.lot_id)
        if not lot or lot.entity_id!=entity_id: raise ValueError("LOT_NOT_FOUND")
        if lot.qty_available + row.qty_delta < 0: raise ValueError("NEGATIVE_STOCK_NOT_ALLOWED")
        lot.qty_available += row.qty_delta
        db.add(StockMovement(organization_id=org_id,entity_id=entity_id,sku_id=row.sku_id,lot_id=row.lot_id,from_warehouse_id=row.warehouse_id,qty=abs(row.qty_delta),movement_type="ADJUSTMENT",reference_type="ADJUSTMENT",reference_id=str(row.id),created_by=actor_id))
    row.status="APPROVED" if approve else "REJECTED"; row.approved_by=actor_id; row.approved_at=datetime.now(timezone.utc)
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="STOCK_ADJUSTMENT",aggregate_id=row.id,event_name="STOCK_ADJUSTMENT_DECIDED",operation="UPDATE",payload={"status":row.status,"qty_delta":str(row.qty_delta)},actor_user_id=actor_id)
    return row

def create_transfer(db:Session, *, org_id:int, entity_id:int, transfer_no:str, from_warehouse_id:int, to_warehouse_id:int, actor_id:int):
    if from_warehouse_id==to_warehouse_id: raise ValueError("TRANSFER_SAME_WAREHOUSE")
    if db.execute(select(StockTransfer).where(StockTransfer.entity_id==entity_id,StockTransfer.transfer_no==transfer_no)).scalar_one_or_none(): raise ValueError("TRANSFER_NO_EXISTS")
    row=StockTransfer(organization_id=org_id,entity_id=entity_id,transfer_no=transfer_no,from_warehouse_id=from_warehouse_id,to_warehouse_id=to_warehouse_id,status="DRAFT",created_by=actor_id)
    db.add(row); db.flush(); return row

def add_transfer_line(db:Session, *, transfer_id:int, sku_id:int, lot_id:int, qty:Decimal):
    if qty<=0: raise ValueError("TRANSFER_QTY_MUST_BE_POSITIVE")
    row=StockTransferLine(transfer_id=transfer_id,sku_id=sku_id,lot_id=lot_id,qty=qty); db.add(row); db.flush(); return row

def approve_transfer(db:Session, *, org_id:int, entity_id:int, transfer_id:int, actor_id:int, actor_role:str):
    if actor_role not in MANAGER_ROLES: raise PermissionError("TRANSFER_APPROVAL_REQUIRED")
    tr=db.get(StockTransfer,transfer_id)
    if not tr or tr.organization_id!=org_id or tr.entity_id!=entity_id: raise ValueError("TRANSFER_NOT_FOUND")
    if tr.status!="DRAFT": raise ValueError("TRANSFER_NOT_DRAFT")
    lines=db.execute(select(StockTransferLine).where(StockTransferLine.transfer_id==tr.id)).scalars().all()
    if not lines: raise ValueError("TRANSFER_HAS_NO_LINES")
    fw=db.get(Warehouse,tr.from_warehouse_id); tw=db.get(Warehouse,tr.to_warehouse_id)
    for ln in lines:
        lot=db.get(InventoryLot,ln.lot_id)
        if not lot or lot.entity_id!=entity_id or lot.warehouse_code!=fw.code: raise ValueError("TRANSFER_LOT_MISMATCH")
        if lot.qty_available < ln.qty: raise ValueError("INSUFFICIENT_STOCK")
        lot.qty_available -= ln.qty
        dest=db.execute(select(InventoryLot).where(InventoryLot.entity_id==entity_id,InventoryLot.warehouse_code==tw.code,InventoryLot.sku_id==ln.sku_id,InventoryLot.batch_no==lot.batch_no)).scalar_one_or_none()
        if dest: dest.qty_available += ln.qty
        else:
            dest=InventoryLot(organization_id=org_id,entity_id=entity_id,warehouse_code=tw.code,sku_id=ln.sku_id,batch_no=lot.batch_no,expiry_date=lot.expiry_date,qty_available=ln.qty,qty_reserved=0); db.add(dest); db.flush()
        db.add(StockMovement(organization_id=org_id,entity_id=entity_id,sku_id=ln.sku_id,from_warehouse_id=fw.id,to_warehouse_id=tw.id,lot_id=dest.id,qty=ln.qty,movement_type="TRANSFER",reference_type="STOCK_TRANSFER",reference_id=str(tr.id),created_by=actor_id))
        db.add(TraceabilityLink(organization_id=org_id,entity_id=entity_id,source_type="INVENTORY_LOT",source_id=str(ln.lot_id),target_type="INVENTORY_LOT",target_id=str(dest.id),relationship="TRANSFERRED"))
    tr.status="APPROVED"; tr.approved_by=actor_id; emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="STOCK_TRANSFER",aggregate_id=tr.id,event_name="STOCK_TRANSFER_POSTED",operation="UPDATE",payload={"status":tr.status},actor_user_id=actor_id); return tr

def record_barcode(db:Session, *, org_id:int, entity_id:int, barcode:str, event_type:str, reference_type:str, reference_id:str, actor_id:int):
    row=BarcodeEvent(organization_id=org_id,entity_id=entity_id,barcode=barcode,code_type="QR",event_type=event_type,reference_type=reference_type,reference_id=str(reference_id),captured_by=actor_id); db.add(row); db.flush(); return row
