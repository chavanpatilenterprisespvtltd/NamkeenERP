from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .gst import *

app = FastAPI(title='Namkeen ERP API v45 — GST Compliance & Tax', version='45.0')

class LineIn(BaseModel):
    sku_id:int; description:str; hsn:str; quantity:Decimal; taxable_amount:Decimal; tax_rate_pct:Decimal; cess_rate_pct:Decimal=0; free_quantity:Decimal=0
class GSTCalcIn(BaseModel):
    lines:list[LineIn]; supplier_state:str; recipient_state:str; supply_type:str='B2B'; reverse_charge:bool=False; igst_on_intra:bool=False
class InvoiceReq(BaseModel):
    doc_type:str; doc_no:str; supplier_gstin:str|None=None; recipient_gstin:str|None=None; supplier_state:str; place_of_supply:str; reverse_charge:bool=False; supply_type:str='B2B'; lines:list[LineIn]
class PeriodDoc(BaseModel):
    document_id:int; entity_id:int; doc_type:str; document_date:date; taxable_value:Decimal; cgst:Decimal; sgst:Decimal; igst:Decimal; cess:Decimal; supply_type:str; party_gstin:str|None=None; place_of_supply:str; hsn:str; reverse_charge:bool=False; status:str='POSTED'
class ReconReq(BaseModel):
    reconciliation_id:int; period_key:str; source:str; local_taxable:Decimal; external_taxable:Decimal; local_tax:Decimal; external_tax:Decimal; tolerance:Decimal=Decimal('1.00')

@app.get('/v45/health')
def health(): return {'version':'45.0','service':'gst-compliance-tax'}

@app.post('/v45/gst/calculate')
def calculate(body:GSTCalcIn):
    try:
        lines=[GSTLine(x.sku_id,x.description,x.hsn,x.quantity,x.taxable_amount,x.tax_rate_pct,x.cess_rate_pct,x.free_quantity) for x in body.lines]
        ctx=TaxRuleContext(body.supplier_state, PartyTaxContext(None,body.recipient_state,False,body.recipient_state), body.supply_type, body.reverse_charge, igst_on_intra=body.igst_on_intra)
        r=calculate_gst(lines,ctx)
        return {k:str(v) for k,v in r.__dict__.items()}
    except (GSTError, ValueError) as e: raise HTTPException(status_code=400, detail=str(e))

@app.post('/v45/gst/validate-invoice')
def validate_invoice(body:InvoiceReq):
    try:
        lines=[GSTLine(x.sku_id,x.description,x.hsn,x.quantity,x.taxable_amount,x.tax_rate_pct,x.cess_rate_pct,x.free_quantity) for x in body.lines]
        errs=validate_invoice_requirements(doc_type=body.doc_type,doc_no=body.doc_no,supplier_gstin=body.supplier_gstin,recipient_gstin=body.recipient_gstin,supplier_state=body.supplier_state,place_of_supply=body.place_of_supply,reverse_charge=body.reverse_charge,supply_type=body.supply_type,lines=lines)
        return {'valid':not errs,'errors':errs}
    except Exception as e: raise HTTPException(status_code=400, detail=str(e))

@app.post('/v45/gstr/summary')
def gstr_summary(body:list[PeriodDoc]):
    docs=[ReturnDocument(x.document_id,x.entity_id,x.doc_type,x.document_date,x.taxable_value,x.cgst,x.sgst,x.igst,x.cess,x.supply_type,x.party_gstin,x.place_of_supply,x.hsn,x.reverse_charge,x.status) for x in body]
    a=build_gstr1_summary(docs); b=build_gstr3b_summary(docs)
    return {'gstr1':a.__dict__ | {k:str(v) for k,v in a.__dict__.items()}, 'gstr3b':b.__dict__ | {k:str(v) for k,v in b.__dict__.items()}}

@app.post('/v45/gst/reconcile')
def reconcile(body:ReconReq):
    r=reconcile_tax(**body.model_dump())
    return r.__dict__ | {k:str(v) for k,v in r.__dict__.items()}
