from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional
import re

Q2 = Decimal('0.01')
Q3 = Decimal('0.001')

class GSTError(ValueError):
    pass

DOC_TYPES = {'TAX_INVOICE','BILL_OF_SUPPLY','CREDIT_NOTE','DEBIT_NOTE','DELIVERY_CHALLAN'}
SUPPLY_TYPES = {'B2B','B2C','EXPORT','SEZ','DEEMED_EXPORT','INTRA_ENTITY','OTHER'}
RCM_MODES = {'FORWARD','REVERSE'}
TAX_CODES = {'CGST','SGST','IGST','UTGST','CESS'}
PERIOD_STATES = {'OPEN','LOCKED','FILED','REOPEN_PENDING'}
RECON_STATES = {'UNMATCHED','MATCHED','MISMATCH','IGNORED','RESOLVED'}


def money(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)


def pct(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q3, rounding=ROUND_HALF_UP)


def normalize_hsn(v: str) -> str:
    h = re.sub(r'[^0-9A-Za-z]', '', (v or '').upper())
    if len(h) not in {4, 6, 8}:
        raise GSTError('HSN_LENGTH_MUST_BE_4_6_OR_8')
    return h


def validate_gstin(gstin: Optional[str]) -> bool:
    if not gstin:
        return False
    return bool(re.fullmatch(r'^[0-9A-Z]{15}$', gstin.upper()))


def state_code_from_gstin(gstin: Optional[str]) -> Optional[str]:
    return gstin[:2] if validate_gstin(gstin) else None

@dataclass(frozen=True)
class TaxRateRule:
    tax_code: str
    rate_pct: Decimal
    effective_from: date
    effective_to: Optional[date] = None
    taxable: bool = True
    rcm_allowed: bool = False

    def active_on(self, on_date: date) -> bool:
        return self.effective_from <= on_date and (self.effective_to is None or on_date <= self.effective_to)

@dataclass(frozen=True)
class ProductTaxProfile:
    tax_code: str
    hsn: str
    description: str
    rate_rule_key: str
    exempt: bool = False
    nil_rated: bool = False
    zero_rated: bool = False

    def validated_hsn(self) -> str:
        return normalize_hsn(self.hsn)

@dataclass(frozen=True)
class PartyTaxContext:
    gstin: Optional[str]
    state_code: str
    registered: bool
    place_of_supply_state: str
    recipient_type: str = 'BUSINESS'
    billing_state: Optional[str] = None
    shipping_state: Optional[str] = None

@dataclass(frozen=True)
class TaxRuleContext:
    supplier_state: str
    recipient: PartyTaxContext
    supply_type: str
    reverse_charge: bool = False
    e_commerce_operator: bool = False
    igst_on_intra: bool = False

@dataclass(frozen=True)
class GSTLine:
    sku_id: int
    description: str
    hsn: str
    quantity: Decimal
    taxable_amount: Decimal
    tax_rate_pct: Decimal
    cess_rate_pct: Decimal = Decimal('0')
    free_quantity: Decimal = Decimal('0')

@dataclass(frozen=True)
class GSTAmounts:
    taxable_value: Decimal
    cgst: Decimal
    sgst: Decimal
    igst: Decimal
    utgst: Decimal
    cess: Decimal
    total_tax: Decimal
    invoice_total: Decimal


def determine_tax_split(ctx: TaxRuleContext, tax_rate_pct: Decimal) -> str:
    if ctx.reverse_charge:
        # Tax incidence remains RCM; split is based on supply being intra/inter-state.
        pass
    if ctx.supply_type in {'EXPORT','SEZ'}:
        return 'IGST'
    if ctx.igst_on_intra:
        return 'IGST'
    if ctx.supplier_state == ctx.recipient.place_of_supply_state:
        return 'INTRA'
    return 'IGST'


def calculate_gst(lines: list[GSTLine], ctx: TaxRuleContext, *, ut_state=False) -> GSTAmounts:
    if ctx.supply_type not in SUPPLY_TYPES:
        raise GSTError('INVALID_SUPPLY_TYPE')
    if ctx.reverse_charge and ctx.supply_type == 'EXPORT':
        raise GSTError('RCM_EXPORT_COMBINATION_REQUIRES_REVIEW')
    taxable = Decimal('0'); cgst = sgst = igst = utgst = cess = Decimal('0')
    split = determine_tax_split(ctx, Decimal('0'))
    for line in lines:
        if line.quantity < 0 or line.taxable_amount < 0 or line.tax_rate_pct < 0 or line.cess_rate_pct < 0:
            raise GSTError('NEGATIVE_GST_LINE_VALUE')
        normalize_hsn(line.hsn)
        base = money(line.taxable_amount)
        taxable += base
        tax = money(base * line.tax_rate_pct / Decimal('100'))
        c = money(base * line.cess_rate_pct / Decimal('100'))
        cess += c
        if split == 'IGST':
            igst += tax
        elif split == 'INTRA':
            half = money(tax / Decimal('2'))
            cgst += half
            sgst += money(tax - half)
        else:
            igst += tax
    taxable = money(taxable); cgst = money(cgst); sgst = money(sgst); igst = money(igst); utgst = money(utgst); cess = money(cess)
    total = money(cgst + sgst + igst + utgst + cess)
    return GSTAmounts(taxable, cgst, sgst, igst, utgst, cess, total, money(taxable + total))


def validate_invoice_requirements(*, doc_type: str, doc_no: str, supplier_gstin: Optional[str], recipient_gstin: Optional[str],
                                  supplier_state: str, place_of_supply: str, reverse_charge: bool, supply_type: str,
                                  lines: list[GSTLine]) -> list[str]:
    errors=[]
    if doc_type not in DOC_TYPES: errors.append('INVALID_DOCUMENT_TYPE')
    if not doc_no.strip(): errors.append('DOCUMENT_NUMBER_REQUIRED')
    if supplier_gstin and not validate_gstin(supplier_gstin): errors.append('INVALID_SUPPLIER_GSTIN')
    if recipient_gstin and not validate_gstin(recipient_gstin): errors.append('INVALID_RECIPIENT_GSTIN')
    if not supplier_state.strip(): errors.append('SUPPLIER_STATE_REQUIRED')
    if not place_of_supply.strip(): errors.append('PLACE_OF_SUPPLY_REQUIRED')
    if supply_type not in SUPPLY_TYPES: errors.append('INVALID_SUPPLY_TYPE')
    if reverse_charge not in {True, False}: errors.append('INVALID_RCM_FLAG')
    if not lines: errors.append('INVOICE_LINES_REQUIRED')
    for line in lines:
        try: normalize_hsn(line.hsn)
        except GSTError as e: errors.append(f'HSN:{e}')
    return errors

@dataclass(frozen=True)
class TaxPeriod:
    period_key: str
    start_date: date
    end_date: date
    state: str = 'OPEN'

    def contains(self, d: date) -> bool:
        return self.start_date <= d <= self.end_date

@dataclass(frozen=True)
class ReturnDocument:
    document_id: int
    entity_id: int
    doc_type: str
    document_date: date
    taxable_value: Decimal
    cgst: Decimal
    sgst: Decimal
    igst: Decimal
    cess: Decimal
    supply_type: str
    party_gstin: Optional[str]
    place_of_supply: str
    hsn: str
    reverse_charge: bool
    status: str = 'POSTED'

@dataclass(frozen=True)
class GSTR1Summary:
    b2b_taxable: Decimal
    b2b_tax: Decimal
    b2c_taxable: Decimal
    b2c_tax: Decimal
    credit_notes_taxable: Decimal
    debit_notes_taxable: Decimal
    nil_exempt_zero: Decimal

@dataclass(frozen=True)
class GSTR3BSummary:
    outward_taxable: Decimal
    outward_tax: Decimal
    inward_rcm_taxable: Decimal
    inward_rcm_tax: Decimal
    credit_note_taxable: Decimal
    debit_note_taxable: Decimal


def build_gstr1_summary(docs: list[ReturnDocument]) -> GSTR1Summary:
    b2b_tax = b2b_taxable = b2c_tax = b2c_taxable = cn = dn = nil = Decimal('0')
    for d in docs:
        base=money(d.taxable_value); tax=money(d.cgst+d.sgst+d.igst+d.cess)
        if d.reverse_charge:
            continue
        if d.doc_type == 'CREDIT_NOTE': cn += base; continue
        if d.doc_type == 'DEBIT_NOTE': dn += base; continue
        if d.supply_type in {'B2B','SEZ','DEEMED_EXPORT'} and d.party_gstin:
            b2b_taxable += base; b2b_tax += tax
        elif d.supply_type == 'B2C':
            b2c_taxable += base; b2c_tax += tax
        elif d.taxable_value == 0: nil += base
    return GSTR1Summary(*map(money,[b2b_taxable,b2b_tax,b2c_taxable,b2c_tax,cn,dn,nil]))


def build_gstr3b_summary(docs: list[ReturnDocument]) -> GSTR3BSummary:
    outward_taxable=outward_tax=inward_rcm_taxable=inward_rcm_tax=cn=dn=Decimal('0')
    for d in docs:
        base=money(d.taxable_value); tax=money(d.cgst+d.sgst+d.igst+d.cess)
        if d.reverse_charge:
            inward_rcm_taxable += base; inward_rcm_tax += tax
        elif d.doc_type == 'CREDIT_NOTE': cn += base
        elif d.doc_type == 'DEBIT_NOTE': dn += base
        elif d.status == 'POSTED': outward_taxable += base; outward_tax += tax
    return GSTR3BSummary(*map(money,[outward_taxable,outward_tax,inward_rcm_taxable,inward_rcm_tax,cn,dn]))

@dataclass(frozen=True)
class TaxReconciliation:
    reconciliation_id: int
    period_key: str
    source: str
    local_taxable: Decimal
    external_taxable: Decimal
    local_tax: Decimal
    external_tax: Decimal
    taxable_difference: Decimal
    tax_difference: Decimal
    status: str


def reconcile_tax(*, reconciliation_id: int, period_key: str, source: str, local_taxable: Decimal, external_taxable: Decimal,
                  local_tax: Decimal, external_tax: Decimal, tolerance: Decimal = Decimal('1.00')) -> TaxReconciliation:
    td = money(local_taxable - external_taxable); taxd = money(local_tax - external_tax)
    status='MATCHED' if abs(td) <= tolerance and abs(taxd) <= tolerance else 'MISMATCH'
    return TaxReconciliation(reconciliation_id, period_key, source, money(local_taxable), money(external_taxable), money(local_tax), money(external_tax), td, taxd, status)
