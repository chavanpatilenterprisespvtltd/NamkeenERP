from __future__ import annotations
import json
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

SCHEMA = '''
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS outbox (
    client_event_id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    client_version INTEGER,
    payload_json TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'PENDING',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS inbox (
    change_id INTEGER PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    version INTEGER NOT NULL,
    operation TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    occurred_at TEXT
);
CREATE TABLE IF NOT EXISTS conflicts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_event_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    client_version INTEGER,
    server_version INTEGER,
    client_payload_json TEXT NOT NULL,
    server_payload_json TEXT,
    state TEXT NOT NULL DEFAULT 'OPEN',
    resolution TEXT,
    note TEXT,
    created_at TEXT NOT NULL
);
'''


def now(): return datetime.now(timezone.utc).isoformat()

@dataclass(frozen=True)
class OutboxItem:
    client_event_id: str
    device_id: str
    event_type: str
    entity_type: str
    entity_id: str
    client_version: int|None
    payload: dict
    attempts: int

class OfflineStore:
    def __init__(self, path=':memory:'):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)

    def close(self): self.db.close()

    def cursor(self) -> int:
        row = self.db.execute("SELECT value FROM sync_meta WHERE key='cursor'").fetchone()
        return int(row['value']) if row else 0

    def enqueue(self, *, device_id, event_type, entity_type, entity_id, payload, client_version=None, client_event_id=None):
        eid = client_event_id or str(uuid.uuid4())
        ts=now()
        self.db.execute("INSERT INTO outbox(client_event_id,device_id,event_type,entity_type,entity_id,client_version,payload_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                        (eid,device_id,event_type,entity_type,str(entity_id),client_version,json.dumps(payload,separators=(',',':')),ts,ts))
        self.db.commit(); return eid

    def pending(self, limit=100):
        rows=self.db.execute("SELECT * FROM outbox WHERE state IN ('PENDING','RETRY') ORDER BY created_at LIMIT ?",(limit,)).fetchall()
        return [OutboxItem(r['client_event_id'],r['device_id'],r['event_type'],r['entity_type'],r['entity_id'],r['client_version'],json.loads(r['payload_json']),r['attempts']) for r in rows]

    def mark_result(self, client_event_id, *, status, error=None):
        attempts=self.db.execute("SELECT attempts FROM outbox WHERE client_event_id=?",(client_event_id,)).fetchone()['attempts']
        state={'ACCEPTED':'ACKED','DUPLICATE':'ACKED','CONFLICT':'CONFLICT','REJECTED':'DEAD_LETTER'}.get(status,'RETRY')
        self.db.execute("UPDATE outbox SET state=?,attempts=?,last_error=?,updated_at=? WHERE client_event_id=?",(state,attempts+1,error,now(),client_event_id))
        self.db.commit()

    def apply_delta(self, delta: dict):
        cid=int(delta['change_id'])
        current=self.db.execute("SELECT change_id FROM inbox WHERE change_id=?",(cid,)).fetchone()
        if current: return False
        self.db.execute("INSERT INTO inbox(change_id,entity_type,entity_id,version,operation,payload_json,occurred_at) VALUES(?,?,?,?,?,?,?)",
                        (cid,delta['entity_type'],str(delta['entity_id']),delta['version'],delta['operation'],json.dumps(delta['payload'],separators=(',',':')),delta.get('occurred_at')))
        self.db.execute("INSERT INTO sync_meta(key,value) VALUES('cursor',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(str(cid),))
        self.db.commit(); return True

    def record_conflict(self, *, client_event_id, entity_type, entity_id, client_version, server_version, client_payload, server_payload):
        self.db.execute("INSERT INTO conflicts(client_event_id,entity_type,entity_id,client_version,server_version,client_payload_json,server_payload_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
                        (client_event_id,entity_type,str(entity_id),client_version,server_version,json.dumps(client_payload,separators=(',',':')),None if server_payload is None else json.dumps(server_payload,separators=(',',':')),now()))
        self.db.commit()
