from app.db.models_v17 import SalesReturn, SalesReturnLine, ReturnDisposition
from app.sync.domain_integration_v20 import emit

INITIATE_ROLES = {"SALESPERSON", "MANAGER", "MANAGEMENT", "SUPER_ADMIN"}
DISPOSE_ROLES = {"QC", "MANAGER", "MANAGEMENT", "SUPER_ADMIN"}
VALID_DISPOSITIONS = {"SALEABLE", "REPACK", "REWORK", "DAMAGE", "EXPIRED", "DISPOSE"}

def create_return(db, *, org_id, entity_id, customer_id, order_id, actor_id, return_no, reason_code, evidence_file_id, lines):
    r = SalesReturn(organization_id=org_id, entity_id=entity_id, customer_id=customer_id, order_id=order_id,
                    return_no=return_no, status="QC_HOLD", reason_code=reason_code, initiated_by=actor_id, evidence_file_id=evidence_file_id)
    db.add(r); db.flush()
    for x in lines:
        db.add(SalesReturnLine(return_id=r.id, sku_id=x["sku_id"], qty=x["qty"], batch_no=x.get("batch_no")))
    db.flush()
    emit(db, org_id=org_id, entity_id=entity_id, aggregate_type="SALES_RETURN", aggregate_id=r.return_no,
         event_name="SALES_RETURN_CREATED", operation="CREATE", actor_user_id=actor_id,
         payload={"id": r.id, "return_no": r.return_no, "status": r.status, "reason_code": reason_code})
    return r

def dispose_return(db, *, org_id, entity_id, actor_id, actor_role, return_id, disposition, reason=None):
    if actor_role not in DISPOSE_ROLES: raise PermissionError("Return disposition requires QC/manager authorization")
    if disposition not in VALID_DISPOSITIONS: raise ValueError("Invalid disposition")
    r = db.query(SalesReturn).filter(SalesReturn.id==return_id, SalesReturn.organization_id==org_id, SalesReturn.entity_id==entity_id).one()
    if r.status != "QC_HOLD": raise ValueError("Return is not awaiting QC disposition")
    d = ReturnDisposition(organization_id=org_id, entity_id=entity_id, return_id=return_id, disposition=disposition,
                          reason=reason, authorized_by=actor_id)
    r.status = disposition
    db.add(d); db.flush()
    emit(db, org_id=org_id, entity_id=entity_id, aggregate_type="SALES_RETURN", aggregate_id=r.return_no,
         event_name="SALES_RETURN_DISPOSITIONED", operation="UPDATE", actor_user_id=actor_id,
         payload={"id": r.id, "return_no": r.return_no, "status": r.status, "disposition": disposition, "reason": reason})
    return r
