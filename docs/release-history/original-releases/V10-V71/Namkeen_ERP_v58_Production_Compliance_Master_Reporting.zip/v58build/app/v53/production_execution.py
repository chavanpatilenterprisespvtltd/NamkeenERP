from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Iterable, Optional

Q6 = Decimal('0.000001')

def q(v):
    return Decimal(str(v)).quantize(Q6, rounding=ROUND_HALF_UP)

class ExecutionError(ValueError):
    pass

class ExecutionStatus(str, Enum):
    RELEASED='RELEASED'
    MATERIALS_RESERVED='MATERIALS_RESERVED'
    IN_PROGRESS='IN_PROGRESS'
    COMPLETED='COMPLETED'
    CANCELLED='CANCELLED'

@dataclass(frozen=True)
class LotAllocation:
    item_id: int
    lot_id: int
    batch_no: str
    qty_kg: Decimal
    expiry_date: Optional[str] = None

    def __post_init__(self):
        if min(self.item_id, self.lot_id) <= 0 or q(self.qty_kg) <= 0:
            raise ExecutionError('INVALID_LOT_ALLOCATION')

@dataclass(frozen=True)
class ExecutionRequirement:
    item_id: int
    item_type: str
    planned_qty_kg: Decimal
    issued_qty_kg: Decimal = Decimal('0')
    allocations: tuple[LotAllocation, ...] = ()

@dataclass
class ProductionExecution:
    production_order_id: int
    organization_id: int
    entity_id: int
    sku_id: int
    planned_output_kg: Decimal
    bom_version: str
    status: ExecutionStatus = ExecutionStatus.RELEASED
    requirements: list[ExecutionRequirement] = field(default_factory=list)
    actual_input_kg: Decimal = Decimal('0')
    good_output_kg: Decimal = Decimal('0')
    reject_output_kg: Decimal = Decimal('0')
    wip_qty_kg: Decimal = Decimal('0')
    completed_batch_id: Optional[int] = None

    def total_issued(self) -> Decimal:
        return q(sum((r.issued_qty_kg for r in self.requirements), Decimal('0')))

    def completion_yield_pct(self) -> Decimal:
        if self.actual_input_kg <= 0:
            return Decimal('0.00')
        return (self.good_output_kg / self.actual_input_kg * Decimal('100')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def build_execution_from_plan(production_order, plan) -> ProductionExecution:
    status_value = production_order.status.value if hasattr(production_order.status, 'value') else str(production_order.status)
    if status_value not in {'RELEASED', 'IN_PROGRESS'}:
        raise ExecutionError('PRODUCTION_ORDER_NOT_RELEASED')
    requirements = [
        ExecutionRequirement(r.item_id, r.item_type.value if hasattr(r.item_type, 'value') else str(r.item_type), q(r.gross_required_qty_kg))
        for r in plan.requirements
    ]
    return ProductionExecution(
        production_order_id=production_order.production_order_id,
        organization_id=production_order.organization_id,
        entity_id=production_order.entity_id,
        sku_id=production_order.sku_id,
        planned_output_kg=q(production_order.planned_good_output_kg),
        bom_version=production_order.bom_version,
        status=ExecutionStatus.RELEASED,
        requirements=requirements,
    )


def reserve_allocations(execution: ProductionExecution, allocations: dict[int, Iterable[LotAllocation]]) -> ProductionExecution:
    if execution.status not in {ExecutionStatus.RELEASED, ExecutionStatus.MATERIALS_RESERVED}:
        raise ExecutionError('EXECUTION_NOT_RESERVABLE')
    updated=[]
    for req in execution.requirements:
        lots=tuple(allocations.get(req.item_id, ()))
        total=q(sum((a.qty_kg for a in lots), Decimal('0')))
        if total > req.planned_qty_kg:
            raise ExecutionError(f'ALLOCATION_EXCEEDS_PLAN:{req.item_id}')
        if total < req.planned_qty_kg:
            raise ExecutionError(f'MATERIAL_SHORTFALL:{req.item_id}:{q(req.planned_qty_kg-total)}')
        updated.append(ExecutionRequirement(req.item_id, req.item_type, req.planned_qty_kg, total, lots))
    execution.requirements = updated
    execution.status = ExecutionStatus.MATERIALS_RESERVED
    return execution


def issue_reserved_material(execution: ProductionExecution, actual_issues: Optional[dict[int, Decimal]] = None) -> ProductionExecution:
    if execution.status != ExecutionStatus.MATERIALS_RESERVED:
        raise ExecutionError('MATERIALS_NOT_RESERVED')
    actual_issues = actual_issues or {r.item_id: r.issued_qty_kg for r in execution.requirements}
    updated=[]
    total_input=Decimal('0')
    for req in execution.requirements:
        a=q(actual_issues.get(req.item_id, Decimal('0')))
        if a <= 0:
            raise ExecutionError(f'ACTUAL_ISSUE_REQUIRED:{req.item_id}')
        if a > req.issued_qty_kg:
            # Actual physical issue cannot exceed the reserved quantity without an explicit extra-issue path.
            raise ExecutionError(f'ACTUAL_ISSUE_EXCEEDS_RESERVATION:{req.item_id}')
        updated.append(ExecutionRequirement(req.item_id, req.item_type, req.planned_qty_kg, a, req.allocations))
        total_input += a
    execution.requirements = updated
    execution.actual_input_kg = q(total_input)
    execution.status = ExecutionStatus.IN_PROGRESS
    return execution


def record_output(execution: ProductionExecution, *, good_output_kg, reject_output_kg=0, wip_qty_kg=0) -> ProductionExecution:
    if execution.status != ExecutionStatus.IN_PROGRESS:
        raise ExecutionError('EXECUTION_NOT_IN_PROGRESS')
    good=q(good_output_kg); reject=q(reject_output_kg); wip=q(wip_qty_kg)
    if good <= 0:
        raise ExecutionError('GOOD_OUTPUT_REQUIRED')
    if reject < 0 or wip < 0:
        raise ExecutionError('NEGATIVE_OUTPUT_QTY')
    if good + reject + wip > execution.actual_input_kg + Q6:
        raise ExecutionError('OUTPUT_EXCEEDS_ACTUAL_INPUT')
    execution.good_output_kg=good
    execution.reject_output_kg=reject
    execution.wip_qty_kg=wip
    return execution


def complete_execution(execution: ProductionExecution, *, batch_id: int) -> ProductionExecution:
    if execution.status != ExecutionStatus.IN_PROGRESS:
        raise ExecutionError('EXECUTION_NOT_IN_PROGRESS')
    if batch_id <= 0:
        raise ExecutionError('BATCH_ID_REQUIRED')
    if execution.good_output_kg <= 0:
        raise ExecutionError('GOOD_OUTPUT_REQUIRED')
    execution.completed_batch_id=batch_id
    execution.status=ExecutionStatus.COMPLETED
    return execution
