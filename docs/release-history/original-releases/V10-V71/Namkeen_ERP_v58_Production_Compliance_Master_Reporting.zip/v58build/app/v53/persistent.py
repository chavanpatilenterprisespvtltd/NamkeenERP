from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import select
from app.db.models import InventoryLot, InventoryLedger
from app.db.models_v24 import ProductionBatch
from app.db.models_v53 import ProductionExecutionRunV53, ProductionExecutionIssueV53
from app.sync.domain_integration_v20 import emit
from .production_execution import q

class PersistentExecutionError(ValueError):
    pass

ROLE_WRITE={'FACTORY','MANAGER','MANAGEMENT','SUPER_ADMIN'}

def start_execution(db, *, org_id, entity_id, production_order_id, sku_id, bom_version, planned_output_kg, actor_id, actor_role):
    if actor_role not in ROLE_WRITE: raise PermissionError('INSUFFICIENT_ROLE')
    po=db.execute(select(__import__('app.db.models_v53',fromlist=['ProductionExecutionRunV53']))).scalar_one_or_none() if False else None
    existing=db.execute(select(ProductionExecutionRunV53).where(ProductionExecutionRunV53.organization_id==org_id,ProductionExecutionRunV53.production_order_id==production_order_id)).scalar_one_or_none()
    if existing: raise PersistentExecutionError('EXECUTION_ALREADY_EXISTS')
    row=ProductionExecutionRunV53(organization_id=org_id,entity_id=entity_id,production_order_id=production_order_id,sku_id=sku_id,bom_version=bom_version,status='RELEASED',planned_output_kg=q(planned_output_kg))
    db.add(row); db.flush()
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_ORDER',aggregate_id=str(production_order_id),event_name='PRODUCTION_EXECUTION_CREATED',operation='CREATE',actor_user_id=actor_id,payload={'execution_id':row.id,'sku_id':sku_id,'planned_output_kg':str(row.planned_output_kg),'bom_version':bom_version})
    return row

def reserve_lot(db, *, execution_id, org_id, entity_id, item_id, lot_id, planned_qty_kg, issue_type, actor_id):
    ex=db.execute(select(ProductionExecutionRunV53).where(ProductionExecutionRunV53.id==execution_id,ProductionExecutionRunV53.organization_id==org_id,ProductionExecutionRunV53.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not ex: raise PersistentExecutionError('EXECUTION_NOT_FOUND')
    lot=db.execute(select(InventoryLot).where(InventoryLot.id==lot_id,InventoryLot.organization_id==org_id,InventoryLot.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not lot: raise PersistentExecutionError('LOT_NOT_FOUND')
    free=Decimal(lot.qty_available or 0)-Decimal(lot.qty_reserved or 0)
    qplan=q(planned_qty_kg)
    if qplan<=0: raise PersistentExecutionError('INVALID_PLANNED_QTY')
    if free < qplan: raise PersistentExecutionError('INSUFFICIENT_AVAILABLE_STOCK')
    lot.qty_reserved=Decimal(lot.qty_reserved or 0)+qplan
    row=ProductionExecutionIssueV53(organization_id=org_id,entity_id=entity_id,execution_id=ex.id,item_id=item_id,lot_id=lot_id,issue_type=issue_type,planned_qty_kg=qplan,reserved_qty_kg=qplan,actual_qty_kg=0)
    db.add(row); db.flush()
    ex.status='MATERIALS_RESERVED'
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_ORDER',aggregate_id=str(ex.production_order_id),event_name='PRODUCTION_MATERIAL_RESERVED',operation='UPDATE',actor_user_id=actor_id,payload={'execution_id':ex.id,'item_id':item_id,'lot_id':lot_id,'qty_kg':str(qplan)})
    return row

def issue_reserved(db, *, issue_id, org_id, entity_id, actual_qty_kg, actor_id):
    row=db.execute(select(ProductionExecutionIssueV53).where(ProductionExecutionIssueV53.id==issue_id,ProductionExecutionIssueV53.organization_id==org_id,ProductionExecutionIssueV53.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not row: raise PersistentExecutionError('ISSUE_NOT_FOUND')
    ex=db.execute(select(ProductionExecutionRunV53).where(ProductionExecutionRunV53.id==row.execution_id).with_for_update()).scalar_one()
    a=q(actual_qty_kg)
    if a<=0: raise PersistentExecutionError('ACTUAL_ISSUE_REQUIRED')
    if a>q(row.reserved_qty_kg): raise PersistentExecutionError('ACTUAL_ISSUE_EXCEEDS_RESERVATION')
    lot=db.execute(select(InventoryLot).where(InventoryLot.id==row.lot_id,InventoryLot.organization_id==org_id,InventoryLot.entity_id==entity_id).with_for_update()).scalar_one()
    if Decimal(lot.qty_available or 0)<a or Decimal(lot.qty_reserved or 0)<a: raise PersistentExecutionError('STOCK_OR_RESERVATION_ERROR')
    lot.qty_available=Decimal(lot.qty_available)-a
    lot.qty_reserved=Decimal(lot.qty_reserved)-a
    row.actual_qty_kg=a
    ex.actual_input_kg=q(Decimal(ex.actual_input_kg or 0)+a)
    ex.status='IN_PROGRESS'
    db.add(InventoryLedger(organization_id=org_id,entity_id=entity_id,lot_id=lot.id,txn_type='ISSUE_TO_PRODUCTION',qty=-a,reference_type='PRODUCTION_ORDER',reference_id=str(ex.production_order_id)))
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_ORDER',aggregate_id=str(ex.production_order_id),event_name='PRODUCTION_MATERIAL_ISSUED_V53',operation='UPDATE',actor_user_id=actor_id,payload={'execution_id':ex.id,'issue_id':row.id,'lot_id':row.lot_id,'qty_kg':str(a),'item_id':row.item_id})
    return row

def record_execution_output(db, *, execution_id, org_id, entity_id, batch_id, good_output_kg, reject_output_kg, wip_qty_kg, actor_id):
    ex=db.execute(select(ProductionExecutionRunV53).where(ProductionExecutionRunV53.id==execution_id,ProductionExecutionRunV53.organization_id==org_id,ProductionExecutionRunV53.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not ex: raise PersistentExecutionError('EXECUTION_NOT_FOUND')
    if ex.status!='IN_PROGRESS': raise PersistentExecutionError('EXECUTION_NOT_IN_PROGRESS')
    good=q(good_output_kg); rej=q(reject_output_kg); wip=q(wip_qty_kg)
    if good<=0: raise PersistentExecutionError('GOOD_OUTPUT_REQUIRED')
    if good+rej+wip>q(ex.actual_input_kg): raise PersistentExecutionError('OUTPUT_EXCEEDS_ACTUAL_INPUT')
    batch=db.execute(select(ProductionBatch).where(ProductionBatch.id==batch_id,ProductionBatch.organization_id==org_id,ProductionBatch.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not batch: raise PersistentExecutionError('BATCH_NOT_FOUND')
    batch.actual_qty_kg=good
    batch.status='COMPLETED'
    ex.good_output_kg=good; ex.reject_output_kg=rej; ex.wip_qty_kg=wip; ex.completed_batch_id=batch_id; ex.status='COMPLETED'; ex.completed_at=datetime.now(timezone.utc)
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_ORDER',aggregate_id=str(ex.production_order_id),event_name='PRODUCTION_OUTPUT_RECORDED',operation='UPDATE',actor_user_id=actor_id,payload={'execution_id':ex.id,'batch_id':batch_id,'good_output_kg':str(good),'reject_output_kg':str(rej),'wip_qty_kg':str(wip)})
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_ORDER',aggregate_id=str(ex.production_order_id),event_name='PRODUCTION_EXECUTION_COMPLETED',operation='UPDATE',actor_user_id=actor_id,payload={'execution_id':ex.id,'batch_id':batch_id})
    return ex
