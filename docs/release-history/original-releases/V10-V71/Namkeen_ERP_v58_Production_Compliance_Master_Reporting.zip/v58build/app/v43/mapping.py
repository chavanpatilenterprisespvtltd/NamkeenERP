from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime
import hashlib, json
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models_v43 import AccountingLedgerV43, VoucherMappingV43

SUPPORTED = {'SALES','PURCHASE','RECEIPT','PAYMENT','CREDIT_NOTE','DEBIT_NOTE'}

@dataclass(frozen=True)
class VoucherLine:
    ledger_code: str
    amount: Decimal
    side: str  # DEBIT/CREDIT
    narration: str

@dataclass(frozen=True)
class MappedVoucher:
    document_type: str
    voucher_type: str
    number: str
    date: str
    party_ledger_code: str | None
    lines: list[VoucherLine]


def _d(v): return Decimal(str(v or '0'))

def find_mapping(db: Session, *, organization_id:int, entity_id:int, document_type:str, at:datetime|None=None):
    if document_type not in SUPPORTED: raise ValueError('UNSUPPORTED_DOCUMENT_TYPE')
    q=select(VoucherMappingV43).where(VoucherMappingV43.organization_id==organization_id,
        VoucherMappingV43.entity_id==entity_id, VoucherMappingV43.document_type==document_type,
        VoucherMappingV43.is_active.is_(True))
    rows=db.execute(q.order_by(VoucherMappingV43.effective_from.desc().nulls_last())).scalars().all()
    at=at or datetime.utcnow()
    for r in rows:
        if r.effective_from and r.effective_from > at: continue
        if r.effective_to and r.effective_to <= at: continue
        return r
    return None

def map_document(db:Session, *, organization_id:int, entity_id:int, payload:dict) -> MappedVoucher:
    typ=str(payload.get('document_type') or payload.get('doc_type') or '').upper()
    if typ not in SUPPORTED: raise ValueError('UNSUPPORTED_DOCUMENT_TYPE')
    m=find_mapping(db,organization_id=organization_id,entity_id=entity_id,document_type=typ)
    if not m: raise ValueError('VOUCHER_MAPPING_NOT_FOUND')
    number=str(payload.get('number') or payload.get('invoice_no') or payload.get('document_no') or '')
    if not number: raise ValueError('DOCUMENT_NUMBER_REQUIRED')
    total=_d(payload.get('total') or payload.get('grand_total'))
    taxable=_d(payload.get('taxable') or payload.get('taxable_total'))
    cgst=_d(payload.get('cgst')); sgst=_d(payload.get('sgst')); igst=_d(payload.get('igst')); cess=_d(payload.get('cess'))
    party=payload.get('party_ledger_code') or m.party_ledger_code
    lines=[]
    def add(code, amount, side, narration):
        if amount and amount != 0:
            if not code: raise ValueError(f'LEDGER_MAPPING_MISSING:{narration}')
            lines.append(VoucherLine(code, amount, side, narration))
    if typ in {'SALES','DEBIT_NOTE'}:
        add(party,total,'DEBIT','Customer/party')
        add(m.base_ledger_code,taxable,'CREDIT','Sales / base')
        add(m.cgst_ledger_code,cgst,'CREDIT','CGST')
        add(m.sgst_ledger_code,sgst,'CREDIT','SGST')
        add(m.igst_ledger_code,igst,'CREDIT','IGST')
        add(m.cess_ledger_code,cess,'CREDIT','Cess')
    elif typ in {'PURCHASE','CREDIT_NOTE'}:
        add(m.base_ledger_code,taxable,'DEBIT','Purchase / base')
        add(m.cgst_ledger_code,cgst,'DEBIT','CGST input')
        add(m.sgst_ledger_code,sgst,'DEBIT','SGST input')
        add(m.igst_ledger_code,igst,'DEBIT','IGST input')
        add(m.cess_ledger_code,cess,'DEBIT','Cess input')
        add(party,total,'CREDIT','Supplier/party')
    elif typ=='RECEIPT':
        add(m.base_ledger_code,total,'DEBIT','Bank/Cash received')
        add(party,total,'CREDIT','Customer receivable')
    elif typ=='PAYMENT':
        add(party,total,'DEBIT','Supplier payable')
        add(m.base_ledger_code,total,'CREDIT','Bank/Cash paid')
    net=sum((l.amount if l.side=='DEBIT' else -l.amount) for l in lines)
    if abs(net) > Decimal('0.01'): raise ValueError(f'VOUCHER_UNBALANCED:{net}')
    return MappedVoucher(typ,m.voucher_type,number,str(payload.get('date') or payload.get('doc_date') or ''),party,lines)

def voucher_hash(mapped:MappedVoucher):
    raw=json.dumps({'type':mapped.document_type,'voucher_type':mapped.voucher_type,'number':mapped.number,'date':mapped.date,
                    'party':mapped.party_ledger_code,'lines':[{'ledger':l.ledger_code,'amount':str(l.amount),'side':l.side} for l in mapped.lines]},sort_keys=True,separators=(',',':'))
    return hashlib.sha256(raw.encode()).hexdigest()
