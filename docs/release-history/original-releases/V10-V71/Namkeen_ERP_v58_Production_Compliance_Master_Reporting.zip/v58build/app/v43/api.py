from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from decimal import Decimal
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.v43.mapping import map_document, voucher_hash
from app.v43.reconciliation import reconcile_voucher

app=FastAPI(title='Namkeen ERP v43 Accounting Mapping API')
class PreviewIn(BaseModel):
    organization_id:int; entity_id:int; payload:dict
class ReconIn(BaseModel):
    organization_id:int; entity_id:int; voucher_id:int; external_amount:Decimal|None=None; external_reference:str|None=None; tolerance:Decimal=Decimal('0.01')

@app.post('/preview')
def preview(x:PreviewIn, db:Session=Depends(get_db)):
    try:
        m=map_document(db,organization_id=x.organization_id,entity_id=x.entity_id,payload=x.payload)
    except ValueError as e: raise HTTPException(422,str(e))
    return {'document_type':m.document_type,'voucher_type':m.voucher_type,'number':m.number,'date':m.date,'party_ledger_code':m.party_ledger_code,'hash':voucher_hash(m),'lines':[{'ledger_code':l.ledger_code,'amount':str(l.amount),'side':l.side,'narration':l.narration} for l in m.lines]}

@app.post('/reconcile')
def reconcile(x:ReconIn, db:Session=Depends(get_db)):
    try: return reconcile_voucher(db,organization_id=x.organization_id,entity_id=x.entity_id,voucher_id=x.voucher_id,external_amount=x.external_amount,external_reference=x.external_reference,tolerance=x.tolerance)
    except Exception as e: raise HTTPException(422,str(e))
