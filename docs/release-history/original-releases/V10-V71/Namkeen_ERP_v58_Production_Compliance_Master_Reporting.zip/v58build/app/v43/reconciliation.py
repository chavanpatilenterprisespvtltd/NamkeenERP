from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models_v43 import AccountingVoucherV43, AccountingReconciliationV43

def compare_amounts(internal:Decimal, external:Decimal|None, tolerance:Decimal=Decimal('0.01')):
    if external is None: return 'UNMATCHED', None, 'EXTERNAL_AMOUNT_MISSING'
    diff=(Decimal(str(external))-Decimal(str(internal))).quantize(Decimal('0.01'))
    if abs(diff) <= tolerance: return 'MATCHED', diff, None
    return 'MISMATCH', diff, 'AMOUNT_MISMATCH'

def reconcile_voucher(db:Session, *, organization_id:int, entity_id:int, voucher_id:int, external_amount, external_reference:str|None, tolerance='0.01'):
    v=db.execute(select(AccountingVoucherV43).where(AccountingVoucherV43.organization_id==organization_id,AccountingVoucherV43.entity_id==entity_id,AccountingVoucherV43.id==voucher_id)).scalar_one()
    status,diff,reason=compare_amounts(Decimal(v.amount), None if external_amount is None else Decimal(str(external_amount)), Decimal(str(tolerance)))
    row=AccountingReconciliationV43(organization_id=organization_id,entity_id=entity_id,voucher_id=voucher_id,internal_amount=Decimal(v.amount),external_amount=None if external_amount is None else Decimal(str(external_amount)),amount_difference=diff,external_reference=external_reference,status=status,mismatch_reason=reason)
    db.add(row); db.flush();
    return {'status':status,'difference':str(diff) if diff is not None else None,'reason':reason}
