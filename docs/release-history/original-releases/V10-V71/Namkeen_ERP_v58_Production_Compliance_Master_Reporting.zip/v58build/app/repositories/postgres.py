from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal
import json, hashlib, secrets
from sqlalchemy import select, update
from sqlalchemy.orm import Session
from app.db.models import User, UserEntity, Customer, SalesOrder, SalesOrderLine, Payment, InventoryLot, InventoryLedger, ApprovalRequest, AuditEvent, SyncEvent
from app.db.models_v15 import UserDevice, UserSession, NotificationOutbox
from app.auth.security import verify_password, issue_access_token, issue_refresh_token

class RepositoryError(Exception): pass

class PostgresRepository:
    """Concrete PostgreSQL repository for auth, customer, order, payment, inventory and sync persistence."""
    def __init__(self, session_factory): self.session_factory = session_factory

    @contextmanager
    def tx(self):
        db = self.session_factory()
        try:
            with db.begin():
                yield db
        finally:
            db.close()

    def authenticate(self, username, password, device_id, device_name=None, platform=None, app_version=None):
        
        with self.tx() as db:
            user = db.execute(select(User).where(User.username==username, User.active==True)).scalar_one_or_none()
            if not user or not verify_password(password, user.password_hash): raise RepositoryError("INVALID_CREDENTIALS")
            entity_ids = [x.entity_id for x in db.execute(select(UserEntity).where(UserEntity.user_id==user.id)).scalars().all()]
            dev = db.execute(select(UserDevice).where(UserDevice.user_id==user.id, UserDevice.device_id==device_id).with_for_update()).scalar_one_or_none()
            now = datetime.now(timezone.utc)
            if dev is None:
                dev = UserDevice(user_id=user.id,device_id=device_id,device_name=device_name,platform=platform,app_version=app_version,active=True,last_seen_at=now)
                db.add(dev)
            else:
                if not dev.active: raise RepositoryError("DEVICE_REVOKED")
                dev.device_name=device_name or dev.device_name; dev.platform=platform or dev.platform; dev.app_version=app_version or dev.app_version; dev.last_seen_at=now
            sid = secrets.token_urlsafe(32)
            refresh_raw, refresh_hash = issue_refresh_token(user.id, sid)
            sess=UserSession(id=sid,user_id=user.id,device_id=device_id,refresh_token_hash=refresh_hash,expires_at=now.replace(microsecond=0)+__import__('datetime').timedelta(days=30))
            db.add(sess)
            access=issue_access_token(user.id,user.organization_id,user.role,entity_ids,sid)
            return {"access_token":access,"refresh_token":refresh_raw,"session_id":sid,"user_id":user.id,"organization_id":user.organization_id,"role":user.role,"entity_ids":entity_ids}

    def record_sync(self, org_id, device_id, client_event_id, event_type, entity_type, entity_id, client_version, payload):
        with self.tx() as db:
            existing=db.execute(select(SyncEvent).where(SyncEvent.organization_id==org_id, SyncEvent.client_event_id==client_event_id).with_for_update()).scalar_one_or_none()
            if existing: return {"status":existing.status,"duplicate":True,"server_version":existing.server_version}
            ev=SyncEvent(organization_id=org_id,device_id=device_id,client_event_id=client_event_id,event_type=event_type,payload_json=json.dumps(payload,separators=(",",":")),status="RECEIVED")
            ev.entity_type=entity_type; ev.entity_id=str(entity_id); ev.client_version=client_version
            db.add(ev); db.flush()
            return {"status":"RECEIVED","duplicate":False,"sync_event_id":ev.id}

    def set_sync_result(self, sync_event_id, status, server_version=None, conflict_code=None):
        with self.tx() as db:
            ev=db.execute(select(SyncEvent).where(SyncEvent.id==sync_event_id).with_for_update()).scalar_one()
            ev.status=status; ev.server_version=server_version; ev.conflict_code=conflict_code
            return {"status":ev.status,"server_version":ev.server_version,"conflict_code":ev.conflict_code}

    def queue_notification(self, org_id, title, body, notification_type="GENERAL", role=None, user_id=None, data=None):
        
        with self.tx() as db:
            n=NotificationOutbox(organization_id=org_id,user_id=user_id,role=role,notification_type=notification_type,title=title,body=body,data_json=json.dumps(data or {}),status="PENDING")
            db.add(n); db.flush(); return n.id

    def claim_notifications(self, limit=50):
        
        with self.tx() as db:
            rows=db.execute(select(NotificationOutbox).where(NotificationOutbox.status=="PENDING").order_by(NotificationOutbox.id).limit(limit).with_for_update(skip_locked=True)).scalars().all()
            out=[]
            for n in rows:
                n.status="PROCESSING"; n.attempts+=1
                out.append({"id":n.id,"organization_id":n.organization_id,"user_id":n.user_id,"role":n.role,"title":n.title,"body":n.body,"data":json.loads(n.data_json)})
            return out

    def complete_notification(self, notification_id, ok=True):
        
        with self.tx() as db:
            n=db.execute(select(NotificationOutbox).where(NotificationOutbox.id==notification_id).with_for_update()).scalar_one()
            n.status="SENT" if ok else "FAILED"; n.sent_at=datetime.now(timezone.utc) if ok else None

