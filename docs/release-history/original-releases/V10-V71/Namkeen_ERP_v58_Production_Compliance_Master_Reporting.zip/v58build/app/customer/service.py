import json
from app.db.models import Customer
from app.db.models_v17 import CustomerProfile, CustomerApproval
from app.sync.domain_integration_v20 import emit

MANAGER_ROLES = {"MANAGER", "MANAGEMENT", "SUPER_ADMIN"}

def onboard_customer(db, *, org_id, entity_id, actor_id, code, name, mobile=None, address=None, gps_lat=None, gps_lng=None,
                      shop_photo_file_id=None, aadhaar_file_id=None, pan_file_id=None, extra_docs=None):
    c = Customer(organization_id=org_id, entity_id=entity_id, code=code, name=name, mobile=mobile,
                 gps_lat=gps_lat, gps_lng=gps_lng, approval_status="PENDING", active=True)
    db.add(c); db.flush()
    profile = CustomerProfile(organization_id=org_id, customer_id=c.id, address_text=address,
                              shop_photo_file_id=shop_photo_file_id, aadhaar_file_id=aadhaar_file_id,
                              pan_file_id=pan_file_id, extra_docs_json=json.dumps(extra_docs or {}), captured_by=actor_id)
    approval = CustomerApproval(organization_id=org_id, customer_id=c.id, status="PENDING")
    db.add_all([profile, approval]); db.flush()
    emit(db, org_id=org_id, entity_id=entity_id, aggregate_type="CUSTOMER", aggregate_id=c.id,
         event_name="CUSTOMER_CREATED", operation="CREATE", actor_user_id=actor_id,
         payload={"id": c.id, "code": c.code, "name": c.name, "approval_status": c.approval_status})
    return c

def decide_customer(db, *, customer_id, org_id, actor, approve: bool, reason=None):
    if actor.role not in MANAGER_ROLES: raise PermissionError("Customer approval requires manager/management role")
    c = db.query(Customer).filter(Customer.id==customer_id, Customer.organization_id==org_id).one()
    a = db.query(CustomerApproval).filter(CustomerApproval.customer_id==customer_id, CustomerApproval.organization_id==org_id, CustomerApproval.status=="PENDING").one()
    a.status = "APPROVED" if approve else "REJECTED"; a.decided_by = actor.id; a.reason = reason
    c.approval_status = a.status
    db.flush()
    emit(db, org_id=org_id, entity_id=c.entity_id, aggregate_type="CUSTOMER", aggregate_id=c.id,
         event_name="CUSTOMER_APPROVED" if approve else "CUSTOMER_REJECTED", operation="UPDATE",
         actor_user_id=actor.id, payload={"id": c.id, "approval_status": c.approval_status, "reason": reason})
    return c
