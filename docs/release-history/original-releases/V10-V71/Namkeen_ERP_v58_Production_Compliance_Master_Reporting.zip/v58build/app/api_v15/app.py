from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from app.db.session import SessionLocal
from app.repositories.postgres import PostgresRepository, RepositoryError
from app.auth.security import decode_access, actor_from_claims

app=FastAPI(title="Namkeen ERP v15 — Production PostgreSQL Integration",version="15.0")
repo=PostgresRepository(SessionLocal)

class LoginIn(BaseModel):
    username:str; password:str; device_id:str=Field(min_length=2,max_length=120); device_name:str|None=None; platform:str|None=None; app_version:str|None=None
class SyncIn(BaseModel):
    client_event_id:str; event_type:str; entity_type:str; entity_id:str; client_version:int; payload:dict
class NotificationIn(BaseModel):
    organization_id:int; title:str; body:str; notification_type:str="GENERAL"; role:str|None=None; user_id:int|None=None; data:dict={}

def current_actor(auth:str|None):
    if not auth or not auth.lower().startswith("bearer "): raise HTTPException(401,"Bearer token required")
    try: return actor_from_claims(decode_access(auth.split(" ",1)[1]))
    except Exception: raise HTTPException(401,"Invalid or expired token")

@app.get("/health")
def health(): return {"status":"ok","version":"15.0"}

@app.post("/auth/login")
def login(body:LoginIn):
    try: return repo.authenticate(**body.model_dump())
    except RepositoryError as e: raise HTTPException(401,str(e))

@app.post("/sync/events")
def sync(body:SyncIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization)
    try:
        return repo.record_sync(a.organization_id,a.entity_ids[0] if a.entity_ids else "NONE",body.client_event_id,body.event_type,body.entity_type,body.entity_id,body.client_version,body.payload)
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/notifications")
def notification(body:NotificationIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization)
    if a.organization_id!=body.organization_id: raise HTTPException(403,"Organization scope violation")
    if a.role not in {"MANAGEMENT","MANAGER","SUPER_ADMIN"}: raise HTTPException(403,"Notification enqueue not permitted")
    try: return {"id":repo.queue_notification(**body.model_dump())}
    except Exception as e: raise HTTPException(400,str(e))
