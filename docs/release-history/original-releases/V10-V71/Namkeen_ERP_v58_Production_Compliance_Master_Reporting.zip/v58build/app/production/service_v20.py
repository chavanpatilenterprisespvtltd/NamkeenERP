from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import text
from app.sync.domain_integration_v20 import emit

PRODUCTION_EVENTS = {"PRODUCTION_BATCH_CREATED", "PRODUCTION_BATCH_QC_RECORDED"}

def record_batch_change(db, *, org_id:int, entity_id:int, batch_no:str, event_name:str, actor_user_id:int,
                        status:str, product_id:int|None=None, qty: str|None=None, payload:dict|None=None):
    """Event-only bridge for production modules not yet represented by a stable v19 model.
    The eventual production batch service should call this in the same transaction as its write.
    """
    if event_name not in PRODUCTION_EVENTS:
        raise ValueError("INVALID_PRODUCTION_EVENT")
    body={"batch_no":batch_no,"status":status}
    if product_id is not None: body["product_id"]=product_id
    if qty is not None: body["qty"]=str(qty)
    if payload: body.update(payload)
    return emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="PRODUCTION_BATCH",
                aggregate_id=batch_no,event_name=event_name,operation="CREATE" if event_name.endswith("CREATED") else "UPDATE",
                actor_user_id=actor_user_id,payload=body)
