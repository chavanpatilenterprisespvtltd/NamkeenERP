from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import date
from enum import Enum
from typing import Optional


class MasterDataError(ValueError):
    pass


class RequirementClass(str, Enum):
    MANDATORY = 'MANDATORY'
    CONDITION_DEPENDENT = 'CONDITION_DEPENDENT'
    INSPECTION_SUPPORTING = 'INSPECTION_SUPPORTING'
    INTERNAL_RECOMMENDED = 'INTERNAL_RECOMMENDED'


class RecordStatus(str, Enum):
    DRAFT = 'DRAFT'
    ACTIVE = 'ACTIVE'
    SUPERSEDED = 'SUPERSEDED'
    RETIRED = 'RETIRED'


@dataclass(frozen=True)
class SourceReference:
    source_id: str
    authority: str
    title: str
    official_url: str
    issued_on: Optional[date] = None
    effective_from: Optional[date] = None
    notes: str = ''


@dataclass(frozen=True)
class ComplianceControl:
    control_code: str
    title: str
    requirement_class: RequirementClass
    authority: str
    evidence_type: str
    frequency_days: Optional[int] = None
    condition: str = ''
    source_ids: tuple[str, ...] = ()
    active_from: date = field(default_factory=date.today)
    active_to: Optional[date] = None
    status: RecordStatus = RecordStatus.ACTIVE

    def active_on(self, on: date) -> bool:
        return (
            self.status == RecordStatus.ACTIVE
            and self.active_from <= on
            and (self.active_to is None or on <= self.active_to)
        )


@dataclass(frozen=True)
class SiteDocument:
    document_id: int
    site_id: int
    document_type: str
    title: str
    document_number: str = ''
    issued_on: Optional[date] = None
    valid_from: Optional[date] = None
    valid_to: Optional[date] = None
    perpetual: bool = False
    status: RecordStatus = RecordStatus.ACTIVE
    storage_ref: str = ''
    sha256: str = ''

    def is_current(self, as_of: date) -> bool:
        if self.status != RecordStatus.ACTIVE:
            return False
        if self.valid_from and as_of < self.valid_from:
            return False
        if self.perpetual:
            return True
        return self.valid_to is None or as_of <= self.valid_to


@dataclass(frozen=True)
class InspectionChecklistItem:
    checklist_code: str
    control_code: str
    prompt: str
    critical: bool = False
    expected_evidence: str = ''
    fail_action: str = 'FINDING'


@dataclass(frozen=True)
class RegisterExportRow:
    register_name: str
    record_id: int
    site_id: int
    occurred_on: date
    reference: str
    status: str
    evidence_ref: str = ''


def validate_source_url(url: str) -> bool:
    if not (url.startswith('https://') and ('.gov.in' in url or '.nic.in' in url)):
        raise MasterDataError('OFFICIAL_SOURCE_REQUIRED')
    return True


def validate_control(control: ComplianceControl, sources: dict[str, SourceReference]) -> None:
    if not control.control_code.strip() or not control.title.strip():
        raise MasterDataError('CONTROL_CODE_AND_TITLE_REQUIRED')
    if control.frequency_days is not None and control.frequency_days <= 0:
        raise MasterDataError('INVALID_FREQUENCY')
    if control.active_to and control.active_to < control.active_from:
        raise MasterDataError('INVALID_EFFECTIVE_RANGE')
    for source_id in control.source_ids:
        if source_id not in sources:
            raise MasterDataError('SOURCE_REFERENCE_NOT_FOUND')


def document_expiry_state(document: SiteDocument, as_of: date, warning_days: int = 30) -> str:
    if document.status != RecordStatus.ACTIVE:
        return 'INACTIVE'
    if document.perpetual:
        return 'VALID_PERPETUAL'
    if document.valid_to is None:
        return 'NO_EXPIRY_RECORDED'
    days = (document.valid_to - as_of).days
    if days < 0:
        return 'EXPIRED'
    if days <= warning_days:
        return 'EXPIRING_SOON'
    return 'VALID'


def build_document_register(documents: list[SiteDocument], as_of: date, warning_days: int = 30) -> list[dict]:
    rows = []
    for doc in documents:
        row = asdict(doc)
        row['expiry_state'] = document_expiry_state(doc, as_of, warning_days)
        rows.append(row)
    return rows


def build_inspection_checklist(
    controls: list[ComplianceControl],
    checklist_code: str,
    as_of: date,
    include_classes: tuple[RequirementClass, ...] = (
        RequirementClass.MANDATORY,
        RequirementClass.CONDITION_DEPENDENT,
        RequirementClass.INSPECTION_SUPPORTING,
    ),
) -> list[InspectionChecklistItem]:
    items: list[InspectionChecklistItem] = []
    for control in sorted(controls, key=lambda c: c.control_code):
        if control.active_on(as_of) and control.requirement_class in include_classes:
            items.append(
                InspectionChecklistItem(
                    checklist_code=checklist_code,
                    control_code=control.control_code,
                    prompt=control.title,
                    critical=(control.requirement_class == RequirementClass.MANDATORY and control.evidence_type == 'CRITICAL'),
                    expected_evidence=control.evidence_type,
                )
            )
    return items


def export_register(rows: list[RegisterExportRow], register_name: Optional[str] = None) -> list[dict]:
    selected = [r for r in rows if register_name is None or r.register_name == register_name]
    return [asdict(r) for r in sorted(selected, key=lambda r: (r.occurred_on, r.record_id))]


def management_score(
    *, mandatory_overdue: int,
    critical_findings: int,
    active_capa: int,
    expiring_documents: int,
    missing_evidence: int,
) -> dict:
    penalties = (mandatory_overdue * 15) + (critical_findings * 25) + (active_capa * 10) + (expiring_documents * 4) + (missing_evidence * 2)
    score = max(0, 100 - penalties)
    if score >= 90:
        band = 'GREEN'
    elif score >= 70:
        band = 'AMBER'
    else:
        band = 'RED'
    return {'score': score, 'band': band, 'penalty_points': penalties}
