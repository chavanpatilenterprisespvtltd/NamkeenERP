from __future__ import annotations
from datetime import date
from .compliance_master import *


def document_register(documents: list[SiteDocument], as_of: date | None = None, warning_days: int = 30) -> list[dict]:
    return build_document_register(documents, as_of or date.today(), warning_days)


def inspection_checklist(controls: list[ComplianceControl], checklist_code: str, as_of: date | None = None) -> list[dict]:
    return [asdict(x) for x in build_inspection_checklist(controls, checklist_code, as_of or date.today())]


def statutory_register(rows: list[RegisterExportRow], register_name: str | None = None) -> list[dict]:
    return export_register(rows, register_name)


def compliance_score(**kwargs) -> dict:
    return management_score(**kwargs)
