from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from decimal import Decimal

from .execution import *

router = APIRouter(prefix="/v31/warehouse", tags=["v31-warehouse-execution"])

_counts: dict[int, StockCountSession] = {}
_picks: dict[int, DirectedPick] = {}
_replenishments: dict[int, ReplenishmentTask] = {}
_movements: dict[int, BinMovement] = {}

class PutawayConfirmIn(BaseModel):
    task_id: int
    lpn_id: int
    destination_location_id: int
    destination_allow_putaway: bool = True
    destination_active: bool = True
    task_status: str = "OPEN"
    task_destination_location_id: int
    actor_user_id: int
    client_event_id: str | None = None

class PickStartIn(BaseModel):
    operator_id: int

class PickConfirmIn(BaseModel):
    actual_qty_kg: Decimal = Field(ge=0)
    expected_qty_kg: Decimal = Field(gt=0)
    confirmed_by: int
    picked_lpn_id: int | None = None
    client_event_id: str | None = None
    short_reason: str | None = None

class CountCreateIn(BaseModel):
    organization_id: int
    warehouse_id: int
    location_ids: list[int]
    reason: str = "CYCLE_COUNT"
    tolerance_kg: Decimal = Decimal("0")
    opened_by: int

class CountLineIn(BaseModel):
    location_id: int
    sku_id: int
    lot_id: int | None = None
    book_qty_kg: Decimal = Field(ge=0)
    barcode: str | None = None
    evidence_file_id: str | None = None

class CountRecordIn(BaseModel):
    counted_qty_kg: Decimal = Field(ge=0)

class CountActorIn(BaseModel):
    actor_id: int

class ReplenishIn(BaseModel):
    organization_id: int
    warehouse_id: int
    sku_id: int
    lot_id: int | None = None
    source_location_id: int
    destination_location_id: int
    qty_kg: Decimal = Field(gt=0)
    priority: int = 100
    reason: str = "MIN_STOCK"

class ReplenishConfirmIn(BaseModel):
    actor_id: int

class BinMoveIn(BaseModel):
    organization_id: int
    warehouse_id: int
    source_location_id: int
    destination_location_id: int
    qty_kg: Decimal = Field(gt=0)
    lpn_id: int | None = None
    sku_id: int | None = None
    lot_id: int | None = None
    created_by: int | None = None
    reason: str = "BIN_TRANSFER"

class BinMoveConfirmIn(BaseModel):
    actor_id: int
    client_event_id: str | None = None

@router.post("/putaway/confirm")
def putaway_confirm(req: PutawayConfirmIn):
    try:
        c = confirm_putaway(**req.model_dump(), confirmation_id=1)
        return c.__dict__
    except WarehouseExecutionError as e:
        raise HTTPException(409, str(e))

@router.post("/pick-tasks/{task_id}/start")
def pick_start(task_id: int, req: PickStartIn):
    task = _picks.setdefault(task_id, DirectedPick(task_id=task_id))
    try:
        return start_pick(task, req.operator_id).__dict__
    except WarehouseExecutionError as e:
        raise HTTPException(409, str(e))

@router.post("/pick-tasks/{task_id}/confirm")
def pick_confirm(task_id: int, req: PickConfirmIn):
    task = _picks.get(task_id)
    if task is None:
        raise HTTPException(404, "PICK_TASK_NOT_FOUND")
    try:
        return confirm_pick(task, **req.model_dump()).__dict__
    except WarehouseExecutionError as e:
        raise HTTPException(409, str(e))

@router.post("/counts")
def count_create(req: CountCreateIn):
    sid = max(_counts, default=0) + 1
    session = StockCountSession(sid, **req.model_dump())
    _counts[sid] = session
    try:
        begin_count(session)
    except WarehouseExecutionError as e:
        _counts.pop(sid, None)
        raise HTTPException(409, str(e))
    return {"id": sid, "status": session.status}

@router.post("/counts/{session_id}/lines")
def count_line(session_id: int, req: CountLineIn):
    session = _counts.get(session_id)
    if not session:
        raise HTTPException(404, "COUNT_SESSION_NOT_FOUND")
    lid = len(session.lines) + 1
    line = StockCountLine(lid, session_id, **req.model_dump())
    session.lines.append(line)
    return line.__dict__

@router.post("/counts/{session_id}/lines/{line_id}/record")
def count_record(session_id: int, line_id: int, req: CountRecordIn):
    session = _counts.get(session_id)
    if not session:
        raise HTTPException(404, "COUNT_SESSION_NOT_FOUND")
    line = next((x for x in session.lines if x.line_id == line_id), None)
    if not line:
        raise HTTPException(404, "COUNT_LINE_NOT_FOUND")
    try:
        line.record_count(req.counted_qty_kg)
        return line.__dict__
    except WarehouseExecutionError as e:
        raise HTTPException(409, str(e))

@router.post("/counts/{session_id}/submit")
def count_submit(session_id: int, req: CountActorIn):
    session = _counts.get(session_id)
    if not session: raise HTTPException(404, "COUNT_SESSION_NOT_FOUND")
    try: return submit_count(session, req.actor_id).__dict__
    except WarehouseExecutionError as e: raise HTTPException(409, str(e))

@router.post("/counts/{session_id}/approve")
def count_approve(session_id: int, req: CountActorIn):
    session = _counts.get(session_id)
    if not session: raise HTTPException(404, "COUNT_SESSION_NOT_FOUND")
    try: return approve_count(session, req.actor_id).__dict__
    except WarehouseExecutionError as e: raise HTTPException(409, str(e))

@router.post("/counts/{session_id}/post")
def count_post(session_id: int, req: CountActorIn):
    session = _counts.get(session_id)
    if not session: raise HTTPException(404, "COUNT_SESSION_NOT_FOUND")
    try: return post_count(session, req.actor_id).__dict__
    except WarehouseExecutionError as e: raise HTTPException(409, str(e))

@router.post("/replenishments")
def replenishment_create(req: ReplenishIn):
    tid = max(_replenishments, default=0) + 1
    try:
        task = make_replenishment(task_id=tid, **req.model_dump())
        _replenishments[tid] = task
        return task.__dict__
    except WarehouseExecutionError as e:
        raise HTTPException(409, str(e))

@router.post("/replenishments/{task_id}/assign")
def replenishment_assign(task_id: int, req: ReplenishConfirmIn):
    task = _replenishments.get(task_id)
    if not task: raise HTTPException(404, "REPLENISH_TASK_NOT_FOUND")
    if req.actor_id <= 0: raise HTTPException(409, "ASSIGNEE_REQUIRED")
    if task.status != "OPEN": raise HTTPException(409, "REPLENISH_NOT_OPEN")
    task.assigned_to = req.actor_id
    task.status = "ASSIGNED"
    return task.__dict__

@router.post("/replenishments/{task_id}/confirm")
def replenishment_confirm(task_id: int, req: ReplenishConfirmIn):
    task = _replenishments.get(task_id)
    if not task: raise HTTPException(404, "REPLENISH_TASK_NOT_FOUND")
    try: return confirm_replenishment(task, req.actor_id).__dict__
    except WarehouseExecutionError as e: raise HTTPException(409, str(e))

@router.post("/bin-movements")
def bin_move(req: BinMoveIn):
    mid = max(_movements, default=0) + 1
    try:
        m = create_bin_movement(movement_id=mid, **req.model_dump())
        _movements[mid] = m
        return m.__dict__
    except WarehouseExecutionError as e: raise HTTPException(409, str(e))

@router.post("/bin-movements/{movement_id}/confirm")
def bin_move_confirm(movement_id: int, req: BinMoveConfirmIn):
    m = _movements.get(movement_id)
    if not m: raise HTTPException(404, "BIN_MOVE_NOT_FOUND")
    try: return confirm_bin_movement(m, **req.model_dump()).__dict__
    except WarehouseExecutionError as e: raise HTTPException(409, str(e))
