from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

class WarehouseExecutionError(ValueError):
    pass

PICK_STATES = {"OPEN", "ASSIGNED", "PICKED", "SHORT", "CANCELLED"}
COUNT_STATES = {"OPEN", "COUNTING", "SUBMITTED", "APPROVED", "POSTED", "CANCELLED"}
REPLENISHMENT_STATES = {"OPEN", "ASSIGNED", "COMPLETED", "CANCELLED"}
MOVEMENT_STATES = {"OPEN", "CONFIRMED", "CANCELLED"}

@dataclass
class PutawayConfirmation:
    confirmation_id: int
    task_id: int
    lpn_id: int
    destination_location_id: int
    confirmed_by: int
    client_event_id: Optional[str] = None
    confirmed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

@dataclass
class DirectedPick:
    task_id: int
    operator_id: Optional[int] = None
    status: str = "OPEN"
    actual_qty_kg: Decimal = Decimal("0")
    short_reason: Optional[str] = None
    picked_lpn_id: Optional[int] = None
    confirmed_by: Optional[int] = None
    confirmed_at: Optional[datetime] = None
    client_event_id: Optional[str] = None

@dataclass
class StockCountLine:
    line_id: int
    count_session_id: int
    location_id: int
    sku_id: int
    lot_id: Optional[int]
    book_qty_kg: Decimal
    counted_qty_kg: Optional[Decimal] = None
    count_uom: str = "KG"
    barcode: Optional[str] = None
    evidence_file_id: Optional[str] = None
    variance_qty_kg: Optional[Decimal] = None
    recount_required: bool = False

    def record_count(self, counted_qty_kg: Decimal) -> None:
        counted = Decimal(counted_qty_kg)
        if counted < 0:
            raise WarehouseExecutionError("COUNT_QTY_NEGATIVE")
        self.counted_qty_kg = counted
        self.variance_qty_kg = counted - self.book_qty_kg

@dataclass
class StockCountSession:
    session_id: int
    organization_id: int
    warehouse_id: int
    location_ids: list[int]
    reason: str = "CYCLE_COUNT"
    tolerance_kg: Decimal = Decimal("0")
    status: str = "OPEN"
    opened_by: Optional[int] = None
    submitted_by: Optional[int] = None
    approved_by: Optional[int] = None
    posted_by: Optional[int] = None
    lines: list[StockCountLine] = field(default_factory=list)

@dataclass
class ReplenishmentTask:
    task_id: int
    organization_id: int
    warehouse_id: int
    sku_id: int
    lot_id: Optional[int]
    source_location_id: int
    destination_location_id: int
    qty_kg: Decimal
    status: str = "OPEN"
    reason: str = "MIN_STOCK"
    priority: int = 100
    assigned_to: Optional[int] = None
    confirmed_by: Optional[int] = None

@dataclass
class BinMovement:
    movement_id: int
    organization_id: int
    warehouse_id: int
    source_location_id: int
    destination_location_id: int
    lpn_id: Optional[int]
    sku_id: Optional[int]
    lot_id: Optional[int]
    qty_kg: Decimal
    status: str = "OPEN"
    reason: str = "BIN_TRANSFER"
    created_by: Optional[int] = None
    confirmed_by: Optional[int] = None
    client_event_id: Optional[str] = None


def confirm_putaway(*, task_id: int, lpn_id: int, destination_location_id: int, destination_allow_putaway: bool,
                    destination_active: bool, actor_user_id: int, task_status: str, task_destination_location_id: int,
                    client_event_id: Optional[str] = None, confirmation_id: int = 1) -> PutawayConfirmation:
    if task_status != "OPEN":
        raise WarehouseExecutionError("PUTAWAY_TASK_NOT_OPEN")
    if not destination_active:
        raise WarehouseExecutionError("DESTINATION_INACTIVE")
    if not destination_allow_putaway:
        raise WarehouseExecutionError("PUTAWAY_NOT_ALLOWED_AT_LOCATION")
    if destination_location_id != task_destination_location_id:
        raise WarehouseExecutionError("PUTAWAY_DESTINATION_MISMATCH")
    if lpn_id <= 0 or actor_user_id <= 0:
        raise WarehouseExecutionError("IDENTITY_REQUIRED")
    return PutawayConfirmation(confirmation_id, task_id, lpn_id, destination_location_id, actor_user_id, client_event_id)


def start_pick(task: DirectedPick, operator_id: int) -> DirectedPick:
    if task.status != "OPEN":
        raise WarehouseExecutionError("PICK_TASK_NOT_OPEN")
    if operator_id <= 0:
        raise WarehouseExecutionError("OPERATOR_REQUIRED")
    task.operator_id = operator_id
    task.status = "ASSIGNED"
    return task


def confirm_pick(task: DirectedPick, *, actual_qty_kg: Decimal, confirmed_by: int,
                 expected_qty_kg: Decimal, picked_lpn_id: Optional[int] = None,
                 client_event_id: Optional[str] = None, short_reason: Optional[str] = None) -> DirectedPick:
    if task.status not in {"ASSIGNED", "SHORT"}:
        raise WarehouseExecutionError("PICK_TASK_NOT_CONFIRMABLE")
    actual = Decimal(actual_qty_kg)
    expected = Decimal(expected_qty_kg)
    if actual < 0 or expected <= 0:
        raise WarehouseExecutionError("INVALID_PICK_QUANTITY")
    if confirmed_by <= 0:
        raise WarehouseExecutionError("CONFIRMER_REQUIRED")
    if actual > expected:
        raise WarehouseExecutionError("PICK_OVERAGE_NOT_ALLOWED")
    if actual < expected and not short_reason:
        raise WarehouseExecutionError("SHORT_REASON_REQUIRED")
    task.actual_qty_kg = actual
    task.confirmed_by = confirmed_by
    task.confirmed_at = datetime.now(timezone.utc)
    task.picked_lpn_id = picked_lpn_id
    task.client_event_id = client_event_id
    if actual < expected:
        task.status = "SHORT"
        task.short_reason = short_reason
    else:
        task.status = "PICKED"
        task.short_reason = None
    return task


def begin_count(session: StockCountSession) -> StockCountSession:
    if session.status != "OPEN":
        raise WarehouseExecutionError("COUNT_SESSION_NOT_OPEN")
    if not session.location_ids:
        raise WarehouseExecutionError("COUNT_LOCATIONS_REQUIRED")
    session.status = "COUNTING"
    return session


def submit_count(session: StockCountSession, submitted_by: int) -> StockCountSession:
    if session.status != "COUNTING":
        raise WarehouseExecutionError("COUNT_NOT_IN_COUNTING_STATE")
    if submitted_by <= 0:
        raise WarehouseExecutionError("SUBMITTER_REQUIRED")
    if not session.lines:
        raise WarehouseExecutionError("COUNT_LINES_REQUIRED")
    missing = [l.line_id for l in session.lines if l.counted_qty_kg is None]
    if missing:
        raise WarehouseExecutionError("COUNT_LINES_UNCOUNTED")
    session.submitted_by = submitted_by
    session.status = "SUBMITTED"
    return session


def approve_count(session: StockCountSession, approved_by: int) -> StockCountSession:
    if session.status != "SUBMITTED":
        raise WarehouseExecutionError("COUNT_NOT_SUBMITTED")
    if approved_by <= 0:
        raise WarehouseExecutionError("APPROVER_REQUIRED")
    session.approved_by = approved_by
    session.status = "APPROVED"
    return session


def post_count(session: StockCountSession, posted_by: int) -> StockCountSession:
    if session.status != "APPROVED":
        raise WarehouseExecutionError("COUNT_NOT_APPROVED")
    if posted_by <= 0:
        raise WarehouseExecutionError("POSTER_REQUIRED")
    session.posted_by = posted_by
    session.status = "POSTED"
    return session


def variance_exceeds_tolerance(line: StockCountLine, tolerance_kg: Decimal) -> bool:
    if line.variance_qty_kg is None:
        raise WarehouseExecutionError("COUNT_NOT_RECORDED")
    return abs(line.variance_qty_kg) > Decimal(tolerance_kg)


def make_replenishment(*, task_id: int, organization_id: int, warehouse_id: int, sku_id: int,
                       lot_id: Optional[int], source_location_id: int, destination_location_id: int,
                       qty_kg: Decimal, priority: int = 100, reason: str = "MIN_STOCK") -> ReplenishmentTask:
    qty = Decimal(qty_kg)
    if qty <= 0:
        raise WarehouseExecutionError("REPLENISH_QTY_MUST_BE_POSITIVE")
    if source_location_id == destination_location_id:
        raise WarehouseExecutionError("REPLENISH_SOURCE_DESTINATION_SAME")
    return ReplenishmentTask(task_id, organization_id, warehouse_id, sku_id, lot_id,
                             source_location_id, destination_location_id, qty, priority=priority, reason=reason)


def confirm_replenishment(task: ReplenishmentTask, actor_id: int) -> ReplenishmentTask:
    if task.status != "ASSIGNED":
        raise WarehouseExecutionError("REPLENISH_NOT_ASSIGNED")
    if actor_id <= 0:
        raise WarehouseExecutionError("CONFIRMER_REQUIRED")
    task.confirmed_by = actor_id
    task.status = "COMPLETED"
    return task


def create_bin_movement(*, movement_id: int, organization_id: int, warehouse_id: int,
                        source_location_id: int, destination_location_id: int,
                        qty_kg: Decimal, lpn_id: Optional[int] = None,
                        sku_id: Optional[int] = None, lot_id: Optional[int] = None,
                        created_by: Optional[int] = None, reason: str = "BIN_TRANSFER") -> BinMovement:
    qty = Decimal(qty_kg)
    if qty <= 0:
        raise WarehouseExecutionError("BIN_MOVE_QTY_MUST_BE_POSITIVE")
    if source_location_id == destination_location_id:
        raise WarehouseExecutionError("BIN_MOVE_SOURCE_DESTINATION_SAME")
    return BinMovement(movement_id, organization_id, warehouse_id, source_location_id,
                       destination_location_id, lpn_id, sku_id, lot_id, qty,
                       created_by=created_by, reason=reason)


def confirm_bin_movement(movement: BinMovement, *, actor_id: int, client_event_id: Optional[str] = None) -> BinMovement:
    if movement.status != "OPEN":
        raise WarehouseExecutionError("BIN_MOVE_NOT_OPEN")
    if actor_id <= 0:
        raise WarehouseExecutionError("CONFIRMER_REQUIRED")
    movement.confirmed_by = actor_id
    movement.client_event_id = client_event_id or movement.client_event_id
    movement.status = "CONFIRMED"
    return movement
