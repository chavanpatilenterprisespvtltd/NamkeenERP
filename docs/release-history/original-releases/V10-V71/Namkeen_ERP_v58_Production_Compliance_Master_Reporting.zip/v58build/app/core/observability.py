import logging, uuid
from contextvars import ContextVar

request_id_ctx: ContextVar[str] = ContextVar("request_id", default="-")
log=logging.getLogger("namkeen_erp")

def new_request_id() -> str:
    rid=uuid.uuid4().hex
    request_id_ctx.set(rid)
    return rid

def log_event(message: str, **fields):
    log.info(message, extra={"request_id":request_id_ctx.get(), **fields})
