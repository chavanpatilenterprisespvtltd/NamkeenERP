from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.db.models_v43 import AccountingReconciliationV43, AccountingVoucherV43
from app.db.models_v44 import PartyLedgerLinkV44, LedgerSyncJobV44, AccountingReconciliationActionV44

def dashboard(db:Session, *, organization_id:int, entity_id:int):
    def count(model, status=None):
        q=select(func.count()).select_from(model).where(model.organization_id==organization_id,model.entity_id==entity_id)
        if status is not None: q=q.where(model.status==status)
        return int(db.execute(q).scalar() or 0)
    return {
      'ledger_links': {s:count(PartyLedgerLinkV44,s) for s in ('PENDING','SYNCED','ERROR')},
      'ledger_sync_jobs': {s:count(LedgerSyncJobV44,s) for s in ('PENDING','PROCESSING','POSTED','DEAD_LETTER')},
      'reconciliations': {s:count(AccountingReconciliationV43,s) for s in ('UNMATCHED','MATCHED','MISMATCH')},
      'reconciliation_actions_pending': count(AccountingReconciliationActionV44,'PENDING'),
      'vouchers': {s:count(AccountingVoucherV43,s) for s in ('DRAFT','POSTED','ERROR')}
    }
