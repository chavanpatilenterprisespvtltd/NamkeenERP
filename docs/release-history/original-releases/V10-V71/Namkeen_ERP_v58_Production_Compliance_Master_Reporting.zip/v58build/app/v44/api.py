from decimal import Decimal
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.v44.master_sync import ensure_party_link, validate_party_exists, mark_synced
from app.v44.dashboard import dashboard
from app.v44.reconciliation_actions import request_action, approve_action
app=FastAPI(title='Namkeen ERP v44 Accounting Masters & Reconciliation API')
class PartyLinkIn(BaseModel): organization_id:int; entity_id:int; party_type:str; party_id:int; ledger_code:str; external_name:str|None=None
class SyncIn(BaseModel): link_id:int; external_name:str|None=None
class ActionIn(BaseModel): organization_id:int; entity_id:int; reconciliation_id:int; action:str; reason:str; requested_by:int
class ApproveIn(BaseModel): organization_id:int; entity_id:int; approved_by:int; apply:bool=False
@app.post('/party-ledger/link')
def link(x:PartyLinkIn,db:Session=Depends(get_db)):
    try:
        validate_party_exists(db,organization_id=x.organization_id,entity_id=x.entity_id,party_type=x.party_type,party_id=x.party_id)
        return ensure_party_link(db,organization_id=x.organization_id,entity_id=x.entity_id,party_type=x.party_type,party_id=x.party_id,ledger_code=x.ledger_code,external_name=x.external_name)
    except ValueError as e: raise HTTPException(422,str(e))
@app.post('/party-ledger/synced')
def synced(x:SyncIn,db:Session=Depends(get_db)):
    try:return mark_synced(db,link_id=x.link_id,external_name=x.external_name)
    except Exception as e: raise HTTPException(422,str(e))
@app.get('/dashboard')
def dash(organization_id:int,entity_id:int,db:Session=Depends(get_db)): return dashboard(db,organization_id=organization_id,entity_id=entity_id)
@app.post('/reconciliation/action')
def action(x:ActionIn,db:Session=Depends(get_db)):
    try:return request_action(db,organization_id=x.organization_id,entity_id=x.entity_id,reconciliation_id=x.reconciliation_id,action=x.action,reason=x.reason,requested_by=x.requested_by)
    except ValueError as e: raise HTTPException(422,str(e))
@app.post('/reconciliation/action/{action_id}/approve')
def approve(action_id:int,x:ApproveIn,db:Session=Depends(get_db)):
    try:return approve_action(db,organization_id=x.organization_id,entity_id=x.entity_id,action_id=action_id,approved_by=x.approved_by,apply=x.apply)
    except ValueError as e: raise HTTPException(422,str(e))
