from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models import Customer
from app.db.models_v25 import Supplier
from app.db.models_v43 import AccountingLedgerV43
from app.db.models_v44 import PartyLedgerLinkV44, LedgerSyncJobV44

def now(): return datetime.now(timezone.utc)

def ensure_party_link(db:Session, *, organization_id:int, entity_id:int, party_type:str, party_id:int, ledger_code:str, external_name:str|None=None):
    if party_type not in {'CUSTOMER','SUPPLIER'}: raise ValueError('INVALID_PARTY_TYPE')
    if not ledger_code.strip(): raise ValueError('LEDGER_CODE_REQUIRED')
    row=db.execute(select(PartyLedgerLinkV44).where(PartyLedgerLinkV44.organization_id==organization_id,PartyLedgerLinkV44.entity_id==entity_id,PartyLedgerLinkV44.party_type==party_type,PartyLedgerLinkV44.party_id==party_id)).scalar_one_or_none()
    if row is None:
        row=PartyLedgerLinkV44(organization_id=organization_id,entity_id=entity_id,party_type=party_type,party_id=party_id,ledger_code=ledger_code,external_name=external_name,status='PENDING'); db.add(row)
    else:
        row.ledger_code=ledger_code; row.external_name=external_name; row.status='PENDING'
    key=f'LEDGER_MASTER:{organization_id}:{entity_id}:{party_type}:{party_id}:{ledger_code}'
    job=db.execute(select(LedgerSyncJobV44).where(LedgerSyncJobV44.idempotency_key==key)).scalar_one_or_none()
    if job is None: db.add(LedgerSyncJobV44(organization_id=organization_id,entity_id=entity_id,ledger_code=ledger_code,idempotency_key=key,available_at=now()))
    db.flush(); return {'party_type':party_type,'party_id':party_id,'ledger_code':ledger_code,'status':'PENDING'}

def validate_party_exists(db:Session, *, organization_id:int, entity_id:int, party_type:str, party_id:int):
    model=Customer if party_type=='CUSTOMER' else Supplier if party_type=='SUPPLIER' else None
    if model is None: raise ValueError('INVALID_PARTY_TYPE')
    q=select(model).where(model.organization_id==organization_id, model.entity_id==entity_id, model.id==party_id) if party_type=='CUSTOMER' else select(model).where(model.organization_id==organization_id, model.entity_id==entity_id, model.id==party_id)
    if db.execute(q).scalar_one_or_none() is None: raise ValueError('PARTY_NOT_FOUND')

def mark_synced(db:Session, *, link_id:int, external_name:str|None=None):
    row=db.execute(select(PartyLedgerLinkV44).where(PartyLedgerLinkV44.id==link_id).with_for_update()).scalar_one()
    row.status='SYNCED'; row.last_synced_at=now(); row.external_name=external_name or row.external_name; row.sync_error=None
    return {'id':row.id,'status':row.status,'ledger_code':row.ledger_code}
