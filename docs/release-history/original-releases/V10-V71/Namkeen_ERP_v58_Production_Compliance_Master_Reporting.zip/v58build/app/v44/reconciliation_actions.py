from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models_v43 import AccountingReconciliationV43
from app.db.models_v44 import AccountingReconciliationActionV44

def request_action(db:Session, *, organization_id:int, entity_id:int, reconciliation_id:int, action:str, reason:str, requested_by:int):
    allowed={'ACCEPT_EXTERNAL','REQUEUE','CORRECT_MAPPING','REJECT'}
    if action not in allowed: raise ValueError('INVALID_RECON_ACTION')
    if not reason.strip(): raise ValueError('REASON_REQUIRED')
    r=db.execute(select(AccountingReconciliationV43).where(AccountingReconciliationV43.organization_id==organization_id,AccountingReconciliationV43.entity_id==entity_id,AccountingReconciliationV43.id==reconciliation_id)).scalar_one_or_none()
    if not r: raise ValueError('RECONCILIATION_NOT_FOUND')
    row=AccountingReconciliationActionV44(organization_id=organization_id,entity_id=entity_id,reconciliation_id=reconciliation_id,action=action,reason=reason.strip(),requested_by=requested_by,status='PENDING')
    db.add(row); db.flush(); return {'action_id':row.id,'status':row.status,'action':row.action}

def approve_action(db:Session, *, organization_id:int, entity_id:int, action_id:int, approved_by:int, apply=False):
    row=db.execute(select(AccountingReconciliationActionV44).where(AccountingReconciliationActionV44.organization_id==organization_id,AccountingReconciliationActionV44.entity_id==entity_id,AccountingReconciliationActionV44.id==action_id).with_for_update()).scalar_one_or_none()
    if not row: raise ValueError('ACTION_NOT_FOUND')
    if row.status!='PENDING': raise ValueError('ACTION_NOT_PENDING')
    if row.requested_by==approved_by: raise ValueError('SELF_APPROVAL_NOT_ALLOWED')
    row.status='APPROVED'; row.approved_by=approved_by; row.approved_at=datetime.now(timezone.utc)
    if apply:
        rec=db.execute(select(AccountingReconciliationV43).where(AccountingReconciliationV43.id==row.reconciliation_id).with_for_update()).scalar_one()
        if row.action=='ACCEPT_EXTERNAL': rec.status='MATCHED'; rec.mismatch_reason=None
        elif row.action=='REJECT': rec.status='MISMATCH'; rec.mismatch_reason='RECON_REJECTED'
    return {'action_id':row.id,'status':row.status,'applied':apply}
