from datetime import datetime, timezone
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.v46.einvoice import *

app=FastAPI(title='Namkeen ERP API v46 — E-Invoice & E-Way Bill', version='46.0')
class EInvIn(BaseModel):
 entity_id:int; invoice_id:int; doc_type:str='TAX_INVOICE'; doc_no:str; doc_date:str; supplier_gstin:str; recipient_gstin:str|None=None; place_of_supply:str; supply_type:str='B2B'; taxable_value:Decimal; invoice_value:Decimal; hsn:str; reverse_charge:bool=False
class EwbIn(BaseModel):
 invoice_id:int; doc_no:str; doc_date:str; from_state:str; to_state:str; total_value:Decimal; transport_mode:str; vehicle_no:str|None=None; transporter_id:str|None=None; distance_km:Decimal|None=None; trans_doc_no:str|None=None; trans_doc_date:str|None=None
class CancelIn(BaseModel):
 generated_at:str; active_ewb:bool=False; now:str|None=None

@app.get('/v46/health')
def health(): return {'version':'46.0','service':'einvoice-ewaybill'}
@app.post('/v46/einvoice/validate')
def validate(body:EInvIn):
 d=EInvoiceDoc(**body.model_dump()); errs=validate_einvoice_document(d); return {'valid':not errs,'errors':errs,'payload_hash':canonical_hash(d.payload())}
@app.post('/v46/einvoice/mock-generate')
def mock_generate(body:EInvIn):
 d=EInvoiceDoc(**body.model_dump()); errs=validate_einvoice_document(d)
 if errs: raise HTTPException(400,detail=errs)
 r=MockIRPClient().generate_irn(d.payload()); return r.__dict__
@app.post('/v46/ewaybill/validate')
def ewb_validate(body:EwbIn):
 d=EWayBillData(**body.model_dump()); errs=validate_eway_bill(d); return {'valid':not errs,'errors':errs}
@app.post('/v46/ewaybill/mock-generate')
def ewb_generate(body:EwbIn):
 d=EWayBillData(**body.model_dump()); r=MockEWayBillClient().generate(d)
 if not r['success']: raise HTTPException(400,detail=r['errors'])
 return r
@app.post('/v46/einvoice/cancel-check')
def cancel_check(body:CancelIn):
 try:
  generated=datetime.fromisoformat(body.generated_at); now=datetime.fromisoformat(body.now) if body.now else datetime.now(timezone.utc)
  return {'allowed':can_cancel_irn(generated,now,body.active_ewb)}
 except ValueError as e: raise HTTPException(400,detail='INVALID_DATETIME')
