from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
import re

D = lambda x: Decimal(str(x))
Q = Decimal('0.000001')

@dataclass(frozen=True)
class UOM:
    code: str
    name: str
    dimension: str  # WEIGHT, COUNT, LENGTH, VOLUME, etc.
    base_code: str
    base_factor: Decimal  # 1 code unit = factor base units

@dataclass(frozen=True)
class Conversion:
    from_code: str
    to_code: str
    factor: Decimal
    source: str = 'SYSTEM'

class UOMError(ValueError):
    pass

class UOMRegistry:
    def __init__(self):
        self.units: dict[str,UOM] = {}
        self._seed()
    def _seed(self):
        self.add(UOM('KG','Kilogram','WEIGHT','KG',D(1)))
        self.add(UOM('G','Gram','WEIGHT','KG',D('0.001')))
        self.add(UOM('MG','Milligram','WEIGHT','KG',D('0.000001')))
        self.add(UOM('PCS','Piece','COUNT','PCS',D(1)))
        self.add(UOM('PACK','Pack','COUNT','PCS',D(1)))
        self.add(UOM('CARTON','Carton','COUNT','PCS',D(1)))
    def add(self,u:UOM):
        if u.code in self.units: raise UOMError('UOM_ALREADY_EXISTS')
        if u.base_factor <= 0: raise UOMError('INVALID_FACTOR')
        self.units[u.code]=u
    def compatible(self,a,b):
        return self.units[a].dimension == self.units[b].dimension
    def convert(self,qty,from_code,to_code,rounding='0.000001'):
        if from_code not in self.units or to_code not in self.units: raise UOMError('UNKNOWN_UOM')
        if not self.compatible(from_code,to_code): raise UOMError('INCOMPATIBLE_UOM')
        a=self.units[from_code]; b=self.units[to_code]
        base=D(qty)*a.base_factor
        return (base/b.base_factor).quantize(Decimal(rounding), rounding=ROUND_HALF_UP)

PACK_RE=re.compile(r'^[A-Z0-9._-]{2,40}$')

@dataclass(frozen=True)
class PackConversion:
    sku_id:int
    from_uom:str
    to_uom:str
    qty:Decimal
    effective_from:str
    effective_to:str|None=None
    active:bool=True

@dataclass(frozen=True)
class SKUHierarchy:
    sku_id:int
    product_id:int
    pack_size_code:str
    net_weight_kg:Decimal
    sales_uom:str='PACK'
    pieces_per_pack:Decimal=Decimal('1')
    packs_per_carton:Decimal=Decimal('1')
    kg_per_piece:Decimal=Decimal('1')
    barcode:str|None=None

class PackHierarchy:
    def validate(self,h:SKUHierarchy):
        if h.net_weight_kg <= 0 or h.pieces_per_pack <= 0 or h.packs_per_carton <= 0 or h.kg_per_piece <= 0:
            raise UOMError('INVALID_PACK_HIERARCHY')
        if h.sales_uom not in {'PCS','PACK','CARTON'}:
            raise UOMError('INVALID_SALES_UOM')
    def to_kg(self,h,qty,from_uom):
        self.validate(h); q=D(qty)
        if from_uom=='KG': return q
        if from_uom=='PCS': return q*h.kg_per_piece
        if from_uom=='PACK': return q*h.net_weight_kg
        if from_uom=='CARTON': return q*h.packs_per_carton*h.net_weight_kg
        raise UOMError('UNKNOWN_PACK_UOM')
    def from_kg(self,h,qty_kg,to_uom):
        self.validate(h); q=D(qty_kg)
        if to_uom=='KG': return q
        if to_uom=='PCS': return (q/h.kg_per_piece).quantize(Q, rounding=ROUND_HALF_UP)
        if to_uom=='PACK': return (q/h.net_weight_kg).quantize(Q, rounding=ROUND_HALF_UP)
        if to_uom=='CARTON': return (q/(h.packs_per_carton*h.net_weight_kg)).quantize(Q, rounding=ROUND_HALF_UP)
        raise UOMError('UNKNOWN_PACK_UOM')
    def carton_to_piece(self,h,cartons):
        self.validate(h); return D(cartons)*h.packs_per_carton*h.pieces_per_pack
    def pack_to_piece(self,h,packs):
        self.validate(h); return D(packs)*h.pieces_per_pack

BARCODE_TYPES={'EAN13','EAN8','UPC_A','CODE128','QR','GS1','INTERNAL'}

def validate_barcode(code,barcode_type):
    if barcode_type not in BARCODE_TYPES: raise UOMError('UNSUPPORTED_BARCODE_TYPE')
    c=str(code).strip()
    if not c: raise UOMError('EMPTY_BARCODE')
    if barcode_type=='EAN13':
        if not (c.isdigit() and len(c)==13): raise UOMError('INVALID_EAN13')
        total=sum((1 if i%2==0 else 3)*int(d) for i,d in enumerate(c[:12]))
        if (10-total%10)%10 != int(c[-1]): raise UOMError('INVALID_EAN13_CHECKSUM')
    elif barcode_type=='EAN8':
        if not (c.isdigit() and len(c)==8): raise UOMError('INVALID_EAN8')
    elif barcode_type=='UPC_A':
        if not (c.isdigit() and len(c)==12): raise UOMError('INVALID_UPCA')
    elif barcode_type=='CODE128':
        if len(c)>80: raise UOMError('BARCODE_TOO_LONG')
    return c
