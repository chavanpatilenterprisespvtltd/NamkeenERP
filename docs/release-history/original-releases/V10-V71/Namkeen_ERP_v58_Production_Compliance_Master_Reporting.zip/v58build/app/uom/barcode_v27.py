from dataclasses import dataclass
from datetime import datetime, timezone
from .service_v27 import validate_barcode

@dataclass(frozen=True)
class BarcodeIdentity:
    barcode:str
    barcode_type:str
    entity_type:str
    entity_id:int
    sku_id:int|None=None
    lot_id:int|None=None
    active:bool=True

class BarcodeRegistry:
    def __init__(self): self._by_code={}
    def register(self, b:BarcodeIdentity):
        code=validate_barcode(b.barcode,b.barcode_type)
        if code in self._by_code and self._by_code[code] != b: raise ValueError('BARCODE_ALREADY_ASSIGNED')
        self._by_code[code]=b
        return b
    def resolve(self,code):
        return self._by_code.get(code)
