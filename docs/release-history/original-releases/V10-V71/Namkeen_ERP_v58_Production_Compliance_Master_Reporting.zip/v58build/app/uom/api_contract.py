from dataclasses import dataclass
from decimal import Decimal

@dataclass(frozen=True)
class QuantityLine:
    qty: Decimal
    uom_code: str
    normalized_kg: Decimal

@dataclass(frozen=True)
class ScanResolve:
    barcode: str
    barcode_type: str
    entity_type: str
    entity_id: int
    sku_id: int|None
    lot_id: int|None
    normalized_kg_per_unit: Decimal|None
