from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

Q2 = Decimal('0.01')

class AccountsError(ValueError):
    pass

ACCOUNTING_DOC_STATES = {'DRAFT','POSTED','CANCELLED','REVERSED'}
NOTE_TYPES = {'DEBIT','CREDIT'}
TAX_TYPES = {'CGST','SGST','IGST','UTGST','CESS'}


def money(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)

@dataclass(frozen=True)
class TaxComponent:
    code: str
    rate_pct: Decimal
    amount: Decimal

@dataclass(frozen=True)
class TaxProfile:
    tax_code: str
    effective_from: date
    effective_to: Optional[date]
    intra_state: tuple[TaxComponent, ...]
    inter_state: tuple[TaxComponent, ...]
    inclusive: bool = False

    def active_on(self, on_date: date) -> bool:
        return self.effective_from <= on_date and (self.effective_to is None or on_date <= self.effective_to)

@dataclass(frozen=True)
class TaxableLine:
    sku_id: int
    quantity_kg: Decimal
    unit_price: Decimal
    tax_code: str
    discount: Decimal = Decimal('0')

@dataclass
class TaxCalculation:
    taxable_value: Decimal
    tax_components: list[TaxComponent]
    tax_total: Decimal
    grand_total: Decimal
    withholding_tds: Decimal = Decimal('0')
    withholding_tcs: Decimal = Decimal('0')
    net_payable: Decimal = Decimal('0')
    inclusive: bool = False


def _tax_components(base: Decimal, rates: tuple[TaxComponent, ...]) -> list[TaxComponent]:
    out = []
    for r in rates:
        amt = money(base * r.rate_pct / Decimal('100'))
        out.append(TaxComponent(r.code, r.rate_pct, amt))
    return out


def calculate_tax(lines: list[TaxableLine], profiles: dict[str, TaxProfile], on_date: date, *, interstate: bool,
                  tds_rate_pct: Decimal = Decimal('0'), tcs_rate_pct: Decimal = Decimal('0')) -> TaxCalculation:
    if tds_rate_pct < 0 or tcs_rate_pct < 0:
        raise AccountsError('NEGATIVE_WITHHOLDING_RATE')
    taxable = Decimal('0')
    components: list[TaxComponent] = []
    inclusive = False
    for line in lines:
        if line.quantity_kg < 0 or line.unit_price < 0 or line.discount < 0:
            raise AccountsError('NEGATIVE_LINE_VALUE')
        gross = line.quantity_kg * line.unit_price
        if line.discount > gross:
            raise AccountsError('DISCOUNT_EXCEEDS_GROSS')
        net = gross - line.discount
        profile = profiles.get(line.tax_code)
        if profile is None or not profile.active_on(on_date):
            raise AccountsError(f'TAX_PROFILE_NOT_ACTIVE:{line.tax_code}')
        inclusive = inclusive or profile.inclusive
        rates = profile.inter_state if interstate else profile.intra_state
        if profile.inclusive:
            rate_sum = sum((r.rate_pct for r in rates), Decimal('0'))
            base = money(net / (Decimal('1') + rate_sum / Decimal('100'))) if rate_sum else money(net)
        else:
            base = money(net)
        taxable += base
        components.extend(_tax_components(base, rates))
    taxable = money(taxable)
    tax_total = money(sum((c.amount for c in components), Decimal('0')))
    gross_total = money(taxable + tax_total)
    tds = money(taxable * tds_rate_pct / Decimal('100'))
    tcs = money((taxable + tax_total) * tcs_rate_pct / Decimal('100'))
    net = money(gross_total - tds + tcs)
    return TaxCalculation(taxable, components, tax_total, gross_total, tds, tcs, net, inclusive)

@dataclass(frozen=True)
class AdjustmentNote:
    note_id: int
    supplier_id: int
    note_type: str
    original_invoice_id: int
    taxable_amount: Decimal
    tax_amount: Decimal
    grand_amount: Decimal
    reason: str
    note_date: date
    status: str = 'DRAFT'


def validate_note(note: AdjustmentNote, original_invoice_id: int) -> None:
    if note.note_type not in NOTE_TYPES:
        raise AccountsError('INVALID_NOTE_TYPE')
    if note.original_invoice_id != original_invoice_id:
        raise AccountsError('ORIGINAL_INVOICE_MISMATCH')
    if note.taxable_amount < 0 or note.tax_amount < 0 or note.grand_amount < 0:
        raise AccountsError('NEGATIVE_NOTE_AMOUNT')
    expected = money(note.taxable_amount + note.tax_amount)
    if expected != money(note.grand_amount):
        raise AccountsError('NOTE_TOTAL_MISMATCH')
    if not note.reason.strip():
        raise AccountsError('NOTE_REASON_REQUIRED')

@dataclass(frozen=True)
class PayableRef:
    payable_id: int
    supplier_id: int
    invoice_no: str
    invoice_date: date
    due_date: date
    original_amount: Decimal
    outstanding_amount: Decimal
    status: str
    entity_id: int

@dataclass
class AgingBucket:
    label: str
    amount: Decimal = Decimal('0')
    invoice_count: int = 0


def supplier_ageing(payables: list[PayableRef], as_of: date) -> list[AgingBucket]:
    labels = ['CURRENT','1-30','31-60','61-90','91-120','120+']
    out = {x: AgingBucket(x, Decimal('0'), 0) for x in labels}
    for p in payables:
        amt = money(p.outstanding_amount)
        if amt <= 0 or p.status == 'CANCELLED':
            continue
        days = (as_of - p.due_date).days
        if days <= 0: label = 'CURRENT'
        elif days <= 30: label = '1-30'
        elif days <= 60: label = '31-60'
        elif days <= 90: label = '61-90'
        elif days <= 120: label = '91-120'
        else: label = '120+'
        out[label].amount = money(out[label].amount + amt)
        out[label].invoice_count += 1
    return [out[x] for x in labels]

@dataclass(frozen=True)
class PaymentReconciliation:
    payment_id: int
    supplier_id: int
    amount: Decimal
    bank_reference: str
    value_date: date
    matched_payable_id: Optional[int]
    status: str
    difference: Decimal = Decimal('0')


def reconcile_payment(*, payment_id: int, supplier_id: int, amount: Decimal, bank_reference: str,
                      value_date: date, payable: Optional[PayableRef]) -> PaymentReconciliation:
    if amount <= 0:
        raise AccountsError('PAYMENT_AMOUNT_MUST_BE_POSITIVE')
    if not bank_reference.strip():
        raise AccountsError('BANK_REFERENCE_REQUIRED')
    if payable is None:
        return PaymentReconciliation(payment_id, supplier_id, money(amount), bank_reference, value_date, None, 'UNMATCHED')
    if payable.supplier_id != supplier_id:
        raise AccountsError('PAYMENT_SUPPLIER_MISMATCH')
    diff = money(amount - payable.outstanding_amount)
    status = 'MATCHED' if diff == 0 else ('SHORT' if diff < 0 else 'OVER')
    return PaymentReconciliation(payment_id, supplier_id, money(amount), bank_reference, value_date, payable.payable_id, status, diff)

@dataclass(frozen=True)
class AccountingPosting:
    posting_id: int
    source_type: str
    source_id: int
    debit_account: str
    credit_account: str
    amount: Decimal
    posting_date: date
    status: str = 'DRAFT'
    external_reference: Optional[str] = None


def validate_posting(p: AccountingPosting) -> None:
    if p.status not in ACCOUNTING_DOC_STATES:
        raise AccountsError('INVALID_POSTING_STATUS')
    if p.amount <= 0:
        raise AccountsError('POSTING_AMOUNT_MUST_BE_POSITIVE')
    if not p.debit_account.strip() or not p.credit_account.strip():
        raise AccountsError('GL_ACCOUNTS_REQUIRED')
    if p.debit_account == p.credit_account:
        raise AccountsError('DEBIT_CREDIT_ACCOUNT_MUST_DIFFER')
