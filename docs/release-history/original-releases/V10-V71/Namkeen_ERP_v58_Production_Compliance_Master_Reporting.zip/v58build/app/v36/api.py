from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.v36.accounts import TaxComponent, TaxProfile, TaxableLine, calculate_tax, supplier_ageing, PayableRef, AccountsError, reconcile_payment

app = FastAPI(title='Namkeen ERP API v36 — Accounts & Tax', version='36.0')

class RateIn(BaseModel):
    code:str; rate_pct:Decimal
class ProfileIn(BaseModel):
    tax_code:str; effective_from:date; effective_to:date|None=None; intra_state:list[RateIn]; inter_state:list[RateIn]; inclusive:bool=False
class LineIn(BaseModel):
    sku_id:int; quantity_kg:Decimal; unit_price:Decimal; tax_code:str; discount:Decimal=0
class TaxRequest(BaseModel):
    lines:list[LineIn]; profiles:list[ProfileIn]; on_date:date; interstate:bool=False; tds_rate_pct:Decimal=0; tcs_rate_pct:Decimal=0
class PayableIn(BaseModel):
    payable_id:int; supplier_id:int; invoice_no:str; invoice_date:date; due_date:date; original_amount:Decimal; outstanding_amount:Decimal; status:str; entity_id:int
class AgeingRequest(BaseModel):
    payables:list[PayableIn]; as_of:date

@app.get('/v36/health')
def health(): return {'version':'36.0','service':'accounts-tax'}

@app.post('/v36/tax/calculate')
def tax_calculate(body: TaxRequest):
    try:
        profiles={p.tax_code: TaxProfile(p.tax_code,p.effective_from,p.effective_to,
            tuple(TaxComponent(r.code,r.rate_pct,Decimal('0')) for r in p.intra_state),
            tuple(TaxComponent(r.code,r.rate_pct,Decimal('0')) for r in p.inter_state), p.inclusive) for p in body.profiles}
        lines=[TaxableLine(x.sku_id,x.quantity_kg,x.unit_price,x.tax_code,x.discount) for x in body.lines]
        result=calculate_tax(lines,profiles,body.on_date,interstate=body.interstate,tds_rate_pct=body.tds_rate_pct,tcs_rate_pct=body.tcs_rate_pct)
        return {'taxable_value':str(result.taxable_value),'tax_total':str(result.tax_total),'grand_total':str(result.grand_total),
                'tds':str(result.withholding_tds),'tcs':str(result.withholding_tcs),'net_payable':str(result.net_payable),
                'inclusive':result.inclusive,'components':[{'code':x.code,'rate_pct':str(x.rate_pct),'amount':str(x.amount)} for x in result.tax_components]}
    except (AccountsError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post('/v36/supplier-ageing')
def ageing(body: AgeingRequest):
    try:
        pay=[PayableRef(x.payable_id,x.supplier_id,x.invoice_no,x.invoice_date,x.due_date,x.original_amount,x.outstanding_amount,x.status,x.entity_id) for x in body.payables]
        return {'as_of':str(body.as_of),'buckets':[{'label':x.label,'amount':f'{x.amount:.2f}','invoice_count':x.invoice_count} for x in supplier_ageing(pay,body.as_of)]}
    except (AccountsError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post('/v36/payments/reconcile')
def payment_reconcile(body:dict):
    try:
        p=body.get('payable')
        payable=None if p is None else PayableRef(p['payable_id'],p['supplier_id'],p['invoice_no'],date.fromisoformat(p['invoice_date']),date.fromisoformat(p['due_date']),Decimal(str(p['original_amount'])),Decimal(str(p['outstanding_amount'])),p['status'],p['entity_id'])
        r=reconcile_payment(payment_id=int(body['payment_id']),supplier_id=int(body['supplier_id']),amount=Decimal(str(body['amount'])),bank_reference=body['bank_reference'],value_date=date.fromisoformat(body['value_date']),payable=payable)
        return r.__dict__ | {'amount':str(r.amount),'difference':str(r.difference)}
    except (AccountsError, ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=str(e))
