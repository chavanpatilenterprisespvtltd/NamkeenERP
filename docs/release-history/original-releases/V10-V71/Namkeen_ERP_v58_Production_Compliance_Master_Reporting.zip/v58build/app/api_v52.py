from __future__ import annotations
from decimal import Decimal
from fastapi import APIRouter, HTTPException
from app.v52_mrp import InventoryPosition, explode_mrp, create_production_order
from app.v51.api import _bom

router=APIRouter(prefix='/v52/mrp',tags=['v52-mrp'])

@router.post('/explode')
def explode(payload:dict):
    try:
        positions=[InventoryPosition(int(x['item_id']),Decimal(str(x.get('available_qty_kg','0'))),Decimal(str(x.get('reserved_qty_kg','0'))),Decimal(str(x.get('open_po_qty_kg','0'))),Decimal(str(x.get('open_production_qty_kg','0')))) for x in payload.get('positions',[])]
        r=explode_mrp(_bom(payload['bom']),Decimal(str(payload['planned_good_output_kg'])),positions)
        return {'sku_id':r.sku_id,'planned_output_kg':str(r.planned_output_kg),'bom_version':r.bom_version,'requirements':[r.__dict__|{'gross_required_qty_kg':str(r.gross_required_qty_kg),'planned_available_qty_kg':str(r.planned_available_qty_kg),'net_to_make_or_buy_qty_kg':str(r.net_to_make_or_buy_qty_kg)} for r in r.requirements]}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))

@router.post('/production-orders')
def production_order(payload:dict):
    try:
        po=create_production_order(production_order_id=int(payload['production_order_id']),organization_id=int(payload['organization_id']),entity_id=int(payload['entity_id']),sku_id=int(payload['sku_id']),bom_version=str(payload['bom_version']),planned_good_output_kg=Decimal(str(payload['planned_good_output_kg'])),due_date=str(payload['due_date']),created_by=int(payload['created_by']),source_demand_ids=payload.get('source_demand_ids',[]))
        return {'production_order_id':po.production_order_id,'status':po.status.value,'sku_id':po.sku_id,'planned_good_output_kg':str(po.planned_good_output_kg)}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))
