from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import hashlib, json, re
from typing import Optional

class EInvoiceError(ValueError): pass

IRN_STATES={'PENDING','SUBMITTED','GENERATED','CANCEL_REQUESTED','CANCELLED','FAILED'}
EWB_STATES={'NOT_REQUIRED','PENDING','GENERATED','ACTIVE','CANCEL_REQUESTED','CANCELLED','EXPIRED','FAILED'}
OUTBOX_STATES={'PENDING','PROCESSING','SUCCEEDED','RETRY','DEAD_LETTER'}

def _norm(v): return (v or '').strip()
def validate_doc_no(v): return bool(re.fullmatch(r'[A-Za-z0-9\-/]{1,50}', _norm(v)))
def validate_gstin(v): return bool(v and re.fullmatch(r'[0-9A-Z]{15}',v.upper()))
def validate_state(v): return bool(re.fullmatch(r'\d{2}',_norm(v)))

def canonical_hash(payload:dict)->str:
    raw=json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()

@dataclass(frozen=True)
class EInvoiceDoc:
    entity_id:int; invoice_id:int; doc_type:str; doc_no:str; doc_date:str
    supplier_gstin:str; recipient_gstin:Optional[str]; place_of_supply:str
    supply_type:str; taxable_value:Decimal; invoice_value:Decimal; hsn:str
    reverse_charge:bool=False
    def payload(self)->dict:
        return {'entity_id':self.entity_id,'invoice_id':self.invoice_id,'doc_type':self.doc_type,'doc_no':self.doc_no,'doc_date':self.doc_date,
                'supplier_gstin':self.supplier_gstin,'recipient_gstin':self.recipient_gstin,'place_of_supply':self.place_of_supply,
                'supply_type':self.supply_type,'taxable_value':str(self.taxable_value),'invoice_value':str(self.invoice_value),
                'hsn':self.hsn,'reverse_charge':self.reverse_charge}

def validate_einvoice_document(d:EInvoiceDoc)->list[str]:
    e=[]
    if d.doc_type not in {'TAX_INVOICE','DEBIT_NOTE','CREDIT_NOTE'}: e.append('UNSUPPORTED_DOC_TYPE')
    if not validate_doc_no(d.doc_no): e.append('INVALID_DOC_NO')
    if not validate_gstin(d.supplier_gstin): e.append('INVALID_SUPPLIER_GSTIN')
    if d.recipient_gstin and not validate_gstin(d.recipient_gstin): e.append('INVALID_RECIPIENT_GSTIN')
    if not validate_state(d.place_of_supply): e.append('INVALID_PLACE_OF_SUPPLY')
    if d.taxable_value < 0 or d.invoice_value < 0: e.append('NEGATIVE_AMOUNT')
    if not d.hsn or not re.fullmatch(r'[0-9]{4,8}',d.hsn): e.append('INVALID_HSN')
    return e

def irn_cancel_deadline(generated_at:datetime, hours:int=24)->datetime:
    return generated_at + timedelta(hours=hours)

def can_cancel_irn(generated_at:datetime, now:datetime, active_ewb:bool, hours:int=24)->bool:
    if active_ewb: return False
    return now <= irn_cancel_deadline(generated_at,hours)

@dataclass(frozen=True)
class EInvoiceResponse:
    success:bool; irn:Optional[str]=None; ack_no:Optional[str]=None; ack_date:Optional[str]=None; signed_qr:Optional[str]=None; error_code:Optional[str]=None; error_message:Optional[str]=None

class MockIRPClient:
    def generate_irn(self, payload:dict)->EInvoiceResponse:
        if payload.get('force_error'): return EInvoiceResponse(False,error_code='MOCK_ERROR',error_message='Forced mock failure')
        h=canonical_hash(payload)
        irn=h[:64]
        ack='ACK-'+h[:12]
        qr='SIGNEDQR:'+h[:32]
        return EInvoiceResponse(True,irn,ack,datetime.now(timezone.utc).isoformat(),qr)
    def cancel_irn(self, irn:str)->EInvoiceResponse: return EInvoiceResponse(True,irn=irn)
    def get_irn(self, irn:str)->EInvoiceResponse: return EInvoiceResponse(True,irn=irn)

@dataclass(frozen=True)
class EWayBillData:
    invoice_id:int; doc_no:str; doc_date:str; from_state:str; to_state:str; total_value:Decimal
    transport_mode:str; vehicle_no:Optional[str]=None; transporter_id:Optional[str]=None; distance_km:Optional[Decimal]=None
    trans_doc_no:Optional[str]=None; trans_doc_date:Optional[str]=None

def validate_eway_bill(d:EWayBillData)->list[str]:
    e=[]
    if not validate_doc_no(d.doc_no): e.append('INVALID_DOC_NO')
    if not validate_state(d.from_state) or not validate_state(d.to_state): e.append('INVALID_STATE')
    if d.total_value < 0: e.append('NEGATIVE_TOTAL')
    if d.transport_mode not in {'ROAD','RAIL','AIR','SHIP','OTHER'}: e.append('INVALID_TRANSPORT_MODE')
    if d.transport_mode=='ROAD' and not d.vehicle_no: e.append('VEHICLE_REQUIRED_FOR_ROAD')
    if d.transport_mode in {'RAIL','AIR','SHIP'} and not d.trans_doc_no: e.append('TRANSPORT_DOC_REQUIRED')
    if d.distance_km is not None and d.distance_km < 0: e.append('INVALID_DISTANCE')
    return e

@dataclass(frozen=True)
class MockEWayBillClient:
    def generate(self,d:EWayBillData)->dict:
        errs=validate_eway_bill(d)
        if errs: return {'success':False,'errors':errs}
        seed=canonical_hash({'invoice_id':d.invoice_id,'doc_no':d.doc_no,'vehicle_no':d.vehicle_no,'distance':str(d.distance_km)})
        return {'success':True,'ewb_no':int(seed[:12],16),'valid_upto':None}

@dataclass
class IntegrationRecord:
    integration_id:int; document_id:int; action:str; idempotency_key:str; status:str='PENDING'; attempts:int=0; last_error:Optional[str]=None
    external_ref:Optional[str]=None

def next_retry_delay(attempt:int, base_seconds:int=30, cap_seconds:int=3600)->int:
    return min(cap_seconds, base_seconds*(2**max(0,attempt-1)))
