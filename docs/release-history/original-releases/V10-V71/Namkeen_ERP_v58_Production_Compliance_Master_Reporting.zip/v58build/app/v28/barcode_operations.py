from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models_v25 import BarcodeEvent, Warehouse, InventoryQc, Receipt, ReceiptLine, StockMovement, StockTransfer, StockTransferLine, InventoryLot
from app.uom.barcode_v27 import BarcodeIdentity
from app.uom.service_v27 import validate_barcode
from app.sync.domain_integration_v20 import emit
from .scanner import ScanContext, ScanError, validate_scan_context

WAREHOUSE_ACTION_PERMISSIONS = {
    "RECEIVE": "stock.receive",
    "ISSUE": "production.record",
    "TRANSFER": "stock.reserve",
    "PICK": "stock.reserve",
    "DISPATCH": "stock.dispatch",
    "COUNT": "stock.receive",
    "VERIFY_LOT": "stock.receive",
}

@dataclass(frozen=True)
class ScanResolution:
    barcode: str
    barcode_type: str
    entity_type: str
    entity_id: int
    sku_id: int | None
    lot_id: int | None


def resolve_barcode(db: Session, *, org_id: int, barcode: str) -> ScanResolution:
    row = db.execute(select(BarcodeMaster).where(BarcodeMaster.organization_id == org_id, BarcodeMaster.barcode == barcode, BarcodeMaster.active.is_(True))).scalar_one_or_none()
    if not row:
        raise ScanError("BARCODE_NOT_FOUND")
    return ScanResolution(row.barcode, row.barcode_type, row.entity_type, row.entity_id, row.sku_id, row.lot_id)


def record_scan_event(db: Session, *, org_id: int, entity_id: int, ctx: ScanContext, resolved: ScanResolution, actor_id: int) -> BarcodeEvent:
    validate_scan_context(ctx)
    validate_barcode(ctx.barcode, ctx.code_type)
    event = BarcodeEvent(
        organization_id=org_id,
        entity_id=entity_id,
        barcode=ctx.barcode,
        code_type=ctx.code_type,
        event_type=ctx.action,
        reference_type=resolved.entity_type,
        reference_id=str(resolved.entity_id),
        captured_by=actor_id,
    )
    db.add(event)
    db.flush()
    emit(db, org_id=org_id, entity_id=entity_id, aggregate_type="BARCODE_SCAN", aggregate_id=event.id,
         event_name=f"BARCODE_{ctx.action}", operation="CREATE",
         payload={"barcode": ctx.barcode, "entity_type": resolved.entity_type, "entity_id": resolved.entity_id, "sku_id": resolved.sku_id, "lot_id": resolved.lot_id, "quantity": str(ctx.quantity), "uom": ctx.quantity_uom}, actor_user_id=actor_id)
    return event


def ensure_lot_action_allowed(db: Session, *, org_id: int, entity_id: int, lot_id: int, action: str, warehouse_code: str | None = None) -> InventoryLot:
    lot = db.get(InventoryLot, lot_id)
    if not lot or lot.organization_id != org_id or lot.entity_id != entity_id:
        raise ScanError("LOT_NOT_FOUND")
    if warehouse_code and lot.warehouse_code != warehouse_code:
        raise ScanError("LOT_WAREHOUSE_MISMATCH")
    if action in {"ISSUE", "PICK", "DISPATCH", "TRANSFER"} and lot.qty_available <= 0:
        raise ScanError("LOT_HAS_NO_AVAILABLE_STOCK")
    return lot


def lot_verification_payload(lot: InventoryLot) -> dict:
    return {"lot_id": lot.id, "sku_id": lot.sku_id, "batch_no": lot.batch_no, "warehouse_code": lot.warehouse_code, "expiry_date": lot.expiry_date.isoformat() if lot.expiry_date else None, "qty_available": str(lot.qty_available), "qty_reserved": str(lot.qty_reserved)}


# Import late to preserve v27 compatibility when this module is used without model registry side effects.
from app.db.models_v25 import InventoryLot
from app.db.models_v27 import BarcodeMaster
