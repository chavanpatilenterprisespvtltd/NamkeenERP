from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional
from app.uom.service_v27 import PackHierarchy, SKUHierarchy, D

ALLOWED_ACTIONS = {
    "RECEIVE", "ISSUE", "TRANSFER", "PICK", "DISPATCH", "COUNT", "VERIFY_LOT"
}

@dataclass(frozen=True)
class ScanContext:
    organization_id: int
    entity_id: int
    actor_id: int
    action: str
    barcode: str
    code_type: str = "QR"
    warehouse_code: Optional[str] = None
    quantity: Decimal = Decimal("1")
    quantity_uom: str = "PCS"
    client_event_id: Optional[str] = None

@dataclass(frozen=True)
class ResolvedScan:
    barcode: str
    code_type: str
    entity_type: str
    entity_id: int
    sku_id: Optional[int]
    lot_id: Optional[int]
    transaction_entity_id: Optional[int] = None

class ScanError(ValueError):
    pass


def validate_scan_context(ctx: ScanContext) -> None:
    if ctx.action not in ALLOWED_ACTIONS:
        raise ScanError("UNSUPPORTED_SCAN_ACTION")
    if not str(ctx.barcode).strip():
        raise ScanError("BARCODE_REQUIRED")
    if D(ctx.quantity) <= 0:
        raise ScanError("SCAN_QUANTITY_MUST_BE_POSITIVE")
    if not str(ctx.quantity_uom).strip():
        raise ScanError("SCAN_UOM_REQUIRED")


def normalize_sku_quantity(hierarchy: SKUHierarchy, quantity: Decimal, quantity_uom: str) -> Decimal:
    """Convert a scanned SKU quantity to kg using the effective hierarchy."""
    validate_scan_context(ScanContext(0, 0, 0, "COUNT", "SCAN", quantity=quantity, quantity_uom=quantity_uom))
    return PackHierarchy().to_kg(hierarchy, quantity, quantity_uom)


def scan_preview(*, hierarchy: Optional[SKUHierarchy], resolved: ResolvedScan, quantity: Decimal, quantity_uom: str) -> dict:
    q = D(quantity)
    result = {
        "barcode": resolved.barcode,
        "code_type": resolved.code_type,
        "entity_type": resolved.entity_type,
        "entity_id": resolved.entity_id,
        "sku_id": resolved.sku_id,
        "lot_id": resolved.lot_id,
        "quantity": str(q),
        "quantity_uom": quantity_uom,
        "normalized_kg": None,
    }
    if hierarchy is not None and resolved.sku_id is not None and quantity_uom in {"PCS", "PACK", "CARTON", "KG"}:
        result["normalized_kg"] = str(normalize_sku_quantity(hierarchy, q, quantity_uom))
    return result
