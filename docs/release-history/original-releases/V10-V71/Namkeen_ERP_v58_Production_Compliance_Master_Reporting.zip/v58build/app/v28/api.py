from __future__ import annotations
from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from app.db.session import SessionLocal
from app.auth.security import decode_token
from app.auth.authorization import Actor, require_entity_access, require_permission
from app.db.models_v27 import BarcodeMaster
from .barcode_operations import resolve_barcode, record_scan_event, ensure_lot_action_allowed, lot_verification_payload
from .scanner import ScanContext, ScanError

app = FastAPI(title='Namkeen ERP v28 Barcode Warehouse Operations API')


def actor_from_auth(auth: str | None) -> Actor:
    if not auth or not auth.lower().startswith('bearer '):
        raise HTTPException(401, 'Authentication required')
    try:
        p = decode_token(auth.split(' ', 1)[1])
        return Actor(user_id=int(p['sub']), organization_id=int(p['org_id']), role=p['role'])
    except Exception as e:
        raise HTTPException(401, f'Invalid token: {e}')


def guard(a: Actor, entity_id: int, permission: str):
    require_entity_access(a.user_id, entity_id)
    require_permission(a.role, permission)

class ScanIn(BaseModel):
    entity_id: int
    barcode: str
    code_type: str = 'QR'
    action: str
    warehouse_code: str | None = None
    quantity: Decimal = Field(default=Decimal('1'), gt=0)
    quantity_uom: str = 'PCS'
    client_event_id: str | None = None

class ResolveOut(BaseModel):
    barcode: str
    barcode_type: str
    entity_type: str
    entity_id: int
    sku_id: int | None
    lot_id: int | None

@app.get('/v28/barcodes/resolve', response_model=ResolveOut)
def resolve(barcode: str, authorization: str | None = Header(default=None)):
    a = actor_from_auth(authorization)
    with SessionLocal() as db:
        try:
            r = resolve_barcode(db, org_id=a.organization_id, barcode=barcode.strip())
            return ResolveOut(barcode=r.barcode, barcode_type=r.barcode_type, entity_type=r.entity_type, entity_id=r.entity_id, sku_id=r.sku_id, lot_id=r.lot_id)
        except ScanError as e:
            raise HTTPException(404, str(e))

@app.post('/v28/barcodes/scan')
def scan(body: ScanIn, authorization: str | None = Header(default=None)):
    a = actor_from_auth(authorization)
    permission = {
        'RECEIVE':'stock.receive','ISSUE':'production.record','TRANSFER':'stock.reserve','PICK':'stock.reserve','DISPATCH':'stock.dispatch','COUNT':'stock.receive','VERIFY_LOT':'stock.receive'
    }.get(body.action)
    if not permission:
        raise HTTPException(422, 'UNSUPPORTED_SCAN_ACTION')
    try:
        guard(a, body.entity_id, permission)
        ctx = ScanContext(a.organization_id, body.entity_id, a.user_id, body.action, body.barcode, body.code_type, body.warehouse_code, body.quantity, body.quantity_uom, body.client_event_id)
        with SessionLocal() as db:
            with db.begin():
                r = resolve_barcode(db, org_id=a.organization_id, barcode=body.barcode.strip())
                if r.lot_id and body.action in {'ISSUE','PICK','DISPATCH','TRANSFER','VERIFY_LOT'}:
                    lot = ensure_lot_action_allowed(db, org_id=a.organization_id, entity_id=body.entity_id, lot_id=r.lot_id, action=body.action, warehouse_code=body.warehouse_code)
                event = record_scan_event(db, org_id=a.organization_id, entity_id=body.entity_id, ctx=ctx, resolved=r, actor_id=a.user_id)
                response = {'scan_event_id': event.id, 'status': 'CAPTURED', 'barcode': r.barcode, 'entity_type': r.entity_type, 'entity_id': r.entity_id, 'sku_id': r.sku_id, 'lot_id': r.lot_id}
                if r.lot_id and body.action == 'VERIFY_LOT':
                    response['lot'] = lot_verification_payload(lot)
                return response
    except PermissionError as e:
        raise HTTPException(403, str(e))
    except ScanError as e:
        raise HTTPException(409, str(e))
