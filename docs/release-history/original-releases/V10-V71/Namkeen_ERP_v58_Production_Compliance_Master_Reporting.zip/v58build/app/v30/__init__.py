"""v30 warehouse location, bin and LPN hierarchy primitives."""
