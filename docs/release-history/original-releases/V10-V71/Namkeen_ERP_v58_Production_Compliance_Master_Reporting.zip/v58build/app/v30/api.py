try:
    from fastapi import APIRouter, HTTPException
    from pydantic import BaseModel, Field
except Exception:
    APIRouter=None

from .warehouse import Location, LPNNode, PutawayRule, attach_lpn, move_lpn, create_pick_task, pick_route, choose_putaway_location, validate_parent_lpn, WarehouseLocationError

if APIRouter:
    router = APIRouter(prefix="/v30/warehouse", tags=["v30-warehouse-locations"])
    _locations: dict[int, Location] = {}
    _lpns: dict[int, LPNNode] = {}
    _rules: list[PutawayRule] = []
    _tasks: dict[int, object] = {}

    class LocationIn(BaseModel):
        organization_id: int; warehouse_id: int; code: str = Field(min_length=1,max_length=80); name: str = Field(min_length=1,max_length=160)
        location_type: str = "BIN"; parent_location_id: int|None = None; capacity_kg: float|None = None
        allow_putaway: bool = True; allow_picking: bool = True
    class LPNAttachIn(BaseModel): location_id: int
    class LPNParentIn(BaseModel): parent_lpn_id: int
    class MoveIn(BaseModel): destination_location_id: int
    class PickIn(BaseModel): source_location_id:int; destination_location_id:int; lpn_id:int|None=None; sku_id:int|None=None; lot_id:int|None=None; qty_kg:float=Field(gt=0); sequence_no:int=0
    class RuleIn(BaseModel): organization_id:int; warehouse_id:int; sku_id:int|None=None; product_id:int|None=None; location_id:int; priority:int=100; min_qty_kg:float|None=None; max_qty_kg:float|None=None

    @router.post("/locations")
    def location_create(req: LocationIn):
        if any(x.organization_id==req.organization_id and x.code==req.code for x in _locations.values()): raise HTTPException(409,"LOCATION_CODE_EXISTS")
        i=max(_locations, default=0)+1; loc=Location(i,**req.model_dump()); _locations[i]=loc
        try: loc.path_key(_locations); return {"id":i,"code":loc.code,"path":loc.path_key(_locations)}
        except WarehouseLocationError as e: _locations.pop(i,None); raise HTTPException(409,str(e))

    @router.get("/locations/{location_id}")
    def location_get(location_id:int):
        loc=_locations.get(location_id)
        if not loc: raise HTTPException(404,"LOCATION_NOT_FOUND")
        return {"id":loc.location_id,"code":loc.code,"type":loc.location_type,"path":loc.path_key(_locations),"warehouse_id":loc.warehouse_id}

    @router.post("/lpns/{lpn_id}/attach")
    def lpn_attach(lpn_id:int, req:LPNAttachIn):
        lpn=_lpns.get(lpn_id); loc=_locations.get(req.location_id)
        if not lpn: raise HTTPException(404,"LPN_NOT_FOUND")
        if not loc: raise HTTPException(404,"LOCATION_NOT_FOUND")
        try: attach_lpn(lpn,loc,_locations); return {"lpn_id":lpn_id,"location_id":loc.location_id}
        except WarehouseLocationError as e: raise HTTPException(409,str(e))

    @router.post("/lpns/{lpn_id}/move")
    def lpn_move(lpn_id:int, req:MoveIn):
        lpn=_lpns.get(lpn_id); dest=_locations.get(req.destination_location_id)
        if not lpn: raise HTTPException(404,"LPN_NOT_FOUND")
        if not dest: raise HTTPException(404,"LOCATION_NOT_FOUND")
        try:
            e=move_lpn(lpn,dest,_locations); return {"lpn_id":lpn_id,"from_location_id":e.from_location_id,"to_location_id":e.to_location_id}
        except WarehouseLocationError as ex: raise HTTPException(409,str(ex))

    @router.post("/lpns/{lpn_id}/parent")
    def lpn_parent(lpn_id:int, req:LPNParentIn):
        child=_lpns.get(lpn_id); parent=_lpns.get(req.parent_lpn_id)
        if not child or not parent: raise HTTPException(404,"LPN_NOT_FOUND")
        try: validate_parent_lpn(parent,child,_lpns); return {"child_lpn_id":lpn_id,"parent_lpn_id":parent.lpn_id,"location_id":child.location_id}
        except WarehouseLocationError as e: raise HTTPException(409,str(e))

    @router.post("/putaway-rules")
    def rule_create(req:RuleIn):
        rid=len(_rules)+1; _rules.append(PutawayRule(rid,**req.model_dump())); return {"id":rid}

    @router.get("/putaway/suggest")
    def putaway_suggest(organization_id:int, warehouse_id:int, sku_id:int|None=None, product_id:int|None=None, qty_kg:float=1):
        try:
            r=choose_putaway_location([x for x in _rules if x.organization_id==organization_id and x.warehouse_id==warehouse_id],sku_id=sku_id,product_id=product_id,qty_kg=qty_kg)
            loc=_locations[r.location_id]; return {"rule_id":r.rule_id,"location_id":loc.location_id,"location_code":loc.code,"path":loc.path_key(_locations)}
        except WarehouseLocationError as e: raise HTTPException(409,str(e))

    @router.post("/pick-tasks")
    def pick_create(req:PickIn):
        src=_locations.get(req.source_location_id); dst=_locations.get(req.destination_location_id); lpn=_lpns.get(req.lpn_id) if req.lpn_id else None
        if not src or not dst: raise HTTPException(404,"LOCATION_NOT_FOUND")
        try:
            t=create_pick_task(task_id=max(_tasks,default=0)+1,organization_id=src.organization_id,warehouse_id=src.warehouse_id,source=src,destination=dst,lpn=lpn,sku_id=req.sku_id,lot_id=req.lot_id,qty_kg=req.qty_kg,sequence_no=req.sequence_no); _tasks[t.task_id]=t; return t.__dict__
        except WarehouseLocationError as e: raise HTTPException(409,str(e))

    @router.get("/pick-route")
    def get_pick_route(): return [t.__dict__ for t in pick_route(list(_tasks.values()))]
