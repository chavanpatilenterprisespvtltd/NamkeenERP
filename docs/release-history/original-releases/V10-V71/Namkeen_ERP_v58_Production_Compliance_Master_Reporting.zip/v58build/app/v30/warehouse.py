from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional

class WarehouseLocationError(ValueError):
    pass

VALID_LOCATION_TYPES = {"WAREHOUSE", "ZONE", "AISLE", "RACK", "SHELF", "BIN", "STAGING", "DISPATCH", "QUARANTINE"}
VALID_LPN_TYPES = {"CARTON", "PALLET", "CONTAINER"}

@dataclass
class Location:
    location_id: int
    organization_id: int
    warehouse_id: int
    code: str
    name: str
    location_type: str = "BIN"
    parent_location_id: Optional[int] = None
    active: bool = True
    capacity_kg: Optional[float] = None
    sequence_no: int = 0
    allow_putaway: bool = True
    allow_picking: bool = True

    def path_key(self, locations: dict[int, "Location"]) -> str:
        parts=[]; cur: Optional[Location]=self; seen=set()
        while cur is not None:
            if cur.location_id in seen: raise WarehouseLocationError("LOCATION_HIERARCHY_CYCLE")
            seen.add(cur.location_id); parts.append(cur.code)
            cur = locations.get(cur.parent_location_id) if cur.parent_location_id else None
        return "/".join(reversed(parts))

@dataclass
class LPNNode:
    lpn_id: int
    code: str
    lpn_type: str = "CARTON"
    parent_lpn_id: Optional[int] = None
    location_id: Optional[int] = None
    status: str = "ACTIVE"

@dataclass
class PutawayRule:
    rule_id: int
    organization_id: int
    warehouse_id: int
    sku_id: Optional[int]
    product_id: Optional[int]
    location_id: int
    priority: int = 100
    min_qty_kg: Optional[float] = None
    max_qty_kg: Optional[float] = None
    active: bool = True

@dataclass
class PickTask:
    task_id: int
    organization_id: int
    warehouse_id: int
    source_location_id: int
    destination_location_id: int
    lpn_id: Optional[int] = None
    sku_id: Optional[int] = None
    lot_id: Optional[int] = None
    qty_kg: float = 0.0
    sequence_no: int = 0
    status: str = "OPEN"

@dataclass
class LocationMoveEvent:
    event_id: int
    organization_id: int
    lpn_id: int
    from_location_id: Optional[int]
    to_location_id: Optional[int]
    event_type: str
    actor_user_id: Optional[int] = None
    client_event_id: Optional[str] = None
    event_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


def validate_location(location: Location, locations: dict[int, Location]) -> None:
    if location.organization_id <= 0: raise WarehouseLocationError("ORGANIZATION_REQUIRED")
    if not location.code.strip(): raise WarehouseLocationError("LOCATION_CODE_REQUIRED")
    if location.location_type not in VALID_LOCATION_TYPES: raise WarehouseLocationError("INVALID_LOCATION_TYPE")
    if location.parent_location_id == location.location_id: raise WarehouseLocationError("LOCATION_PARENT_SELF")
    if location.capacity_kg is not None and location.capacity_kg < 0: raise WarehouseLocationError("NEGATIVE_LOCATION_CAPACITY")
    location.path_key(locations)


def attach_lpn(lpn: LPNNode, location: Location, locations: dict[int, Location]) -> None:
    validate_location(location, locations)
    if not location.active: raise WarehouseLocationError("LOCATION_INACTIVE")
    if not location.allow_putaway: raise WarehouseLocationError("PUTAWAY_NOT_ALLOWED_AT_LOCATION")
    if location.warehouse_id <= 0: raise WarehouseLocationError("WAREHOUSE_REQUIRED")
    if lpn.lpn_type not in VALID_LPN_TYPES: raise WarehouseLocationError("INVALID_LPN_TYPE")
    if lpn.status in {"DISPATCHED", "VOID"}: raise WarehouseLocationError("LPN_NOT_LOCATABLE")
    lpn.location_id = location.location_id


def move_lpn(lpn: LPNNode, destination: Location, locations: dict[int, Location]) -> LocationMoveEvent:
    if lpn.status in {"DISPATCHED", "VOID"}: raise WarehouseLocationError("LPN_NOT_MOVABLE")
    validate_location(destination, locations)
    if not destination.active: raise WarehouseLocationError("LOCATION_INACTIVE")
    if not destination.allow_putaway: raise WarehouseLocationError("PUTAWAY_NOT_ALLOWED_AT_LOCATION")
    old = lpn.location_id
    lpn.location_id = destination.location_id
    return LocationMoveEvent(0, 0, lpn.lpn_id, old, destination.location_id, "PUTAWAY_MOVE")


def create_pick_task(*, task_id: int, organization_id: int, warehouse_id: int,
                     source: Location, destination: Location, lpn: Optional[LPNNode] = None,
                     sku_id: Optional[int] = None, lot_id: Optional[int] = None,
                     qty_kg: float = 0.0, sequence_no: int = 0) -> PickTask:
    if not source.allow_picking: raise WarehouseLocationError("PICKING_NOT_ALLOWED_AT_SOURCE")
    if not destination.active: raise WarehouseLocationError("DESTINATION_INACTIVE")
    if qty_kg <= 0: raise WarehouseLocationError("PICK_QTY_MUST_BE_POSITIVE")
    if lpn and lpn.location_id != source.location_id: raise WarehouseLocationError("LPN_NOT_AT_PICK_SOURCE")
    return PickTask(task_id, organization_id, warehouse_id, source.location_id, destination.location_id,
                    lpn.lpn_id if lpn else None, sku_id, lot_id, qty_kg, sequence_no)


def pick_route(tasks: List[PickTask]) -> List[PickTask]:
    return sorted((t for t in tasks if t.status == "OPEN"), key=lambda t: (t.sequence_no, t.source_location_id, t.task_id))


def choose_putaway_location(rules: List[PutawayRule], *, sku_id: Optional[int], product_id: Optional[int], qty_kg: float) -> PutawayRule:
    candidates=[]
    for r in rules:
        if not r.active: continue
        if r.sku_id is not None and r.sku_id != sku_id: continue
        if r.product_id is not None and r.product_id != product_id: continue
        if r.min_qty_kg is not None and qty_kg < r.min_qty_kg: continue
        if r.max_qty_kg is not None and qty_kg > r.max_qty_kg: continue
        candidates.append(r)
    if not candidates: raise WarehouseLocationError("NO_PUTAWAY_RULE_MATCH")
    candidates.sort(key=lambda r: (r.priority, -(1 if r.sku_id is not None else 0), r.rule_id))
    return candidates[0]


def validate_parent_lpn(parent: LPNNode, child: LPNNode, lpn_index: dict[int, LPNNode]) -> None:
    if parent.lpn_id == child.lpn_id: raise WarehouseLocationError("LPN_PARENT_SELF")
    if parent.lpn_type == "CARTON": raise WarehouseLocationError("CARTON_CANNOT_PARENT_LPN")
    cur = parent; seen=set()
    while cur.parent_lpn_id:
        if cur.lpn_id in seen: raise WarehouseLocationError("LPN_HIERARCHY_CYCLE")
        seen.add(cur.lpn_id)
        if cur.parent_lpn_id == child.lpn_id: raise WarehouseLocationError("LPN_HIERARCHY_CYCLE")
        nxt=lpn_index.get(cur.parent_lpn_id)
        if nxt is None: break
        cur=nxt
    child.parent_lpn_id=parent.lpn_id
    if parent.location_id is not None: child.location_id=parent.location_id
