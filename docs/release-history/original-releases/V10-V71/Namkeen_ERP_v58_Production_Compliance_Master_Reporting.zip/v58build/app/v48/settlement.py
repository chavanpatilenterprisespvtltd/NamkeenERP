from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from datetime import datetime, timezone
from typing import Optional

class SettlementStatus(str, Enum): OPEN='OPEN'; RECONCILED='RECONCILED'; EXCEPTION='EXCEPTION'; APPROVED='APPROVED'; POSTED='POSTED'
class ExceptionType(str, Enum): SHORT='SHORT'; FAILED='FAILED'; RETURN='RETURN'; DAMAGE='DAMAGE'; OTHER='OTHER'

@dataclass
class DeliverySettlement:
    settlement_id:int; delivery_id:int; invoice_id:int; ordered_kg:Decimal; delivered_kg:Decimal; failed_kg:Decimal=Decimal('0');
    returned_kg:Decimal=Decimal('0'); customer_accepted_kg:Decimal=Decimal('0'); status:SettlementStatus=SettlementStatus.OPEN
    variance_reason:Optional[str]=None
    @property
    def undelivered_kg(self)->Decimal: return max(Decimal('0'), self.ordered_kg-self.delivered_kg)
    @property
    def settlement_kg(self)->Decimal: return self.delivered_kg

@dataclass(frozen=True)
class SettlementException:
    exception_id:int; settlement_id:int; exception_type:ExceptionType; qty_kg:Decimal; reason:str; evidence_ref:Optional[str]=None

@dataclass
class CustomerAdjustment:
    adjustment_id:int; invoice_id:int; customer_id:int; kind:str; amount:Decimal; reason:str; approved:bool=False; posted:bool=False

@dataclass(frozen=True)
class FreightSettlement:
    trip_id:int; freight_amount:Decimal; delivered_kg:Decimal; freight_per_kg:Decimal


def build_settlement(delivery_id:int, invoice_id:int, ordered_kg:Decimal, delivered_kg:Decimal, *, failed_kg:Decimal=Decimal('0'), returned_kg:Decimal=Decimal('0')) -> DeliverySettlement:
    if ordered_kg < 0 or delivered_kg < 0 or failed_kg < 0 or returned_kg < 0: raise ValueError('INVALID_QTY')
    if delivered_kg > ordered_kg: raise ValueError('DELIVERED_EXCEEDS_ORDER')
    if failed_kg + returned_kg > ordered_kg - delivered_kg: raise ValueError('EXCEPTION_QTY_EXCEEDS_UNDELIVERED')
    accepted = delivered_kg
    status = SettlementStatus.RECONCILED if failed_kg + returned_kg == ordered_kg-delivered_kg else SettlementStatus.EXCEPTION
    return DeliverySettlement(delivery_id, delivery_id, invoice_id, ordered_kg, delivered_kg, failed_kg, returned_kg, accepted, status)


def add_customer_exception(settlement:DeliverySettlement, exception:SettlementException)->None:
    if exception.settlement_id != settlement.settlement_id: raise ValueError('SETTLEMENT_MISMATCH')
    if exception.qty_kg <= 0: raise ValueError('INVALID_EXCEPTION_QTY')
    if not exception.reason.strip(): raise ValueError('REASON_REQUIRED')
    settlement.variance_reason = exception.reason
    settlement.status = SettlementStatus.EXCEPTION


def approve_exception(settlement:DeliverySettlement, approver_role:str, reason:str)->None:
    if settlement.status != SettlementStatus.EXCEPTION: raise ValueError('NO_EXCEPTION_TO_APPROVE')
    if approver_role not in {'MANAGER','MANAGEMENT','ACCOUNTS'}: raise ValueError('APPROVER_NOT_AUTHORIZED')
    if not reason.strip(): raise ValueError('REASON_REQUIRED')
    settlement.variance_reason = reason
    settlement.status = SettlementStatus.APPROVED


def post_settlement(settlement:DeliverySettlement, *, stock_action:str, receivable_action:str)->None:
    if settlement.status not in {SettlementStatus.RECONCILED, SettlementStatus.APPROVED}: raise ValueError('SETTLEMENT_NOT_APPROVED')
    if stock_action not in {'RETAIN','RETURN_TO_QC','DAMAGE_HOLD','DISPOSE'}: raise ValueError('INVALID_STOCK_ACTION')
    if receivable_action not in {'NO_CHANGE','CREDIT_NOTE_REQUIRED','MANAGEMENT_REVIEW'}: raise ValueError('INVALID_RECEIVABLE_ACTION')
    settlement.status = SettlementStatus.POSTED


def freight_settlement(trip_id:int, freight_amount:Decimal, delivered_kg:Decimal)->FreightSettlement:
    if freight_amount < 0 or delivered_kg <= 0: raise ValueError('INVALID_FREIGHT_INPUT')
    return FreightSettlement(trip_id, freight_amount, delivered_kg, (freight_amount/delivered_kg).quantize(Decimal('0.0001')))
