from fastapi import APIRouter, HTTPException
from decimal import Decimal
from .settlement import build_settlement, approve_exception, post_settlement

router=APIRouter(prefix='/v48/settlements', tags=['v48-settlements'])

@router.post('/reconcile')
def reconcile(payload:dict):
    try:
        s=build_settlement(int(payload['delivery_id']), int(payload['invoice_id']), Decimal(str(payload['ordered_kg'])), Decimal(str(payload['delivered_kg'])), failed_kg=Decimal(str(payload.get('failed_kg','0'))), returned_kg=Decimal(str(payload.get('returned_kg','0'))))
        return {'status':s.status.value,'delivery_id':s.delivery_id,'invoice_id':s.invoice_id,'delivered_kg':str(s.delivered_kg),'undelivered_kg':str(s.undelivered_kg)}
    except (KeyError,ValueError) as e:
        raise HTTPException(400,str(e))

@router.post('/approve-exception')
def approve(payload:dict):
    try:
        from .settlement import DeliverySettlement, SettlementStatus
        s=DeliverySettlement(int(payload['settlement_id']),int(payload['delivery_id']),int(payload['invoice_id']),Decimal(str(payload['ordered_kg'])),Decimal(str(payload['delivered_kg'])),status=SettlementStatus.EXCEPTION)
        approve_exception(s,payload['approver_role'],payload['reason'])
        return {'status':s.status.value,'reason':s.variance_reason}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))

@router.post('/post')
def post(payload:dict):
    try:
        from .settlement import DeliverySettlement, SettlementStatus
        s=DeliverySettlement(int(payload['settlement_id']),int(payload['delivery_id']),int(payload['invoice_id']),Decimal(str(payload['ordered_kg'])),Decimal(str(payload['delivered_kg'])),status=SettlementStatus(payload.get('status','APPROVED')))
        post_settlement(s,stock_action=payload['stock_action'],receivable_action=payload['receivable_action'])
        return {'status':s.status.value}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))
