from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Optional


class ComplianceError(ValueError):
    pass


class TaskStatus(str, Enum):
    OPEN = 'OPEN'
    IN_PROGRESS = 'IN_PROGRESS'
    SUBMITTED = 'SUBMITTED'
    VERIFIED = 'VERIFIED'
    OVERDUE = 'OVERDUE'
    CLOSED = 'CLOSED'
    WAIVED = 'WAIVED'


class EvidenceType(str, Enum):
    PHOTO = 'PHOTO'
    DOCUMENT = 'DOCUMENT'
    LAB_REPORT = 'LAB_REPORT'
    CERTIFICATE = 'CERTIFICATE'
    CHECKLIST = 'CHECKLIST'
    TEST_RESULT = 'TEST_RESULT'
    CORRESPONDENCE = 'CORRESPONDENCE'


class Disposition(str, Enum):
    ACCEPT = 'ACCEPT'
    HOLD = 'HOLD'
    CAPA = 'CAPA'
    REJECT = 'REJECT'
    ESCALATE = 'ESCALATE'


@dataclass(frozen=True)
class Requirement:
    requirement_code: str
    authority: str
    title: str
    mandatory: bool
    frequency_days: Optional[int] = None
    condition: str = ''
    active_from: date = field(default_factory=date.today)
    active_to: Optional[date] = None

    def active_on(self, on: date) -> bool:
        return self.active_from <= on and (self.active_to is None or on <= self.active_to)


@dataclass
class ComplianceTask:
    task_id: int
    site_id: int
    requirement_code: str
    due_date: date
    status: TaskStatus = TaskStatus.OPEN
    owner_user_id: Optional[int] = None
    completed_at: Optional[datetime] = None
    verified_at: Optional[datetime] = None
    evidence_ids: list[int] = field(default_factory=list)
    finding_count: int = 0
    severity: str = 'LOW'

    def is_overdue(self, today: Optional[date] = None) -> bool:
        today = today or date.today()
        return self.status not in {TaskStatus.CLOSED, TaskStatus.WAIVED, TaskStatus.VERIFIED} and self.due_date < today

    def submit(self, evidence_count: int = 0) -> None:
        if self.status not in {TaskStatus.OPEN, TaskStatus.IN_PROGRESS, TaskStatus.OVERDUE}:
            raise ComplianceError('TASK_NOT_SUBMITTABLE')
        if evidence_count <= 0 and not self.evidence_ids:
            raise ComplianceError('EVIDENCE_REQUIRED')
        self.status = TaskStatus.SUBMITTED
        self.completed_at = datetime.utcnow()

    def verify(self) -> None:
        if self.status != TaskStatus.SUBMITTED:
            raise ComplianceError('TASK_NOT_READY_FOR_VERIFICATION')
        if self.finding_count > 0:
            raise ComplianceError('OPEN_FINDINGS_REQUIRE_DISPOSITION')
        self.status = TaskStatus.VERIFIED
        self.verified_at = datetime.utcnow()


@dataclass(frozen=True)
class Evidence:
    evidence_id: int
    site_id: int
    evidence_type: EvidenceType
    captured_at: datetime
    storage_ref: str
    sha256: str
    captured_by: int
    linked_entity_type: str
    linked_entity_id: int
    confidential: bool = False


@dataclass(frozen=True)
class InspectionFinding:
    finding_id: int
    task_id: int
    severity: str
    description: str
    disposition: Disposition
    capa_id: Optional[int] = None
    closed: bool = False


@dataclass(frozen=True)
class SiteComplianceSnapshot:
    site_id: int
    as_of: date
    mandatory_open: int
    mandatory_overdue: int
    open_findings: int
    critical_findings: int
    active_capa: int
    missing_evidence: int
    inspection_ready: bool


def build_snapshot(site_id: int, tasks: list[ComplianceTask], findings: list[InspectionFinding], active_capa: int, as_of: Optional[date] = None) -> SiteComplianceSnapshot:
    as_of = as_of or date.today()
    mandatory_open = sum(1 for t in tasks if t.status not in {TaskStatus.VERIFIED, TaskStatus.CLOSED, TaskStatus.WAIVED})
    mandatory_overdue = sum(1 for t in tasks if t.is_overdue(as_of))
    open_findings = sum(1 for f in findings if not f.closed)
    critical_findings = sum(1 for f in findings if not f.closed and f.severity.upper() == 'CRITICAL')
    missing_evidence = sum(1 for t in tasks if t.status not in {TaskStatus.VERIFIED, TaskStatus.CLOSED, TaskStatus.WAIVED} and not t.evidence_ids)
    ready = mandatory_overdue == 0 and critical_findings == 0 and missing_evidence == 0 and active_capa == 0
    return SiteComplianceSnapshot(site_id, as_of, mandatory_open, mandatory_overdue, open_findings, critical_findings, active_capa, missing_evidence, ready)


def generate_recurring_tasks(requirements: list[Requirement], *, site_id: int, last_completed: dict[str, date], as_of: Optional[date] = None, id_start: int = 1) -> list[ComplianceTask]:
    as_of = as_of or date.today()
    tasks: list[ComplianceTask] = []
    next_id = id_start
    for req in requirements:
        if not req.mandatory or req.frequency_days is None or not req.active_on(as_of):
            continue
        last = last_completed.get(req.requirement_code)
        if last is None:
            due = as_of
        else:
            due = last.fromordinal(last.toordinal() + req.frequency_days)
        status = TaskStatus.OVERDUE if due < as_of else TaskStatus.OPEN
        tasks.append(ComplianceTask(next_id, site_id, req.requirement_code, due, status=status))
        next_id += 1
    return tasks


def validate_oil_tpc(tpc_percent: Decimal, configured_limit: Decimal = Decimal('25')) -> bool:
    if tpc_percent < 0:
        raise ComplianceError('NEGATIVE_TPC')
    return tpc_percent <= configured_limit


def validate_test_result(value: Decimal, *, minimum: Optional[Decimal] = None, maximum: Optional[Decimal] = None) -> bool:
    if minimum is not None and value < minimum:
        return False
    if maximum is not None and value > maximum:
        return False
    return True
