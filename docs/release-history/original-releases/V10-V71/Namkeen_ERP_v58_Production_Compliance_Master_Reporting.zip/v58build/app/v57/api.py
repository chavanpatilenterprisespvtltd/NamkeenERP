from __future__ import annotations
from dataclasses import asdict
from datetime import date
from decimal import Decimal
from .compliance_operations import *


def compliance_dashboard(site_id: int, tasks: list[ComplianceTask], findings: list[InspectionFinding], active_capa: int, as_of: date | None = None) -> dict:
    return asdict(build_snapshot(site_id, tasks, findings, active_capa, as_of))


def evaluate_oil_check(tpc_percent: Decimal, configured_limit: Decimal = Decimal('25')) -> dict:
    passed = validate_oil_tpc(tpc_percent, configured_limit)
    return {'tpc_percent': str(tpc_percent), 'limit': str(configured_limit), 'passed': passed, 'requires_action': not passed}


def submit_task(task: ComplianceTask, evidence_ids: list[int]) -> ComplianceTask:
    task.evidence_ids.extend(evidence_ids)
    task.submit()
    return task
