from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.v37.sales_accounts import *

app=FastAPI(title="Namkeen ERP API v37 — Sales & Customer Accounts",version="37.0")
class LineIn(BaseModel): sku_id:int; quantity_kg:Decimal; unit_price:Decimal; taxable_value:Decimal; tax_amount:Decimal
class InvoiceIn(BaseModel): invoice_id:int; organization_id:int; entity_id:int; customer_id:int; invoice_no:str; invoice_date:date; lines:list[LineIn]; taxable_total:Decimal; tax_total:Decimal; grand_total:Decimal; status:str="DRAFT"; salesperson_id:int|None=None
class CreditIn(BaseModel): customer_id:int; entity_id:int; credit_limit:Decimal; outstanding:Decimal=0; credit_days:int=0; active:bool=True; new_amount:Decimal
class ReceiptIn(BaseModel): receipt_id:int; organization_id:int; entity_id:int; customer_id:int; receipt_date:date; amount:Decimal; mode:str; reference_no:str|None=None; status:str="DRAFT"; collected_by:int|None=None; outstanding_before:Decimal; allocation:Decimal
class NoteIn(BaseModel): note_id:int; customer_id:int; note_type:str; original_invoice_id:int; taxable_amount:Decimal; tax_amount:Decimal; grand_amount:Decimal; reason:str; note_date:date; status:str="DRAFT"
class AgeIn(BaseModel): as_of:date; rows:list[dict]
class IncIn(BaseModel): salesperson_id:int; invoice_id:int; lines:list[dict]; returns_qty_kg:Decimal=0

@app.get('/v37/health')
def health(): return {'version':'37.0','service':'sales-customer-accounts'}
@app.post('/v37/invoices/validate')
def invoice_validate(b:InvoiceIn):
    try:
        inv=SalesInvoice(b.invoice_id,b.organization_id,b.entity_id,b.customer_id,b.invoice_no,b.invoice_date,tuple(SalesInvoiceLine(x.sku_id,x.quantity_kg,x.unit_price,x.taxable_value,x.tax_amount) for x in b.lines),b.taxable_total,b.tax_total,b.grand_total,b.status,b.salesperson_id)
        validate_sales_invoice(inv); return {'valid':True,'invoice_id':b.invoice_id,'grand_total':str(money(b.grand_total))}
    except (SalesAccountsError,ValueError) as e: raise HTTPException(400,str(e))
@app.post('/v37/credit/check')
def credit_check(b:CreditIn):
    try:
        a=CustomerAccount(b.customer_id,b.entity_id,b.credit_limit,b.outstanding,b.credit_days,b.active)
        return {'state':customer_credit_check(a,b.new_amount),'available_credit':str(a.available_credit())}
    except (SalesAccountsError,ValueError) as e: raise HTTPException(400,str(e))
@app.post('/v37/receipts/allocate')
def receipt_allocate(b:ReceiptIn):
    try:
        r=CustomerReceipt(b.receipt_id,b.organization_id,b.entity_id,b.customer_id,b.receipt_date,b.amount,b.mode,b.reference_no,b.status,b.collected_by)
        new_out,unallocated=allocate_customer_receipt(receipt=r,outstanding_before=b.outstanding_before,allocation=b.allocation)
        return {'new_outstanding':str(new_out),'unallocated':str(unallocated)}
    except (SalesAccountsError,ValueError) as e: raise HTTPException(400,str(e))
@app.post('/v37/notes/validate')
def note_validate(b:NoteIn):
    try: validate_customer_note(CustomerAdjustmentNote(**b.model_dump())); return {'valid':True}
    except (SalesAccountsError,ValueError) as e: raise HTTPException(400,str(e))
@app.post('/v37/customer-ageing')
def ageing(b:AgeIn):
    return {'as_of':str(b.as_of),'buckets':customer_ageing([(date.fromisoformat(x['due_date']),Decimal(str(x['amount']))) for x in b.rows],b.as_of)}
@app.post('/v37/incentive/basis')
def incentive(b:IncIn):
    try:
        lines=[(Decimal(str(x['qty_kg'])),Decimal(str(x['selling_price_per_kg'])),Decimal(str(x['company_cost_per_kg']))) for x in b.lines]
        r=build_incentive_basis(salesperson_id=b.salesperson_id,invoice_id=b.invoice_id,lines=lines,returns_qty_kg=b.returns_qty_kg)
        return {'eligible_qty_kg':str(r.eligible_qty_kg),'net_sales_value':str(r.net_sales_value),'gross_margin_value':str(r.gross_margin_value),'status':r.status}
    except (SalesAccountsError,ValueError,KeyError) as e: raise HTTPException(400,str(e))
