from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

Q2 = Decimal("0.01")
class SalesAccountsError(ValueError): pass

INVOICE_STATES={"DRAFT","POSTED","CANCELLED","REVERSED"}
RECEIPT_STATES={"DRAFT","POSTED","CANCELLED","REVERSED"}
NOTE_TYPES={"DEBIT","CREDIT"}

def money(v: Decimal|int|str)->Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)

@dataclass(frozen=True)
class CustomerAccount:
    customer_id:int; entity_id:int; credit_limit:Decimal; outstanding:Decimal=Decimal("0"); credit_days:int=0; active:bool=True
    def available_credit(self)->Decimal: return money(self.credit_limit-self.outstanding)

@dataclass(frozen=True)
class SalesInvoiceLine:
    sku_id:int; quantity_kg:Decimal; unit_price:Decimal; taxable_value:Decimal; tax_amount:Decimal

@dataclass(frozen=True)
class SalesInvoice:
    invoice_id:int; organization_id:int; entity_id:int; customer_id:int; invoice_no:str; invoice_date:date
    lines:tuple[SalesInvoiceLine,...]; taxable_total:Decimal; tax_total:Decimal; grand_total:Decimal
    status:str="DRAFT"; salesperson_id:Optional[int]=None

@dataclass(frozen=True)
class CustomerReceipt:
    receipt_id:int; organization_id:int; entity_id:int; customer_id:int; receipt_date:date; amount:Decimal
    mode:str; reference_no:Optional[str]=None; status:str="DRAFT"; collected_by:Optional[int]=None

@dataclass(frozen=True)
class CustomerAdjustmentNote:
    note_id:int; customer_id:int; note_type:str; original_invoice_id:int; taxable_amount:Decimal
    tax_amount:Decimal; grand_amount:Decimal; reason:str; note_date:date; status:str="DRAFT"

def validate_sales_invoice(inv:SalesInvoice)->None:
    if inv.status not in INVOICE_STATES: raise SalesAccountsError("INVALID_INVOICE_STATUS")
    if not inv.invoice_no.strip(): raise SalesAccountsError("INVOICE_NUMBER_REQUIRED")
    if not inv.lines: raise SalesAccountsError("INVOICE_LINES_REQUIRED")
    calc_taxable=money(sum((x.taxable_value for x in inv.lines),Decimal("0")))
    calc_tax=money(sum((x.tax_amount for x in inv.lines),Decimal("0")))
    calc_grand=money(calc_taxable+calc_tax)
    if calc_taxable!=money(inv.taxable_total): raise SalesAccountsError("INVOICE_TAXABLE_TOTAL_MISMATCH")
    if calc_tax!=money(inv.tax_total): raise SalesAccountsError("INVOICE_TAX_TOTAL_MISMATCH")
    if calc_grand!=money(inv.grand_total): raise SalesAccountsError("INVOICE_GRAND_TOTAL_MISMATCH")
    for x in inv.lines:
        if x.quantity_kg<=0 or x.unit_price<0 or x.taxable_value<0 or x.tax_amount<0: raise SalesAccountsError("INVALID_INVOICE_LINE")

def customer_credit_check(account:CustomerAccount, new_amount:Decimal, *, allow_override:bool=False)->str:
    new_amount=money(new_amount)
    if new_amount<=0: raise SalesAccountsError("AMOUNT_MUST_BE_POSITIVE")
    if not account.active: raise SalesAccountsError("CUSTOMER_INACTIVE")
    if account.credit_limit<=0:
        return "CASH_ONLY" if not allow_override else "OVERRIDE_ALLOWED"
    projected=money(account.outstanding+new_amount)
    if projected<=account.credit_limit: return "WITHIN_LIMIT"
    if allow_override: return "OVERRIDE_ALLOWED"
    raise SalesAccountsError("CREDIT_LIMIT_EXCEEDED")

def apply_customer_invoice(account:CustomerAccount, inv:SalesInvoice, *, is_credit_sale:bool)->CustomerAccount:
    validate_sales_invoice(inv)
    if inv.customer_id!=account.customer_id: raise SalesAccountsError("CUSTOMER_MISMATCH")
    add=inv.grand_total if is_credit_sale else Decimal("0")
    return CustomerAccount(account.customer_id,account.entity_id,account.credit_limit,money(account.outstanding+add),account.credit_days,account.active)

def allocate_customer_receipt(*, receipt:CustomerReceipt, outstanding_before:Decimal, allocation:Decimal)->tuple[Decimal,Decimal]:
    if receipt.status!="POSTED": raise SalesAccountsError("RECEIPT_NOT_POSTED")
    if receipt.amount<=0: raise SalesAccountsError("RECEIPT_AMOUNT_MUST_BE_POSITIVE")
    outstanding_before=money(outstanding_before); allocation=money(allocation)
    if allocation<=0 or allocation>receipt.amount: raise SalesAccountsError("INVALID_RECEIPT_ALLOCATION")
    if allocation>outstanding_before: raise SalesAccountsError("ALLOCATION_EXCEEDS_OUTSTANDING")
    return money(outstanding_before-allocation), money(receipt.amount-allocation)

def validate_customer_note(note:CustomerAdjustmentNote)->None:
    if note.note_type not in NOTE_TYPES: raise SalesAccountsError("INVALID_NOTE_TYPE")
    if note.taxable_amount<0 or note.tax_amount<0 or note.grand_amount<0: raise SalesAccountsError("NEGATIVE_NOTE_AMOUNT")
    if money(note.taxable_amount+note.tax_amount)!=money(note.grand_amount): raise SalesAccountsError("NOTE_TOTAL_MISMATCH")
    if not note.reason.strip(): raise SalesAccountsError("NOTE_REASON_REQUIRED")

def customer_ageing(invoice_rows:list[tuple[date,Decimal]], as_of:date)->list[dict]:
    labels=["CURRENT","1-30","31-60","61-90","91-120","120+"]
    out={k:{"label":k,"amount":Decimal("0"),"invoice_count":0} for k in labels}
    for due,amt in invoice_rows:
        amt=money(amt)
        if amt<=0: continue
        d=(as_of-due).days
        key="CURRENT" if d<=0 else "1-30" if d<=30 else "31-60" if d<=60 else "61-90" if d<=90 else "91-120" if d<=120 else "120+"
        out[key]["amount"]=money(out[key]["amount"]+amt); out[key]["invoice_count"]+=1
    return [out[k] for k in labels]

@dataclass(frozen=True)
class IncentiveBasis:
    salesperson_id:int; invoice_id:int; eligible_qty_kg:Decimal; net_sales_value:Decimal; gross_margin_value:Decimal
    status:str="ELIGIBLE"

def build_incentive_basis(*, salesperson_id:int, invoice_id:int, lines:list[tuple[Decimal,Decimal,Decimal]], returns_qty_kg:Decimal=Decimal("0"))->IncentiveBasis:
    # line tuple: qty_kg, selling_price_per_kg, company_cost_per_kg
    gross_qty=sum((q for q,_,_ in lines),Decimal("0"))
    eligible=max(Decimal("0"),gross_qty-returns_qty_kg)
    sales=sum((q*p for q,p,_ in lines),Decimal("0"))
    cost=sum((q*c for q,_,c in lines),Decimal("0"))
    # proportionally reduce sales/cost for returned qty; avoids incentive on returned goods.
    factor=(eligible/gross_qty) if gross_qty else Decimal("0")
    net_sales=money(sales*factor); margin=money((sales-cost)*factor)
    return IncentiveBasis(salesperson_id,invoice_id,eligible,net_sales,margin)
