from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Optional

Q6 = Decimal('0.000001')
Q2 = Decimal('0.01')

def q(v) -> Decimal:
    return Decimal(str(v)).quantize(Q6, rounding=ROUND_HALF_UP)

def q2(v) -> Decimal:
    return Decimal(str(v)).quantize(Q2, rounding=ROUND_HALF_UP)

class QCControlError(ValueError):
    pass

class CheckStatus(str, Enum):
    PASS='PASS'; FAIL='FAIL'; HOLD='HOLD'; NOT_CHECKED='NOT_CHECKED'

class ControlSeverity(str, Enum):
    CRITICAL='CRITICAL'; MAJOR='MAJOR'; MINOR='MINOR'; INFO='INFO'

class Disposition(str, Enum):
    RELEASE='RELEASE'; REWORK='REWORK'; REJECT='REJECT'; SCRAP='SCRAP'; HOLD='HOLD'

@dataclass(frozen=True)
class SpecificationLimit:
    parameter_code: str
    min_value: Optional[Decimal] = None
    max_value: Optional[Decimal] = None
    target_value: Optional[Decimal] = None
    unit: str = ''
    severity: ControlSeverity = ControlSeverity.MAJOR

    def __post_init__(self):
        if not self.parameter_code: raise QCControlError('PARAMETER_CODE_REQUIRED')
        if self.min_value is not None and self.max_value is not None and q(self.min_value) > q(self.max_value):
            raise QCControlError('INVALID_SPEC_LIMIT')

    def evaluate(self, value: Decimal) -> CheckStatus:
        value = q(value)
        if self.min_value is not None and value < q(self.min_value): return CheckStatus.FAIL
        if self.max_value is not None and value > q(self.max_value): return CheckStatus.FAIL
        return CheckStatus.PASS

@dataclass(frozen=True)
class ProductSpecification:
    spec_code: str
    sku_id: int
    version: str
    effective_from: str
    effective_to: Optional[str]
    parameters: tuple[SpecificationLimit, ...]
    active: bool = True

    def __post_init__(self):
        if not self.spec_code or self.sku_id <= 0 or not self.version: raise QCControlError('INVALID_PRODUCT_SPEC')
        if not self.parameters: raise QCControlError('SPEC_PARAMETERS_REQUIRED')

    def parameter(self, code: str) -> SpecificationLimit:
        for p in self.parameters:
            if p.parameter_code == code: return p
        raise QCControlError('SPEC_PARAMETER_NOT_FOUND')

@dataclass(frozen=True)
class SamplingPlan:
    plan_code: str
    sample_count: int
    min_pass_count: int
    critical_all_must_pass: bool = True

    def __post_init__(self):
        if not self.plan_code or self.sample_count <= 0 or not (0 < self.min_pass_count <= self.sample_count):
            raise QCControlError('INVALID_SAMPLING_PLAN')

    def passes(self, checks: list[CheckStatus]) -> bool:
        if len(checks) != self.sample_count: raise QCControlError('SAMPLE_COUNT_MISMATCH')
        if self.critical_all_must_pass and any(x == CheckStatus.FAIL for x in checks): return False
        return sum(1 for x in checks if x == CheckStatus.PASS) >= self.min_pass_count

@dataclass(frozen=True)
class Measurement:
    parameter_code: str
    value: Decimal
    status: CheckStatus
    severity: ControlSeverity
    evidence_ref: Optional[str] = None
    note: str = ''

@dataclass
class QCInspection:
    inspection_id: str
    batch_id: int
    sku_id: int
    stage_code: str
    spec: ProductSpecification
    sampling_plan: SamplingPlan
    measurements: list[Measurement] = field(default_factory=list)
    status: CheckStatus = CheckStatus.NOT_CHECKED
    disposition: Optional[Disposition] = None
    deviations: list[str] = field(default_factory=list)
    capa_required: bool = False
    released_by: Optional[int] = None

    def record_measurement(self, parameter_code: str, value: Decimal, *, evidence_ref: Optional[str] = None, note: str = '') -> Measurement:
        spec = self.spec.parameter(parameter_code)
        st = spec.evaluate(value)
        m = Measurement(parameter_code, q(value), st, spec.severity, evidence_ref, note)
        self.measurements.append(m)
        if st == CheckStatus.FAIL:
            self.deviations.append(parameter_code)
            if spec.severity in {ControlSeverity.CRITICAL, ControlSeverity.MAJOR}:
                self.capa_required = True
            self.status = CheckStatus.FAIL
        elif self.status == CheckStatus.NOT_CHECKED:
            self.status = CheckStatus.PASS
        return m

    def finalize(self) -> CheckStatus:
        if len(self.measurements) < self.sampling_plan.sample_count:
            raise QCControlError('INSPECTION_SAMPLES_INCOMPLETE')
        statuses = [m.status for m in self.measurements]
        self.status = CheckStatus.PASS if self.sampling_plan.passes(statuses) else CheckStatus.FAIL
        if self.status == CheckStatus.FAIL:
            self.capa_required = True
        return self.status

    def apply_disposition(self, disposition: Disposition, actor_id: int, *, evidence_ref: Optional[str] = None, reason: Optional[str] = None):
        if actor_id <= 0: raise QCControlError('INVALID_QC_ACTOR')
        if self.status == CheckStatus.NOT_CHECKED: raise QCControlError('QC_NOT_FINALIZED')
        if disposition == Disposition.RELEASE and self.status != CheckStatus.PASS:
            raise QCControlError('RELEASE_REQUIRES_QC_PASS')
        if disposition in {Disposition.REWORK, Disposition.REJECT, Disposition.SCRAP, Disposition.HOLD} and not reason:
            raise QCControlError('DISPOSITION_REASON_REQUIRED')
        self.disposition = disposition
        self.released_by = actor_id

@dataclass(frozen=True)
class OilTPCReading:
    batch_id: int
    reading_pct: Decimal
    limit_pct: Decimal = Decimal('25')
    checked_by: Optional[int] = None

    def __post_init__(self):
        if self.batch_id <= 0: raise QCControlError('INVALID_BATCH_ID')
        if q(self.reading_pct) < 0 or q(self.limit_pct) <= 0: raise QCControlError('INVALID_TPC_READING')

    @property
    def status(self) -> CheckStatus:
        return CheckStatus.PASS if q(self.reading_pct) <= q(self.limit_pct) else CheckStatus.FAIL

@dataclass(frozen=True)
class WaterTest:
    test_id: str
    source_code: str
    test_date: str
    status: CheckStatus
    lab_report_ref: Optional[str] = None

@dataclass(frozen=True)
class ProcessDeviation:
    batch_id: int
    stage_code: str
    parameter_code: str
    actual_value: Decimal
    reason: str
    severity: ControlSeverity = ControlSeverity.MAJOR
    capa_required: bool = True

@dataclass
class CAPARecord:
    capa_id: str
    source_type: str
    source_id: str
    description: str
    owner_id: Optional[int] = None
    due_date: Optional[str] = None
    status: str = 'OPEN'
    root_cause: Optional[str] = None
    corrective_action: Optional[str] = None
    preventive_action: Optional[str] = None

    def close(self):
        if not self.root_cause or not self.corrective_action:
            raise QCControlError('CAPA_ROOT_CAUSE_AND_CORRECTIVE_ACTION_REQUIRED')
        self.status = 'CLOSED'

def finalize_production_qc(*, inspections: list[QCInspection], oil_reading: Optional[OilTPCReading] = None, deviations: list[ProcessDeviation] | None = None) -> dict:
    deviations = deviations or []
    failures = []
    holds = []
    for i in inspections:
        i.finalize()
        if i.status == CheckStatus.FAIL: failures.append(i.inspection_id)
    if oil_reading is not None and oil_reading.status == CheckStatus.FAIL:
        failures.append(f'OIL_TPC:{oil_reading.batch_id}')
    for d in deviations:
        if d.severity in {ControlSeverity.CRITICAL, ControlSeverity.MAJOR}: failures.append(f'DEV:{d.stage_code}:{d.parameter_code}')
    status = CheckStatus.FAIL if failures else CheckStatus.PASS
    if any(i.disposition == Disposition.HOLD for i in inspections): holds.append('INSPECTION_HOLD')
    if holds: status = CheckStatus.HOLD
    return {'status':status.value,'failures':failures,'holds':holds,'capa_required':bool(failures or any(i.capa_required for i in inspections))}
