from __future__ import annotations
from decimal import Decimal
from sqlalchemy import select
from app.db.models import InventoryLot, InventoryLedger
from app.db.models_v24 import ProductionBatch, ProductionRecord
from app.db.models_v26 import ProductionMaterialIssue, ProductionWipLot, ProductionWipMovement, PackingRun, PackingMaterialIssue, ProductionFgOutput, ProductionWastage
from app.sync.domain_integration_v20 import emit, EVENTS

ROLE_WRITE = {'FACTORY','MANAGER','MANAGEMENT','SUPER_ADMIN'}
ROLE_WASTAGE = {'FACTORY','QC','MANAGER','MANAGEMENT','SUPER_ADMIN'}

def _positive(q):
    q=Decimal(str(q))
    if q <= 0: raise ValueError('QTY_MUST_BE_POSITIVE')
    return q

def _check_role(role, allowed):
    if role not in allowed: raise PermissionError('INSUFFICIENT_ROLE')

def create_wip_output(db, *, org_id, entity_id, batch_id, warehouse_code, good_qty_kg, actor_id, actor_role, wip_batch_no):
    _check_role(actor_role, ROLE_WRITE); q=_positive(good_qty_kg)
    batch=db.execute(select(ProductionBatch).where(ProductionBatch.id==batch_id, ProductionBatch.organization_id==org_id, ProductionBatch.entity_id==entity_id)).scalar_one()
    if batch.status not in {'PLANNED','IN_PROGRESS','COMPLETED'}: raise ValueError('INVALID_BATCH_STATUS')
    existing=db.execute(select(ProductionWipLot).where(ProductionWipLot.entity_id==entity_id, ProductionWipLot.wip_batch_no==wip_batch_no)).scalar_one_or_none()
    if existing: raise ValueError('DUPLICATE_WIP_BATCH')
    w=ProductionWipLot(organization_id=org_id,entity_id=entity_id,batch_id=batch_id,product_id=batch.product_id,warehouse_code=warehouse_code,wip_batch_no=wip_batch_no,qty_kg=q,qty_available_kg=q,created_by=actor_id)
    db.add(w); db.flush()
    batch.actual_qty_kg = Decimal(batch.actual_qty_kg or 0) + q
    batch.status='COMPLETED'
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_BATCH',aggregate_id=batch.batch_no,event_name='PRODUCTION_WIP_CREATED',operation='UPDATE',actor_user_id=actor_id,payload={'batch_id':batch.id,'wip_lot_id':w.id,'qty_kg':str(q),'wip_batch_no':wip_batch_no})
    return w

def issue_material(db, *, org_id, entity_id, batch_id, warehouse_code, sku_id, lot_id, qty_kg, actor_id, actor_role, issue_type='RM'):
    _check_role(actor_role, ROLE_WRITE); q=_positive(qty_kg)
    lot=db.execute(select(InventoryLot).where(InventoryLot.id==lot_id,InventoryLot.organization_id==org_id,InventoryLot.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not lot: raise ValueError('LOT_NOT_FOUND')
    if lot.warehouse_code != warehouse_code or lot.sku_id != sku_id: raise ValueError('LOT_SCOPE_MISMATCH')
    avail=Decimal(lot.qty_available or 0)-Decimal(lot.qty_reserved or 0)
    if q > avail: raise ValueError('INSUFFICIENT_AVAILABLE_STOCK')
    row=ProductionMaterialIssue(organization_id=org_id,entity_id=entity_id,batch_id=batch_id,sku_id=sku_id,lot_id=lot_id,warehouse_code=warehouse_code,qty_kg=q,issue_type=issue_type,created_by=actor_id)
    lot.qty_available=Decimal(lot.qty_available)-q
    db.add(row); db.flush()
    db.add(InventoryLedger(organization_id=org_id,entity_id=entity_id,lot_id=lot_id,txn_type='ISSUE_TO_PRODUCTION',qty=-q,reference_type='PRODUCTION_BATCH',reference_id=str(batch_id)))
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_BATCH',aggregate_id=str(batch_id),event_name='PRODUCTION_MATERIAL_ISSUED',operation='UPDATE',actor_user_id=actor_id,payload={'lot_id':lot_id,'sku_id':sku_id,'qty_kg':str(q),'issue_type':issue_type})
    return row

def create_packing_run(db, *, org_id, entity_id, batch_id, wip_lot_id, sku_id, fg_warehouse_code, planned_qty_kg, packing_no, actor_id, actor_role):
    _check_role(actor_role, ROLE_WRITE); q=_positive(planned_qty_kg)
    w=db.execute(select(ProductionWipLot).where(ProductionWipLot.id==wip_lot_id,ProductionWipLot.organization_id==org_id,ProductionWipLot.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not w: raise ValueError('WIP_LOT_NOT_FOUND')
    if q > Decimal(w.qty_available_kg): raise ValueError('INSUFFICIENT_WIP')
    dup=db.execute(select(PackingRun).where(PackingRun.entity_id==entity_id,PackingRun.packing_no==packing_no)).scalar_one_or_none()
    if dup: raise ValueError('DUPLICATE_PACKING_NO')
    p=PackingRun(organization_id=org_id,entity_id=entity_id,batch_id=batch_id,wip_lot_id=wip_lot_id,sku_id=sku_id,fg_warehouse_code=fg_warehouse_code,planned_qty_kg=q,packing_no=packing_no,created_by=actor_id)
    w.qty_available_kg=Decimal(w.qty_available_kg)-q
    db.add(p); db.flush()
    db.add(ProductionWipMovement(organization_id=org_id,entity_id=entity_id,wip_lot_id=wip_lot_id,qty_kg=-q,movement_type='ISSUE_TO_PACKING',reference_type='PACKING_RUN',reference_id=str(p.id),created_by=actor_id))
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PACKING_RUN',aggregate_id=str(p.id),event_name='PACKING_RUN_CREATED',operation='CREATE',actor_user_id=actor_id,payload={'packing_no':packing_no,'batch_id':batch_id,'wip_lot_id':wip_lot_id,'sku_id':sku_id,'planned_qty_kg':str(q)})
    return p

def issue_packaging(db, *, org_id, entity_id, packing_run_id, warehouse_code, sku_id, lot_id, qty_base, actor_id, actor_role):
    _check_role(actor_role, ROLE_WRITE); q=_positive(qty_base)
    lot=db.execute(select(InventoryLot).where(InventoryLot.id==lot_id,InventoryLot.organization_id==org_id,InventoryLot.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not lot: raise ValueError('LOT_NOT_FOUND')
    if lot.warehouse_code != warehouse_code or lot.sku_id != sku_id: raise ValueError('LOT_SCOPE_MISMATCH')
    avail=Decimal(lot.qty_available or 0)-Decimal(lot.qty_reserved or 0)
    if q>avail: raise ValueError('INSUFFICIENT_AVAILABLE_STOCK')
    lot.qty_available=Decimal(lot.qty_available)-q
    row=PackingMaterialIssue(organization_id=org_id,entity_id=entity_id,packing_run_id=packing_run_id,sku_id=sku_id,lot_id=lot_id,warehouse_code=warehouse_code,qty_base=q,created_by=actor_id)
    db.add(row); db.flush()
    db.add(InventoryLedger(organization_id=org_id,entity_id=entity_id,lot_id=lot_id,txn_type='ISSUE_TO_PACKING',qty=-q,reference_type='PACKING_RUN',reference_id=str(packing_run_id)))
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PACKING_RUN',aggregate_id=str(packing_run_id),event_name='PACKAGING_MATERIAL_ISSUED',operation='UPDATE',actor_user_id=actor_id,payload={'lot_id':lot_id,'sku_id':sku_id,'qty_base':str(q)})
    return row

def complete_packing(db, *, org_id, entity_id, packing_run_id, good_qty_kg, pack_qty, reject_qty_kg, expiry_date, actor_id, actor_role, batch_no):
    _check_role(actor_role, ROLE_WRITE); good=_positive(good_qty_kg); reject=Decimal(str(reject_qty_kg or 0)); packs=_positive(pack_qty)
    if reject < 0: raise ValueError('INVALID_REJECT_QTY')
    p=db.execute(select(PackingRun).where(PackingRun.id==packing_run_id,PackingRun.organization_id==org_id,PackingRun.entity_id==entity_id).with_for_update()).scalar_one_or_none()
    if not p: raise ValueError('PACKING_RUN_NOT_FOUND')
    if p.status=='COMPLETED': raise ValueError('PACKING_ALREADY_COMPLETED')
    if good+reject > p.planned_qty_kg: raise ValueError('OUTPUT_EXCEEDS_ISSUED_WIP')
    # reuse/create FG lot in target warehouse, stock quantity is kg at the valuation layer
    lot=db.execute(select(InventoryLot).where(InventoryLot.organization_id==org_id,InventoryLot.entity_id==entity_id,InventoryLot.warehouse_code==p.fg_warehouse_code,InventoryLot.sku_id==p.sku_id,InventoryLot.batch_no==batch_no)).scalar_one_or_none()
    if not lot:
        lot=InventoryLot(organization_id=org_id,entity_id=entity_id,warehouse_code=p.fg_warehouse_code,sku_id=p.sku_id,batch_no=batch_no,expiry_date=expiry_date,qty_available=0,qty_reserved=0)
        db.add(lot); db.flush()
    lot.qty_available=Decimal(lot.qty_available)+good
    if expiry_date: lot.expiry_date=expiry_date
    p.actual_good_qty_kg=good; p.reject_qty_kg=reject; p.status='COMPLETED'
    out=ProductionFgOutput(organization_id=org_id,entity_id=entity_id,packing_run_id=packing_run_id,sku_id=p.sku_id,lot_id=lot.id,batch_no=batch_no,good_qty_kg=good,good_pack_qty=packs,reject_qty_kg=reject,expiry_date=expiry_date,created_by=actor_id)
    db.add(out); db.flush()
    db.add(InventoryLedger(organization_id=org_id,entity_id=entity_id,lot_id=lot.id,txn_type='PACKING_OUTPUT',qty=good,reference_type='PACKING_RUN',reference_id=str(packing_run_id)))
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PACKING_RUN',aggregate_id=str(packing_run_id),event_name='PACKING_COMPLETED',operation='UPDATE',actor_user_id=actor_id,payload={'sku_id':p.sku_id,'good_qty_kg':str(good),'pack_qty':str(packs),'reject_qty_kg':str(reject),'lot_id':lot.id,'batch_no':batch_no})
    return out

def record_wastage(db, *, org_id, entity_id, batch_id, packing_run_id, qty_kg, reason_code, actor_id, actor_role, authorized_by=None):
    _check_role(actor_role, ROLE_WASTAGE); q=_positive(qty_kg)
    if actor_role not in {'MANAGER','MANAGEMENT','SUPER_ADMIN'} and authorized_by is None:
        raise PermissionError('WASTAGE_AUTHORIZATION_REQUIRED')
    row=ProductionWastage(organization_id=org_id,entity_id=entity_id,batch_id=batch_id,packing_run_id=packing_run_id,qty_kg=q,reason_code=reason_code,status='AUTHORIZED' if authorized_by else 'RECORDED',authorized_by=authorized_by,created_by=actor_id)
    db.add(row); db.flush()
    emit(db,org_id=org_id,entity_id=entity_id,aggregate_type='PRODUCTION_BATCH',aggregate_id=str(batch_id),event_name='PRODUCTION_WASTAGE_RECORDED',operation='UPDATE',actor_user_id=actor_id,payload={'wastage_id':row.id,'qty_kg':str(q),'reason_code':reason_code,'packing_run_id':packing_run_id})
    return row
