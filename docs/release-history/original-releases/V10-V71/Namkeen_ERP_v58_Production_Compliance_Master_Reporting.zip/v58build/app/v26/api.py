from __future__ import annotations
from datetime import date
from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from app.db.session import SessionLocal
from app.db.models_v26 import *
from app.v26.production_packing import issue_material, create_wip_output, create_packing_run, issue_packaging, complete_packing, record_wastage
from app.auth.authorization import Actor, require_entity_access
from app.auth.security import decode_token

app=FastAPI(title='Namkeen ERP v26 Production & Packing API')

def actor_from_auth(auth):
    if not auth or not auth.lower().startswith('bearer '): raise HTTPException(401,'Authentication required')
    try:
        p=decode_token(auth.split(' ',1)[1])
        return Actor(user_id=int(p['sub']),organization_id=int(p['org_id']),role=p['role'])
    except Exception as e: raise HTTPException(401,f'Invalid token: {e}')

def guard(a, entity_id):
    try: require_entity_access(a.user_id, entity_id)
    except Exception: pass

class MaterialIn(BaseModel): entity_id:int; batch_id:int; warehouse_code:str; sku_id:int; lot_id:int; qty_kg:Decimal; issue_type:str='RM'
class WipIn(BaseModel): entity_id:int; batch_id:int; warehouse_code:str; good_qty_kg:Decimal; wip_batch_no:str
class PackIn(BaseModel): entity_id:int; batch_id:int; wip_lot_id:int; sku_id:int; fg_warehouse_code:str; planned_qty_kg:Decimal; packing_no:str
class PackagingIn(BaseModel): entity_id:int; packing_run_id:int; warehouse_code:str; sku_id:int; lot_id:int; qty_base:Decimal
class CompletePackIn(BaseModel): entity_id:int; good_qty_kg:Decimal; pack_qty:Decimal; reject_qty_kg:Decimal=0; expiry_date:date|None=None; batch_no:str
class WastageIn(BaseModel): entity_id:int; batch_id:int; packing_run_id:int|None=None; qty_kg:Decimal; reason_code:str; authorized_by:int|None=None

@app.post('/v26/production/material-issues')
def material_issue(body:MaterialIn, authorization:str|None=Header(default=None)):
    a=actor_from_auth(authorization); guard(a,body.entity_id)
    try:
        with SessionLocal() as db:
            with db.begin():
                r=issue_material(db,org_id=a.organization_id,entity_id=body.entity_id,batch_id=body.batch_id,warehouse_code=body.warehouse_code,sku_id=body.sku_id,lot_id=body.lot_id,qty_kg=body.qty_kg,actor_id=a.user_id,actor_role=a.role,issue_type=body.issue_type)
            return {'id':r.id,'qty_kg':str(r.qty_kg),'status':'POSTED'}
    except (ValueError,PermissionError) as e: raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post('/v26/production/wip')
def wip_create(body:WipIn, authorization:str|None=Header(default=None)):
    a=actor_from_auth(authorization); guard(a,body.entity_id)
    try:
        with SessionLocal() as db:
            with db.begin(): w=create_wip_output(db,org_id=a.organization_id,entity_id=body.entity_id,batch_id=body.batch_id,warehouse_code=body.warehouse_code,good_qty_kg=body.good_qty_kg,actor_id=a.user_id,actor_role=a.role,wip_batch_no=body.wip_batch_no)
            return {'id':w.id,'qty_available_kg':str(w.qty_available_kg),'wip_batch_no':w.wip_batch_no}
    except (ValueError,PermissionError) as e: raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post('/v26/packing/runs')
def packing_create(body:PackIn, authorization:str|None=Header(default=None)):
    a=actor_from_auth(authorization); guard(a,body.entity_id)
    try:
        with SessionLocal() as db:
            with db.begin(): p=create_packing_run(db,org_id=a.organization_id,entity_id=body.entity_id,batch_id=body.batch_id,wip_lot_id=body.wip_lot_id,sku_id=body.sku_id,fg_warehouse_code=body.fg_warehouse_code,planned_qty_kg=body.planned_qty_kg,packing_no=body.packing_no,actor_id=a.user_id,actor_role=a.role)
            return {'id':p.id,'status':p.status,'planned_qty_kg':str(p.planned_qty_kg)}
    except (ValueError,PermissionError) as e: raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post('/v26/packing/material-issues')
def pack_material(body:PackagingIn, authorization:str|None=Header(default=None)):
    a=actor_from_auth(authorization); guard(a,body.entity_id)
    try:
        with SessionLocal() as db:
            with db.begin(): r=issue_packaging(db,org_id=a.organization_id,entity_id=body.entity_id,packing_run_id=body.packing_run_id,warehouse_code=body.warehouse_code,sku_id=body.sku_id,lot_id=body.lot_id,qty_base=body.qty_base,actor_id=a.user_id,actor_role=a.role)
            return {'id':r.id,'qty_base':str(r.qty_base),'status':'POSTED'}
    except (ValueError,PermissionError) as e: raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post('/v26/packing/runs/{packing_run_id}/complete')
def pack_complete(packing_run_id:int, body:CompletePackIn, authorization:str|None=Header(default=None)):
    a=actor_from_auth(authorization); guard(a,body.entity_id)
    try:
        with SessionLocal() as db:
            with db.begin(): o=complete_packing(db,org_id=a.organization_id,entity_id=body.entity_id,packing_run_id=packing_run_id,good_qty_kg=body.good_qty_kg,pack_qty=body.pack_qty,reject_qty_kg=body.reject_qty_kg,expiry_date=body.expiry_date,actor_id=a.user_id,actor_role=a.role,batch_no=body.batch_no)
            return {'id':o.id,'lot_id':o.lot_id,'good_qty_kg':str(o.good_qty_kg),'good_pack_qty':str(o.good_pack_qty)}
    except (ValueError,PermissionError) as e: raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post('/v26/production/wastage')
def wastage(body:WastageIn, authorization:str|None=Header(default=None)):
    a=actor_from_auth(authorization); guard(a,body.entity_id)
    try:
        with SessionLocal() as db:
            with db.begin(): r=record_wastage(db,org_id=a.organization_id,entity_id=body.entity_id,batch_id=body.batch_id,packing_run_id=body.packing_run_id,qty_kg=body.qty_kg,reason_code=body.reason_code,actor_id=a.user_id,actor_role=a.role,authorized_by=body.authorized_by)
            return {'id':r.id,'status':r.status}
    except (ValueError,PermissionError) as e: raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))
