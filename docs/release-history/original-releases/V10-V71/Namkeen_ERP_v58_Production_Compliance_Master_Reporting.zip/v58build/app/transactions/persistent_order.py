from __future__ import annotations
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models import SalesOrder, SalesOrderLine, InventoryLot, InventoryLedger, AuditEvent, Customer
from app.db.models_v16 import OrderAllocation
from app.services.order_posting import create_order, approve_order, verify_payment, clear_cheque, _audit
from app.services.inventory import InventoryError

def reserve_order_persistent(db: Session, *, order_id: int, warehouse_code: str, actor_user):
    order = db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    if order.status != "READY_FOR_STOCK_CHECK":
        raise ValueError(f"ORDER_NOT_READY:{order.status}")
    if actor_user.role not in {"STORE","MANAGER","MANAGEMENT","SUPER_ADMIN"}:
        raise PermissionError("STOCK_RESERVATION_ROLE_REQUIRED")
    lines = db.execute(select(SalesOrderLine).where(SalesOrderLine.order_id==order.id)).scalars().all()
    allocations=[]
    for line in lines:
        qty=Decimal(line.qty)
        lots=db.execute(select(InventoryLot).where(
            InventoryLot.entity_id==order.entity_id,
            InventoryLot.warehouse_code==warehouse_code,
            InventoryLot.sku_id==line.sku_id,
            (InventoryLot.qty_available-InventoryLot.qty_reserved)>0
        ).order_by(InventoryLot.expiry_date.asc().nulls_last(),InventoryLot.id.asc()).with_for_update()).scalars().all()
        remain=qty
        for lot in lots:
            free=Decimal(lot.qty_available)-Decimal(lot.qty_reserved)
            take=min(free, remain)
            if take>0:
                lot.qty_reserved += take
                allocations.append((line.id, lot, take))
                remain -= take
            if remain <= 0: break
        if remain > 0:
            raise InventoryError(f"STOCK_SHORTAGE:{remain}")
    for line_id, lot, take in allocations:
        existing=db.execute(select(OrderAllocation).where(OrderAllocation.order_line_id==line_id,OrderAllocation.lot_id==lot.id)).scalar_one_or_none()
        if existing:
            existing.qty += take
            existing.status="RESERVED"
        else:
            db.add(OrderAllocation(organization_id=order.organization_id,entity_id=order.entity_id,
                                   order_id=order.id,order_line_id=line_id,lot_id=lot.id,qty=take,status="RESERVED"))
    order.status="STOCK_RESERVED"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,
           action="STOCK_RESERVED",ref_type="SALES_ORDER",ref_id=order.order_no,after={"warehouse":warehouse_code})
    return order

def dispatch_order_persistent(db: Session, *, order_id: int, actor_user):
    if actor_user.role not in {"STORE","MANAGER","MANAGEMENT","SUPER_ADMIN"}:
        raise PermissionError("DISPATCH_ROLE_REQUIRED")
    order=db.execute(select(SalesOrder).where(SalesOrder.id==order_id).with_for_update()).scalar_one()
    if order.status!="STOCK_RESERVED":
        raise ValueError(f"ORDER_NOT_DISPATCH_READY:{order.status}")
    allocs=db.execute(select(OrderAllocation).where(OrderAllocation.order_id==order.id,OrderAllocation.status=="RESERVED").with_for_update()).scalars().all()
    if not allocs:
        raise ValueError("NO_STOCK_ALLOCATIONS")
    total=Decimal("0")
    for a in allocs:
        lot=db.execute(select(InventoryLot).where(InventoryLot.id==a.lot_id).with_for_update()).scalar_one()
        qty=Decimal(a.qty)
        if Decimal(lot.qty_reserved)<qty or Decimal(lot.qty_available)<qty:
            raise InventoryError(f"STOCK_OR_RESERVATION_ERROR:{lot.batch_no}")
        lot.qty_reserved-=qty; lot.qty_available-=qty
        db.add(InventoryLedger(organization_id=order.organization_id,entity_id=order.entity_id,lot_id=lot.id,
                               txn_type="DISPATCH",qty=-qty,reference_type="SALES_ORDER",reference_id=order.order_no))
        a.status="DISPATCHED"
        total+=qty
    order.status="DISPATCHED"
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,
           action="DISPATCH_POSTED",ref_type="SALES_ORDER",ref_id=order.order_no,after={"qty":str(total)})
    return order, total
