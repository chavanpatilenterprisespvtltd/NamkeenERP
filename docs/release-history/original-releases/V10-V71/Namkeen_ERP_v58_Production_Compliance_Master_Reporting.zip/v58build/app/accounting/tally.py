from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol

@dataclass(frozen=True)
class AccountingDocument:
    doc_type: str
    doc_no: str
    doc_date: str
    party: str
    taxable_value: Decimal
    gst: Decimal
    total: Decimal

class AccountingAdapter(Protocol):
    def preview(self, docs: list[AccountingDocument]) -> list[dict]: ...
    def export(self, docs: list[AccountingDocument]) -> str: ...

class TallyXmlAdapter:
    """Adapter seam; actual TallyPrime endpoint/file format should be finalized during deployment/UAT."""
    def preview(self, docs):
        return [{"doc_no":d.doc_no,"doc_type":d.doc_type,"party":d.party,"total":str(d.total)} for d in docs]
    def export(self, docs):
        lines=["<ENVELOPE>","<BODY><DATA>"]
        for d in docs:
            lines += [f"<DOCUMENT><TYPE>{d.doc_type}</TYPE><NUMBER>{d.doc_no}</NUMBER><DATE>{d.doc_date}</DATE>",
                      f"<PARTY>{d.party}</PARTY><TAXABLE>{d.taxable_value}</TAXABLE><GST>{d.gst}</GST><TOTAL>{d.total}</TOTAL></DOCUMENT>"]
        lines += ["</DATA></BODY>","</ENVELOPE>"]
        return "".join(lines)
