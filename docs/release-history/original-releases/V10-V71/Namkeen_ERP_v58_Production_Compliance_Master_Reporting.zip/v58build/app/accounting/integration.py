import hashlib, json
from dataclasses import dataclass
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session

@dataclass(frozen=True)
class IntegrationResult:
    integration_code:str; idempotency_key:str; status:str; request_hash:str; response_hash:str|None=None; message:str|None=None

def run_idempotent(db:Session, *, organization_id:int, integration_code:str, idempotency_key:str, payload:dict, handler):
    from app.db.integration_models import IntegrationRun
    raw=json.dumps(payload,sort_keys=True,separators=(",",":")); req_hash=hashlib.sha256(raw.encode()).hexdigest()
    existing=db.execute(select(IntegrationRun).where(IntegrationRun.organization_id==organization_id,IntegrationRun.integration_code==integration_code,IntegrationRun.idempotency_key==idempotency_key).with_for_update()).scalar_one_or_none()
    if existing and existing.status=="SUCCESS": return IntegrationResult(integration_code,idempotency_key,"DUPLICATE",existing.request_hash,existing.response_hash,"Already applied")
    run=existing or IntegrationRun(organization_id=organization_id,integration_code=integration_code,idempotency_key=idempotency_key,request_hash=req_hash,status="RUNNING",started_at=datetime.now(timezone.utc))
    if existing: run.status="RUNNING"; run.request_hash=req_hash
    else: db.add(run)
    db.flush()
    try:
        response=handler(payload); out=json.dumps(response,sort_keys=True,separators=(",",":")); run.status="SUCCESS"; run.response_hash=hashlib.sha256(out.encode()).hexdigest(); run.completed_at=datetime.now(timezone.utc)
        return IntegrationResult(integration_code,idempotency_key,"SUCCESS",req_hash,run.response_hash)
    except Exception as e:
        run.status="FAILED"; run.error_message=str(e); run.completed_at=datetime.now(timezone.utc); raise
