from __future__ import annotations
from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.db.session import transaction
from app.v38.collections_credit import CreditControlProfile
from app.v39.pricing import PricingPolicy, CustomerPriceRule, Promotion
from app.v40.transaction import SalesLineInput, SalesTransactionRequest
from .transaction import post_persistent_sales_transaction, PersistentTransactionError

app=FastAPI(title='Namkeen ERP API v41 — Persistent End-to-End Sales Posting', version='41.0')

class LineIn(BaseModel):
    sku_id:int; quantity_kg:Decimal; negotiated_unit_price:Decimal; actual_cost_per_unit:Decimal; policy:dict
    customer_rule:dict|None=None; promotion:dict|None=None; gst_pct:Decimal=Decimal('0'); tax_inclusive:bool=False
class TxnIn(BaseModel):
    organization_id:int; entity_id:int; customer_id:int; salesperson_id:int; order_no:str; transaction_date:date
    payment_mode:str; payment_state:str; credit_limit:Decimal; outstanding:Decimal; overdue:Decimal=Decimal('0'); overdue_days:int=0; credit_days:int=0
    block_threshold:Decimal=Decimal('0'); hard_block:bool=False; warehouse_code:str; lines:list[LineIn]
    cash_evidence_ref:str|None=None; cheque_ref:str|None=None; management_override:bool=False; idempotency_key:str|None=None

def _date(v): return v if isinstance(v,date) else date.fromisoformat(v)
def _policy(d):
    x=dict(d); x['effective_from']=_date(x['effective_from']); x['effective_to']=_date(x['effective_to']) if x.get('effective_to') else None
    for k in ('target_price','floor_price','max_discount_pct'): x[k]=Decimal(str(x[k]))
    return PricingPolicy(**x)
def _cr(d):
    if not d:return None
    return CustomerPriceRule(int(d['rule_id']),int(d['sku_id']),int(d['customer_id']),Decimal(str(d['unit_price'])),_date(d['effective_from']),_date(d['effective_to']) if d.get('effective_to') else None,Decimal(str(d.get('min_qty','0'))),bool(d.get('active',True)))
def _promo(d):
    if not d:return None
    return Promotion(int(d['promotion_id']),d['name'],int(d['sku_id']),d['promo_type'],Decimal(str(d['value'])),_date(d['start_date']),_date(d['end_date']),Decimal(str(d.get('min_qty','0'))),Decimal(str(d.get('buy_qty','0'))),Decimal(str(d.get('get_qty','0'))),Decimal(str(d['max_discount_per_unit'])) if d.get('max_discount_per_unit') is not None else None,bool(d.get('active',True)))

@app.get('/v41/health')
def health(): return {'version':'41.0','service':'persistent-end-to-end-sales-posting'}

@app.post('/v41/sales/post')
def post_sale(b:TxnIn):
    try:
        lines=[SalesLineInput(x.sku_id,x.quantity_kg,x.negotiated_unit_price,x.actual_cost_per_unit,_policy(x.policy),_cr(x.customer_rule),_promo(x.promotion),x.gst_pct,x.tax_inclusive) for x in b.lines]
        req=SalesTransactionRequest(b.organization_id,b.entity_id,b.customer_id,b.salesperson_id,b.order_no,b.transaction_date,b.payment_mode,b.payment_state,
            CreditControlProfile(b.customer_id,b.credit_limit,b.outstanding,b.overdue,b.overdue_days,b.credit_days,b.block_threshold,b.hard_block),tuple(lines),b.warehouse_code,b.cash_evidence_ref,b.cheque_ref,b.management_override,b.idempotency_key)
        # v41 test actor is a minimal role-bearing object; production route should resolve authenticated actor from JWT.
        class Actor: pass
        actor=Actor(); actor.id=b.salesperson_id; actor.role='STORE'
        with transaction() as db:
            r=post_persistent_sales_transaction(db,req=req,actor_user=actor)
        return r.__dict__ | {'taxable_total':str(r.taxable_total),'tax_total':str(r.tax_total),'grand_total':str(r.grand_total),'dispatched_qty_kg':str(r.dispatched_qty_kg)}
    except PersistentTransactionError as e: raise HTTPException(400,str(e))
    except Exception as e: raise HTTPException(500,f'PERSISTENT_POST_FAILED:{e}')
