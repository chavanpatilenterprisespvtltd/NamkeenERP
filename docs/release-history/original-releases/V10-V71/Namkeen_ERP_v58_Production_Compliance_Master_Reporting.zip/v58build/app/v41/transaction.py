from __future__ import annotations
import json
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_HALF_UP
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.db.models import Customer, SalesOrder, SalesOrderLine, Payment, InventoryLot, InventoryLedger, AuditEvent
from app.db.models_v41 import PersistentSalesTxnRun, SalesInvoiceV41, SalesInvoiceLineV41, CustomerReceivableV41, ReceiptAllocationV41, AccountingOutboxV41
from app.v40.transaction import SalesTransactionRequest, orchestrate_transaction
from app.v40.transaction import SalesTransactionError
from app.db.models_v16 import OrderAllocation
from app.sync.domain_events import record_change

Q2=Decimal('0.01')
class PersistentTransactionError(ValueError): pass
@dataclass(frozen=True)
class PersistentPostedResult:
    transaction_run_id:int; order_id:int; order_no:str; invoice_id:int; invoice_no:str; state:str
    taxable_total:Decimal; tax_total:Decimal; grand_total:Decimal; dispatched_qty_kg:Decimal
    accounting_outbox_id:int; duplicate:bool=False

def money(x): return Decimal(str(x)).quantize(Q2, rounding=ROUND_HALF_UP)

def _next_pk(db:Session, model):
    if db.bind is not None and db.bind.dialect.name == 'sqlite':
        v=db.execute(select(func.max(model.id))).scalar_one()
        return int(v or 0)+1
    return None

def _add(db, obj, model):
    pk=_next_pk(db,model)
    if pk is not None: obj.id=pk
    db.add(obj); db.flush(); return obj

def _audit(db, *, org_id, entity_id, user_id, action, ref_type, ref_id, after=None):
    _add(db, AuditEvent(organization_id=org_id,entity_id=entity_id,user_id=user_id,action=action,reference_type=ref_type,reference_id=ref_id,after_json=None if after is None else json.dumps(after,default=str)), AuditEvent)

def _reserve_and_dispatch(db:Session, order:SalesOrder, lines:list[SalesOrderLine], warehouse_code:str, actor_user):
    if actor_user.role not in {'STORE','MANAGER','MANAGEMENT','SUPER_ADMIN'}: raise PermissionError('DISPATCH_ROLE_REQUIRED')
    allocations=[]; total=Decimal('0')
    for line in lines:
        lots=db.execute(select(InventoryLot).where(InventoryLot.entity_id==order.entity_id,InventoryLot.organization_id==order.organization_id,InventoryLot.warehouse_code==warehouse_code,InventoryLot.sku_id==line.sku_id,(InventoryLot.qty_available-InventoryLot.qty_reserved)>0).order_by(InventoryLot.expiry_date.asc().nulls_last(),InventoryLot.id.asc()).with_for_update()).scalars().all()
        remain=Decimal(line.qty)
        for lot in lots:
            free=Decimal(lot.qty_available)-Decimal(lot.qty_reserved)
            take=min(free,remain)
            if take<=0: continue
            lot.qty_reserved=Decimal(lot.qty_reserved)+take
            alloc=_add(db,OrderAllocation(organization_id=order.organization_id,entity_id=order.entity_id,order_id=order.id,order_line_id=line.id,lot_id=lot.id,qty=take,status='RESERVED'),OrderAllocation)
            allocations.append((alloc,lot,take)); remain-=take
            if remain<=0: break
        if remain>0: raise PersistentTransactionError(f'STOCK_SHORTAGE:{remain}')
    order.status='STOCK_RESERVED'; db.flush()
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,action='STOCK_RESERVED',ref_type='SALES_ORDER',ref_id=order.order_no,after={'warehouse':warehouse_code})
    for alloc,lot,take in allocations:
        if Decimal(lot.qty_reserved)<take or Decimal(lot.qty_available)<take: raise PersistentTransactionError('STOCK_OR_RESERVATION_ERROR')
        lot.qty_reserved=Decimal(lot.qty_reserved)-take
        lot.qty_available=Decimal(lot.qty_available)-take
        _add(db,InventoryLedger(organization_id=order.organization_id,entity_id=order.entity_id,lot_id=lot.id,txn_type='DISPATCH',qty=-take,reference_type='SALES_ORDER',reference_id=order.order_no),InventoryLedger)
        alloc.status='DISPATCHED'; total+=take
    order.status='DISPATCHED'; db.flush()
    _audit(db,org_id=order.organization_id,entity_id=order.entity_id,user_id=actor_user.id,action='DISPATCH_POSTED',ref_type='SALES_ORDER',ref_id=order.order_no,after={'qty':str(total)})
    record_change(db,org_id=order.organization_id,entity_scope_id=order.entity_id,aggregate_type='SALES_ORDER',aggregate_id=order.order_no,operation='UPDATE',event_name='ORDER_DISPATCHED',actor_user_id=actor_user.id,payload={'id':order.id,'status':order.status})
    return total

def post_persistent_sales_transaction(db:Session, *, req:SalesTransactionRequest, actor_user, invoice_no=None)->PersistentPostedResult:
    existing=None
    if req.idempotency_key:
        existing=db.execute(select(PersistentSalesTxnRun).where(PersistentSalesTxnRun.organization_id==req.organization_id,PersistentSalesTxnRun.idempotency_key==req.idempotency_key).with_for_update()).scalar_one_or_none()
        if existing:
            if existing.order_no!=req.order_no: raise PersistentTransactionError('IDEMPOTENCY_KEY_REUSED_FOR_DIFFERENT_ORDER')
            inv=db.get(SalesInvoiceV41,existing.invoice_id); outbox=db.execute(select(AccountingOutboxV41).where(AccountingOutboxV41.transaction_run_id==existing.id)).scalar_one_or_none()
            if not inv or not outbox: raise PersistentTransactionError('IDEMPOTENCY_RECORD_INCOMPLETE')
            return PersistentPostedResult(existing.id,existing.order_id,existing.order_no,inv.id,inv.invoice_no,existing.state,Decimal(inv.taxable_total),Decimal(inv.tax_total),Decimal(inv.grand_total),Decimal('0'),outbox.id,True)
    commercial=orchestrate_transaction(req)
    if commercial.state!='INVOICED': raise PersistentTransactionError(f'COMMERCIAL_GATE:{commercial.state}')
    customer=db.execute(select(Customer).where(Customer.id==req.customer_id,Customer.organization_id==req.organization_id,Customer.entity_id==req.entity_id).with_for_update()).scalar_one_or_none()
    if not customer or not customer.active or customer.approval_status!='APPROVED': raise PersistentTransactionError('CUSTOMER_NOT_APPROVED')
    if db.execute(select(SalesOrder).where(SalesOrder.organization_id==req.organization_id,SalesOrder.order_no==req.order_no)).scalar_one_or_none(): raise PersistentTransactionError('ORDER_NUMBER_EXISTS')
    order=SalesOrder(id=_next_pk(db,SalesOrder),organization_id=req.organization_id,entity_id=req.entity_id,customer_id=req.customer_id,salesperson_id=req.salesperson_id,order_no=req.order_no,status='READY_FOR_STOCK_CHECK',payment_mode=req.payment_mode,payment_state=req.payment_state,credit_state='CLEAR')
    db.add(order); db.flush()
    req_by_sku={x.sku_id:x for x in req.lines}
    db_lines=[]
    for x in commercial.lines:
        q=req_by_sku[x.sku_id]
        row=SalesOrderLine(id=_next_pk(db,SalesOrderLine),order_id=order.id,sku_id=x.sku_id,qty=x.quantity_kg,negotiated_price=x.unit_price,floor_price=q.policy.floor_price,company_cost=q.actual_cost_per_unit)
        db.add(row); db.flush(); db_lines.append(row)
    _audit(db,org_id=req.organization_id,entity_id=req.entity_id,user_id=req.salesperson_id,action='ORDER_CREATED',ref_type='SALES_ORDER',ref_id=req.order_no,after={'status':order.status})
    record_change(db,org_id=req.organization_id,entity_scope_id=req.entity_id,aggregate_type='SALES_ORDER',aggregate_id=req.order_no,operation='CREATE',event_name='SALES_ORDER_CREATED',actor_user_id=req.salesperson_id,payload={'id':order.id,'order_no':order.order_no,'status':order.status,'customer_id':req.customer_id})
    run=PersistentSalesTxnRun(id=_next_pk(db,PersistentSalesTxnRun),organization_id=req.organization_id,entity_id=req.entity_id,order_id=order.id,order_no=req.order_no,idempotency_key=req.idempotency_key,state='ORDER_CREATED')
    db.add(run); db.flush()
    pay_status='CLEARED' if req.payment_mode.upper()=='CHEQUE' else 'VERIFIED'
    payment=Payment(id=_next_pk(db,Payment),organization_id=req.organization_id,entity_id=req.entity_id,order_id=order.id,customer_id=req.customer_id,mode=req.payment_mode,status=pay_status,amount=commercial.invoice_total,reference=req.cheque_ref,proof_file_id=req.cash_evidence_ref,collected_by=req.salesperson_id,verified_by=actor_user.id)
    db.add(payment); db.flush()
    dispatched=_reserve_and_dispatch(db,order,db_lines,req.warehouse_code,actor_user)
    inv_no=invoice_no or req.order_no
    if db.execute(select(SalesInvoiceV41).where(SalesInvoiceV41.organization_id==req.organization_id,SalesInvoiceV41.invoice_no==inv_no)).scalar_one_or_none(): raise PersistentTransactionError('INVOICE_NUMBER_EXISTS')
    inv=SalesInvoiceV41(organization_id=req.organization_id,entity_id=req.entity_id,order_id=order.id,customer_id=req.customer_id,invoice_no=inv_no,taxable_total=commercial.taxable_total,tax_total=commercial.tax_total,grand_total=commercial.invoice_total,status='POSTED')
    _add(db,inv,SalesInvoiceV41)
    for x in commercial.lines: _add(db,SalesInvoiceLineV41(invoice_id=inv.id,sku_id=x.sku_id,qty_kg=x.quantity_kg,unit_price=x.unit_price,taxable_value=x.taxable_value,tax_amount=x.tax_amount),SalesInvoiceLineV41)
    due=datetime.combine(req.transaction_date,datetime.min.time(),tzinfo=timezone.utc)+timedelta(days=req.credit_profile.credit_days)
    ar=_add(db,CustomerReceivableV41(organization_id=req.organization_id,entity_id=req.entity_id,customer_id=req.customer_id,invoice_id=inv.id,original_amount=commercial.invoice_total,outstanding_amount=Decimal('0'),status='PAID',due_date=due),CustomerReceivableV41)
    _add(db,ReceiptAllocationV41(organization_id=req.organization_id,entity_id=req.entity_id,payment_id=payment.id,receivable_id=ar.id,amount=commercial.invoice_total),ReceiptAllocationV41)
    payload={'order_no':req.order_no,'order_id':order.id,'invoice_no':inv_no,'invoice_id':inv.id,'customer_id':req.customer_id,'taxable_total':str(commercial.taxable_total),'tax_total':str(commercial.tax_total),'grand_total':str(commercial.invoice_total),'payment_id':payment.id,'payment_mode':req.payment_mode,'payment_state':payment.status,'dispatched_qty_kg':str(dispatched),'state':'DISPATCHED'}
    idem=req.idempotency_key or f'SALES:{req.order_no}'
    out=_add(db,AccountingOutboxV41(organization_id=req.organization_id,entity_id=req.entity_id,transaction_run_id=run.id,integration_code='TALLY',idempotency_key=idem,payload_json=json.dumps(payload,separators=(',',':')),status='PENDING'),AccountingOutboxV41)
    run.invoice_id=inv.id; run.state='COMMITTED'; run.completed_at=datetime.now(timezone.utc); db.flush()
    record_change(db,org_id=req.organization_id,entity_scope_id=req.entity_id,aggregate_type='SALES_INVOICE',aggregate_id=str(inv.id),operation='CREATE',event_name='SALES_INVOICE_POSTED',actor_user_id=actor_user.id,payload=payload)
    record_change(db,org_id=req.organization_id,entity_scope_id=req.entity_id,aggregate_type='CUSTOMER_RECEIVABLE',aggregate_id=str(ar.id),operation='CREATE',event_name='CUSTOMER_RECEIVABLE_SETTLED',actor_user_id=actor_user.id,payload={'invoice_id':inv.id,'amount':str(commercial.invoice_total)})
    return PersistentPostedResult(run.id,order.id,req.order_no,inv.id,inv_no,'COMMITTED',commercial.taxable_total,commercial.tax_total,commercial.invoice_total,Decimal(dispatched),out.id,False)
