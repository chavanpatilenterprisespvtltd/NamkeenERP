from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Iterable, Optional

Q2 = Decimal('0.01')
Q6 = Decimal('0.000001')


def money(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)


def qty(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q6, rounding=ROUND_HALF_UP)


class CostingError(ValueError):
    pass


class CostComponent(str, Enum):
    RM = 'RM'
    OIL = 'OIL'
    FUEL_WOOD = 'FUEL_WOOD'
    PACKAGING = 'PACKAGING'
    LABOUR = 'LABOUR'
    POWER = 'POWER'
    UTILITIES = 'UTILITIES'
    REWORK = 'REWORK'
    OVERHEAD = 'OVERHEAD'
    OTHER = 'OTHER'


@dataclass(frozen=True)
class CostComponentEntry:
    component: CostComponent
    quantity: Decimal
    unit_cost: Decimal
    amount: Decimal
    reference: Optional[str] = None
    lot_id: Optional[int] = None

    @classmethod
    def build(cls, component: CostComponent, quantity: Decimal, unit_cost: Decimal, *, reference: Optional[str] = None, lot_id: Optional[int] = None) -> 'CostComponentEntry':
        q = qty(quantity); uc = money(unit_cost)
        if q < 0 or uc < 0:
            raise CostingError('NEGATIVE_COMPONENT_INPUT')
        return cls(component, q, uc, money(q * uc), reference, lot_id)


@dataclass(frozen=True)
class StandardCostComponent:
    component: CostComponent
    cost_per_kg_output: Decimal
    expected_input_kg_per_kg_output: Decimal = Decimal('0')

    def __post_init__(self):
        if self.cost_per_kg_output < 0 or self.expected_input_kg_per_kg_output < 0:
            raise CostingError('NEGATIVE_STANDARD_COST')


@dataclass(frozen=True)
class StandardCost:
    standard_cost_id: int
    sku_id: int
    entity_id: int
    effective_from: str
    effective_to: Optional[str]
    components: tuple[StandardCostComponent, ...]

    @property
    def total_cost_per_kg(self) -> Decimal:
        return money(sum((money(x.cost_per_kg_output) for x in self.components), Decimal('0')))


@dataclass(frozen=True)
class BatchCostResult:
    batch_id: int
    sku_id: int
    input_kg: Decimal
    good_output_kg: Decimal
    reject_kg: Decimal
    rework_kg: Decimal
    total_actual_cost: Decimal
    actual_cost_per_good_kg: Decimal
    yield_pct: Decimal
    standard_cost_per_kg: Optional[Decimal]
    standard_cost_for_actual_output: Optional[Decimal]
    total_cost_variance: Optional[Decimal]
    cost_variance_pct: Optional[Decimal]
    component_variances: tuple[tuple[str, Decimal], ...]

    def selling_margin(self, selling_price_per_kg: Decimal) -> tuple[Decimal, Decimal]:
        sp = money(selling_price_per_kg)
        if sp <= 0:
            raise CostingError('INVALID_SELLING_PRICE')
        margin_per_kg = money(sp - self.actual_cost_per_good_kg)
        margin_pct = ((sp - self.actual_cost_per_good_kg) / sp * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP)
        return margin_per_kg, margin_pct


def validate_batch_quantities(*, input_kg: Decimal, good_output_kg: Decimal, reject_kg: Decimal = Decimal('0'), rework_kg: Decimal = Decimal('0')) -> None:
    values = [input_kg, good_output_kg, reject_kg, rework_kg]
    if any(x < 0 for x in values):
        raise CostingError('NEGATIVE_BATCH_QTY')
    if good_output_kg + reject_kg + rework_kg > input_kg + Decimal('0.000001'):
        raise CostingError('OUTPUT_EXCEEDS_INPUT')
    if input_kg == 0 and good_output_kg > 0:
        raise CostingError('GOOD_OUTPUT_WITHOUT_INPUT')


def calculate_batch_cost(*, batch_id: int, sku_id: int, input_kg: Decimal, good_output_kg: Decimal, components: Iterable[CostComponentEntry], reject_kg: Decimal = Decimal('0'), rework_kg: Decimal = Decimal('0'), standard: Optional[StandardCost] = None) -> BatchCostResult:
    validate_batch_quantities(input_kg=input_kg, good_output_kg=good_output_kg, reject_kg=reject_kg, rework_kg=rework_kg)
    if batch_id <= 0 or sku_id <= 0:
        raise CostingError('INVALID_BATCH_OR_SKU')
    component_list = tuple(components)
    if good_output_kg <= 0:
        raise CostingError('GOOD_OUTPUT_REQUIRED_FOR_COST_PER_KG')
    total_actual = money(sum((x.amount for x in component_list), Decimal('0')))
    actual_per_kg = money(total_actual / good_output_kg)
    yield_pct = (good_output_kg / input_kg * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP) if input_kg > 0 else Decimal('0.00')

    std_total = None
    variance = None
    variance_pct = None
    component_variances: list[tuple[str, Decimal]] = []
    if standard:
        if standard.sku_id != sku_id:
            raise CostingError('STANDARD_SKU_MISMATCH')
        std_total = money(standard.total_cost_per_kg * good_output_kg)
        variance = money(total_actual - std_total)
        variance_pct = (variance / std_total * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP) if std_total else None
        actual_by_component = {c: Decimal('0') for c in CostComponent}
        for entry in component_list:
            actual_by_component[entry.component] += entry.amount
        for s in standard.components:
            expected = money(s.cost_per_kg_output * good_output_kg)
            actual = money(actual_by_component[s.component])
            component_variances.append((s.component.value, money(actual - expected)))

    return BatchCostResult(
        batch_id=batch_id,
        sku_id=sku_id,
        input_kg=qty(input_kg),
        good_output_kg=qty(good_output_kg),
        reject_kg=qty(reject_kg),
        rework_kg=qty(rework_kg),
        total_actual_cost=total_actual,
        actual_cost_per_good_kg=actual_per_kg,
        yield_pct=yield_pct,
        standard_cost_per_kg=standard.total_cost_per_kg if standard else None,
        standard_cost_for_actual_output=std_total,
        total_cost_variance=variance,
        cost_variance_pct=variance_pct,
        component_variances=tuple(component_variances),
    )
