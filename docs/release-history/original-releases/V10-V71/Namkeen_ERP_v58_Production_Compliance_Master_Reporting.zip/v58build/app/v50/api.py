from fastapi import APIRouter, HTTPException
from decimal import Decimal
from .costing import CostComponent, CostComponentEntry, StandardCost, StandardCostComponent, calculate_batch_cost

router = APIRouter(prefix='/v50/costing', tags=['v50-costing'])


def _standard(payload: dict):
    s = payload.get('standard')
    if not s:
        return None
    return StandardCost(
        int(s['standard_cost_id']),
        int(s['sku_id']),
        int(s['entity_id']),
        str(s['effective_from']),
        s.get('effective_to'),
        tuple(StandardCostComponent(CostComponent(x['component']), Decimal(str(x['cost_per_kg_output'])), Decimal(str(x.get('expected_input_kg_per_kg_output', '0')))) for x in s.get('components', [])),
    )


@router.post('/batch/calculate')
def batch_calculate(payload: dict):
    try:
        comps = [CostComponentEntry.build(CostComponent(x['component']), Decimal(str(x['quantity'])), Decimal(str(x['unit_cost'])), reference=x.get('reference'), lot_id=x.get('lot_id')) for x in payload.get('components', [])]
        result = calculate_batch_cost(
            batch_id=int(payload['batch_id']),
            sku_id=int(payload['sku_id']),
            input_kg=Decimal(str(payload['input_kg'])),
            good_output_kg=Decimal(str(payload['good_output_kg'])),
            reject_kg=Decimal(str(payload.get('reject_kg', '0'))),
            rework_kg=Decimal(str(payload.get('rework_kg', '0'))),
            components=comps,
            standard=_standard(payload),
        )
        return {
            'batch_id': result.batch_id,
            'sku_id': result.sku_id,
            'total_actual_cost': str(result.total_actual_cost),
            'actual_cost_per_good_kg': str(result.actual_cost_per_good_kg),
            'yield_pct': str(result.yield_pct),
            'standard_cost_per_kg': str(result.standard_cost_per_kg) if result.standard_cost_per_kg is not None else None,
            'standard_cost_for_actual_output': str(result.standard_cost_for_actual_output) if result.standard_cost_for_actual_output is not None else None,
            'total_cost_variance': str(result.total_cost_variance) if result.total_cost_variance is not None else None,
            'cost_variance_pct': str(result.cost_variance_pct) if result.cost_variance_pct is not None else None,
            'component_variances': [{'component': c, 'variance': str(v)} for c, v in result.component_variances],
        }
    except (KeyError, ValueError) as exc:
        raise HTTPException(400, str(exc))
