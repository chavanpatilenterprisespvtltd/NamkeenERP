from decimal import Decimal
from fastapi import FastAPI
from pydantic import BaseModel, Field
from app.v54.production_floor import *

app = FastAPI(title='Namkeen ERP v54 Production Floor API')

class StageIn(BaseModel):
    code: str
    sequence: int = Field(gt=0)
    machine_id: int | None = Field(default=None, gt=0)
    target_minutes: Decimal | None = Field(default=None, gt=0)
    temperature_c: Decimal | None = None
    pressure_bar: Decimal | None = None

class FloorInitIn(BaseModel):
    production_order_id: int = Field(gt=0)
    batch_id: int = Field(gt=0)
    sku_id: int = Field(gt=0)
    planned_output_kg: Decimal = Field(gt=0)
    stages: list[StageIn]

class ConsumptionIn(BaseModel):
    component: str
    quantity: Decimal = Field(gt=0)
    unit_cost: Decimal = Field(ge=0)
    lot_id: int | None = Field(default=None, gt=0)
    reference: str | None = None

@app.post('/v54/production/floor/validate')
def validate_floor(payload: FloorInitIn):
    run = build_floor_run(production_order_id=payload.production_order_id,batch_id=payload.batch_id,sku_id=payload.sku_id,planned_output_kg=payload.planned_output_kg,stages=[ProcessStage(**x.model_dump()) for x in payload.stages])
    return {'status': run.status.value, 'stages': [x.stage.code for x in run.stages], 'planned_output_kg': str(run.planned_output_kg)}

@app.post('/v54/production/floor/cost-preview')
def cost_preview(items: list[ConsumptionIn]):
    entries=[ConsumptionEntry(**x.model_dump()) for x in items]
    total=money(sum((e.amount() for e in entries), Decimal('0')))
    return {'material_cost': str(total), 'components': [{'component':e.component,'quantity_kg':str(qty(e.quantity)),'amount':str(e.amount())} for e in entries]}
