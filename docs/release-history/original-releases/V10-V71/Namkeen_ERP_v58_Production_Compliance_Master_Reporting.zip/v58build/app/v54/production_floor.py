from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Optional

Q6 = Decimal('0.000001')
Q2 = Decimal('0.01')

def qty(v) -> Decimal:
    return Decimal(str(v)).quantize(Q6, rounding=ROUND_HALF_UP)

def money(v) -> Decimal:
    return Decimal(str(v)).quantize(Q2, rounding=ROUND_HALF_UP)

class FloorError(ValueError):
    pass

class StageStatus(str, Enum):
    PLANNED='PLANNED'; RUNNING='RUNNING'; HOLD='HOLD'; COMPLETED='COMPLETED'; CANCELLED='CANCELLED'

class QCStatus(str, Enum):
    PENDING='PENDING'; PASS='PASS'; FAIL='FAIL'; HOLD='HOLD'

class WastageStatus(str, Enum):
    RECORDED='RECORDED'; AUTHORIZED='AUTHORIZED'; REJECTED='REJECTED'; POSTED='POSTED'

@dataclass(frozen=True)
class ShiftEntry:
    operator_id: int
    shift_code: str
    hours: Decimal
    headcount: int = 1
    notes: str = ''
    def __post_init__(self):
        if self.operator_id <= 0 or not self.shift_code: raise FloorError('INVALID_SHIFT_ENTRY')
        if qty(self.hours) <= 0: raise FloorError('SHIFT_HOURS_REQUIRED')
        if self.headcount <= 0: raise FloorError('HEADCOUNT_REQUIRED')

@dataclass(frozen=True)
class ProcessStage:
    code: str
    sequence: int
    machine_id: Optional[int] = None
    target_minutes: Optional[Decimal] = None
    temperature_c: Optional[Decimal] = None
    pressure_bar: Optional[Decimal] = None
    notes: str = ''
    def __post_init__(self):
        if not self.code or self.sequence <= 0: raise FloorError('INVALID_PROCESS_STAGE')
        if self.machine_id is not None and self.machine_id <= 0: raise FloorError('INVALID_MACHINE')
        if self.target_minutes is not None and qty(self.target_minutes) <= 0: raise FloorError('INVALID_TARGET_MINUTES')

@dataclass
class StageEntry:
    stage: ProcessStage
    status: StageStatus = StageStatus.PLANNED
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    actual_minutes: Decimal = Decimal('0')
    downtime_minutes: Decimal = Decimal('0')
    operator_id: Optional[int] = None
    notes: str = ''

@dataclass(frozen=True)
class ConsumptionEntry:
    component: str
    quantity: Decimal
    unit_cost: Decimal
    lot_id: Optional[int] = None
    reference: Optional[str] = None
    def amount(self) -> Decimal: return money(qty(self.quantity) * money(self.unit_cost))

@dataclass(frozen=True)
class QCCheckpoint:
    checkpoint_code: str
    status: QCStatus
    parameter_values: dict[str, str] = field(default_factory=dict)
    result_notes: str = ''
    evidence_ref: Optional[str] = None
    checked_by: Optional[int] = None
    def __post_init__(self):
        if not self.checkpoint_code: raise FloorError('QC_CHECKPOINT_REQUIRED')
        if self.status == QCStatus.FAIL and not self.result_notes: raise FloorError('QC_FAIL_REASON_REQUIRED')
        if self.checked_by is not None and self.checked_by <= 0: raise FloorError('INVALID_QC_ACTOR')

@dataclass
class WastageRecord:
    qty_kg: Decimal
    reason_code: str
    status: WastageStatus = WastageStatus.RECORDED
    authorized_by: Optional[int] = None
    evidence_ref: Optional[str] = None

@dataclass
class ProductionFloorRun:
    production_order_id: int
    batch_id: int
    sku_id: int
    planned_output_kg: Decimal
    stages: list[StageEntry]
    status: StageStatus = StageStatus.PLANNED
    shifts: list[ShiftEntry] = field(default_factory=list)
    consumptions: list[ConsumptionEntry] = field(default_factory=list)
    qc_checkpoints: list[QCCheckpoint] = field(default_factory=list)
    wastage: list[WastageRecord] = field(default_factory=list)
    oil_qty_kg: Decimal = Decimal('0')
    fuel_qty_kg: Decimal = Decimal('0')
    downtime_minutes: Decimal = Decimal('0')
    good_output_kg: Decimal = Decimal('0')
    reject_output_kg: Decimal = Decimal('0')
    wip_output_kg: Decimal = Decimal('0')

    def start(self):
        if self.status not in {StageStatus.PLANNED, StageStatus.HOLD}: raise FloorError('RUN_NOT_STARTABLE')
        self.status = StageStatus.RUNNING

    def start_stage(self, sequence: int, operator_id: int):
        e = self._stage(sequence)
        if self.status != StageStatus.RUNNING: raise FloorError('RUN_NOT_RUNNING')
        if operator_id <= 0: raise FloorError('INVALID_OPERATOR')
        if e.status not in {StageStatus.PLANNED, StageStatus.HOLD}: raise FloorError('STAGE_NOT_STARTABLE')
        e.status = StageStatus.RUNNING; e.operator_id = operator_id

    def complete_stage(self, sequence: int, actual_minutes: Decimal):
        e = self._stage(sequence)
        if e.status != StageStatus.RUNNING: raise FloorError('STAGE_NOT_RUNNING')
        if qty(actual_minutes) <= 0: raise FloorError('ACTUAL_MINUTES_REQUIRED')
        e.actual_minutes = qty(actual_minutes); e.status = StageStatus.COMPLETED

    def add_downtime(self, minutes: Decimal, reason_code: str):
        if qty(minutes) <= 0 or not reason_code: raise FloorError('INVALID_DOWNTIME')
        self.downtime_minutes = qty(self.downtime_minutes + qty(minutes))
        for e in self.stages:
            if e.status == StageStatus.RUNNING:
                e.downtime_minutes = qty(e.downtime_minutes + qty(minutes))
                break

    def add_shift(self, entry: ShiftEntry): self.shifts.append(entry)

    def add_consumption(self, entry: ConsumptionEntry):
        if qty(entry.quantity) <= 0 or money(entry.unit_cost) < 0: raise FloorError('INVALID_CONSUMPTION')
        self.consumptions.append(entry)

    def record_oil(self, quantity_kg: Decimal):
        if qty(quantity_kg) < 0: raise FloorError('INVALID_OIL_QTY')
        self.oil_qty_kg = qty(self.oil_qty_kg + qty(quantity_kg))

    def record_fuel(self, quantity_kg: Decimal):
        if qty(quantity_kg) < 0: raise FloorError('INVALID_FUEL_QTY')
        self.fuel_qty_kg = qty(self.fuel_qty_kg + qty(quantity_kg))

    def add_qc(self, checkpoint: QCCheckpoint):
        self.qc_checkpoints.append(checkpoint)
        if checkpoint.status in {QCStatus.FAIL, QCStatus.HOLD}: self.status = StageStatus.HOLD

    def authorize_wastage(self, qty_kg: Decimal, reason_code: str, actor_id: int, evidence_ref: Optional[str] = None):
        if qty(qty_kg) <= 0 or not reason_code: raise FloorError('INVALID_WASTAGE')
        if actor_id <= 0: raise FloorError('INVALID_AUTHORIZER')
        if self.wastage and self.wastage[-1].status == WastageStatus.RECORDED:
            raise FloorError('WASTAGE_ALREADY_PENDING')
        self.wastage.append(WastageRecord(qty(qty_kg), reason_code, WastageStatus.AUTHORIZED, actor_id, evidence_ref))

    def record_output(self, good: Decimal, reject: Decimal = 0, wip: Decimal = 0):
        good, reject, wip = qty(good), qty(reject), qty(wip)
        if good <= 0: raise FloorError('GOOD_OUTPUT_REQUIRED')
        if min(reject, wip) < 0: raise FloorError('NEGATIVE_OUTPUT_QTY')
        issued = self.total_input_kg()
        if good + reject + wip > issued + Q6: raise FloorError('OUTPUT_EXCEEDS_ACTUAL_INPUT')
        self.good_output_kg, self.reject_output_kg, self.wip_output_kg = good, reject, wip

    def complete(self):
        if self.status != StageStatus.RUNNING: raise FloorError('RUN_NOT_COMPLETEABLE')
        if any(e.status != StageStatus.COMPLETED for e in self.stages): raise FloorError('ALL_STAGES_NOT_COMPLETED')
        if any(q.status != QCStatus.PASS for q in self.qc_checkpoints if q.checkpoint_code): raise FloorError('QC_NOT_PASSED')
        if self.good_output_kg <= 0: raise FloorError('GOOD_OUTPUT_REQUIRED')
        self.status = StageStatus.COMPLETED

    def total_input_kg(self) -> Decimal:
        return qty(sum((x.quantity for x in self.consumptions), Decimal('0')))

    def total_material_cost(self) -> Decimal:
        return money(sum((x.amount() for x in self.consumptions), Decimal('0')))

    def yield_pct(self) -> Decimal:
        base = self.total_input_kg()
        return (self.good_output_kg / base * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP) if base else Decimal('0.00')

    def _stage(self, sequence: int) -> StageEntry:
        for e in self.stages:
            if e.stage.sequence == sequence: return e
        raise FloorError('STAGE_NOT_FOUND')

def build_floor_run(*, production_order_id: int, batch_id: int, sku_id: int, planned_output_kg: Decimal, stages: list[ProcessStage]) -> ProductionFloorRun:
    if min(production_order_id, batch_id, sku_id) <= 0: raise FloorError('INVALID_PRODUCTION_REFERENCE')
    if qty(planned_output_kg) <= 0: raise FloorError('PLANNED_OUTPUT_REQUIRED')
    if not stages: raise FloorError('PROCESS_STAGES_REQUIRED')
    seqs = [x.sequence for x in stages]
    if len(seqs) != len(set(seqs)): raise FloorError('DUPLICATE_STAGE_SEQUENCE')
    if seqs != sorted(seqs): raise FloorError('STAGES_NOT_SEQUENTIAL')
    return ProductionFloorRun(production_order_id, batch_id, sku_id, qty(planned_output_kg), [StageEntry(x) for x in stages])
