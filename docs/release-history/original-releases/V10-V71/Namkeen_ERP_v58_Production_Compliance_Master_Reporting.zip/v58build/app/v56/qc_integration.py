from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Iterable, Optional

from app.v55.qc_control import CheckStatus, Disposition, QCInspection, finalize_production_qc

Q6 = Decimal("0.000001")

def q(v) -> Decimal:
    return Decimal(str(v)).quantize(Q6, rounding=ROUND_HALF_UP)

class IntegrationError(ValueError):
    pass

class Outcome(str, Enum):
    RELEASE = "RELEASE"
    REWORK = "REWORK"
    REJECT = "REJECT"
    SCRAP = "SCRAP"
    HOLD = "HOLD"

@dataclass(frozen=True)
class InventoryAction:
    action: str
    warehouse_code: str
    qty_kg: Decimal
    reason: str = ""

@dataclass(frozen=True)
class ComplianceLink:
    requirement_code: str
    reference_type: str
    reference_id: str
    result: str

@dataclass(frozen=True)
class QCSettlement:
    batch_id: int
    qc_status: CheckStatus
    outcome: Outcome
    can_complete_batch: bool
    inventory_actions: tuple[InventoryAction, ...]
    compliance_links: tuple[ComplianceLink, ...]
    requires_capa: bool


def validate_qc_for_batch_completion(*, inspections: Iterable[QCInspection], oil_reading=None, deviations=None) -> dict:
    result = finalize_production_qc(
        inspections=list(inspections), oil_reading=oil_reading, deviations=list(deviations or [])
    )
    status = CheckStatus(result["status"])
    return {**result, "can_complete_batch": status == CheckStatus.PASS}


def build_settlement(
    *,
    batch_id: int,
    inspections: Iterable[QCInspection],
    oil_reading=None,
    deviations=None,
    good_output_kg=0,
    reject_output_kg=0,
    rework_output_kg=0,
    reject_warehouse="QC_REJECT",
    rework_warehouse="WIP_REWORK",
    compliance_requirement="FSMS_PROCESS_QC",
) -> QCSettlement:
    if batch_id <= 0:
        raise IntegrationError("INVALID_BATCH_ID")
    good = q(good_output_kg); reject = q(reject_output_kg); rework = q(rework_output_kg)
    if min(good, reject, rework) < 0:
        raise IntegrationError("NEGATIVE_OUTPUT_QTY")
    summary = validate_qc_for_batch_completion(inspections=inspections, oil_reading=oil_reading, deviations=deviations)
    status = CheckStatus(summary["status"])
    if status == CheckStatus.HOLD:
        outcome = Outcome.HOLD
    elif status == CheckStatus.FAIL:
        outcome = Outcome.REWORK if rework > 0 else Outcome.REJECT
    else:
        outcome = Outcome.RELEASE
    actions: list[InventoryAction] = []
    if rework > 0:
        actions.append(InventoryAction("MOVE_TO_REWORK", rework_warehouse, rework, "QC_REWORK"))
    if reject > 0:
        actions.append(InventoryAction("MOVE_TO_QUARANTINE", reject_warehouse, reject, "QC_REJECT"))
    if status == CheckStatus.PASS and good <= 0:
        raise IntegrationError("QC_PASS_REQUIRES_GOOD_OUTPUT")
    links = (ComplianceLink(compliance_requirement, "PRODUCTION_BATCH", str(batch_id), status.value),)
    return QCSettlement(
        batch_id=batch_id,
        qc_status=status,
        outcome=outcome,
        can_complete_batch=status == CheckStatus.PASS and good > 0,
        inventory_actions=tuple(actions),
        compliance_links=links,
        requires_capa=bool(summary["capa_required"]),
    )


def assert_batch_can_complete(settlement: QCSettlement) -> None:
    if not settlement.can_complete_batch:
        raise IntegrationError("QC_RELEASE_GATE_FAILED")
    if settlement.outcome != Outcome.RELEASE:
        raise IntegrationError("NON_RELEASE_OUTCOME")
