from decimal import Decimal
from fastapi import FastAPI
from pydantic import BaseModel, Field
from app.v52_mrp import ProductionOrder, ProductionOrderStatus, MRPResult
from app.v53.production_execution import build_execution_from_plan, reserve_allocations, issue_reserved_material, record_output, complete_execution, LotAllocation

app = FastAPI(title='Namkeen ERP v53 Production Execution API')

class AllocateIn(BaseModel):
    item_id: int
    lot_id: int
    batch_no: str
    qty_kg: Decimal = Field(gt=0)
    expiry_date: str | None = None

class OutputIn(BaseModel):
    good_output_kg: Decimal = Field(gt=0)
    reject_output_kg: Decimal = Field(default=Decimal('0'), ge=0)
    wip_qty_kg: Decimal = Field(default=Decimal('0'), ge=0)

@app.post('/v53/production/execution/initialize')
def initialize(production_order: dict, mrp_plan: dict):
    # Reference-contract endpoint: actual persistent reconstruction is performed by the deployment service.
    raise NotImplementedError('PERSISTENT_EXECUTION_SERVICE_REQUIRED')

@app.post('/v53/production/execution/validate-allocation')
def validate_allocation(items: list[AllocateIn], production_order: dict, requirements: list[dict]):
    po=ProductionOrder(
        production_order_id=int(production_order['production_order_id']), organization_id=int(production_order['organization_id']),
        entity_id=int(production_order['entity_id']), sku_id=int(production_order['sku_id']), bom_version=str(production_order['bom_version']),
        planned_good_output_kg=Decimal(str(production_order['planned_good_output_kg'])), due_date=str(production_order['due_date']),
        status=ProductionOrderStatus.RELEASED, source_demand_ids=[], created_by=int(production_order.get('created_by',1)), approved_by=int(production_order.get('approved_by',2))
    )
    from app.v52_mrp import MRPComponentRequirement, MRPResult
    plan=MRPResult(po.sku_id, po.planned_good_output_kg, po.bom_version, tuple(MRPComponentRequirement(int(r['item_id']),str(r['item_type']),Decimal(str(r['gross_required_qty_kg'])),Decimal('0'),Decimal('0')) for r in requirements))
    exe=build_execution_from_plan(po, plan)
    allocations={}
    for x in items:
        allocations.setdefault(x.item_id, []).append(LotAllocation(x.item_id,x.lot_id,x.batch_no,x.qty_kg,x.expiry_date))
    reserve_allocations(exe, allocations)
    return {'status': exe.status.value, 'requirements': [{'item_id':r.item_id,'planned_qty_kg':str(r.planned_qty_kg),'reserved_qty_kg':str(r.issued_qty_kg)} for r in exe.requirements]}

@app.post('/v53/production/execution/validate-output')
def validate_output(execution: dict, body: OutputIn):
    from types import SimpleNamespace
    exe=SimpleNamespace(**execution)
    raise NotImplementedError('PERSISTENT_EXECUTION_SERVICE_REQUIRED')
