from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.v47_logistics import *

app=FastAPI(title='Namkeen ERP API v47 — Dispatch Logistics', version='47.0')

class VehicleIn(BaseModel): entity_id:int; vehicle_no:str; vehicle_type:str='TRUCK'; capacity_kg:Decimal|None=None; transporter_id:int|None=None
class TripIn(BaseModel): entity_id:int; trip_no:str; transporter_id:int; vehicle_id:int; origin_warehouse_id:int; ewb_no:str|None=None
class LoadIn(BaseModel): load_id:int; trip_id:int; lpn_id:int; invoice_id:int; qty_kg:Decimal; sequence:int
class DeliveryIn(BaseModel): delivery_id:int; trip_id:int; invoice_id:int; customer_id:int; ordered_kg:Decimal
class PODIn(BaseModel): delivered_kg:Decimal; pod_type:str='NONE'; pod_ref:str|None=None

@app.get('/v47/health')
def health(): return {'version':'47.0','service':'dispatch-logistics'}

@app.post('/v47/vehicle/validate')
def vehicle_validate(body:VehicleIn):
    return {'valid':validate_vehicle_no(body.vehicle_no),'normalized_vehicle_no':normalize_vehicle_no(body.vehicle_no)}

@app.post('/v47/trip/load')
def trip_load(trip_body:TripIn, load_body:LoadIn):
    trip=DeliveryTrip(**trip_body.model_dump()); load=TripLoad(**load_body.model_dump());
    try: start_loading(trip); add_load(trip,load); return {'status':trip.status,'destination_count':trip.destination_count}
    except ValueError as e: raise HTTPException(400,detail=str(e))

@app.post('/v47/trip/depart')
def trip_depart(trip_body:TripIn):
    trip=DeliveryTrip(**trip_body.model_dump(), status=TransportStatus.LOADED)
    depart_trip(trip, trip_body.ewb_no); return {'status':trip.status,'started_at':trip.started_at.isoformat(),'ewb_no':trip.ewb_no}

@app.post('/v47/delivery/pod')
def delivery_pod(delivery_body:DeliveryIn, pod:PODIn):
    d=Delivery(**delivery_body.model_dump())
    try:
        t=PODType(pod.pod_type); record_delivery(d,pod.delivered_kg,t,pod.pod_ref)
        return {'status':d.status,'delivered_kg':str(d.delivered_kg),'balance_kg':str(d.balance_kg),'pod_type':d.pod_type}
    except (ValueError) as e: raise HTTPException(400,detail=str(e))

@app.post('/v47/freight/rate')
def freight_rate(total_freight:Decimal,total_kg:Decimal):
    try: return {'freight_per_kg':str(freight_per_kg(total_freight,total_kg))}
    except ValueError as e: raise HTTPException(400,detail=str(e))
