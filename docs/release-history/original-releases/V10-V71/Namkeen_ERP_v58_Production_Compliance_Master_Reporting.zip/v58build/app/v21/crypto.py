from __future__ import annotations
import base64, hashlib, hmac, os, secrets

# Android stores the actual token using Android Keystore-backed EncryptedSharedPreferences.
# This module is a server/test-side token envelope helper only; it never stores raw tokens.

def digest_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()

def protect_local_secret(secret: bytes, key: bytes | None = None) -> str:
    key = key or os.urandom(32)
    nonce = secrets.token_bytes(16)
    mask = hashlib.sha256(key + nonce).digest()
    padded = secret + b"\0" * max(0, len(mask) - len(secret))
    body = bytes(a ^ b for a, b in zip(padded[:len(mask)], mask))
    tag = hmac.new(key, nonce + body, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(nonce + tag + body).decode()
