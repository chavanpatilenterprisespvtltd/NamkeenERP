from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class SyncItem:
    client_event_id: str
    device_id: str
    event_type: str
    entity_type: str
    entity_id: str
    client_version: int | None
    payload: dict[str, Any]

@dataclass(frozen=True)
class PushResult:
    client_event_id: str
    status: str
    event_id: int | None = None
    server_version: int | None = None
    error_code: str | None = None

RETRYABLE = {"RETRY", "TEMPORARY_ERROR", "TIMEOUT", "SERVER_BUSY"}
TERMINAL = {"ACKED", "DUPLICATE", "CONFLICT", "DEAD_LETTER"}
