from __future__ import annotations
from fastapi import FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field
from app.auth.security import decode_access, actor_from_claims
from app.db.session import SessionLocal
from app.db.models_v19 import DomainChange
from app.sync.twoway import upsert_sync_event, compare_version, get_deltas
from app.db.models_v18 import SyncConflict, SyncDeadLetter, SyncChangeLog
import json

app=FastAPI(title="Namkeen ERP v21 — Production Mobile Sync Client API", version="21.0")

class PushIn(BaseModel):
    device_id:str=Field(min_length=2,max_length=120)
    client_event_id:str=Field(min_length=2,max_length=160)
    event_type:str=Field(min_length=2,max_length=100)
    entity_type:str=Field(min_length=2,max_length=80)
    entity_id:str=Field(min_length=1,max_length=120)
    client_version:int|None=None
    payload:dict

class DeviceIn(BaseModel): device_id:str=Field(min_length=2,max_length=120)

def actor(auth:str|None):
    if not auth or not auth.lower().startswith('bearer '): raise HTTPException(401,'Bearer token required')
    try:return actor_from_claims(decode_access(auth.split(' ',1)[1]))
    except Exception: raise HTTPException(401,'Invalid or expired token')

@app.post('/v21/mobile/push')
def push(body:PushIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            ev,status=upsert_sync_event(db,org_id=a.organization_id,device_id=body.device_id,client_event_id=body.client_event_id,event_type=body.event_type,payload=body.payload,base_version=body.client_version)
            if status=="DUPLICATE": return {"status":"DUPLICATE","client_event_id":body.client_event_id,"event_id":ev.id}
            latest=db.query(DomainChange).filter(DomainChange.organization_id==a.organization_id,DomainChange.aggregate_type==body.entity_type,DomainChange.aggregate_id==body.entity_id).order_by(DomainChange.version.desc()).first()
            server_version=latest.version if latest else None
            verdict=compare_version(client_version=body.client_version,server_version=server_version)
            if verdict=="CONFLICT":
                ev.status="CONFLICT"
                db.add(SyncConflict(organization_id=a.organization_id,device_id=body.device_id,client_event_id=body.client_event_id,entity_type=body.entity_type,entity_id=body.entity_id,client_version=body.client_version,server_version=server_version,client_payload_json=json.dumps(body.payload,separators=(',',':')),server_payload_json=latest.payload_json if latest else None))
                return {"status":"CONFLICT","client_event_id":body.client_event_id,"event_id":ev.id,"server_version":server_version}
            if verdict=="REJECTED":
                ev.status="REJECTED"
                db.add(SyncDeadLetter(organization_id=a.organization_id,device_id=body.device_id,client_event_id=body.client_event_id,event_type=body.event_type,payload_json=json.dumps(body.payload,separators=(',',':')),error_code="CLIENT_VERSION_AHEAD",error_message="Refresh device state before retrying."))
                return {"status":"REJECTED","client_event_id":body.client_event_id,"event_id":ev.id,"server_version":server_version}
            ev.status="ACCEPTED"
            return {"status":"ACCEPTED","client_event_id":body.client_event_id,"event_id":ev.id,"server_version":server_version}
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.get('/v21/mobile/pull')
def pull(device_id:str=Query(min_length=2),cursor:int=Query(default=0,ge=0),limit:int=Query(default=200,ge=1,le=1000),authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        with db.begin(): deltas,next_cursor=get_deltas(db,change_log_model=SyncChangeLog,org_id=a.organization_id,cursor=cursor,limit=limit)
        return {"device_id":device_id,"from_cursor":cursor,"next_cursor":next_cursor,"has_more":next_cursor>cursor and len(deltas)>=limit,"deltas":deltas}
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.get('/v21/mobile/conflicts')
def conflicts(device_id:str=Query(min_length=2),authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        rows=(db.query(SyncConflict).filter(SyncConflict.organization_id==a.organization_id,SyncConflict.device_id==device_id,SyncConflict.resolution_status=='OPEN').order_by(SyncConflict.created_at.desc()).limit(200).all())
        return {"items":[{"id":r.id,"client_event_id":r.client_event_id,"entity_type":r.entity_type,"entity_id":r.entity_id,"client_version":r.client_version,"server_version":r.server_version,"client_payload":json.loads(r.client_payload_json),"server_payload":json.loads(r.server_payload_json) if r.server_payload_json else None} for r in rows]}
    finally: db.close()
