from __future__ import annotations
import hashlib
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class DocumentUpload:
    local_id: str
    path: str
    content_type: str
    sha256: str
    state: str = "PENDING"
    attempts: int = 0
    last_error: str | None = None

class DocumentQueue:
    """Durable queue abstraction for shop/payment/customer evidence uploads."""
    def __init__(self): self.items: dict[str, DocumentUpload] = {}
    def enqueue(self, local_id: str, path: str, content_type: str) -> DocumentUpload:
        p=Path(path)
        sha=hashlib.sha256(p.read_bytes()).hexdigest()
        item=DocumentUpload(local_id,path,content_type,sha)
        self.items[local_id]=item
        return item
    def pending(self): return [x for x in self.items.values() if x.state in {"PENDING","RETRY"}]
    def mark(self, local_id: str, state: str, error: str|None=None):
        x=self.items[local_id]
        self.items[local_id]=DocumentUpload(x.local_id,x.path,x.content_type,x.sha256,state,x.attempts+1,error)
