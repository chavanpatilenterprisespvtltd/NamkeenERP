from __future__ import annotations
import random
import time
from dataclasses import dataclass
from typing import Callable, Iterable
from .contracts import SyncItem, PushResult, RETRYABLE

@dataclass(frozen=True)
class SyncStats:
    pushed: int = 0
    pulled: int = 0
    retried: int = 0
    conflicts: int = 0
    dead_letters: int = 0

class Backoff:
    def __init__(self, base_seconds=1.0, cap_seconds=60.0, jitter=0.2, rand: Callable[[], float]=random.random):
        self.base_seconds, self.cap_seconds, self.jitter, self.rand = base_seconds, cap_seconds, jitter, rand
    def delay(self, attempts: int) -> float:
        raw=min(self.cap_seconds, self.base_seconds*(2**max(0, attempts-1)))
        return max(0.0, raw*(1-self.jitter + 2*self.jitter*self.rand()))

class SyncEngine:
    """Transport-agnostic two-way sync orchestrator. Persistence stays in the local store."""
    def __init__(self, store, api, sleep: Callable[[float], None]=lambda _s: None, backoff: Backoff|None=None):
        self.store, self.api, self.sleep, self.backoff = store, api, sleep, backoff or Backoff()

    def run_once(self, batch_size=50, pull_limit=200) -> SyncStats:
        stats=SyncStats()
        pending=self.store.pending(batch_size)
        for item in pending:
            result=self.api.push(item)
            self.store.mark_result(item.client_event_id, status=result.status, error=result.error_code)
            stats=SyncStats(stats.pushed+1,stats.pulled,stats.retried+(result.status in RETRYABLE),stats.conflicts+(result.status=="CONFLICT"),stats.dead_letters+(result.status=="REJECTED"))
            if result.status in RETRYABLE:
                self.sleep(self.backoff.delay(item.attempts+1))
        cursor=self.store.cursor()
        deltas,next_cursor,has_more=self.api.pull(cursor, pull_limit)
        for delta in deltas:
            self.store.apply_delta(delta)
        if deltas or next_cursor != cursor:
            self.store.ack_cursor(next_cursor)
        return SyncStats(stats.pushed, stats.pulled+len(deltas), stats.retried, stats.conflicts, stats.dead_letters)
