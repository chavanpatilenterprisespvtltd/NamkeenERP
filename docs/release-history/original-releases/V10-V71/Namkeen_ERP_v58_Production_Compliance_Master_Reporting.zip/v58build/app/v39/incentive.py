from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

Q2=Decimal('0.01')
class IncentiveError(ValueError): pass

FORMULA_TYPES={'PER_KG','PERCENT_SALES','PERCENT_MARGIN','COLLECTION','TARGET','COMBINED'}


def money(v): return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)

@dataclass(frozen=True)
class IncentivePolicy:
    policy_id:int
    name:str
    formula_type:str
    per_kg_rate:Decimal=Decimal('0')
    sales_pct:Decimal=Decimal('0')
    margin_pct:Decimal=Decimal('0')
    collection_pct:Decimal=Decimal('0')
    target_pct:Decimal=Decimal('0')
    target_amount:Decimal=Decimal('0')
    effective_from:str=''
    effective_to:Optional[str]=None
    approved_by:Optional[int]=None
    active:bool=True

    def __post_init__(self):
        if self.formula_type not in FORMULA_TYPES: raise IncentiveError('INVALID_FORMULA_TYPE')
        for x in (self.per_kg_rate,self.sales_pct,self.margin_pct,self.collection_pct,self.target_pct):
            if Decimal(x)<0: raise IncentiveError('INCENTIVE_RATE_CANNOT_BE_NEGATIVE')
        if self.active and not self.approved_by: raise IncentiveError('MANAGEMENT_APPROVAL_REQUIRED')

@dataclass(frozen=True)
class IncentiveInput:
    eligible_kg:Decimal
    net_sales:Decimal
    gross_margin:Decimal
    verified_collections:Decimal
    target_achievement_pct:Decimal
    returned_kg:Decimal=Decimal('0')
    cancelled_sales:Decimal=Decimal('0')

@dataclass(frozen=True)
class IncentiveResult:
    eligible_kg:Decimal
    eligible_sales:Decimal
    eligible_margin:Decimal
    incentive:Decimal
    components:dict


def calculate_incentive(p:IncentivePolicy, i:IncentiveInput)->IncentiveResult:
    eligible_kg=max(Decimal('0'),Decimal(i.eligible_kg)-Decimal(i.returned_kg))
    eligible_sales=max(Decimal('0'),Decimal(i.net_sales)-Decimal(i.cancelled_sales))
    # Conservative: gross margin is capped at the eligible-sales base and never increased by returns.
    eligible_margin=max(Decimal('0'),Decimal(i.gross_margin))
    if eligible_sales<=0: eligible_margin=Decimal('0')
    c={}
    if p.formula_type=='PER_KG': c['per_kg']=money(eligible_kg*p.per_kg_rate); total=c['per_kg']
    elif p.formula_type=='PERCENT_SALES': c['sales']=money(eligible_sales*p.sales_pct/100); total=c['sales']
    elif p.formula_type=='PERCENT_MARGIN': c['margin']=money(eligible_margin*p.margin_pct/100); total=c['margin']
    elif p.formula_type=='COLLECTION': c['collection']=money(max(Decimal('0'),Decimal(i.verified_collections))*p.collection_pct/100); total=c['collection']
    elif p.formula_type=='TARGET':
        achievement=max(Decimal('0'),Decimal(i.target_achievement_pct))
        if p.target_amount>0:
            achieved_amount=eligible_sales*achievement/100
            c['target']=money(achieved_amount*p.target_pct/100)
        else: c['target']=Decimal('0.00')
        total=c['target']
    else:
        for k,val in [('per_kg',eligible_kg*p.per_kg_rate),('sales',eligible_sales*p.sales_pct/100),('margin',eligible_margin*p.margin_pct/100),('collection',max(Decimal('0'),Decimal(i.verified_collections))*p.collection_pct/100)]: c[k]=money(val)
        c['target']=money((eligible_sales*max(Decimal('0'),Decimal(i.target_achievement_pct))/100)*p.target_pct/100) if p.target_amount>0 else Decimal('0.00')
        total=sum(c.values(),Decimal('0.00'))
    return IncentiveResult(money(eligible_kg),money(eligible_sales),money(eligible_margin),money(total),c)
