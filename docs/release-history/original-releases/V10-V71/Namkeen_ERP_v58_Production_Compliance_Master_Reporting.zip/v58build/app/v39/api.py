from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime

def _date(v):
    return v if isinstance(v,date) else date.fromisoformat(v)

def _pricing_dict(d):
    x=dict(d); x['effective_from']=_date(x['effective_from']); x['effective_to']=_date(x['effective_to']) if x.get('effective_to') else None
    for k in ('target_price','floor_price','max_discount_pct'): x[k]=Decimal(str(x[k]))
    return x

def _rule_dict(d):
    x=dict(d); x['effective_from']=_date(x['effective_from']); x['effective_to']=_date(x['effective_to']) if x.get('effective_to') else None
    for k in ('unit_price','min_qty'): x[k]=Decimal(str(x[k]))
    return x

def _promo_dict(d):
    x=dict(d); x['start_date']=_date(x['start_date']); x['end_date']=_date(x['end_date'])
    for k in ('value','min_qty','buy_qty','get_qty'): x[k]=Decimal(str(x[k]))
    if x.get('max_discount_per_unit') is not None: x['max_discount_per_unit']=Decimal(str(x['max_discount_per_unit']))
    return x

def _incentive_policy_dict(d):
    x=dict(d)
    for k in ('per_kg_rate','sales_pct','margin_pct','collection_pct','target_pct','target_amount'): x[k]=Decimal(str(x.get(k,'0')))
    return x

def _incentive_input_dict(d):
    x=dict(d)
    for k in ('eligible_kg','net_sales','gross_margin','verified_collections','target_achievement_pct','returned_kg','cancelled_sales'): x[k]=Decimal(str(x.get(k,'0')))
    return x
from .pricing import *
from .incentive import *

app=FastAPI(title='Namkeen ERP API v39 — Pricing, Schemes & Incentives',version='39.0')
class PriceIn(BaseModel):
    sku_id:int; customer_id:int|None=None; quantity:Decimal; negotiated_unit_price:Decimal; actual_cost_per_unit:Decimal; order_date:date
    policy:dict; customer_rule:dict|None=None; promotion:dict|None=None; gst_pct:Decimal=Decimal('0'); tax_inclusive:bool=False; requires_approval:bool=False
class IncentiveIn(BaseModel): policy:dict; input:dict
@app.get('/v39/health')
def health(): return {'version':'39.0','service':'pricing-schemes-incentives'}
@app.post('/v39/pricing/calculate')
def price(b:PriceIn):
    try:
        policy=PricingPolicy(**_pricing_dict(b.policy)); rule=CustomerPriceRule(**_rule_dict(b.customer_rule)) if b.customer_rule else None; promo=Promotion(**_promo_dict(b.promotion)) if b.promotion else None
        r=PricingRequest(b.sku_id,b.customer_id,b.quantity,b.negotiated_unit_price,b.actual_cost_per_unit,b.order_date,policy,rule,promo,b.gst_pct,b.tax_inclusive,b.requires_approval)
        d=calculate_price(r)
        return d.__dict__
    except (PricingError,ValueError,TypeError) as e: raise HTTPException(400,str(e))
@app.post('/v39/incentive/calculate')
def incentive(b:IncentiveIn):
    try:
        p=IncentivePolicy(**_incentive_policy_dict(b.policy)); i=IncentiveInput(**_incentive_input_dict(b.input)); r=calculate_incentive(p,i); return {'eligible_kg':str(r.eligible_kg),'eligible_sales':str(r.eligible_sales),'eligible_margin':str(r.eligible_margin),'incentive':str(r.incentive),'components':{k:str(v) for k,v in r.components.items()}}
    except (IncentiveError,ValueError,TypeError) as e: raise HTTPException(400,str(e))
