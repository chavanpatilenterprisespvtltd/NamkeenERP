from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

Q2 = Decimal('0.01')
class PricingError(ValueError): pass

PRICING_STATES = {'DRAFT','SUBMITTED','APPROVED','REJECTED','EXPIRED','ACTIVE','CANCELLED'}
PROMO_TYPES = {'PERCENT','AMOUNT_PER_UNIT','FIXED_UNIT_PRICE','BUY_X_GET_Y','CARTON_DISCOUNT'}
APPROVAL_ROLES = {'MANAGER','MANAGEMENT'}


def money(v: Decimal|int|str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)

@dataclass(frozen=True)
class PricingPolicy:
    policy_id: int
    sku_id: int
    entity_id: int
    customer_id: Optional[int]
    effective_from: date
    effective_to: Optional[date]
    target_price: Decimal
    floor_price: Decimal
    max_discount_pct: Decimal = Decimal('0')
    approval_below_floor: bool = True
    active: bool = True

    def is_effective(self, on_date: date) -> bool:
        return self.active and self.effective_from <= on_date and (self.effective_to is None or on_date <= self.effective_to)

    def __post_init__(self):
        if money(self.floor_price) <= 0 or money(self.target_price) <= 0:
            raise PricingError('PRICE_MUST_BE_POSITIVE')
        if money(self.floor_price) > money(self.target_price):
            raise PricingError('FLOOR_ABOVE_TARGET')
        if money(self.max_discount_pct) < 0 or money(self.max_discount_pct) > 100:
            raise PricingError('INVALID_MAX_DISCOUNT_PCT')
        if self.effective_to and self.effective_to < self.effective_from:
            raise PricingError('INVALID_EFFECTIVE_PERIOD')

@dataclass(frozen=True)
class CustomerPriceRule:
    rule_id: int
    sku_id: int
    customer_id: int
    unit_price: Decimal
    effective_from: date
    effective_to: Optional[date] = None
    min_qty: Decimal = Decimal('0')
    active: bool = True

    def __post_init__(self):
        if money(self.unit_price) <= 0: raise PricingError('PRICE_MUST_BE_POSITIVE')
        if Decimal(self.min_qty) < 0: raise PricingError('INVALID_MIN_QTY')

@dataclass(frozen=True)
class Promotion:
    promotion_id: int
    name: str
    sku_id: int
    promo_type: str
    value: Decimal
    start_date: date
    end_date: date
    min_qty: Decimal = Decimal('0')
    buy_qty: Decimal = Decimal('0')
    get_qty: Decimal = Decimal('0')
    max_discount_per_unit: Optional[Decimal] = None
    active: bool = True

    def __post_init__(self):
        if self.promo_type not in PROMO_TYPES: raise PricingError('INVALID_PROMO_TYPE')
        if self.end_date < self.start_date: raise PricingError('INVALID_PROMO_PERIOD')
        if self.promo_type in {'PERCENT','AMOUNT_PER_UNIT','FIXED_UNIT_PRICE','CARTON_DISCOUNT'} and Decimal(self.value) < 0:
            raise PricingError('INVALID_PROMO_VALUE')
        if self.promo_type == 'BUY_X_GET_Y' and (self.buy_qty <= 0 or self.get_qty <= 0):
            raise PricingError('INVALID_BUY_GET_RULE')

@dataclass(frozen=True)
class PricingRequest:
    sku_id: int
    customer_id: Optional[int]
    quantity: Decimal
    negotiated_unit_price: Decimal
    actual_cost_per_unit: Decimal
    order_date: date
    policy: PricingPolicy
    customer_rule: Optional[CustomerPriceRule] = None
    promotion: Optional[Promotion] = None
    gst_pct: Decimal = Decimal('0')
    tax_inclusive: bool = False
    requires_approval: bool = False
    role: str = 'SALESPERSON'

@dataclass(frozen=True)
class PricingDecision:
    list_unit_price: Decimal
    target_unit_price: Decimal
    allowed_floor_price: Decimal
    negotiated_unit_price: Decimal
    discount_per_unit: Decimal
    taxable_value: Decimal
    gst_amount: Decimal
    invoice_total: Decimal
    gross_margin_value: Decimal
    gross_margin_pct: Decimal
    state: str
    reason: str
    approval_required: bool
    effective_discount_pct: Decimal


def _promotion_discount(p: Promotion, qty: Decimal, base: Decimal) -> Decimal:
    if not p.active or not (p.start_date <= date.today() <= p.end_date) or p.sku_id <= 0:
        return Decimal('0')
    if qty < p.min_qty:
        return Decimal('0')
    if p.promo_type == 'PERCENT': disc = base * p.value / Decimal('100')
    elif p.promo_type == 'AMOUNT_PER_UNIT': disc = p.value
    elif p.promo_type == 'FIXED_UNIT_PRICE': disc = max(Decimal('0'), base - p.value)
    elif p.promo_type == 'CARTON_DISCOUNT': disc = p.value
    elif p.promo_type == 'BUY_X_GET_Y': disc = base * (p.get_qty / (p.buy_qty + p.get_qty))
    else: disc = Decimal('0')
    if p.max_discount_per_unit is not None:
        disc = min(disc, money(p.max_discount_per_unit))
    return money(max(Decimal('0'), disc))


def calculate_price(r: PricingRequest) -> PricingDecision:
    qty = Decimal(r.quantity)
    if qty <= 0: raise PricingError('QUANTITY_MUST_BE_POSITIVE')
    cost = money(r.actual_cost_per_unit)
    if cost < 0: raise PricingError('INVALID_COST')
    if not r.policy.is_effective(r.order_date): raise PricingError('NO_ACTIVE_PRICING_POLICY')
    target = money(r.policy.target_price)
    floor = money(r.policy.floor_price)
    list_price = target
    if r.customer_rule and r.customer_rule.sku_id == r.sku_id and r.customer_rule.customer_id == r.customer_id and r.customer_rule.active and r.customer_rule.effective_from <= r.order_date and (r.customer_rule.effective_to is None or r.order_date <= r.customer_rule.effective_to) and qty >= r.customer_rule.min_qty:
        list_price = money(r.customer_rule.unit_price)
    promo_disc = _promotion_discount(r.promotion, qty, list_price) if r.promotion and r.promotion.sku_id == r.sku_id else Decimal('0')
    negotiated = money(r.negotiated_unit_price)
    discount = money(max(Decimal('0'), list_price - negotiated))
    effective_disc_pct = Decimal('0') if list_price == 0 else (discount / list_price * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP)
    max_disc = money(r.policy.max_discount_pct)
    approval = bool(r.requires_approval)
    reason = 'WITHIN_POLICY'
    if promo_disc > 0 and negotiated >= money(list_price - promo_disc):
        reason = 'PROMOTION_APPLIED'
    if effective_disc_pct > max_disc:
        approval = True
        reason = 'MAX_DISCOUNT_EXCEEDED'
    if negotiated < floor:
        if r.policy.approval_below_floor:
            approval = True
            reason = 'BELOW_FLOOR_APPROVAL_REQUIRED'
        else:
            raise PricingError('PRICE_BELOW_FLOOR')
    if negotiated <= 0: raise PricingError('PRICE_MUST_BE_POSITIVE')
    taxable = money(qty * negotiated)
    gst_rate = Decimal(r.gst_pct)
    if gst_rate < 0 or gst_rate > 100: raise PricingError('INVALID_GST_PCT')
    if r.tax_inclusive:
        gst = money(taxable * gst_rate / (Decimal('100') + gst_rate)) if gst_rate else Decimal('0.00')
        net_taxable = money(taxable - gst)
        total = taxable
    else:
        gst = money(taxable * gst_rate / Decimal('100')) if gst_rate else Decimal('0.00')
        net_taxable = taxable
        total = money(taxable + gst)
    margin = money((negotiated - cost) * qty)
    margin_pct = Decimal('0') if cost <= 0 else ((negotiated - cost) / negotiated * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP)
    if margin < 0 and not approval:
        approval = True; reason = 'NEGATIVE_MARGIN_APPROVAL_REQUIRED'
    state = 'SUBMITTED' if approval else 'ACTIVE'
    return PricingDecision(list_price,target,floor,negotiated,money(discount),net_taxable,gst,total,margin,margin_pct,state,reason,approval,effective_disc_pct)
