from fastapi import FastAPI, Header, HTTPException
from app.auth.security import decode_access, actor_from_claims
from app.db.session import SessionLocal
from app.v23.role_policy import role_definition
from app.v23.dashboard import build_dashboard

app = FastAPI(title="Namkeen ERP API v23 — Role Dashboards", version="23.0")

def actor(auth: str | None):
    if not auth or not auth.lower().startswith("bearer "):
        raise HTTPException(401, "Bearer token required")
    try:
        return actor_from_claims(decode_access(auth.split(" ", 1)[1]))
    except Exception:
        raise HTTPException(401, "Invalid or expired token")

@app.get("/me")
def me(authorization: str | None = Header(default=None)):
    a = actor(authorization)
    return {"user_id": a.user_id, "organization_id": a.organization_id, "role": a.role, "entity_ids": sorted(a.entity_ids), "dashboard": role_definition(a.role)["dashboard"], "offline_capabilities": sorted(role_definition(a.role)["offline"])}

@app.get("/dashboard")
def dashboard(authorization: str | None = Header(default=None)):
    a = actor(authorization)
    db = SessionLocal()
    try:
        return build_dashboard(db, a.organization_id, a.role, set(a.entity_ids))
    finally:
        db.close()
