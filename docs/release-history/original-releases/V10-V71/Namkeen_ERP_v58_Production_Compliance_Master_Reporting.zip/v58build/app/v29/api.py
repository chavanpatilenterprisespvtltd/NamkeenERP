from dataclasses import asdict
from decimal import Decimal
from .license_plate import LicensePlate, LPNContent, add_content, seal_lpn, move_lpn, pick_lpn, dispatch_lpn, fefo_lpn_order

try:
    from fastapi import APIRouter, HTTPException
    from pydantic import BaseModel
except Exception:
    APIRouter = None

class LPNCreateRequest(BaseModel):
    organization_id: int
    code: str
    lpn_type: str = "CARTON"
    warehouse_id: int | None = None

class LPNMoveRequest(BaseModel):
    destination_warehouse_id: int

class LPNContentRequest(BaseModel):
    sku_id: int
    lot_id: int
    quantity: Decimal
    quantity_uom: str
    normalized_kg: Decimal
    expiry_date: str | None = None

if APIRouter:
    router = APIRouter(prefix="/v29/lpns", tags=["v29-license-plates"])
    _store: dict[str, LicensePlate] = {}

    @router.post("")
    def create_lpn(req: LPNCreateRequest):
        if req.code in _store:
            raise HTTPException(status_code=409, detail="LPN_CODE_EXISTS")
        lpn = LicensePlate(len(_store)+1, req.organization_id, req.code, req.lpn_type, warehouse_id=req.warehouse_id)
        _store[req.code] = lpn
        return {"id": lpn.lpn_id, "code": lpn.code, "status": lpn.status}

    @router.get("/{code}")
    def get_lpn(code: str):
        lpn = _store.get(code)
        if not lpn:
            raise HTTPException(status_code=404, detail="LPN_NOT_FOUND")
        return {"id": lpn.lpn_id, "code": lpn.code, "status": lpn.status, "warehouse_id": lpn.warehouse_id, "total_kg": str(lpn.total_kg), "contents": [asdict(c) for c in lpn.contents]}

    @router.post("/{code}/contents")
    def add_lpn_content(code: str, req: LPNContentRequest):
        lpn = _store.get(code)
        if not lpn: raise HTTPException(status_code=404, detail="LPN_NOT_FOUND")
        try: add_content(lpn, LPNContent(lpn.lpn_id, req.sku_id, req.lot_id, req.quantity, req.quantity_uom, req.normalized_kg, req.expiry_date))
        except ValueError as e: raise HTTPException(status_code=409, detail=str(e))
        return {"code": lpn.code, "total_kg": str(lpn.total_kg)}

    @router.post("/{code}/seal")
    def seal(code: str):
        lpn = _store.get(code)
        if not lpn: raise HTTPException(status_code=404, detail="LPN_NOT_FOUND")
        try: seal_lpn(lpn)
        except ValueError as e: raise HTTPException(status_code=409, detail=str(e))
        return {"code": lpn.code, "status": lpn.status}

    @router.post("/{code}/move")
    def move(code: str, req: LPNMoveRequest):
        lpn = _store.get(code)
        if not lpn: raise HTTPException(status_code=404, detail="LPN_NOT_FOUND")
        try: move_lpn(lpn, req.destination_warehouse_id)
        except ValueError as e: raise HTTPException(status_code=409, detail=str(e))
        return {"code": lpn.code, "warehouse_id": lpn.warehouse_id}

    @router.post("/{code}/pick")
    def pick(code: str):
        lpn = _store.get(code)
        if not lpn: raise HTTPException(status_code=404, detail="LPN_NOT_FOUND")
        try: pick_lpn(lpn)
        except ValueError as e: raise HTTPException(status_code=409, detail=str(e))
        return {"code": lpn.code, "status": lpn.status}

    @router.post("/{code}/dispatch")
    def dispatch(code: str):
        lpn = _store.get(code)
        if not lpn: raise HTTPException(status_code=404, detail="LPN_NOT_FOUND")
        try: dispatch_lpn(lpn)
        except ValueError as e: raise HTTPException(status_code=409, detail=str(e))
        return {"code": lpn.code, "status": lpn.status}
