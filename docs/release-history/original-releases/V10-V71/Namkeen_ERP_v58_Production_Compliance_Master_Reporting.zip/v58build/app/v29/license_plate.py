from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List

class LPNError(ValueError):
    pass

VALID_STATUSES = {"ACTIVE", "SEALED", "OPEN", "PICKED", "DISPATCHED", "RETURNED", "QUARANTINED", "VOID"}
VALID_EVENT_TYPES = {"CREATE", "ADD_CONTENT", "REMOVE_CONTENT", "MOVE", "SEAL", "OPEN", "PICK", "DISPATCH", "RETURN", "QUARANTINE", "VOID"}

def q9(v: Decimal) -> Decimal:
    return v.quantize(Decimal("0.000000001"), rounding=ROUND_HALF_UP)

@dataclass
class LPNContent:
    lpn_id: int
    sku_id: int
    lot_id: int
    quantity: Decimal
    quantity_uom: str
    normalized_kg: Decimal
    expiry_date: str | None = None
    source_ref: str | None = None

@dataclass
class LicensePlate:
    lpn_id: int
    organization_id: int
    code: str
    lpn_type: str = "CARTON"
    status: str = "ACTIVE"
    warehouse_id: int | None = None
    parent_lpn_id: int | None = None
    sealed: bool = False
    contents: List[LPNContent] = field(default_factory=list)

    @property
    def total_kg(self) -> Decimal:
        return q9(sum((c.normalized_kg for c in self.contents), Decimal("0")))


def validate_lpn(lpn: LicensePlate) -> None:
    if not lpn.code.strip():
        raise LPNError("LPN_CODE_REQUIRED")
    if lpn.organization_id <= 0:
        raise LPNError("ORGANIZATION_REQUIRED")
    if lpn.status not in VALID_STATUSES:
        raise LPNError("INVALID_LPN_STATUS")
    if lpn.sealed and lpn.status == "OPEN":
        raise LPNError("SEALED_LPN_CANNOT_BE_OPEN")


def add_content(lpn: LicensePlate, content: LPNContent) -> None:
    validate_lpn(lpn)
    if lpn.sealed or lpn.status in {"DISPATCHED", "VOID"}:
        raise LPNError("LPN_NOT_OPEN_FOR_CONTENT")
    if content.quantity <= 0 or content.normalized_kg <= 0:
        raise LPNError("CONTENT_QUANTITY_MUST_BE_POSITIVE")
    lpn.contents.append(content)


def remove_content(lpn: LicensePlate, content_id: int) -> LPNContent:
    for i, c in enumerate(lpn.contents):
        if c.sku_id == content_id:
            return lpn.contents.pop(i)
    raise LPNError("LPN_CONTENT_NOT_FOUND")


def seal_lpn(lpn: LicensePlate) -> None:
    validate_lpn(lpn)
    if not lpn.contents:
        raise LPNError("EMPTY_LPN_CANNOT_BE_SEALED")
    if lpn.status in {"DISPATCHED", "VOID"}:
        raise LPNError("INVALID_LPN_STATUS_FOR_SEAL")
    lpn.sealed = True
    lpn.status = "SEALED"


def open_lpn(lpn: LicensePlate) -> None:
    if lpn.status not in {"SEALED", "OPEN", "PICKED"}:
        raise LPNError("LPN_NOT_REOPENABLE")
    lpn.sealed = False
    lpn.status = "OPEN"


def pick_lpn(lpn: LicensePlate) -> None:
    if lpn.status != "SEALED":
        raise LPNError("ONLY_SEALED_LPN_CAN_BE_PICKED")
    lpn.status = "PICKED"


def dispatch_lpn(lpn: LicensePlate) -> None:
    if lpn.status != "PICKED":
        raise LPNError("ONLY_PICKED_LPN_CAN_BE_DISPATCHED")
    lpn.status = "DISPATCHED"


def move_lpn(lpn: LicensePlate, destination_warehouse_id: int) -> None:
    if lpn.status == "VOID":
        raise LPNError("VOID_LPN_CANNOT_MOVE")
    if destination_warehouse_id <= 0:
        raise LPNError("DESTINATION_WAREHOUSE_REQUIRED")
    lpn.warehouse_id = destination_warehouse_id


def fefo_lpn_order(lpns: List[LicensePlate]) -> List[LicensePlate]:
    """Order eligible LPNs by earliest non-null expiry, then code."""
    def key(x: LicensePlate):
        dates = [c.expiry_date for c in x.contents if c.expiry_date]
        return (min(dates) if dates else "9999-12-31", x.code)
    return sorted((x for x in lpns if x.status in {"SEALED", "PICKED"}), key=key)
