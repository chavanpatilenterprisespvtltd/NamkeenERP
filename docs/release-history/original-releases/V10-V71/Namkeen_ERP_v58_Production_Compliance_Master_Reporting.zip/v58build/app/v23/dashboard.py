from sqlalchemy import func
from app.db.models import Customer, SalesOrder, Payment, InventoryLot
from app.v23.role_policy import dashboard_cards

def dashboard_metrics(db, org_id: int, entity_ids: set[int]) -> dict:
    q = lambda model: db.query(model).filter(model.organization_id == org_id)
    orders_today = q(SalesOrder).filter(SalesOrder.entity_id.in_(entity_ids)).count()
    pending_customers = q(Customer).filter(Customer.entity_id.in_(entity_ids), Customer.approval_status == "PENDING").count()
    pending_payments = q(Payment).filter(Payment.entity_id.in_(entity_ids), Payment.status.in_(["PENDING_VERIFICATION", "COLLECTED"])).count()
    inventory_shortage = 0
    return {
        "today_orders": orders_today,
        "pending_customers": pending_customers,
        "pending_collections": pending_payments,
        "customer_approvals": pending_customers,
        "unverified_payments": pending_payments,
        "stock_shortages": inventory_shortage,
        "accounting_sync": 0,
        "production_plan_kg": 0,
        "fg_ready_kg": 0,
        "rm_shortage": 0,
        "qc_pending": 0,
        "returns_qc_hold": 0,
        "price_exceptions": 0,
        "cash_with_sales": 0,
        "cheques_hold": 0,
        "incoming_qc": 0,
        "process_qc": 0,
        "lab_failures": 0,
        "sales_today": orders_today,
        "production_today": 0,
        "receivables": 0,
        "compliance_alerts": 0,
    }

def build_dashboard(db, org_id: int, role: str, entity_ids: set[int]) -> dict:
    metrics = dashboard_metrics(db, org_id, entity_ids)
    return {"role": role, "metrics": metrics, "cards": [c.__dict__ for c in dashboard_cards(role, metrics)], "server_authoritative": True}
