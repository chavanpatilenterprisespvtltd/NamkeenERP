from dataclasses import dataclass

ROLES = {
    "SALESPERSON": {"dashboard": "FIELD_SALES", "offline": {"customers", "orders", "collections", "returns", "documents", "sync"}},
    "MANAGER": {"dashboard": "MANAGER", "offline": {"customers", "orders", "collections", "returns", "documents", "sync", "approvals"}},
    "FACTORY": {"dashboard": "FACTORY", "offline": {"production", "qc", "inventory", "dispatch", "sync"}},
    "QC": {"dashboard": "QC", "offline": {"qc", "returns", "documents", "sync"}},
    "ACCOUNTS": {"dashboard": "ACCOUNTS", "offline": {"collections", "payments", "accounting", "sync"}},
    "MANAGEMENT": {"dashboard": "MANAGEMENT", "offline": {"all_read", "approvals", "pricing", "sync"}},
    "SUPER_ADMIN": {"dashboard": "MANAGEMENT", "offline": {"all_read", "admin", "sync"}},
}

@dataclass(frozen=True)
class DashboardCard:
    key: str
    label: str
    value: str
    severity: str = "NORMAL"
    action: str | None = None

def role_definition(role: str) -> dict:
    if role not in ROLES:
        raise KeyError(role)
    return ROLES[role]

def dashboard_cards(role: str, metrics: dict) -> list[DashboardCard]:
    role_definition(role)
    if role == "SALESPERSON":
        return [
            DashboardCard("today_orders", "Today Orders", str(metrics.get("today_orders", 0)), action="orders"),
            DashboardCard("pending_customers", "Customer Approvals", str(metrics.get("pending_customers", 0)), severity="ATTENTION", action="customers"),
            DashboardCard("pending_collections", "Collections Pending", str(metrics.get("pending_collections", 0)), action="collections"),
            DashboardCard("sync", "Sync Queue", str(metrics.get("sync_pending", 0)), severity="ATTENTION" if metrics.get("sync_pending", 0) else "NORMAL", action="sync"),
        ]
    if role == "MANAGER":
        return [
            DashboardCard("customer_approvals", "Customer Approvals", str(metrics.get("customer_approvals", 0)), severity="ATTENTION", action="approvals"),
            DashboardCard("price_exceptions", "Price Exceptions", str(metrics.get("price_exceptions", 0)), severity="ATTENTION", action="pricing"),
            DashboardCard("stock_shortages", "Stock Shortages", str(metrics.get("stock_shortages", 0)), severity="CRITICAL" if metrics.get("stock_shortages", 0) else "NORMAL", action="stock"),
            DashboardCard("returns_qc_hold", "Returns on QC Hold", str(metrics.get("returns_qc_hold", 0)), action="returns"),
        ]
    if role == "FACTORY":
        return [
            DashboardCard("production_plan", "Today's Production Plan", str(metrics.get("production_plan_kg", 0)) + " kg", action="production"),
            DashboardCard("rm_shortage", "RM Shortages", str(metrics.get("rm_shortage", 0)), severity="CRITICAL" if metrics.get("rm_shortage", 0) else "NORMAL", action="inventory"),
            DashboardCard("fg_ready", "FG Ready", str(metrics.get("fg_ready_kg", 0)) + " kg", action="dispatch"),
            DashboardCard("qc_pending", "QC Pending", str(metrics.get("qc_pending", 0)), severity="ATTENTION", action="qc"),
        ]
    if role == "QC":
        return [
            DashboardCard("incoming_qc", "Incoming QC", str(metrics.get("incoming_qc", 0)), action="qc/incoming"),
            DashboardCard("process_qc", "Process QC", str(metrics.get("process_qc", 0)), action="qc/process"),
            DashboardCard("returns_hold", "Returns QC Hold", str(metrics.get("returns_qc_hold", 0)), severity="ATTENTION", action="returns"),
            DashboardCard("lab_failures", "Lab Failures", str(metrics.get("lab_failures", 0)), severity="CRITICAL" if metrics.get("lab_failures", 0) else "NORMAL", action="compliance"),
        ]
    if role == "ACCOUNTS":
        return [
            DashboardCard("unverified_payments", "Payments to Verify", str(metrics.get("unverified_payments", 0)), severity="ATTENTION", action="payments"),
            DashboardCard("cash_with_sales", "Cash With Sales", str(metrics.get("cash_with_sales", 0)), severity="CRITICAL" if metrics.get("cash_with_sales", 0) else "NORMAL", action="collections"),
            DashboardCard("cheques_hold", "Cheques on Hold", str(metrics.get("cheques_hold", 0)), action="payments"),
            DashboardCard("accounting_sync", "Accounting Queue", str(metrics.get("accounting_sync", 0)), action="accounting"),
        ]
    return [
        DashboardCard("sales_today", "Sales Today", str(metrics.get("sales_today", 0)), action="sales"),
        DashboardCard("production_today", "Production Today", str(metrics.get("production_today", 0)) + " kg", action="production"),
        DashboardCard("receivables", "Receivables", str(metrics.get("receivables", 0)), action="collections"),
        DashboardCard("compliance_alerts", "Compliance Alerts", str(metrics.get("compliance_alerts", 0)), severity="CRITICAL" if metrics.get("compliance_alerts", 0) else "NORMAL", action="compliance"),
    ]
