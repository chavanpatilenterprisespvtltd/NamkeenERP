from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from app.db.session import SessionLocal
from app.db.models import Customer, Payment, SalesOrder
from app.auth.security import decode_access, actor_from_claims
from app.customer.service import onboard_customer, decide_customer
from app.collections.service import capture_collection, submit_deposit, verify_deposit
from app.returns.service import create_return, dispose_return
from app.sync.processor import accept_sync_event

app = FastAPI(title="Namkeen ERP v17 — Mobile Sync, Collections & Returns", version="17.0")

class CustomerIn(BaseModel):
    entity_id:int; code:str; name:str; mobile:str|None=None; address:str|None=None; gps_lat:Decimal|None=None; gps_lng:Decimal|None=None
    shop_photo_file_id:str|None=None; aadhaar_file_id:str|None=None; pan_file_id:str|None=None; extra_docs:dict=Field(default_factory=dict)
class DecisionIn(BaseModel): approve:bool; reason:str|None=None
class CollectionEvidenceIn(BaseModel): payment_id:int; counterparty_photo_file_id:str=Field(min_length=2); lat:Decimal|None=None; lng:Decimal|None=None
class DepositIn(BaseModel): payment_id:int; mode:str; deposit_ref:str|None=None
class ReturnLineIn(BaseModel): sku_id:int; qty:Decimal; batch_no:str|None=None
class ReturnIn(BaseModel): entity_id:int; customer_id:int; order_id:int|None=None; return_no:str; reason_code:str; evidence_file_id:str|None=None; lines:list[ReturnLineIn]
class ReturnDispositionIn(BaseModel): disposition:str; reason:str|None=None
class SyncIn(BaseModel): device_id:str=Field(min_length=2); client_event_id:str=Field(min_length=2); event_type:str; payload:dict; base_version:int|None=None

def actor(auth:str|None):
    if not auth or not auth.lower().startswith("bearer "): raise HTTPException(401,"Bearer token required")
    try:return actor_from_claims(decode_access(auth.split(" ",1)[1]))
    except Exception: raise HTTPException(401,"Invalid or expired token")

def scope(a, entity_id:int):
    if entity_id not in a.entity_ids: raise HTTPException(403,"Entity scope violation")

@app.post("/v17/customers")
def customer_create(body:CustomerIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); scope(a,body.entity_id)
    if a.role not in {"SALESPERSON","MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise HTTPException(403,"Customer onboarding not permitted")
    db=SessionLocal()
    try:
        with db.begin():
            c=onboard_customer(db,org_id=a.organization_id,entity_id=body.entity_id,actor_id=a.user_id,**body.model_dump())
        return {"id":c.id,"status":c.approval_status}
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/customers/{customer_id}/decision")
def customer_decision(customer_id:int, body:DecisionIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            c=db.query(Customer).filter(Customer.id==customer_id,Customer.organization_id==a.organization_id).one(); scope(a,c.entity_id)
            out=decide_customer(db,customer_id=customer_id,org_id=a.organization_id,actor=type("Actor",(),{"id":a.user_id,"role":a.role})(),approve=body.approve,reason=body.reason)
        return {"id":out.id,"status":out.approval_status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/collections/capture")
def collection_capture(body:CollectionEvidenceIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        p=db.query(Payment).filter(Payment.id==body.payment_id,Payment.organization_id==a.organization_id).one(); scope(a,p.entity_id)
        if a.role not in {"SALESPERSON","MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise HTTPException(403,"Collection not permitted")
        with db.begin(): out=capture_collection(db,org_id=a.organization_id,entity_id=p.entity_id,actor_id=a.user_id,**body.model_dump())
        return {"payment_id":out.id,"status":out.status}
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/collections/deposit")
def collection_deposit(body:DepositIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        p=db.query(Payment).filter(Payment.id==body.payment_id,Payment.organization_id==a.organization_id).one(); scope(a,p.entity_id)
        if a.user_id != p.collected_by and a.role not in {"MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise HTTPException(403,"Only collector or manager can submit deposit")
        with db.begin(): out=submit_deposit(db,org_id=a.organization_id,entity_id=p.entity_id,actor_id=a.user_id,**body.model_dump())
        return {"deposit_id":out.id,"status":out.status}
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/collections/deposit/{deposit_id}/verify")
def collection_verify(deposit_id:int, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        d=db.query(__import__('app.db.models_v17',fromlist=['CollectionDeposit']).CollectionDeposit).filter(__import__('app.db.models_v17',fromlist=['CollectionDeposit']).CollectionDeposit.id==deposit_id, __import__('app.db.models_v17',fromlist=['CollectionDeposit']).CollectionDeposit.organization_id==a.organization_id).one(); scope(a,d.entity_id)
        with db.begin(): out=verify_deposit(db,org_id=a.organization_id,entity_id=d.entity_id,actor_id=a.user_id,actor_role=a.role,deposit_id=deposit_id)
        return {"deposit_id":out.id,"status":out.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/returns")
def return_create(body:ReturnIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); scope(a,body.entity_id)
    db=SessionLocal()
    try:
        with db.begin():
            out=create_return(db,org_id=a.organization_id,entity_id=body.entity_id,customer_id=body.customer_id,order_id=body.order_id,actor_id=a.user_id,return_no=body.return_no,reason_code=body.reason_code,evidence_file_id=body.evidence_file_id,lines=[x.model_dump() for x in body.lines])
        return {"id":out.id,"status":out.status}
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/returns/{return_id}/disposition")
def return_disposition(return_id:int, body:ReturnDispositionIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        from app.db.models_v17 import SalesReturn
        r=db.query(SalesReturn).filter(SalesReturn.id==return_id,SalesReturn.organization_id==a.organization_id).one(); scope(a,r.entity_id)
        with db.begin(): out=dispose_return(db,org_id=a.organization_id,entity_id=r.entity_id,actor_id=a.user_id,actor_role=a.role,return_id=return_id,**body.model_dump())
        return {"id":out.id,"status":out.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v17/sync/events")
def sync_event(body:SyncIn, authorization:str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        with db.begin(): ev,status=accept_sync_event(db,org_id=a.organization_id,**body.model_dump())
        return {"id":ev.id,"status":status}
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()
