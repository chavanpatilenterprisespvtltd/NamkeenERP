from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from app.auth.security import decode_access, actor_from_claims
from app.auth.authorization import require_entity
from app.db.session import SessionLocal, transaction
from app.db.models_v25 import Warehouse, Supplier, Receipt, ReceiptLine, InventoryQc, StockTransfer, StockTransferLine, StockAdjustment, StockMovement, BarcodeEvent
from app.inventory.service_v25 import *
from types import SimpleNamespace

app=FastAPI(title="Namkeen ERP API v25 — Inventory & Warehouse", version="25.0")

def current_actor(auth):
    if not auth or not auth.lower().startswith("bearer "): raise HTTPException(401,"Bearer token required")
    try:return actor_from_claims(decode_access(auth.split(" ",1)[1]))
    except Exception:raise HTTPException(401,"Invalid or expired token")

def guard(a,e):
    try:require_entity(a.entity_ids,e)
    except PermissionError as ex:raise HTTPException(403,str(ex))

class WarehouseIn(BaseModel):entity_id:int; code:str=Field(min_length=1,max_length=50); name:str=Field(min_length=1,max_length=160); warehouse_type:str="FG"
class SupplierIn(BaseModel):entity_id:int; code:str; name:str; gstin:str|None=None
class ReceiptIn(BaseModel):entity_id:int; warehouse_id:int; supplier_id:int|None=None; receipt_no:str; receipt_type:str
class ReceiptLineIn(BaseModel):sku_id:int; qty:Decimal=Field(gt=0); supplier_lot_no:str|None=None; expiry_date:str|None=None; unit_cost:Decimal|None=None
class ReceiptQcIn(BaseModel):entity_id:int; result:str; remarks:str|None=None; coa_reference:str|None=None; evidence_file_id:str|None=None
class AdjustmentIn(BaseModel):entity_id:int; warehouse_id:int; sku_id:int; lot_id:int|None=None; qty_delta:Decimal; reason:str=Field(min_length=1)
class AdjustmentDecisionIn(BaseModel):entity_id:int; approve:bool
class TransferIn(BaseModel):entity_id:int; transfer_no:str; from_warehouse_id:int; to_warehouse_id:int
class TransferLineIn(BaseModel):sku_id:int; lot_id:int; qty:Decimal=Field(gt=0)
class BarcodeIn(BaseModel):entity_id:int; barcode:str; event_type:str; reference_type:str; reference_id:str

@app.get("/v25/health")
def health():return {"version":"25.0","service":"inventory-warehouse"}

@app.post("/v25/warehouses")
def warehouse_create(body:WarehouseIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    try:
        with transaction() as db:
            w=create_warehouse(db,org_id=a.organization_id,entity_id=body.entity_id,code=body.code,name=body.name,warehouse_type=body.warehouse_type);return {"id":w.id,"code":w.code,"name":w.name,"type":w.warehouse_type}
    except ValueError as e:raise HTTPException(409,str(e))

@app.get("/v25/warehouses")
def warehouses(entity_id:int,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,entity_id)
    with SessionLocal() as db:
        rows=db.execute(select(Warehouse).where(Warehouse.organization_id==a.organization_id,Warehouse.entity_id==entity_id,Warehouse.active==True).order_by(Warehouse.code)).scalars().all();return [{"id":w.id,"code":w.code,"name":w.name,"type":w.warehouse_type} for w in rows]

@app.post("/v25/suppliers")
def supplier_create(body:SupplierIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    try:
        with transaction() as db:
            s=create_supplier(db,org_id=a.organization_id,entity_id=body.entity_id,code=body.code,name=body.name,gstin=body.gstin);return {"id":s.id,"code":s.code,"name":s.name}
    except ValueError as e:raise HTTPException(409,str(e))

@app.post("/v25/receipts")
def receipt_create(body:ReceiptIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    try:
        with transaction() as db:
            r=create_receipt(db,org_id=a.organization_id,entity_id=body.entity_id,warehouse_id=body.warehouse_id,supplier_id=body.supplier_id,receipt_no=body.receipt_no,receipt_type=body.receipt_type,actor_id=a.user_id);return {"id":r.id,"receipt_no":r.receipt_no,"status":r.status,"qc_status":r.qc_status}
    except ValueError as e:raise HTTPException(409,str(e))

@app.post("/v25/receipts/{receipt_id}/lines")
def receipt_line(receipt_id:int,body:ReceiptLineIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization)
    try:
        with transaction() as db:
            r=db.get(Receipt,receipt_id)
            if not r or r.organization_id!=a.organization_id:raise HTTPException(404,"Receipt not found")
            guard(a,r.entity_id);l=add_receipt_line(db,receipt=r,sku_id=body.sku_id,qty=body.qty,supplier_lot_no=body.supplier_lot_no,unit_cost=body.unit_cost);return {"id":l.id,"receipt_id":l.receipt_id,"qty":str(l.qty_received)}
    except ValueError as e:raise HTTPException(409,str(e))

@app.post("/v25/receipts/lines/{line_id}/qc")
def receipt_qc(line_id:int,body:ReceiptQcIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    try:
        with transaction() as db:
            q=inspect_receipt(db,org_id=a.organization_id,entity_id=body.entity_id,receipt_line_id=line_id,result=body.result,actor_id=a.user_id,remarks=body.remarks,coa_reference=body.coa_reference,evidence_file_id=body.evidence_file_id);return {"id":q.id,"result":q.result}
    except (ValueError,PermissionError) as e:raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post("/v25/receipts/lines/{line_id}/post")
def receipt_post(line_id:int,entity_id:int,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,entity_id)
    try:
        with transaction() as db:
            lot=post_accepted_receipt(db,org_id=a.organization_id,entity_id=entity_id,receipt_line_id=line_id,actor_id=a.user_id);return {"lot_id":lot.id,"batch_no":lot.batch_no,"qty_available":str(lot.qty_available),"warehouse_code":lot.warehouse_code}
    except (ValueError,PermissionError) as e:raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post("/v25/adjustments")
def adjustment_request(body:AdjustmentIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    with transaction() as db:
        x=request_adjustment(db,org_id=a.organization_id,entity_id=body.entity_id,warehouse_id=body.warehouse_id,sku_id=body.sku_id,lot_id=body.lot_id,qty_delta=body.qty_delta,reason=body.reason,actor_id=a.user_id);return {"id":x.id,"status":x.status}

@app.post("/v25/adjustments/{adjustment_id}/decision")
def adjustment_decision(adjustment_id:int,body:AdjustmentDecisionIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    try:
        with transaction() as db:
            x=decide_adjustment(db,org_id=a.organization_id,entity_id=body.entity_id,adjustment_id=adjustment_id,actor_id=a.user_id,actor_role=a.role,approve=body.approve);return {"id":x.id,"status":x.status}
    except (ValueError,PermissionError) as e:raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post("/v25/transfers")
def transfer_create(body:TransferIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    try:
        with transaction() as db:
            x=create_transfer(db,org_id=a.organization_id,entity_id=body.entity_id,transfer_no=body.transfer_no,from_warehouse_id=body.from_warehouse_id,to_warehouse_id=body.to_warehouse_id,actor_id=a.user_id);return {"id":x.id,"status":x.status}
    except ValueError as e:raise HTTPException(409,str(e))

@app.post("/v25/transfers/{transfer_id}/lines")
def transfer_line(transfer_id:int,body:TransferLineIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization)
    with transaction() as db:
        x=db.get(StockTransfer,transfer_id)
        if not x or x.organization_id!=a.organization_id:raise HTTPException(404,"Transfer not found")
        guard(a,x.entity_id);l=add_transfer_line(db,transfer_id=transfer_id,sku_id=body.sku_id,lot_id=body.lot_id,qty=body.qty);return {"id":l.id}

@app.post("/v25/transfers/{transfer_id}/approve")
def transfer_approve(transfer_id:int,body:BaseModel,authorization:str|None=Header(default=None)):
    a=current_actor(authorization)
    with transaction() as db:
        x=db.get(StockTransfer,transfer_id)
        if not x or x.organization_id!=a.organization_id:raise HTTPException(404,"Transfer not found")
        guard(a,x.entity_id)
        try:t=approve_transfer(db,org_id=a.organization_id,entity_id=x.entity_id,transfer_id=transfer_id,actor_id=a.user_id,actor_role=a.role);return {"id":t.id,"status":t.status}
        except (ValueError,PermissionError) as e:raise HTTPException(409 if isinstance(e,ValueError) else 403,str(e))

@app.post("/v25/barcodes/events")
def barcode_event(body:BarcodeIn,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,body.entity_id)
    with transaction() as db:
        x=record_barcode(db,org_id=a.organization_id,entity_id=body.entity_id,barcode=body.barcode,event_type=body.event_type,reference_type=body.reference_type,reference_id=body.reference_id,actor_id=a.user_id);return {"id":x.id,"barcode":x.barcode}

@app.get("/v25/inventory/stock")
def stock(entity_id:int,warehouse_code:str|None=None,sku_id:int|None=None,authorization:str|None=Header(default=None)):
    a=current_actor(authorization);guard(a,entity_id)
    with SessionLocal() as db:
        q=select(__import__('app.db.models',fromlist=['InventoryLot']).InventoryLot).where(__import__('app.db.models',fromlist=['InventoryLot']).InventoryLot.organization_id==a.organization_id,__import__('app.db.models',fromlist=['InventoryLot']).InventoryLot.entity_id==entity_id)
        Lot=__import__('app.db.models',fromlist=['InventoryLot']).InventoryLot
        if warehouse_code:q=q.where(Lot.warehouse_code==warehouse_code)
        if sku_id:q=q.where(Lot.sku_id==sku_id)
        rows=db.execute(q.order_by(Lot.expiry_date,Lot.id).limit(1000)).scalars().all();return [{"lot_id":x.id,"warehouse_code":x.warehouse_code,"sku_id":x.sku_id,"batch_no":x.batch_no,"expiry_date":x.expiry_date.isoformat() if x.expiry_date else None,"qty_available":str(x.qty_available),"qty_reserved":str(x.qty_reserved)} for x in rows]
