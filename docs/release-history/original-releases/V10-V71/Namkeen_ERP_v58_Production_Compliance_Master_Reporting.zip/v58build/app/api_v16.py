from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from app.db.session import SessionLocal
from app.db.models import Customer, SalesOrder, Payment
from app.repositories.postgres import PostgresRepository, RepositoryError
from app.auth.security import decode_access, actor_from_claims
from app.auth.refresh import rotate_refresh, RefreshError
from app.services.order_posting import create_order, approve_order, verify_payment, clear_cheque
from app.transactions.persistent_order import reserve_order_persistent, dispatch_order_persistent

app=FastAPI(title="Namkeen ERP v16 — Production Transaction API",version="16.0")
repo=PostgresRepository(SessionLocal)

class LoginIn(BaseModel):
    username:str; password:str; device_id:str=Field(min_length=2,max_length=120); device_name:str|None=None; platform:str|None=None; app_version:str|None=None
class RefreshIn(BaseModel): session_id:str; refresh_token:str
class OrderLineIn(BaseModel):
    sku_id:int; qty:Decimal; negotiated_price:Decimal; floor_price:Decimal; company_cost:Decimal
class OrderIn(BaseModel):
    entity_id:int; customer_id:int; order_no:str; payment_mode:str; payment_state:str; credit_state:str; lines:list[OrderLineIn]
class PaymentVerifyIn(BaseModel): payment_id:int|None=None

def current_actor(auth:str|None):
    if not auth or not auth.lower().startswith("bearer "): raise HTTPException(401,"Bearer token required")
    try:
        claims=decode_access(auth.split(" ",1)[1]); a=actor_from_claims(claims)
    except Exception:
        raise HTTPException(401,"Invalid or expired token")
    return a

def require_entity(a, entity_id:int):
    if entity_id not in a.entity_ids: raise HTTPException(403,"Entity scope violation")

@app.get("/health")
def health(): return {"status":"ok","version":"16.0"}

@app.post("/auth/login")
def login(body:LoginIn):
    try:return repo.authenticate(**body.model_dump())
    except RepositoryError as e:raise HTTPException(401,str(e))

@app.post("/auth/refresh")
def refresh(body:RefreshIn):
    db=SessionLocal()
    try:
        with db.begin(): return rotate_refresh(db,session_id=body.session_id,refresh_token=body.refresh_token)
    except RefreshError as e: raise HTTPException(401,str(e))
    finally: db.close()

@app.post("/orders")
def create_sales_order(body:OrderIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); require_entity(a,body.entity_id)
    if a.role not in {"SALESPERSON","MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise HTTPException(403,"Order creation not permitted")
    db=SessionLocal()
    try:
        payload=body.model_dump(); payload["org_id"]=a.organization_id; payload["salesperson_id"]=a.user_id
        with db.begin():
            o=create_order(db,**payload)
        return {"id":o.id,"status":o.status,"order_no":o.order_no}
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/approve")
def approve(order_id:int, reason:str|None=None, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            o=db.execute(select(SalesOrder).where(SalesOrder.id==order_id,SalesOrder.organization_id==a.organization_id)).scalar_one()
            require_entity(a,o.entity_id); out=approve_order(db,order_id=order_id,actor_user=type("Actor",(),{"id":a.user_id,"role":a.role})(),reason=reason)
        return {"id":out.id,"status":out.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/payment-verify")
def payment_verify(order_id:int, body:PaymentVerifyIn=PaymentVerifyIn(), authorization:str|None=Header(default=None)):
    a=current_actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            o=db.execute(select(SalesOrder).where(SalesOrder.id==order_id,SalesOrder.organization_id==a.organization_id)).scalar_one()
            require_entity(a,o.entity_id); out=verify_payment(db,order_id=order_id,actor_user=type("Actor",(),{"id":a.user_id,"role":a.role})(),payment_id=body.payment_id)
        return {"id":out.id,"status":out.status,"payment_state":out.payment_state}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/cheque-clear")
def cheque_clear(order_id:int, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            o=db.execute(select(SalesOrder).where(SalesOrder.id==order_id,SalesOrder.organization_id==a.organization_id)).scalar_one(); require_entity(a,o.entity_id)
            out=clear_cheque(db,order_id=order_id,actor_user=type("Actor",(),{"id":a.user_id,"role":a.role})())
        return {"id":out.id,"status":out.status,"payment_state":out.payment_state}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/reserve")
def reserve(order_id:int, warehouse_code:str, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            o=db.execute(select(SalesOrder).where(SalesOrder.id==order_id,SalesOrder.organization_id==a.organization_id)).scalar_one(); require_entity(a,o.entity_id)
            out=reserve_order_persistent(db,order_id=order_id,warehouse_code=warehouse_code,actor_user=type("Actor",(),{"id":a.user_id,"role":a.role})())
        return {"id":out.id,"status":out.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/orders/{order_id}/dispatch")
def dispatch(order_id:int, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            o=db.execute(select(SalesOrder).where(SalesOrder.id==order_id,SalesOrder.organization_id==a.organization_id)).scalar_one(); require_entity(a,o.entity_id)
            out,total=dispatch_order_persistent(db,order_id=order_id,actor_user=type("Actor",(),{"id":a.user_id,"role":a.role})())
        return {"id":out.id,"status":out.status,"dispatched_qty":str(total)}
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()
