from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from app.v39.pricing import PricingPolicy, CustomerPriceRule, Promotion, PricingRequest, calculate_price, PricingDecision, PricingError
from app.v39.incentive import IncentivePolicy, IncentiveInput, calculate_incentive, IncentiveResult
from app.v37.sales_accounts import SalesInvoice, SalesInvoiceLine, validate_sales_invoice, build_incentive_basis, IncentiveBasis
from app.v38.collections_credit import CreditControlProfile, evaluate_credit_control, CreditDecision, CollectionsError

Q2 = Decimal("0.01")
class SalesTransactionError(ValueError):
    pass

PAYMENT_MODES = {"UPI", "CASH", "CHEQUE", "BANK_TRANSFER", "OTHER"}
PAYMENT_STATES = {"PENDING", "VERIFIED", "CLEARED"}
TRANSACTION_STATES = {"DRAFT", "PRICE_APPROVAL", "PAYMENT_VERIFICATION", "CREDIT_BLOCK", "READY_FOR_STOCK", "STOCK_RESERVED", "INVOICED", "DISPATCHED", "CANCELLED"}


def money(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)


@dataclass(frozen=True)
class SalesLineInput:
    sku_id: int
    quantity_kg: Decimal
    negotiated_unit_price: Decimal
    actual_cost_per_unit: Decimal
    policy: PricingPolicy
    customer_rule: Optional[CustomerPriceRule] = None
    promotion: Optional[Promotion] = None
    gst_pct: Decimal = Decimal("0")
    tax_inclusive: bool = False


@dataclass(frozen=True)
class SalesTransactionRequest:
    organization_id: int
    entity_id: int
    customer_id: int
    salesperson_id: int
    order_no: str
    transaction_date: date
    payment_mode: str
    payment_state: str
    credit_profile: CreditControlProfile
    lines: tuple[SalesLineInput, ...]
    warehouse_code: str
    cash_evidence_ref: Optional[str] = None
    cheque_ref: Optional[str] = None
    management_override: bool = False
    idempotency_key: Optional[str] = None


@dataclass(frozen=True)
class TransactionLineResult:
    sku_id: int
    quantity_kg: Decimal
    unit_price: Decimal
    taxable_value: Decimal
    tax_amount: Decimal
    invoice_total: Decimal
    gross_margin_value: Decimal
    gross_margin_pct: Decimal
    pricing_state: str
    pricing_reason: str
    pricing_approval_required: bool


@dataclass(frozen=True)
class StockAllocation:
    sku_id: int
    lot_id: int
    batch_no: str
    qty_kg: Decimal
    expiry_date: Optional[date]


@dataclass(frozen=True)
class AccountingPosting:
    posting_type: str
    reference_no: str
    debit_account: str
    credit_account: str
    amount: Decimal
    tax_amount: Decimal = Decimal("0.00")


@dataclass(frozen=True)
class SalesTransactionResult:
    order_no: str
    state: str
    customer_id: int
    payment_mode: str
    payment_state: str
    credit_state: str
    taxable_total: Decimal
    tax_total: Decimal
    invoice_total: Decimal
    gross_margin_value: Decimal
    lines: tuple[TransactionLineResult, ...]
    invoice: Optional[SalesInvoice] = None
    allocations: tuple[StockAllocation, ...] = ()
    postings: tuple[AccountingPosting, ...] = ()
    idempotency_key: Optional[str] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


def _require_payment_evidence(req: SalesTransactionRequest) -> None:
    mode = req.payment_mode.upper()
    if mode not in PAYMENT_MODES:
        raise SalesTransactionError("INVALID_PAYMENT_MODE")
    if req.payment_state not in PAYMENT_STATES:
        raise SalesTransactionError("INVALID_PAYMENT_STATE")
    if mode == "CASH" and req.payment_state == "VERIFIED" and not req.cash_evidence_ref:
        raise SalesTransactionError("CASH_EVIDENCE_REQUIRED")
    if mode == "CHEQUE" and req.payment_state == "CLEARED" and not req.cheque_ref:
        raise SalesTransactionError("CHEQUE_REFERENCE_REQUIRED")


def calculate_transaction_lines(req: SalesTransactionRequest) -> tuple[TransactionLineResult, ...]:
    if not req.lines:
        raise SalesTransactionError("LINES_REQUIRED")
    out = []
    for line in req.lines:
        try:
            d: PricingDecision = calculate_price(PricingRequest(
                sku_id=line.sku_id,
                customer_id=req.customer_id,
                quantity=line.quantity_kg,
                negotiated_unit_price=line.negotiated_unit_price,
                actual_cost_per_unit=line.actual_cost_per_unit,
                order_date=req.transaction_date,
                policy=line.policy,
                customer_rule=line.customer_rule,
                promotion=line.promotion,
                gst_pct=line.gst_pct,
                tax_inclusive=line.tax_inclusive,
                role="SALESPERSON",
            ))
        except PricingError as exc:
            raise SalesTransactionError(str(exc)) from exc
        out.append(TransactionLineResult(
            sku_id=line.sku_id,
            quantity_kg=money(line.quantity_kg),
            unit_price=money(d.negotiated_unit_price),
            taxable_value=money(d.taxable_value),
            tax_amount=money(d.gst_amount),
            invoice_total=money(d.invoice_total),
            gross_margin_value=money(d.gross_margin_value),
            gross_margin_pct=d.gross_margin_pct,
            pricing_state=d.state,
            pricing_reason=d.reason,
            pricing_approval_required=d.approval_required,
        ))
    return tuple(out)


def commercial_state(req: SalesTransactionRequest, lines: tuple[TransactionLineResult, ...]) -> tuple[str, CreditDecision]:
    taxable = sum((x.taxable_value for x in lines), Decimal("0"))
    invoice_total = sum((x.invoice_total for x in lines), Decimal("0"))
    credit = evaluate_credit_control(req.credit_profile, invoice_total, management_override=req.management_override)
    if credit.state != "CLEAR":
        return "CREDIT_BLOCK", credit
    if any(x.pricing_approval_required for x in lines):
        return "PRICE_APPROVAL", credit
    mode = req.payment_mode.upper()
    if mode == "CHEQUE" and req.payment_state != "CLEARED":
        return "PAYMENT_VERIFICATION", credit
    if req.payment_state != "VERIFIED" and mode != "CHEQUE":
        return "PAYMENT_VERIFICATION", credit
    return "READY_FOR_STOCK", credit


def build_invoice(req: SalesTransactionRequest, lines: tuple[TransactionLineResult, ...]) -> SalesInvoice:
    inv_lines = tuple(SalesInvoiceLine(
        sku_id=x.sku_id,
        quantity_kg=x.quantity_kg,
        unit_price=x.unit_price,
        taxable_value=x.taxable_value,
        tax_amount=x.tax_amount,
    ) for x in lines)
    taxable = money(sum((x.taxable_value for x in lines), Decimal("0")))
    tax = money(sum((x.tax_amount for x in lines), Decimal("0")))
    grand = money(taxable + tax)
    inv = SalesInvoice(
        invoice_id=0,
        organization_id=req.organization_id,
        entity_id=req.entity_id,
        customer_id=req.customer_id,
        invoice_no=req.order_no,
        invoice_date=req.transaction_date,
        lines=inv_lines,
        taxable_total=taxable,
        tax_total=tax,
        grand_total=grand,
        status="POSTED",
        salesperson_id=req.salesperson_id,
    )
    validate_sales_invoice(inv)
    return inv


def build_postings(req: SalesTransactionRequest, invoice: SalesInvoice) -> tuple[AccountingPosting, ...]:
    ar = AccountingPosting("SALES", invoice.invoice_no, "CUSTOMER_RECEIVABLE", "SALES_REVENUE", invoice.taxable_total, invoice.tax_total)
    tax = AccountingPosting("OUTPUT_TAX", invoice.invoice_no, "CUSTOMER_RECEIVABLE", "OUTPUT_TAX", invoice.tax_total)
    return (ar, tax)


def orchestrate_transaction(req: SalesTransactionRequest, *, allocations: tuple[StockAllocation, ...] = (), invoice_no: Optional[str] = None) -> SalesTransactionResult:
    """Pure orchestration contract. Inventory reservation/dispatch is intentionally supplied by the authoritative inventory service."""
    if not req.order_no.strip():
        raise SalesTransactionError("ORDER_NUMBER_REQUIRED")
    if req.warehouse_code.strip() == "":
        raise SalesTransactionError("WAREHOUSE_REQUIRED")
    _require_payment_evidence(req)
    lines = calculate_transaction_lines(req)
    state, credit = commercial_state(req, lines)
    taxable = money(sum((x.taxable_value for x in lines), Decimal("0")))
    tax = money(sum((x.tax_amount for x in lines), Decimal("0")))
    total = money(sum((x.invoice_total for x in lines), Decimal("0")))
    margin = money(sum((x.gross_margin_value for x in lines), Decimal("0")))
    if state == "CREDIT_BLOCK":
        return SalesTransactionResult(req.order_no, state, req.customer_id, req.payment_mode, req.payment_state, credit.state, taxable, tax, total, margin, lines, idempotency_key=req.idempotency_key)
    if state != "READY_FOR_STOCK":
        return SalesTransactionResult(req.order_no, state, req.customer_id, req.payment_mode, req.payment_state, credit.state, taxable, tax, total, margin, lines, idempotency_key=req.idempotency_key)
    invoice = build_invoice(req, lines)
    if invoice_no and invoice_no != invoice.invoice_no:
        raise SalesTransactionError("INVOICE_NUMBER_MISMATCH")
    postings = build_postings(req, invoice)
    return SalesTransactionResult(req.order_no, "INVOICED", req.customer_id, req.payment_mode, req.payment_state, credit.state, taxable, tax, total, margin, lines, invoice, allocations, postings, req.idempotency_key)


def build_incentive_result(req: SalesTransactionRequest, result: SalesTransactionResult, policy: IncentivePolicy, verified_collections: Decimal = Decimal("0"), target_achievement_pct: Decimal = Decimal("0"), returned_kg: Decimal = Decimal("0"), cancelled_sales: Decimal = Decimal("0")) -> IncentiveResult:
    if result.state not in {"INVOICED", "DISPATCHED"}:
        raise SalesTransactionError("INCENTIVE_NOT_ELIGIBLE_BEFORE_INVOICE")
    inp = IncentiveInput(
        eligible_kg=sum((x.quantity_kg for x in result.lines), Decimal("0")),
        net_sales=result.taxable_total,
        gross_margin=result.gross_margin_value,
        verified_collections=verified_collections,
        target_achievement_pct=target_achievement_pct,
        returned_kg=returned_kg,
        cancelled_sales=cancelled_sales,
    )
    return calculate_incentive(policy, inp)
