from fastapi import APIRouter, HTTPException
from decimal import Decimal
from app.v55.qc_control import *

router = APIRouter(prefix='/v55/qc', tags=['v55-qc'])

@router.post('/evaluate-parameter')
def evaluate_parameter(payload: dict):
    try:
        spec = SpecificationLimit(parameter_code=str(payload['parameter_code']), min_value=Decimal(str(payload['min_value'])) if payload.get('min_value') is not None else None, max_value=Decimal(str(payload['max_value'])) if payload.get('max_value') is not None else None, target_value=Decimal(str(payload['target_value'])) if payload.get('target_value') is not None else None, unit=str(payload.get('unit','')), severity=ControlSeverity(payload.get('severity','MAJOR')))
        return {'parameter_code': spec.parameter_code, 'status': spec.evaluate(Decimal(str(payload['value']))).value}
    except (KeyError, ValueError) as e:
        raise HTTPException(400, str(e))

@router.post('/tpc')
def tpc(payload: dict):
    try:
        r=OilTPCReading(int(payload['batch_id']), Decimal(str(payload['reading_pct'])), Decimal(str(payload.get('limit_pct','25'))), payload.get('checked_by'))
        return {'batch_id':r.batch_id,'reading_pct':str(r.reading_pct),'limit_pct':str(r.limit_pct),'status':r.status.value}
    except (KeyError, ValueError) as e:
        raise HTTPException(400,str(e))
