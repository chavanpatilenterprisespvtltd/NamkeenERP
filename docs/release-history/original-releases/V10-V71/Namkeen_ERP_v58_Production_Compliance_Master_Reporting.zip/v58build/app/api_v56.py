from fastapi import APIRouter, HTTPException
from decimal import Decimal
from app.v56.qc_integration import build_settlement, assert_batch_can_complete
from app.v55.qc_control import CheckStatus

router = APIRouter(prefix="/v56/qc", tags=["v56-qc-integration"])

@router.post("/settlement-preview")
def settlement_preview(payload: dict):
    try:
        # Preview endpoint accepts summary inputs; production/mobile client still sends authoritative inspection records server-side.
        batch_id = int(payload["batch_id"])
        status = CheckStatus(payload["qc_status"])
        good = Decimal(str(payload.get("good_output_kg", "0")))
        reject = Decimal(str(payload.get("reject_output_kg", "0")))
        rework = Decimal(str(payload.get("rework_output_kg", "0")))
        if status is CheckStatus.PASS and good <= 0:
            raise ValueError("QC_PASS_REQUIRES_GOOD_OUTPUT")
        outcome = "RELEASE" if status is CheckStatus.PASS else ("REWORK" if rework > 0 else ("HOLD" if status is CheckStatus.HOLD else "REJECT"))
        return {"batch_id": batch_id, "qc_status": status.value, "outcome": outcome, "can_complete_batch": status is CheckStatus.PASS and good > 0,
                "reject_qty_kg": str(reject), "rework_qty_kg": str(rework)}
    except (KeyError, ValueError) as exc:
        raise HTTPException(400, str(exc))
