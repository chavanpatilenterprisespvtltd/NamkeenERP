from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
import base64, hashlib, hmac, os, secrets

@dataclass(frozen=True)
class ObjectMeta:
    object_id: str
    storage_key: str
    content_type: str
    size_bytes: int
    sha256: str

class LocalDocumentStore:
    """Development/local-server implementation. Swap to S3/Azure/MinIO adapter in production."""
    def __init__(self, root: str = "./private_objects", signing_secret: str|None = None):
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.signing_secret = (signing_secret or os.getenv("DOCUMENT_SIGNING_SECRET", "CHANGE_ME_IN_PRODUCTION")).encode()
    def put(self, data: bytes, content_type: str, object_id: str|None = None) -> ObjectMeta:
        oid = object_id or secrets.token_urlsafe(18)
        sha = hashlib.sha256(data).hexdigest()
        key = f"{oid}/{sha}"
        path = self.root / key
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        return ObjectMeta(oid,key,content_type,len(data),sha)
    def sign(self, object_id: str, expires_seconds: int = 300) -> str:
        exp = int((datetime.now(timezone.utc)+timedelta(seconds=expires_seconds)).timestamp())
        msg=f"{object_id}.{exp}".encode(); sig=hmac.new(self.signing_secret,msg,hashlib.sha256).hexdigest()
        return base64.urlsafe_b64encode(f"{object_id}.{exp}.{sig}".encode()).decode()
    def verify_token(self, token: str, object_id: str) -> bool:
        try:
            raw=base64.urlsafe_b64decode(token.encode()).decode(); oid, exp, sig=raw.split(".",2)
            if oid!=object_id or int(exp)<int(datetime.now(timezone.utc).timestamp()): return False
            expected=hmac.new(self.signing_secret,f"{oid}.{exp}".encode(),hashlib.sha256).hexdigest()
            return hmac.compare_digest(sig,expected)
        except Exception: return False
