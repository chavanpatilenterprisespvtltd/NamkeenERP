
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models import InventoryLot, InventoryLedger

class InventoryError(Exception): pass

def receive_stock(db: Session, *, organization_id, entity_id, warehouse_code, sku_id, batch_no, expiry_date, qty, ref_id):
    qty=Decimal(qty)
    if qty<=0: raise InventoryError("QTY_MUST_BE_POSITIVE")
    lot=db.execute(select(InventoryLot).where(
        InventoryLot.entity_id==entity_id,
        InventoryLot.warehouse_code==warehouse_code,
        InventoryLot.sku_id==sku_id,
        InventoryLot.batch_no==batch_no
    ).with_for_update()).scalar_one_or_none()
    if lot is None:
        lot=InventoryLot(organization_id=organization_id,entity_id=entity_id,warehouse_code=warehouse_code,
                         sku_id=sku_id,batch_no=batch_no,expiry_date=expiry_date,
                         qty_available=qty,qty_reserved=0)
        db.add(lot); db.flush()
    else:
        lot.qty_available+=qty
    db.add(InventoryLedger(organization_id=organization_id,entity_id=entity_id,lot_id=lot.id,
                           txn_type="RECEIPT",qty=qty,reference_type="GRN",reference_id=ref_id))
    return lot

def reserve_fefo(db: Session, *, entity_id, warehouse_code, sku_id, qty):
    qty=Decimal(qty)
    if qty<=0: raise InventoryError("QTY_MUST_BE_POSITIVE")
    lots=db.execute(select(InventoryLot).where(
        InventoryLot.entity_id==entity_id,
        InventoryLot.warehouse_code==warehouse_code,
        InventoryLot.sku_id==sku_id,
        (InventoryLot.qty_available-InventoryLot.qty_reserved)>0
    ).order_by(InventoryLot.expiry_date.asc().nulls_last(),InventoryLot.id.asc()).with_for_update()).scalars().all()
    remain=qty; allocations=[]
    for lot in lots:
        free=lot.qty_available-lot.qty_reserved
        take=min(free,remain)
        if take>0:
            lot.qty_reserved+=take
            allocations.append((lot.id,lot.batch_no,take,lot.expiry_date))
            remain-=take
        if remain<=0: break
    if remain>0:
        raise InventoryError(f"STOCK_SHORTAGE:{remain}")
    return allocations

def post_dispatch(db: Session, *, organization_id, entity_id, order_no, allocations):
    total=Decimal("0")
    for lot_id,batch_no,qty,expiry_date in allocations:
        lot=db.execute(select(InventoryLot).where(InventoryLot.id==lot_id).with_for_update()).scalar_one()
        qty=Decimal(qty)
        if lot.qty_reserved<qty or lot.qty_available<qty:
            raise InventoryError(f"STOCK_OR_RESERVATION_ERROR:{batch_no}")
        lot.qty_reserved-=qty
        lot.qty_available-=qty
        db.add(InventoryLedger(organization_id=organization_id,entity_id=entity_id,lot_id=lot.id,
                               txn_type="DISPATCH",qty=-qty,reference_type="SALES_ORDER",reference_id=order_no))
        total+=qty
    return total
