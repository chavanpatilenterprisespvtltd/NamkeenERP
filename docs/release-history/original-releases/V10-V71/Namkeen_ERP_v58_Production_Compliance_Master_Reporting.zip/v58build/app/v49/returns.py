from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Optional, Iterable
from datetime import datetime, timezone

class ReturnStatus(str, Enum):
    DRAFT='DRAFT'; REQUESTED='REQUESTED'; APPROVED='APPROVED'; PICKUP='PICKUP'; RECEIVED='RECEIVED'; QC_HOLD='QC_HOLD'; DISPOSITIONED='DISPOSITIONED'; SETTLED='SETTLED'; REJECTED='REJECTED'; CANCELLED='CANCELLED'

class ReturnReason(str, Enum):
    WRONG_ITEM='WRONG_ITEM'; DAMAGED='DAMAGED'; EXPIRED='EXPIRED'; QUALITY='QUALITY'; SHORT_SHELF_LIFE='SHORT_SHELF_LIFE'; CUSTOMER_REJECTION='CUSTOMER_REJECTION'; TRANSIT_DAMAGE='TRANSIT_DAMAGE'; OTHER='OTHER'

class Disposition(str, Enum):
    SALEABLE='SALEABLE'; REPACK='REPACK'; REWORK='REWORK'; DAMAGE='DAMAGE'; EXPIRED='EXPIRED'; DISPOSE='DISPOSE'

class CreditNoteStatus(str, Enum):
    NOT_REQUIRED='NOT_REQUIRED'; DRAFT='DRAFT'; APPROVAL='APPROVAL'; APPROVED='APPROVED'; POSTED='POSTED'

@dataclass(frozen=True)
class ReturnLine:
    line_id: int
    return_id: int
    sku_id: int
    invoice_line_id: int
    ordered_qty_kg: Decimal
    requested_qty_kg: Decimal
    reason: ReturnReason
    lpn_id: Optional[int] = None
    lot_id: Optional[int] = None

@dataclass
class SalesReturn:
    return_id: int
    customer_id: int
    invoice_id: int
    status: ReturnStatus = ReturnStatus.DRAFT
    requested_at: datetime = datetime.now(timezone.utc)
    approved_by_role: Optional[str] = None
    approval_reason: Optional[str] = None
    pickup_trip_id: Optional[int] = None
    delivery_return_reference: Optional[str] = None
    credit_note_status: CreditNoteStatus = CreditNoteStatus.NOT_REQUIRED

@dataclass(frozen=True)
class ReturnQCResult:
    line_id: int
    disposition: Disposition
    accepted_qty_kg: Decimal
    rejected_qty_kg: Decimal
    reason: str
    evidence_ref: Optional[str] = None

@dataclass(frozen=True)
class ReturnSettlement:
    return_id: int
    saleable_kg: Decimal
    repack_kg: Decimal
    rework_kg: Decimal
    damage_kg: Decimal
    expired_kg: Decimal
    dispose_kg: Decimal
    credit_note_amount: Decimal

AUTHORIZED_APPROVERS = {'MANAGER','MANAGEMENT','ACCOUNTS'}


def create_return(return_id:int, customer_id:int, invoice_id:int, *, reason:ReturnReason, requested_qty_kg:Decimal, invoice_line_id:int, sku_id:int, lpn_id:Optional[int]=None, lot_id:Optional[int]=None) -> tuple[SalesReturn, ReturnLine]:
    if requested_qty_kg <= 0: raise ValueError('INVALID_RETURN_QTY')
    r=SalesReturn(return_id, customer_id, invoice_id, status=ReturnStatus.REQUESTED)
    line=ReturnLine(return_id*1000+1, return_id, sku_id, invoice_line_id, requested_qty_kg, requested_qty_kg, reason, lpn_id, lot_id)
    return r,line


def approve_return(ret:SalesReturn, role:str, reason:str)->None:
    if ret.status != ReturnStatus.REQUESTED: raise ValueError('RETURN_NOT_REQUESTED')
    if role not in AUTHORIZED_APPROVERS: raise ValueError('APPROVER_NOT_AUTHORIZED')
    if not reason.strip(): raise ValueError('REASON_REQUIRED')
    ret.status=ReturnStatus.APPROVED; ret.approved_by_role=role; ret.approval_reason=reason


def assign_pickup(ret:SalesReturn, trip_id:int)->None:
    if ret.status != ReturnStatus.APPROVED: raise ValueError('RETURN_NOT_APPROVED')
    if trip_id <= 0: raise ValueError('INVALID_TRIP_ID')
    ret.status=ReturnStatus.PICKUP; ret.pickup_trip_id=trip_id


def receive_return(ret:SalesReturn, *, reference:str, scanned_qty_kg:Decimal)->None:
    if ret.status != ReturnStatus.PICKUP: raise ValueError('RETURN_NOT_IN_PICKUP')
    if not reference.strip(): raise ValueError('REFERENCE_REQUIRED')
    if scanned_qty_kg <= 0: raise ValueError('INVALID_RECEIPT_QTY')
    ret.status=ReturnStatus.RECEIVED; ret.delivery_return_reference=reference


def move_to_qc_hold(ret:SalesReturn)->None:
    if ret.status != ReturnStatus.RECEIVED: raise ValueError('RETURN_NOT_RECEIVED')
    ret.status=ReturnStatus.QC_HOLD


def validate_qc_result(result:ReturnQCResult, received_qty_kg:Decimal)->None:
    if result.accepted_qty_kg < 0 or result.rejected_qty_kg < 0: raise ValueError('INVALID_QC_QTY')
    if result.accepted_qty_kg + result.rejected_qty_kg != received_qty_kg: raise ValueError('QC_QTY_MISMATCH')
    if result.disposition in {Disposition.DAMAGE,Disposition.EXPIRED,Disposition.DISPOSE} and not result.reason.strip(): raise ValueError('REASON_REQUIRED')
    if not result.reason.strip(): raise ValueError('QC_REASON_REQUIRED')


def disposition_return(ret:SalesReturn, results:Iterable[ReturnQCResult], *, credit_note_amount:Decimal=Decimal('0'))->ReturnSettlement:
    if ret.status != ReturnStatus.QC_HOLD: raise ValueError('RETURN_NOT_IN_QC_HOLD')
    totals={d:Decimal('0') for d in Disposition}
    got=False
    for x in results:
        got=True; totals[x.disposition]+=x.accepted_qty_kg
    if not got: raise ValueError('QC_RESULT_REQUIRED')
    if credit_note_amount < 0: raise ValueError('INVALID_CREDIT_NOTE_AMOUNT')
    ret.status=ReturnStatus.DISPOSITIONED
    ret.credit_note_status = CreditNoteStatus.DRAFT if credit_note_amount > 0 else CreditNoteStatus.NOT_REQUIRED
    return ReturnSettlement(ret.return_id, totals[Disposition.SALEABLE], totals[Disposition.REPACK], totals[Disposition.REWORK], totals[Disposition.DAMAGE], totals[Disposition.EXPIRED], totals[Disposition.DISPOSE], credit_note_amount)


def approve_credit_note(ret:SalesReturn, role:str, reason:str)->None:
    if ret.credit_note_status != CreditNoteStatus.DRAFT: raise ValueError('CREDIT_NOTE_NOT_PENDING')
    if role not in AUTHORIZED_APPROVERS: raise ValueError('APPROVER_NOT_AUTHORIZED')
    if not reason.strip(): raise ValueError('REASON_REQUIRED')
    ret.credit_note_status=CreditNoteStatus.APPROVED


def post_return_settlement(ret:SalesReturn, *, inventory_action:str, credit_note_action:str)->None:
    if ret.status != ReturnStatus.DISPOSITIONED: raise ValueError('RETURN_NOT_DISPOSITIONED')
    valid_inventory={'REENTER_SALEABLE','SEND_TO_REPACK','SEND_TO_REWORK','HOLD_DAMAGE','HOLD_EXPIRED','DISPOSE'}
    valid_credit={'NO_CREDIT_NOTE','POST_APPROVED_CREDIT_NOTE','MANAGEMENT_REVIEW'}
    if inventory_action not in valid_inventory: raise ValueError('INVALID_INVENTORY_ACTION')
    if credit_note_action not in valid_credit: raise ValueError('INVALID_CREDIT_NOTE_ACTION')
    if credit_note_action == 'POST_APPROVED_CREDIT_NOTE' and ret.credit_note_status != CreditNoteStatus.APPROVED: raise ValueError('CREDIT_NOTE_NOT_APPROVED')
    ret.status=ReturnStatus.SETTLED
