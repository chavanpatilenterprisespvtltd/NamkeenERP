from fastapi import APIRouter, HTTPException
from decimal import Decimal
from .returns import *
router=APIRouter(prefix='/v49/returns', tags=['v49-sales-returns'])

@router.post('/request')
def request_return(payload:dict):
    try:
        r,l=create_return(int(payload['return_id']),int(payload['customer_id']),int(payload['invoice_id']),reason=ReturnReason(payload['reason']),requested_qty_kg=Decimal(str(payload['requested_qty_kg'])),invoice_line_id=int(payload['invoice_line_id']),sku_id=int(payload['sku_id']),lpn_id=payload.get('lpn_id'),lot_id=payload.get('lot_id'))
        return {'status':r.status.value,'return_id':r.return_id,'line_id':l.line_id}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))

@router.post('/approve')
def approve(payload:dict):
    try:
        r=SalesReturn(int(payload['return_id']),int(payload['customer_id']),int(payload['invoice_id']),status=ReturnStatus.REQUESTED)
        approve_return(r,payload['role'],payload['reason'])
        return {'status':r.status.value,'approved_by_role':r.approved_by_role}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))

@router.post('/receive-qc')
def receive_qc(payload:dict):
    try:
        r=SalesReturn(int(payload['return_id']),int(payload['customer_id']),int(payload['invoice_id']),status=ReturnStatus.PICKUP)
        receive_return(r,reference=payload['reference'],scanned_qty_kg=Decimal(str(payload['received_qty_kg'])))
        move_to_qc_hold(r)
        return {'status':r.status.value}
    except (KeyError,ValueError) as e: raise HTTPException(400,str(e))
