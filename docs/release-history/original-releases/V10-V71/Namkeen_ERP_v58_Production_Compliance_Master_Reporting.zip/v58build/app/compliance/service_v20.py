from __future__ import annotations
from app.sync.domain_integration_v20 import emit

def record_compliance_change(db, *, org_id:int, entity_id:int, task_id:int|str, event_name:str,
                             actor_user_id:int, status:str, requirement_code:str, due_date=None, note=None):
    if event_name not in {"COMPLIANCE_TASK_CREATED","COMPLIANCE_TASK_COMPLETED"}:
        raise ValueError("INVALID_COMPLIANCE_EVENT")
    payload={"task_id":str(task_id),"status":status,"requirement_code":requirement_code,
             "due_date":None if due_date is None else str(due_date),"note":note}
    return emit(db,org_id=org_id,entity_id=entity_id,aggregate_type="COMPLIANCE_TASK",aggregate_id=task_id,
                event_name=event_name,operation="CREATE" if event_name.endswith("CREATED") else "UPDATE",
                actor_user_id=actor_user_id,payload=payload)
