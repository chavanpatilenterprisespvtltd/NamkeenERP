from datetime import date
from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from app.auth.security import decode_access, actor_from_claims
from app.auth.authorization import require_entity
from app.db.session import SessionLocal
from sqlalchemy import text

app=FastAPI(title='Namkeen ERP API v32 — Warehouse Intelligence',version='32.0')

def actor(auth):
    if not auth or not auth.lower().startswith('bearer '): raise HTTPException(401,'Bearer token required')
    try: return actor_from_claims(decode_access(auth.split(' ',1)[1]))
    except Exception: raise HTTPException(401,'Invalid or expired token')

def guard(a,entity_id):
    try: require_entity(a.entity_ids,entity_id)
    except PermissionError as e: raise HTTPException(403,str(e))

class AlertIn(BaseModel): entity_id:int; sku_id:int; warehouse_id:int; minimum_stock_kg:Decimal=0; reorder_level_kg:Decimal=0; target_stock_kg:Decimal=0; safety_stock_kg:Decimal=0

@app.get('/v32/health')
def health(): return {'version':'32.0','service':'warehouse-intelligence'}

@app.get('/v32/warehouse/summary')
def summary(entity_id:int,warehouse_id:int,authorization:str|None=Header(default=None)):
    a=actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        # Operational implementation intentionally uses SQL views/tables installed by migration 021.
        row=db.execute(text('SELECT total_stock_kg, available_stock_kg, reserved_stock_kg, expired_kg, expiring_7d_kg, expiring_30d_kg, bin_count, occupied_bin_count, occupancy_pct FROM v32_warehouse_summary WHERE organization_id=:o AND entity_id=:e AND warehouse_id=:w'),{'o':a.organization_id,'e':entity_id,'w':warehouse_id}).mappings().first()
        return dict(row) if row else {'total_stock_kg':'0','available_stock_kg':'0','reserved_stock_kg':'0','expired_kg':'0','expiring_7d_kg':'0','expiring_30d_kg':'0','bin_count':0,'occupied_bin_count':0,'occupancy_pct':'0.00'}

@app.get('/v32/warehouse/replenishment')
def replenishment(entity_id:int,warehouse_id:int,authorization:str|None=Header(default=None)):
    a=actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        rows=db.execute(text('SELECT sku_id, available_kg, minimum_stock_kg, reorder_level_kg, target_stock_kg, suggested_qty_kg, severity FROM v32_replenishment_alerts WHERE organization_id=:o AND entity_id=:e AND warehouse_id=:w ORDER BY severity_order, sku_id'),{'o':a.organization_id,'e':entity_id,'w':warehouse_id}).mappings().all()
        return [dict(r) for r in rows]

@app.get('/v32/warehouse/fefo')
def fefo(entity_id:int,warehouse_id:int,sku_id:int,authorization:str|None=Header(default=None)):
    a=actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        rows=db.execute(text('SELECT lot_id, batch_no, expiry_date, qty_available_kg, qty_reserved_kg, available_kg FROM v32_fefo_availability WHERE organization_id=:o AND entity_id=:e AND warehouse_id=:w AND sku_id=:s ORDER BY expiry_sort, lot_id'),{'o':a.organization_id,'e':entity_id,'w':warehouse_id,'s':sku_id}).mappings().all()
        return [dict(r) for r in rows]

@app.get('/v32/warehouse/picking-kpis')
def picking_kpis(entity_id:int,warehouse_id:int,authorization:str|None=Header(default=None)):
    a=actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        row=db.execute(text('SELECT open_tasks, assigned_tasks, picked_tasks, short_picks, completion_pct, picked_qty_kg FROM v32_picking_kpis WHERE organization_id=:o AND entity_id=:e AND warehouse_id=:w'),{'o':a.organization_id,'e':entity_id,'w':warehouse_id}).mappings().first()
        return dict(row) if row else {'open_tasks':0,'assigned_tasks':0,'picked_tasks':0,'short_picks':0,'completion_pct':'0.00','picked_qty_kg':'0'}

@app.get('/v32/warehouse/count-kpis')
def count_kpis(entity_id:int,warehouse_id:int,authorization:str|None=Header(default=None)):
    a=actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        row=db.execute(text('SELECT open_sessions, pending_approval, approved, variance_kg FROM v32_count_kpis WHERE organization_id=:o AND entity_id=:e AND warehouse_id=:w'),{'o':a.organization_id,'e':entity_id,'w':warehouse_id}).mappings().first()
        return dict(row) if row else {'open_sessions':0,'pending_approval':0,'approved':0,'variance_kg':'0'}
