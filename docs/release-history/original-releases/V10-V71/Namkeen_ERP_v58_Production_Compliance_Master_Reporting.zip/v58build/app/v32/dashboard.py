from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable, Optional

class DashboardError(ValueError):
    pass

@dataclass(frozen=True)
class StockRow:
    warehouse_id: int
    sku_id: int
    lot_id: int
    qty_kg: Decimal
    reserved_kg: Decimal = Decimal('0')
    expiry_date: Optional[date] = None
    location_code: Optional[str] = None

    @property
    def available_kg(self) -> Decimal:
        return max(Decimal('0'), self.qty_kg - self.reserved_kg)

@dataclass(frozen=True)
class ReorderPolicy:
    sku_id: int
    warehouse_id: int
    minimum_stock_kg: Decimal = Decimal('0')
    reorder_level_kg: Decimal = Decimal('0')
    target_stock_kg: Decimal = Decimal('0')
    safety_stock_kg: Decimal = Decimal('0')
    active: bool = True

@dataclass(frozen=True)
class WarehouseKpis:
    total_stock_kg: Decimal
    available_stock_kg: Decimal
    reserved_stock_kg: Decimal
    expiring_7d_kg: Decimal
    expiring_30d_kg: Decimal
    expired_kg: Decimal
    bin_count: int
    occupied_bin_count: int
    occupancy_pct: Decimal

@dataclass(frozen=True)
class ReplenishmentSuggestion:
    sku_id: int
    warehouse_id: int
    available_kg: Decimal
    reorder_level_kg: Decimal
    target_stock_kg: Decimal
    suggested_qty_kg: Decimal
    severity: str

@dataclass(frozen=True)
class PickKpis:
    open_tasks: int
    assigned_tasks: int
    picked_tasks: int
    short_picks: int
    completion_pct: Decimal
    picked_qty_kg: Decimal

@dataclass(frozen=True)
class CountKpis:
    open_sessions: int
    pending_approval: int
    approved: int
    variance_kg: Decimal


def inventory_aging(rows: Iterable[StockRow], today: date) -> dict:
    expired = exp7 = exp30 = Decimal('0')
    for r in rows:
        q = r.available_kg
        if q <= 0 or r.expiry_date is None:
            continue
        days = (r.expiry_date - today).days
        if days < 0:
            expired += q
        elif days <= 7:
            exp7 += q
        elif days <= 30:
            exp30 += q
    return {'expired_kg': expired, 'expiring_7d_kg': exp7, 'expiring_30d_kg': exp30}


def warehouse_kpis(rows: Iterable[StockRow], *, bin_capacity: Optional[Decimal] = None,
                   occupied_bins: int = 0, bin_count: int = 0, today: Optional[date] = None) -> WarehouseKpis:
    data=list(rows)
    total=sum((r.qty_kg for r in data), Decimal('0'))
    available=sum((r.available_kg for r in data), Decimal('0'))
    reserved=sum((max(Decimal('0'), r.reserved_kg) for r in data), Decimal('0'))
    age=inventory_aging(data, today or date.today())
    if bin_count < 0 or occupied_bins < 0 or occupied_bins > bin_count:
        raise DashboardError('INVALID_BIN_COUNTS')
    occupancy = (Decimal(occupied_bins) / Decimal(bin_count) * Decimal('100')) if bin_count else Decimal('0')
    return WarehouseKpis(total, available, reserved, age['expiring_7d_kg'], age['expiring_30d_kg'], age['expired_kg'], bin_count, occupied_bins, occupancy.quantize(Decimal('0.01')))


def replenishment_suggestions(rows: Iterable[StockRow], policies: Iterable[ReorderPolicy]) -> list[ReplenishmentSuggestion]:
    by_key={}
    for r in rows:
        by_key[(r.warehouse_id,r.sku_id)] = by_key.get((r.warehouse_id,r.sku_id), Decimal('0')) + r.available_kg
    out=[]
    for p in policies:
        if not p.active or p.target_stock_kg < p.reorder_level_kg:
            continue
        av=by_key.get((p.warehouse_id,p.sku_id),Decimal('0'))
        if av <= p.reorder_level_kg:
            qty=max(Decimal('0'), p.target_stock_kg - av)
            severity='CRITICAL' if av <= p.minimum_stock_kg else 'REORDER'
            if qty > 0:
                out.append(ReplenishmentSuggestion(p.sku_id,p.warehouse_id,av,p.reorder_level_kg,p.target_stock_kg,qty,severity))
    return sorted(out,key=lambda x:(0 if x.severity=='CRITICAL' else 1, x.warehouse_id, x.sku_id))


def fefo_available(rows: Iterable[StockRow], sku_id: int, warehouse_id: int) -> list[StockRow]:
    candidates=[r for r in rows if r.sku_id==sku_id and r.warehouse_id==warehouse_id and r.available_kg>0]
    return sorted(candidates,key=lambda r:(r.expiry_date is None, r.expiry_date or date.max, r.lot_id))


def pick_kpis(tasks: Iterable[dict]) -> PickKpis:
    t=list(tasks)
    status=lambda s: sum(1 for x in t if x.get('status')==s)
    short=sum(1 for x in t if x.get('short_pick_reason'))
    qty=sum((Decimal(str(x.get('picked_qty_kg',0))) for x in t),Decimal('0'))
    completed=status('PICKED')
    denom=len(t)
    pct=(Decimal(completed)/Decimal(denom)*Decimal('100')) if denom else Decimal('0')
    return PickKpis(status('OPEN'),status('ASSIGNED'),completed,short,pct.quantize(Decimal('0.01')),qty)


def count_kpis(sessions: Iterable[dict]) -> CountKpis:
    s=list(sessions)
    var=sum((Decimal(str(x.get('variance_kg',0))) for x in s),Decimal('0'))
    return CountKpis(sum(1 for x in s if x.get('status')=='OPEN'),sum(1 for x in s if x.get('status')=='PENDING_APPROVAL'),sum(1 for x in s if x.get('status')=='APPROVED'),var)
