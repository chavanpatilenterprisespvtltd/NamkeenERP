from __future__ import annotations
from datetime import datetime, timezone
import json
from fastapi import FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, update
from app.db.session import SessionLocal
from app.auth.security import decode_access, actor_from_claims
from app.db.models_v18 import SyncChangeLog, SyncCursor, SyncConflict, SyncDeadLetter
from app.sync.twoway import get_deltas, compare_version, upsert_sync_event

app = FastAPI(title="Namkeen ERP v18 — Two-Way Mobile Sync", version="18.0")

class PushEvent(BaseModel):
    device_id: str = Field(min_length=2)
    client_event_id: str = Field(min_length=2)
    event_type: str = Field(min_length=2)
    entity_type: str = Field(min_length=2)
    entity_id: str = Field(min_length=1)
    client_version: int | None = None
    payload: dict

class SyncPull(BaseModel):
    device_id: str = Field(min_length=2)
    cursor: int = 0
    limit: int = Field(default=200, ge=1, le=1000)

class ConflictResolve(BaseModel):
    resolution: str = Field(pattern="^(ACCEPT_SERVER|ACCEPT_CLIENT|DISCARD)$")
    note: str | None = None

def actor(auth: str|None):
    if not auth or not auth.lower().startswith("bearer "):
        raise HTTPException(401, "Bearer token required")
    try:
        return actor_from_claims(decode_access(auth.split(" ",1)[1]))
    except Exception:
        raise HTTPException(401, "Invalid or expired token")

def scope(a, entity_id:int|None):
    if entity_id is not None and entity_id not in a.entity_ids:
        raise HTTPException(403, "Entity scope violation")

@app.get("/v18/sync/pull")
def pull(device_id: str = Query(min_length=2), cursor: int = Query(default=0, ge=0), limit: int = Query(default=200, ge=1, le=1000), authorization: str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            deltas, next_cursor = get_deltas(db, change_log_model=SyncChangeLog, org_id=a.organization_id, cursor=cursor, limit=limit)
            cur = db.execute(select(SyncCursor).where(SyncCursor.organization_id==a.organization_id, SyncCursor.device_id==device_id).with_for_update()).scalar_one_or_none()
            if cur is None:
                cur = SyncCursor(organization_id=a.organization_id, device_id=device_id, cursor=cursor, updated_at=datetime.now(timezone.utc)); db.add(cur)
            else:
                # Device acknowledgement never moves backwards.
                if cursor > cur.cursor: cur.cursor = cursor
                cur.updated_at = datetime.now(timezone.utc)
        return {"device_id":device_id,"from_cursor":cursor,"next_cursor":next_cursor,"has_more":next_cursor>cursor and len(deltas)>=limit,"deltas":deltas}
    except Exception as e:
        raise HTTPException(400,str(e))
    finally: db.close()

@app.post("/v18/sync/push")
def push(body: PushEvent, authorization: str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        with db.begin():
            ev,status=upsert_sync_event(db, org_id=a.organization_id, device_id=body.device_id, client_event_id=body.client_event_id,
                                        event_type=body.event_type, payload=body.payload, base_version=body.client_version)
            if status == "DUPLICATE":
                return {"status":"DUPLICATE","event_id":ev.id}
            if body.client_version is not None:
                # In this generic sync layer the latest known change for this entity acts as the server version.
                latest = db.execute(select(SyncChangeLog).where(
                    SyncChangeLog.organization_id==a.organization_id,
                    SyncChangeLog.entity_type==body.entity_type,
                    SyncChangeLog.entity_id==body.entity_id,
                ).order_by(SyncChangeLog.version.desc()).limit(1)).scalar_one_or_none()
                server_version = latest.version if latest else None
                verdict = compare_version(client_version=body.client_version, server_version=server_version)
                if verdict == "CONFLICT":
                    db.add(SyncConflict(organization_id=a.organization_id, device_id=body.device_id,
                        client_event_id=body.client_event_id, entity_type=body.entity_type, entity_id=body.entity_id,
                        client_version=body.client_version, server_version=server_version,
                        client_payload_json=json.dumps(body.payload,separators=(",",":")),
                        server_payload_json=latest.payload_json if latest else None))
                    ev.status="CONFLICT"
                    return {"status":"CONFLICT","event_id":ev.id,"server_version":server_version}
                if verdict == "REJECTED":
                    ev.status="REJECTED"
                    db.add(SyncDeadLetter(organization_id=a.organization_id, device_id=body.device_id, client_event_id=body.client_event_id,
                        event_type=body.event_type,payload_json=json.dumps(body.payload,separators=(",",":")),error_code="CLIENT_VERSION_AHEAD",
                        error_message="Client version is ahead of server; refresh before retrying."))
                    return {"status":"REJECTED","event_id":ev.id,"server_version":server_version}
            ev.status="ACCEPTED"
        return {"status":"ACCEPTED","event_id":ev.id}
    except Exception as e:
        raise HTTPException(400,str(e))
    finally: db.close()

@app.get("/v18/sync/conflicts")
def conflicts(status: str = Query(default="OPEN", pattern="^(OPEN|RESOLVED|ALL)$"), authorization: str|None=Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        q=select(SyncConflict).where(SyncConflict.organization_id==a.organization_id)
        if status != "ALL": q=q.where(SyncConflict.resolution_status==status)
        rows=db.execute(q.order_by(SyncConflict.created_at.desc()).limit(500)).scalars().all()
        return {"items":[{"id":r.id,"device_id":r.device_id,"client_event_id":r.client_event_id,"entity_type":r.entity_type,"entity_id":r.entity_id,"client_version":r.client_version,"server_version":r.server_version,"status":r.resolution_status,"client_payload":json.loads(r.client_payload_json),"server_payload":json.loads(r.server_payload_json) if r.server_payload_json else None} for r in rows]}
    finally: db.close()

@app.post("/v18/sync/conflicts/{conflict_id}/resolve")
def resolve(conflict_id:int, body:ConflictResolve, authorization:str|None=Header(default=None)):
    a=actor(authorization)
    if a.role not in {"MANAGER","MANAGEMENT","SUPER_ADMIN"}: raise HTTPException(403,"Conflict resolution requires management role")
    db=SessionLocal()
    try:
        with db.begin():
            row=db.execute(select(SyncConflict).where(SyncConflict.id==conflict_id, SyncConflict.organization_id==a.organization_id).with_for_update()).scalar_one()
            if row.resolution_status != "OPEN": raise HTTPException(409,"Conflict already resolved")
            row.resolution_status="RESOLVED"; row.resolution_note=body.note; row.resolved_by=a.user_id; row.resolved_at=datetime.now(timezone.utc)
            # ACCEPT_SERVER/DISCARD stop the client event. ACCEPT_CLIENT deliberately only marks the conflict resolved;
            # domain-specific replay must be performed by its transaction service after review.
        return {"id":row.id,"status":row.resolution_status,"resolution":body.resolution}
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,str(e))
    finally: db.close()
