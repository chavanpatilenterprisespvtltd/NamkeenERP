from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Iterable, Optional

Q6 = Decimal('0.000001')

def q(v): return Decimal(str(v)).quantize(Q6, rounding=ROUND_HALF_UP)

class MRPError(ValueError): pass

class ProductionOrderStatus(str, Enum):
    DRAFT='DRAFT'; PENDING_APPROVAL='PENDING_APPROVAL'; RELEASED='RELEASED'; IN_PROGRESS='IN_PROGRESS'; COMPLETED='COMPLETED'; CANCELLED='CANCELLED'

@dataclass(frozen=True)
class DemandLine:
    demand_id:int; sku_id:int; required_good_qty_kg:Decimal; due_date:str; source:str='SALES'
    def __post_init__(self):
        if self.demand_id<=0 or self.sku_id<=0 or q(self.required_good_qty_kg)<=0: raise MRPError('INVALID_DEMAND_LINE')

@dataclass(frozen=True)
class InventoryPosition:
    item_id:int; available_qty_kg:Decimal=Decimal('0'); reserved_qty_kg:Decimal=Decimal('0')
    open_po_qty_kg:Decimal=Decimal('0'); open_production_qty_kg:Decimal=Decimal('0')
    def net_available_for_planning(self):
        return max(Decimal('0'), q(self.available_qty_kg-self.reserved_qty_kg)) + q(self.open_po_qty_kg) + q(self.open_production_qty_kg)

@dataclass(frozen=True)
class MRPComponentRequirement:
    item_id:int; item_type:str; gross_required_qty_kg:Decimal; planned_available_qty_kg:Decimal; net_to_make_or_buy_qty_kg:Decimal

@dataclass(frozen=True)
class MRPResult:
    sku_id:int; planned_output_kg:Decimal; bom_version:str; requirements:tuple[MRPComponentRequirement,...]

@dataclass
class ProductionOrder:
    production_order_id:int; organization_id:int; entity_id:int; sku_id:int; bom_version:str
    planned_good_output_kg:Decimal; due_date:str; status:ProductionOrderStatus=ProductionOrderStatus.DRAFT
    source_demand_ids:list[int]=field(default_factory=list); created_by:Optional[int]=None; approved_by:Optional[int]=None
    release_reason:Optional[str]=None


def explode_mrp(bom, planned_good_output_kg:Decimal, positions:Iterable[InventoryPosition]=()) -> MRPResult:
    from app.v51.bom import calculate_requirements
    plan=calculate_requirements(bom, planned_good_output_kg)
    pos={p.item_id:p for p in positions}
    req=[]
    for r in plan.requirements:
        avail=pos.get(r.item_id, InventoryPosition(r.item_id)).net_available_for_planning()
        short=max(Decimal('0'), q(r.gross_issue_qty-avail))
        req.append(MRPComponentRequirement(r.item_id,r.item_type.value,q(r.gross_issue_qty),q(avail),short))
    return MRPResult(bom.sku_id,q(plan.planned_good_output_kg),bom.version,tuple(req))


def create_production_order(*,production_order_id:int, organization_id:int, entity_id:int, sku_id:int, bom_version:str,
                             planned_good_output_kg:Decimal,due_date:str,created_by:int,source_demand_ids:Iterable[int]=()) -> ProductionOrder:
    qout=q(planned_good_output_kg)
    if min(production_order_id,organization_id,entity_id,sku_id,created_by)<=0: raise MRPError('INVALID_PRODUCTION_ORDER_IDENTITY')
    if qout<=0 or not due_date or not bom_version: raise MRPError('INVALID_PRODUCTION_ORDER')
    ids=[int(x) for x in source_demand_ids]
    if any(x<=0 for x in ids): raise MRPError('INVALID_SOURCE_DEMAND')
    return ProductionOrder(production_order_id,organization_id,entity_id,sku_id,bom_version,qout,due_date,ProductionOrderStatus.PENDING_APPROVAL,ids,created_by)


def approve_production_order(po:ProductionOrder, approved_by:int):
    if po.status!=ProductionOrderStatus.PENDING_APPROVAL: raise MRPError('PRODUCTION_ORDER_NOT_PENDING_APPROVAL')
    if approved_by<=0: raise MRPError('APPROVER_REQUIRED')
    if approved_by==po.created_by: raise MRPError('SELF_APPROVAL_NOT_ALLOWED')
    po.approved_by=approved_by; po.status=ProductionOrderStatus.RELEASED; return po


def start_production(po:ProductionOrder):
    if po.status!=ProductionOrderStatus.RELEASED: raise MRPError('PRODUCTION_ORDER_NOT_RELEASED')
    po.status=ProductionOrderStatus.IN_PROGRESS; return po


def complete_production(po:ProductionOrder, good_output_kg:Decimal):
    good=q(good_output_kg)
    if po.status!=ProductionOrderStatus.IN_PROGRESS: raise MRPError('PRODUCTION_ORDER_NOT_IN_PROGRESS')
    if good<=0 or good>po.planned_good_output_kg: raise MRPError('INVALID_GOOD_OUTPUT')
    po.status=ProductionOrderStatus.COMPLETED; return po


def cancel_production(po:ProductionOrder, reason:str):
    if po.status in {ProductionOrderStatus.COMPLETED,ProductionOrderStatus.CANCELLED}: raise MRPError('PRODUCTION_ORDER_NOT_CANCELLABLE')
    if not reason.strip(): raise MRPError('CANCELLATION_REASON_REQUIRED')
    po.status=ProductionOrderStatus.CANCELLED; po.release_reason=reason.strip(); return po
