from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING
from typing import Iterable, Optional

class PlanningError(ValueError):
    pass

@dataclass(frozen=True)
class SupplierTerm:
    supplier_id: int
    sku_id: int
    lead_time_days: int = 0
    moq_kg: Decimal = Decimal("0")
    order_multiple_kg: Decimal = Decimal("0")
    active: bool = True
    priority: int = 100

@dataclass(frozen=True)
class DemandSignal:
    sku_id: int
    warehouse_id: int
    demand_kg: Decimal
    horizon_days: int
    demand_source: str = "SALES_FORECAST"

@dataclass(frozen=True)
class SupplyPosition:
    sku_id: int
    warehouse_id: int
    available_kg: Decimal = Decimal("0")
    reserved_kg: Decimal = Decimal("0")
    open_po_kg: Decimal = Decimal("0")
    open_production_kg: Decimal = Decimal("0")
    safety_stock_kg: Decimal = Decimal("0")

    @property
    def projected_usable_kg(self) -> Decimal:
        # Inventory availability is already net of reservation in v32. Keep the
        # explicit reservation field for import compatibility, but do not deduct
        # it twice.
        return max(Decimal("0"), self.available_kg + self.open_po_kg + self.open_production_kg)

@dataclass(frozen=True)
class ProcurementSuggestion:
    sku_id: int
    warehouse_id: int
    suggested_qty_kg: Decimal
    supplier_id: Optional[int]
    lead_time_days: int
    reason: str
    severity: str
    approval_required: bool = True

@dataclass(frozen=True)
class ProductionRequirement:
    sku_id: int
    warehouse_id: int
    required_qty_kg: Decimal
    reason: str
    approval_required: bool = True


def _ceil_to_multiple(qty: Decimal, multiple: Decimal) -> Decimal:
    if multiple <= 0:
        return qty
    units = (qty / multiple).to_integral_value(rounding=ROUND_CEILING)
    return units * multiple


def choose_supplier(terms: Iterable[SupplierTerm], sku_id: int, needed_qty_kg: Decimal) -> Optional[SupplierTerm]:
    eligible = [t for t in terms if t.active and t.sku_id == sku_id and t.moq_kg <= needed_qty_kg]
    if not eligible:
        eligible = [t for t in terms if t.active and t.sku_id == sku_id]
    return min(eligible, key=lambda x: (x.priority, x.lead_time_days, x.supplier_id), default=None)


def procurement_plan(signals: Iterable[DemandSignal], supplies: Iterable[SupplyPosition], terms: Iterable[SupplierTerm], *, today_stock_as_of_days: int = 0) -> list[ProcurementSuggestion]:
    supply_map={(s.warehouse_id,s.sku_id): s for s in supplies}
    term_list=list(terms)
    out=[]
    for d in signals:
        if d.demand_kg < 0 or d.horizon_days < 0:
            raise PlanningError("INVALID_DEMAND_SIGNAL")
        s=supply_map.get((d.warehouse_id,d.sku_id), SupplyPosition(d.sku_id,d.warehouse_id))
        required=max(Decimal("0"), d.demand_kg + s.safety_stock_kg - s.available_kg - s.open_po_kg - s.open_production_kg)
        if required <= 0:
            continue
        supplier=choose_supplier(term_list,d.sku_id,required)
        if supplier is None:
            out.append(ProcurementSuggestion(d.sku_id,d.warehouse_id,required,None,0,"NO_ACTIVE_SUPPLIER_TERM","CRITICAL",True))
            continue
        qty=max(required,supplier.moq_kg)
        qty=_ceil_to_multiple(qty,supplier.order_multiple_kg)
        severity="CRITICAL" if s.available_kg <= s.safety_stock_kg else "REORDER"
        reason=f"DEMAND_PLUS_SAFETY_MINUS_STOCK_AND_OPEN_SUPPLY:{d.demand_source}"
        out.append(ProcurementSuggestion(d.sku_id,d.warehouse_id,qty,supplier.supplier_id,supplier.lead_time_days,reason,severity,True))
    return sorted(out,key=lambda x:(0 if x.severity=="CRITICAL" else 1,x.warehouse_id,x.sku_id))


def production_plan(signals: Iterable[DemandSignal], supplies: Iterable[SupplyPosition], *, make_skus: Optional[set[int]]=None) -> list[ProductionRequirement]:
    make_skus=make_skus or set()
    supply_map={(s.warehouse_id,s.sku_id): s for s in supplies}
    out=[]
    for d in signals:
        if d.sku_id not in make_skus:
            continue
        s=supply_map.get((d.warehouse_id,d.sku_id), SupplyPosition(d.sku_id,d.warehouse_id))
        required=max(Decimal("0"), d.demand_kg+s.safety_stock_kg-s.available_kg-s.open_po_kg-s.open_production_kg)
        if required>0:
            out.append(ProductionRequirement(d.sku_id,d.warehouse_id,required,"DEMAND_PLUS_SAFETY_MINUS_STOCK_AND_OPEN_SUPPLY",True))
    return sorted(out,key=lambda x:(x.warehouse_id,x.sku_id))


def validate_moq(qty: Decimal, moq: Decimal) -> Decimal:
    if qty < 0 or moq < 0:
        raise PlanningError("INVALID_MOQ")
    return max(qty,moq)
