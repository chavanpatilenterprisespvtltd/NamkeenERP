from decimal import Decimal
from fastapi import FastAPI
from pydantic import BaseModel
from .planning import DemandSignal, SupplyPosition, SupplierTerm, procurement_plan, production_plan

app=FastAPI(title="Namkeen ERP API v33 — Procurement Planning",version="33.0")

class SupplierTermIn(BaseModel):
    supplier_id:int; sku_id:int; lead_time_days:int=0; moq_kg:Decimal=0; order_multiple_kg:Decimal=0; active:bool=True; priority:int=100
class DemandIn(BaseModel):
    sku_id:int; warehouse_id:int; demand_kg:Decimal; horizon_days:int; demand_source:str="SALES_FORECAST"
class SupplyIn(BaseModel):
    sku_id:int; warehouse_id:int; available_kg:Decimal=0; reserved_kg:Decimal=0; open_po_kg:Decimal=0; open_production_kg:Decimal=0; safety_stock_kg:Decimal=0
class PlanIn(BaseModel):
    demands:list[DemandIn]; supplies:list[SupplyIn]; supplier_terms:list[SupplierTermIn]; make_skus:list[int]=[]

@app.get('/v33/health')
def health():
    return {'version':'33.0','service':'procurement-planning'}

@app.post('/v33/procurement/plan')
def plan(body:PlanIn):
    signals=[DemandSignal(**x.model_dump()) for x in body.demands]
    supplies=[SupplyPosition(**x.model_dump()) for x in body.supplies]
    terms=[SupplierTerm(**x.model_dump()) for x in body.supplier_terms]
    p=procurement_plan(signals,supplies,terms)
    prod=production_plan(signals,supplies,make_skus=set(body.make_skus))
    return {'purchase_suggestions':[x.__dict__ for x in p],'production_requirements':[x.__dict__ for x in prod]}
