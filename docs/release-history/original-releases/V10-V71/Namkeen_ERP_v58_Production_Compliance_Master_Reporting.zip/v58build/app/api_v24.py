from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from app.auth.security import decode_access, actor_from_claims
from app.auth.authorization import require_entity
from app.db.session import SessionLocal, transaction
from app.db.models_v24 import ProductionBatch, ProductionRecord, QCInspection, PriceException
from app.v24.operational import create_batch, record_production, record_qc, request_price_exception, decide_price_exception

app = FastAPI(title="Namkeen ERP API v24 — Operational APIs", version="24.0")

def current_actor(auth: str|None):
    if not auth or not auth.lower().startswith("bearer "): raise HTTPException(401, "Bearer token required")
    try: return actor_from_claims(decode_access(auth.split(" ",1)[1]))
    except Exception: raise HTTPException(401, "Invalid or expired token")

def guard(a, entity_id):
    try: require_entity(a.entity_ids, entity_id)
    except PermissionError as e: raise HTTPException(403, str(e))

class BatchIn(BaseModel):
    entity_id:int; batch_no:str=Field(min_length=1,max_length=80); product_id:int; planned_qty_kg:Decimal=Field(gt=0)
class ProductionIn(BaseModel):
    entity_id:int; good_qty_kg:Decimal=Field(ge=0); reject_qty_kg:Decimal=Field(ge=0,default=0); note:str|None=None
class QCIn(BaseModel):
    entity_id:int; batch_id:int|None=None; return_id:int|None=None; result:str="HOLD"; remarks:str|None=None; evidence_file_id:str|None=None
class PriceRequestIn(BaseModel):
    entity_id:int; order_id:int; line_id:int; negotiated_price:Decimal=Field(gt=0); floor_price:Decimal=Field(gt=0); reason:str|None=None
class PriceDecisionIn(BaseModel):
    entity_id:int; approve:bool; reason:str|None=None

@app.get("/v24/health")
def health(): return {"version":"24.0","service":"operational-api"}

@app.post("/v24/production/batches")
def create_production_batch(body:BatchIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id)
    try:
        with transaction() as db:
            b=create_batch(db,org_id=a.organization_id,entity_id=body.entity_id,actor_id=a.user_id,actor_role=a.role,batch_no=body.batch_no,product_id=body.product_id,planned_qty_kg=body.planned_qty_kg)
            return {"id":b.id,"batch_no":b.batch_no,"status":b.status,"planned_qty_kg":str(b.planned_qty_kg)}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.post("/v24/production/batches/{batch_id}/record")
def record_batch(batch_id:int, body:ProductionIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id)
    try:
        with transaction() as db:
            b=record_production(db,org_id=a.organization_id,entity_id=body.entity_id,actor_id=a.user_id,actor_role=a.role,batch_id=batch_id,good_qty_kg=body.good_qty_kg,reject_qty_kg=body.reject_qty_kg,note=body.note)
            return {"id":b.id,"status":b.status,"actual_qty_kg":str(b.actual_qty_kg)}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.get("/v24/production/batches")
def list_batches(entity_id:int, status:str|None=None, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        q=select(ProductionBatch).where(ProductionBatch.organization_id==a.organization_id,ProductionBatch.entity_id==entity_id)
        if status: q=q.where(ProductionBatch.status==status)
        rows=db.execute(q.order_by(ProductionBatch.id.desc()).limit(200)).scalars().all()
        return [{"id":x.id,"batch_no":x.batch_no,"product_id":x.product_id,"planned_qty_kg":str(x.planned_qty_kg),"actual_qty_kg":str(x.actual_qty_kg),"status":x.status} for x in rows]

@app.post("/v24/qc/inspect")
def qc_inspect(body:QCIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id)
    try:
        with transaction() as db:
            x=record_qc(db,org_id=a.organization_id,entity_id=body.entity_id,actor_id=a.user_id,actor_role=a.role,batch_id=body.batch_id,return_id=body.return_id,result=body.result,remarks=body.remarks,evidence_file_id=body.evidence_file_id)
            return {"id":x.id,"result":x.result,"batch_id":x.batch_id,"return_id":x.return_id}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.get("/v24/qc/pending")
def pending_qc(entity_id:int, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,entity_id)
    with SessionLocal() as db:
        batches=db.execute(select(ProductionBatch).where(ProductionBatch.organization_id==a.organization_id,ProductionBatch.entity_id==entity_id,ProductionBatch.status.in_(["COMPLETED","IN_PROGRESS"])).order_by(ProductionBatch.id.desc()).limit(100)).scalars().all()
        return [{"batch_id":b.id,"batch_no":b.batch_no,"status":b.status} for b in batches]

@app.post("/v24/pricing/exceptions")
def pricing_exception(body:PriceRequestIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id)
    try:
        with transaction() as db:
            x=request_price_exception(db,org_id=a.organization_id,entity_id=body.entity_id,actor_id=a.user_id,order_id=body.order_id,line_id=body.line_id,negotiated_price=body.negotiated_price,floor_price=body.floor_price,reason=body.reason)
            return {"id":x.id,"status":x.status,"negotiated_price":str(x.negotiated_price),"floor_price":str(x.floor_price)}
    except ValueError as e: raise HTTPException(409,str(e))

@app.post("/v24/pricing/exceptions/{exception_id}/decision")
def pricing_decision(exception_id:int, body:PriceDecisionIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id)
    try:
        with transaction() as db:
            x=decide_price_exception(db,org_id=a.organization_id,entity_id=body.entity_id,actor_id=a.user_id,actor_role=a.role,exception_id=exception_id,approve=body.approve,reason=body.reason)
            return {"id":x.id,"status":x.status,"decided_by":x.decided_by}
    except PermissionError as e: raise HTTPException(403,str(e))

# Sales/order operational approvals and stock lifecycle
from types import SimpleNamespace
from app.services.order_posting import approve_order, verify_payment, clear_cheque
from app.transactions.persistent_order import reserve_order_persistent, dispatch_order_persistent

class ApprovalIn(BaseModel): entity_id:int; reason:str|None=None
class VerifyPaymentIn(BaseModel): entity_id:int; payment_id:int|None=None
class ReserveIn(BaseModel): entity_id:int; warehouse_code:str=Field(min_length=1,max_length=50)
class DispatchIn(BaseModel): entity_id:int

@app.post("/v24/sales-orders/{order_id}/approve")
def sales_order_approve(order_id:int, body:ApprovalIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id); actor=SimpleNamespace(id=a.user_id, role=a.role)
    try:
        with transaction() as db:
            o=approve_order(db,order_id=order_id,actor_user=actor,reason=body.reason)
            return {"id":o.id,"order_no":o.order_no,"status":o.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.post("/v24/sales-orders/{order_id}/payment/verify")
def sales_order_payment_verify(order_id:int, body:VerifyPaymentIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id); actor=SimpleNamespace(id=a.user_id, role=a.role)
    try:
        with transaction() as db:
            o=verify_payment(db,order_id=order_id,actor_user=actor,payment_id=body.payment_id)
            return {"id":o.id,"order_no":o.order_no,"status":o.status,"payment_state":o.payment_state}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.post("/v24/sales-orders/{order_id}/cheque/clear")
def sales_order_cheque_clear(order_id:int, body:ApprovalIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id); actor=SimpleNamespace(id=a.user_id, role=a.role)
    try:
        with transaction() as db:
            o=clear_cheque(db,order_id=order_id,actor_user=actor)
            return {"id":o.id,"order_no":o.order_no,"status":o.status,"payment_state":o.payment_state}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.post("/v24/sales-orders/{order_id}/stock/reserve")
def sales_order_reserve_stock(order_id:int, body:ReserveIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id); actor=SimpleNamespace(id=a.user_id, role=a.role)
    try:
        with transaction() as db:
            o=reserve_order_persistent(db,order_id=order_id,warehouse_code=body.warehouse_code,actor_user=actor)
            return {"id":o.id,"order_no":o.order_no,"status":o.status}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))

@app.post("/v24/sales-orders/{order_id}/dispatch")
def sales_order_dispatch(order_id:int, body:DispatchIn, authorization:str|None=Header(default=None)):
    a=current_actor(authorization); guard(a,body.entity_id); actor=SimpleNamespace(id=a.user_id, role=a.role)
    try:
        with transaction() as db:
            o,total=dispatch_order_persistent(db,order_id=order_id,actor_user=actor)
            return {"id":o.id,"order_no":o.order_no,"status":o.status,"dispatched_qty":str(total)}
    except PermissionError as e: raise HTTPException(403,str(e))
    except ValueError as e: raise HTTPException(409,str(e))
