from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

class P2PError(ValueError):
    pass

INVOICE_STATES = {"DRAFT", "MATCH_PENDING", "MATCHED", "EXCEPTION", "APPROVED", "REJECTED", "CANCELLED"}
BILL_STATES = {"OPEN", "PARTIALLY_PAID", "PAID", "ON_HOLD", "CANCELLED"}
PAYMENT_STATES = {"SCHEDULED", "DUE", "PAID", "FAILED", "CANCELLED"}

Q2 = Decimal("0.01")

def money(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)

@dataclass(frozen=True)
class POItem:
    po_line_id: int
    sku_id: int
    ordered_qty_kg: Decimal
    unit_price: Decimal
    tax_code: Optional[str] = None

@dataclass(frozen=True)
class GRNItem:
    po_line_id: int
    received_qty_kg: Decimal
    accepted_qty_kg: Decimal
    rejected_qty_kg: Decimal = Decimal("0")
    unit_price: Optional[Decimal] = None

@dataclass(frozen=True)
class PurchaseOrderRef:
    po_id: int
    supplier_id: int
    entity_id: int
    status: str
    items: tuple[POItem, ...]

@dataclass(frozen=True)
class GRNRef:
    grn_id: int
    po_id: int
    supplier_id: int
    status: str
    items: tuple[GRNItem, ...]
    receipt_date: date

@dataclass(frozen=True)
class SupplierInvoiceLine:
    po_line_id: int
    quantity_kg: Decimal
    unit_price: Decimal
    tax_code: Optional[str] = None

@dataclass(frozen=True)
class SupplierInvoice:
    invoice_id: int
    supplier_id: int
    invoice_no: str
    invoice_date: date
    due_date: date
    lines: tuple[SupplierInvoiceLine, ...]
    taxable_total: Decimal
    tax_total: Decimal
    grand_total: Decimal
    status: str = "DRAFT"
    document_file_id: Optional[str] = None

@dataclass(frozen=True)
class MatchTolerance:
    qty_kg: Decimal = Decimal("0")
    price_per_kg: Decimal = Decimal("0")
    amount: Decimal = Decimal("0.01")

@dataclass
class MatchLineResult:
    po_line_id: int
    po_qty_kg: Decimal
    grn_qty_kg: Decimal
    invoice_qty_kg: Decimal
    po_price: Decimal
    invoice_price: Decimal
    qty_variance_kg: Decimal
    price_variance: Decimal
    status: str
    reason: Optional[str] = None

@dataclass
class ThreeWayMatchResult:
    invoice_id: int
    supplier_id: int
    status: str
    lines: list[MatchLineResult] = field(default_factory=list)
    subtotal_variance: Decimal = Decimal("0")
    exception_reasons: list[str] = field(default_factory=list)

    @property
    def matched(self) -> bool:
        return self.status == "MATCHED"

@dataclass
class Payable:
    payable_id: int
    organization_id: int
    entity_id: int
    supplier_id: int
    invoice_id: int
    due_date: date
    original_amount: Decimal
    outstanding_amount: Decimal
    status: str = "OPEN"
    approved_by: Optional[int] = None
    on_hold_reason: Optional[str] = None

@dataclass(frozen=True)
class SupplierPayment:
    payment_id: int
    payable_id: int
    payment_date: date
    amount: Decimal
    mode: str
    reference_no: Optional[str] = None
    status: str = "SCHEDULED"


def _map_po_items(po: PurchaseOrderRef) -> dict[int, POItem]:
    return {x.po_line_id: x for x in po.items}


def _map_grn_items(grns: list[GRNRef]) -> dict[int, GRNItem]:
    out: dict[int, GRNItem] = {}
    for grn in grns:
        for line in grn.items:
            prev = out.get(line.po_line_id)
            if prev is None:
                out[line.po_line_id] = line
            else:
                out[line.po_line_id] = GRNItem(
                    po_line_id=line.po_line_id,
                    received_qty_kg=prev.received_qty_kg + line.received_qty_kg,
                    accepted_qty_kg=prev.accepted_qty_kg + line.accepted_qty_kg,
                    rejected_qty_kg=prev.rejected_qty_kg + line.rejected_qty_kg,
                    unit_price=prev.unit_price if prev.unit_price is not None else line.unit_price,
                )
    return out


def three_way_match(invoice: SupplierInvoice, po: PurchaseOrderRef, grns: list[GRNRef], tol: MatchTolerance) -> ThreeWayMatchResult:
    if invoice.status == "CANCELLED":
        raise P2PError("INVOICE_CANCELLED")
    if invoice.supplier_id != po.supplier_id:
        raise P2PError("SUPPLIER_MISMATCH")
    if po.status not in {"APPROVED", "PARTIALLY_RECEIVED", "FULLY_RECEIVED", "CLOSED"}:
        raise P2PError("PO_NOT_MATCHABLE")
    for grn in grns:
        if grn.po_id != po.po_id or grn.supplier_id != po.supplier_id:
            raise P2PError("GRN_REFERENCE_MISMATCH")
        if grn.status not in {"POSTED", "ACCEPTED", "QC_PASSED"}:
            raise P2PError("GRN_NOT_POSTED")

    po_by_line = _map_po_items(po)
    grn_by_line = _map_grn_items(grns)
    invoice_by_line = {x.po_line_id: x for x in invoice.lines}
    reasons: list[str] = []
    results: list[MatchLineResult] = []

    for line_id, inv in invoice_by_line.items():
        po_line = po_by_line.get(line_id)
        if po_line is None:
            results.append(MatchLineResult(line_id, Decimal("0"), Decimal("0"), inv.quantity_kg, Decimal("0"), inv.unit_price, inv.quantity_kg, inv.unit_price, "EXCEPTION", "INVOICE_LINE_NOT_IN_PO"))
            reasons.append(f"LINE:{line_id}:NOT_IN_PO")
            continue
        grn = grn_by_line.get(line_id)
        po_qty = po_line.ordered_qty_kg
        grn_qty = grn.accepted_qty_kg if grn else Decimal("0")
        qty_var = inv.quantity_kg - grn_qty
        price_var = inv.unit_price - po_line.unit_price
        status = "MATCHED"
        reason = None
        if abs(inv.quantity_kg - po_qty) > tol.qty_kg:
            status = "EXCEPTION"
            reason = "INVOICE_QTY_VS_PO"
            reasons.append(f"LINE:{line_id}:INVOICE_QTY_VS_PO")
        if abs(inv.quantity_kg - grn_qty) > tol.qty_kg:
            status = "EXCEPTION"
            reason = "INVOICE_QTY_VS_GRN"
            reasons.append(f"LINE:{line_id}:INVOICE_QTY_VS_GRN")
        if abs(price_var) > tol.price_per_kg:
            status = "EXCEPTION"
            reason = "PRICE_VARIANCE"
            reasons.append(f"LINE:{line_id}:PRICE_VARIANCE")
        results.append(MatchLineResult(line_id, po_qty, grn_qty, inv.quantity_kg, po_line.unit_price, inv.unit_price, qty_var, price_var, status, reason))

    for line_id in po_by_line:
        if line_id not in invoice_by_line:
            # Partial invoicing can be allowed, but it must be explicit and not silently be treated as a full match.
            continue

    expected_taxable = sum((x.quantity_kg * x.unit_price for x in invoice.lines), Decimal("0"))
    subtotal_variance = money(invoice.taxable_total - expected_taxable)
    if abs(subtotal_variance) > tol.amount:
        reasons.append("INVOICE_TAXABLE_TOTAL_MISMATCH")

    status = "MATCHED" if not reasons else "EXCEPTION"
    return ThreeWayMatchResult(invoice.invoice_id, invoice.supplier_id, status, results, subtotal_variance, reasons)


def approve_payable(*, payable_id: int, organization_id: int, entity_id: int, invoice: SupplierInvoice,
                    match: ThreeWayMatchResult, approver_id: int, allow_exception: bool = False,
                    hold_reason: Optional[str] = None) -> Payable:
    if match.invoice_id != invoice.invoice_id or match.supplier_id != invoice.supplier_id:
        raise P2PError("MATCH_INVOICE_MISMATCH")
    if approver_id <= 0:
        raise P2PError("APPROVER_REQUIRED")
    if not match.matched and not allow_exception:
        raise P2PError("MATCH_EXCEPTION_REQUIRES_APPROVAL")
    if not match.matched and allow_exception and not (hold_reason and hold_reason.strip()):
        raise P2PError("EXCEPTION_REASON_REQUIRED")
    if not invoice.invoice_no.strip():
        raise P2PError("INVOICE_NUMBER_REQUIRED")
    return Payable(
        payable_id=payable_id,
        organization_id=organization_id,
        entity_id=entity_id,
        supplier_id=invoice.supplier_id,
        invoice_id=invoice.invoice_id,
        due_date=invoice.due_date,
        original_amount=money(invoice.grand_total),
        outstanding_amount=money(invoice.grand_total),
        status="ON_HOLD" if not match.matched else "OPEN",
        approved_by=approver_id,
        on_hold_reason=hold_reason.strip() if hold_reason else None,
    )


def schedule_supplier_payment(*, payment_id: int, payable: Payable, payment_date: date, amount: Decimal,
                               mode: str, reference_no: Optional[str] = None) -> SupplierPayment:
    if payable.status in {"CANCELLED", "ON_HOLD"}:
        raise P2PError("PAYABLE_NOT_PAYABLE")
    amount = money(amount)
    if amount <= 0 or amount > payable.outstanding_amount:
        raise P2PError("INVALID_PAYMENT_AMOUNT")
    if payment_date < payable.due_date:
        # Early payment is allowed only by policy; this core rule does not block it.
        pass
    allowed = {"BANK_TRANSFER", "UPI", "CHEQUE", "CASH"}
    if mode not in allowed:
        raise P2PError("INVALID_PAYMENT_MODE")
    return SupplierPayment(payment_id, payable.payable_id, payment_date, amount, mode, reference_no, "SCHEDULED")


def apply_payment(payable: Payable, payment: SupplierPayment) -> Payable:
    if payment.payable_id != payable.payable_id:
        raise P2PError("PAYABLE_PAYMENT_MISMATCH")
    if payment.status != "PAID":
        raise P2PError("PAYMENT_NOT_PAID")
    new_outstanding = money(payable.outstanding_amount - payment.amount)
    if new_outstanding < 0:
        raise P2PError("PAYMENT_EXCEEDS_OUTSTANDING")
    payable.outstanding_amount = new_outstanding
    payable.status = "PAID" if new_outstanding == 0 else "PARTIALLY_PAID"
    return payable
