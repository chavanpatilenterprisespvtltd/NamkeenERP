from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Optional
from uuid import uuid4
from datetime import datetime, timezone
import re

class TransportStatus(str, Enum):
    PLANNED='PLANNED'; LOADING='LOADING'; LOADED='LOADED'; IN_TRANSIT='IN_TRANSIT'; DELIVERED='DELIVERED'; CANCELLED='CANCELLED'; FAILED='FAILED'
class DeliveryStatus(str, Enum):
    PENDING='PENDING'; OUT_FOR_DELIVERY='OUT_FOR_DELIVERY'; PARTIALLY_DELIVERED='PARTIALLY_DELIVERED'; DELIVERED='DELIVERED'; SHORT='SHORT'; FAILED='FAILED'; RETURNED='RETURNED'
class PODType(str, Enum): SIGNATURE='SIGNATURE'; PHOTO='PHOTO'; OTP='OTP'; GPS='GPS'; NONE='NONE'

@dataclass(frozen=True)
class Transporter:
    transporter_id:int; entity_id:int; name:str; gstin:Optional[str]=None; phone:Optional[str]=None; active:bool=True

@dataclass(frozen=True)
class Vehicle:
    vehicle_id:int; entity_id:int; vehicle_no:str; vehicle_type:str='TRUCK'; capacity_kg:Optional[Decimal]=None; transporter_id:Optional[int]=None; active:bool=True

@dataclass
class DeliveryTrip:
    trip_id:int; entity_id:int; trip_no:str; transporter_id:int; vehicle_id:int; origin_warehouse_id:int
    destination_count:int=0; status:TransportStatus=TransportStatus.PLANNED; ewb_no:Optional[str]=None; total_freight:Decimal=Decimal('0')
    started_at:Optional[datetime]=None; delivered_at:Optional[datetime]=None

@dataclass(frozen=True)
class TripLoad:
    load_id:int; trip_id:int; lpn_id:int; invoice_id:int; qty_kg:Decimal; sequence:int

@dataclass
class Delivery:
    delivery_id:int; trip_id:int; invoice_id:int; customer_id:int; ordered_kg:Decimal; delivered_kg:Decimal=Decimal('0')
    status:DeliveryStatus=DeliveryStatus.PENDING; pod_type:PODType=PODType.NONE; pod_ref:Optional[str]=None; notes:Optional[str]=None
    delivered_at:Optional[datetime]=None
    @property
    def balance_kg(self)->Decimal: return self.ordered_kg-self.delivered_kg

def normalize_vehicle_no(value:str)->str:
    return re.sub(r'[^A-Z0-9]', '', value.upper())

def validate_vehicle_no(value:str)->bool:
    return bool(re.fullmatch(r'[A-Z0-9]{6,12}', normalize_vehicle_no(value)))

def add_load(trip:DeliveryTrip, load:TripLoad)->None:
    if load.trip_id != trip.trip_id: raise ValueError('TRIP_MISMATCH')
    if load.qty_kg <= 0: raise ValueError('INVALID_LOAD_QTY')
    if trip.status not in {TransportStatus.PLANNED, TransportStatus.LOADING}: raise ValueError('TRIP_NOT_LOADABLE')
    trip.destination_count += 1

def start_loading(trip:DeliveryTrip)->None:
    if trip.status != TransportStatus.PLANNED: raise ValueError('INVALID_TRIP_STATE')
    trip.status=TransportStatus.LOADING

def confirm_loaded(trip:DeliveryTrip)->None:
    if trip.status != TransportStatus.LOADING: raise ValueError('INVALID_TRIP_STATE')
    trip.status=TransportStatus.LOADED

def depart_trip(trip:DeliveryTrip, ewb_no:Optional[str]=None)->None:
    if trip.status != TransportStatus.LOADED: raise ValueError('NOT_LOADED')
    trip.status=TransportStatus.IN_TRANSIT; trip.started_at=datetime.now(timezone.utc); trip.ewb_no=ewb_no

def record_delivery(delivery:Delivery, delivered_kg:Decimal, pod_type:PODType, pod_ref:Optional[str]=None)->None:
    if delivered_kg < 0 or delivered_kg > delivery.ordered_kg: raise ValueError('INVALID_DELIVERED_QTY')
    if pod_type != PODType.NONE and not pod_ref: raise ValueError('POD_REFERENCE_REQUIRED')
    if delivered_kg == 0: delivery.status=DeliveryStatus.FAILED
    elif delivered_kg < delivery.ordered_kg: delivery.status=DeliveryStatus.PARTIALLY_DELIVERED
    else: delivery.status=DeliveryStatus.DELIVERED
    delivery.delivered_kg=delivered_kg; delivery.pod_type=pod_type; delivery.pod_ref=pod_ref; delivery.delivered_at=datetime.now(timezone.utc)

def finish_trip(trip:DeliveryTrip, deliveries:list[Delivery])->None:
    if trip.status != TransportStatus.IN_TRANSIT: raise ValueError('TRIP_NOT_IN_TRANSIT')
    if any(d.status not in {DeliveryStatus.DELIVERED, DeliveryStatus.PARTIALLY_DELIVERED, DeliveryStatus.FAILED, DeliveryStatus.RETURNED} for d in deliveries):
        raise ValueError('OPEN_DELIVERIES')
    trip.status=TransportStatus.DELIVERED; trip.delivered_at=datetime.now(timezone.utc)

def freight_per_kg(total_freight:Decimal, total_kg:Decimal)->Decimal:
    if total_kg <= 0: raise ValueError('INVALID_TOTAL_KG')
    return (total_freight/total_kg).quantize(Decimal('0.0001'))
