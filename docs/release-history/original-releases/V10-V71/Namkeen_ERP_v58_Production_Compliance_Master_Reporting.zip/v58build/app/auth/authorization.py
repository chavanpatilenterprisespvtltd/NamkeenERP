from dataclasses import dataclass

ROLE_PERMISSIONS = {
    "SALESPERSON": {"customer.create", "order.create", "collection.create", "return.create"},
    "MANAGER": {"customer.approve", "order.create", "order.approve", "price.approve", "return.approve"},
    "ACCOUNTS": {"payment.verify", "cheque.clear", "collection.verify", "accounting.export"},
    "STORE": {"stock.receive", "stock.reserve", "stock.dispatch"},
    "PRODUCTION": {"production.record", "production.qc"},
    "QC": {"qc.inspect", "qc.release", "qc.dispose"},
    "MANAGEMENT": {"*"},
    "SUPER_ADMIN": {"*"},
}

@dataclass(frozen=True)
class AuthzResult:
    allowed: bool
    reason: str = ""

def can(role: str, permission: str) -> AuthzResult:
    p = ROLE_PERMISSIONS.get(role, set())
    if "*" in p or permission in p: return AuthzResult(True)
    return AuthzResult(False, f"Role {role} lacks {permission}")

def require_permission(role: str, permission: str) -> None:
    r = can(role, permission)
    if not r.allowed: raise PermissionError(r.reason)

def require_entity(actor_entity_ids: tuple[int,...], entity_id: int) -> None:
    if entity_id not in actor_entity_ids:
        raise PermissionError("User is not authorized for this entity")
