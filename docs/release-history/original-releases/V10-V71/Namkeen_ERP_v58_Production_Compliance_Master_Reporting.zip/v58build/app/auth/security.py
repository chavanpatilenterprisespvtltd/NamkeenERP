from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import base64, hashlib, hmac, os, secrets
import jwt

PBKDF2_ITERS = int(os.getenv("PBKDF2_ITERS", "310000"))
ACCESS_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "15"))
REFRESH_DAYS = int(os.getenv("REFRESH_TOKEN_DAYS", "30"))
JWT_SECRET = os.getenv("JWT_SECRET", "CHANGE_ME_IN_PRODUCTION")
JWT_ALG = "HS256"


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERS)
    return f"pbkdf2_sha256${PBKDF2_ITERS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(dk).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iters, salt_b64, hash_b64 = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256": return False
        salt = base64.urlsafe_b64decode(salt_b64.encode())
        expected = base64.urlsafe_b64decode(hash_b64.encode())
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iters))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def issue_access_token(user_id: int, org_id: int, role: str, entity_ids: list[int], session_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": str(user_id), "org": org_id, "role": role, "entities": entity_ids,
               "sid": session_id, "typ": "access", "iat": now, "exp": now + timedelta(minutes=ACCESS_MINUTES)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def issue_refresh_token(user_id: int, session_id: str) -> tuple[str, str]:
    raw = secrets.token_urlsafe(48)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    return raw, token_hash


def decode_access(token: str) -> dict:
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG], options={"require": ["sub","org","role","sid","exp","iat"]})

@dataclass(frozen=True)
class Actor:
    user_id: int
    organization_id: int
    role: str
    entity_ids: tuple[int,...]
    session_id: str


def actor_from_claims(claims: dict) -> Actor:
    return Actor(int(claims["sub"]), int(claims["org"]), claims["role"], tuple(claims.get("entities", [])), claims["sid"])
