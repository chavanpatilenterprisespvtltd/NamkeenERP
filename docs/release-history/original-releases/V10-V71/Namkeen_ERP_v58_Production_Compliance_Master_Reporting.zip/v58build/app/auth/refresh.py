from __future__ import annotations
from datetime import datetime, timezone, timedelta
import hashlib
from sqlalchemy import select
from app.db.models_v15 import UserSession
from app.db.models_v15 import UserDevice
from app.db.models import User, UserEntity
from app.auth.security import issue_access_token, issue_refresh_token

class RefreshError(Exception):
    pass

def rotate_refresh(db, *, session_id: str, refresh_token: str):
    now = datetime.now(timezone.utc)
    token_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
    session = db.execute(select(UserSession).where(UserSession.id==session_id).with_for_update()).scalar_one_or_none()
    if not session:
        raise RefreshError("INVALID_SESSION")
    expires_at = session.expires_at
    if expires_at is not None and expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    revoked_at = session.revoked_at
    if revoked_at is not None and revoked_at.tzinfo is None:
        revoked_at = revoked_at.replace(tzinfo=timezone.utc)
    if revoked_at is not None or (expires_at is not None and expires_at <= now):
        raise RefreshError("SESSION_REVOKED_OR_EXPIRED")
    if session.refresh_token_hash != token_hash:
        session.revoked_at = now
        raise RefreshError("REFRESH_REPLAY_OR_INVALID_TOKEN")

    user = db.execute(select(User).where(User.id==session.user_id, User.active==True)).scalar_one_or_none()
    device = db.execute(select(UserDevice).where(UserDevice.user_id==session.user_id, UserDevice.device_id==session.device_id, UserDevice.active==True).with_for_update()).scalar_one_or_none()
    if not user or not device:
        session.revoked_at = now
        raise RefreshError("USER_OR_DEVICE_INACTIVE")
    entity_ids = [x.entity_id for x in db.execute(select(UserEntity).where(UserEntity.user_id==user.id)).scalars().all()]
    raw, new_hash = issue_refresh_token(user.id, session.id)
    session.refresh_token_hash = new_hash
    session.last_used_at = now
    access = issue_access_token(user.id, user.organization_id, user.role, entity_ids, session.id)
    return {"access_token": access, "refresh_token": raw, "session_id": session.id, "user_id": user.id,
            "organization_id": user.organization_id, "role": user.role, "entity_ids": entity_ids}
