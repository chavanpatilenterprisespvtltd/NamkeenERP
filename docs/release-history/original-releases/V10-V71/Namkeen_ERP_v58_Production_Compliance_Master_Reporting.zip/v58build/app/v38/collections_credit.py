from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

Q2=Decimal('0.01')
class CollectionsError(ValueError): pass

PAYMENT_MODES={'UPI','CASH','CHEQUE','BANK_TRANSFER','OTHER'}
RECEIPT_STATES={'DRAFT','PENDING_VERIFICATION','VERIFIED','FAILED','BOUNCED','CANCELLED','REVERSED'}
COLLECTION_STATES={'OPEN','IN_PROGRESS','COMPLETED','CANCELLED'}
BLOCK_STATES={'CLEAR','SOFT_BLOCK','HARD_BLOCK'}


def money(v: Decimal|int|str)->Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)

@dataclass(frozen=True)
class CreditControlProfile:
    customer_id:int
    credit_limit:Decimal
    outstanding:Decimal
    overdue:Decimal
    overdue_days:int
    credit_days:int
    block_threshold:Decimal=Decimal('0')
    hard_block:bool=False
    active:bool=True
    def available(self)->Decimal: return money(self.credit_limit-self.outstanding)

@dataclass(frozen=True)
class CreditDecision:
    state:str
    reason:str
    available_credit:Decimal


def evaluate_credit_control(p:CreditControlProfile, order_value:Decimal, *, management_override:bool=False)->CreditDecision:
    if not p.active: raise CollectionsError('CUSTOMER_INACTIVE')
    amount=money(order_value)
    if amount<=0: raise CollectionsError('ORDER_VALUE_MUST_BE_POSITIVE')
    if p.hard_block and not management_override:
        return CreditDecision('HARD_BLOCK','HARD_BLOCK_CONFIGURED',p.available())
    if p.block_threshold>0 and p.overdue>=p.block_threshold and not management_override:
        return CreditDecision('HARD_BLOCK','OVERDUE_THRESHOLD_REACHED',p.available())
    projected=money(p.outstanding+amount)
    if projected>p.credit_limit and not management_override:
        return CreditDecision('SOFT_BLOCK','CREDIT_LIMIT_EXCEEDED',p.available())
    if p.overdue>0 and p.overdue_days>p.credit_days and not management_override:
        return CreditDecision('SOFT_BLOCK','OVERDUE_BEYOND_CREDIT_DAYS',p.available())
    return CreditDecision('CLEAR','WITHIN_POLICY',p.available())

@dataclass(frozen=True)
class CollectionTarget:
    salesperson_id:int
    period_start:date
    period_end:date
    target_amount:Decimal
    target_customers:int=0

@dataclass(frozen=True)
class CollectionProgress:
    target_amount:Decimal
    verified_amount:Decimal
    achievement_pct:Decimal
    target_customers:int
    active_customers:int


def calculate_collection_progress(t:CollectionTarget, verified_amount:Decimal, active_customers:int)->CollectionProgress:
    ta=money(t.target_amount); va=money(verified_amount)
    pct=Decimal('0') if ta<=0 else (va/ta*Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP)
    return CollectionProgress(ta,va,pct,t.target_customers,active_customers)

@dataclass(frozen=True)
class ReceiptEvidence:
    receipt_id:int
    mode:str
    amount:Decimal
    status:str
    reference_no:Optional[str]=None
    evidence_photo_ref:Optional[str]=None
    collected_by:Optional[int]=None
    verified_by:Optional[int]=None
    failure_reason:Optional[str]=None


def validate_receipt_transition(r:ReceiptEvidence, new_status:str, *, actor_role:str)->None:
    if r.mode not in PAYMENT_MODES: raise CollectionsError('INVALID_PAYMENT_MODE')
    if r.amount<=0: raise CollectionsError('RECEIPT_AMOUNT_MUST_BE_POSITIVE')
    if new_status not in RECEIPT_STATES: raise CollectionsError('INVALID_RECEIPT_STATE')
    privileged={'MANAGER','ACCOUNTS','MANAGEMENT'}
    if new_status in {'VERIFIED','BOUNCED','FAILED','REVERSED'} and actor_role not in privileged:
        raise CollectionsError('VERIFICATION_ROLE_REQUIRED')
    if new_status=='BOUNCED' and not (r.failure_reason or '').strip():
        raise CollectionsError('BOUNCE_REASON_REQUIRED')
    if r.mode=='CASH' and new_status in {'PENDING_VERIFICATION','VERIFIED'}:
        if not r.evidence_photo_ref:
            raise CollectionsError('CASH_EVIDENCE_REQUIRED')

@dataclass(frozen=True)
class CollectionAllocation:
    receipt_id:int
    invoice_id:int
    allocated_amount:Decimal


def validate_allocation(*, receipt_amount:Decimal, already_allocated:Decimal, allocation:Decimal, invoice_outstanding:Decimal)->None:
    ra=money(receipt_amount); aa=money(already_allocated); al=money(allocation); io=money(invoice_outstanding)
    if al<=0: raise CollectionsError('ALLOCATION_MUST_BE_POSITIVE')
    if aa+al>ra: raise CollectionsError('ALLOCATION_EXCEEDS_RECEIPT')
    if al>io: raise CollectionsError('ALLOCATION_EXCEEDS_INVOICE_OUTSTANDING')


def collection_alert_level(*, overdue:Decimal, overdue_days:int, due_soon_days:int=3)->str:
    od=money(overdue)
    if od<=0: return 'CLEAR'
    if overdue_days>=90: return 'CRITICAL'
    if overdue_days>=30: return 'HIGH'
    if overdue_days>due_soon_days: return 'MEDIUM'
    return 'LOW'

@dataclass(frozen=True)
class ManagementOverride:
    override_id:int
    customer_id:int
    requested_by:int
    approved_by:Optional[int]
    reason:str
    created_on:date
    status:str='PENDING'


def validate_override(o:ManagementOverride, *, actor_id:int)->None:
    if not o.reason.strip(): raise CollectionsError('OVERRIDE_REASON_REQUIRED')
    if actor_id==o.requested_by and o.approved_by==actor_id:
        raise CollectionsError('SELF_APPROVAL_NOT_ALLOWED')
    if o.status not in {'PENDING','APPROVED','REJECTED','EXPIRED'}:
        raise CollectionsError('INVALID_OVERRIDE_STATUS')
    if o.status=='APPROVED' and not o.approved_by:
        raise CollectionsError('APPROVER_REQUIRED')
