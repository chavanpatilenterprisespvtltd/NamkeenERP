from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.v38.collections_credit import *

app=FastAPI(title='Namkeen ERP API v38 — Collections & Credit Control',version='38.0')

class CreditIn(BaseModel):
    customer_id:int; credit_limit:Decimal; outstanding:Decimal; overdue:Decimal; overdue_days:int; credit_days:int; block_threshold:Decimal=Decimal('0'); hard_block:bool=False; active:bool=True; order_value:Decimal; management_override:bool=False
class TargetIn(BaseModel):
    salesperson_id:int; period_start:date; period_end:date; target_amount:Decimal; target_customers:int=0; verified_amount:Decimal; active_customers:int
class ReceiptIn(BaseModel):
    receipt_id:int; mode:str; amount:Decimal; status:str; reference_no:str|None=None; evidence_photo_ref:str|None=None; collected_by:int|None=None; verified_by:int|None=None; failure_reason:str|None=None; new_status:str; actor_role:str
class AllocIn(BaseModel):
    receipt_amount:Decimal; already_allocated:Decimal; allocation:Decimal; invoice_outstanding:Decimal
class AlertIn(BaseModel):
    overdue:Decimal; overdue_days:int; due_soon_days:int=3
class OverrideIn(BaseModel):
    override_id:int; customer_id:int; requested_by:int; approved_by:int|None=None; reason:str; created_on:date; status:str='PENDING'; actor_id:int

@app.get('/v38/health')
def health(): return {'version':'38.0','service':'collections-credit-control'}

@app.post('/v38/credit/evaluate')
def credit(b:CreditIn):
    try:
        p=CreditControlProfile(b.customer_id,b.credit_limit,b.outstanding,b.overdue,b.overdue_days,b.credit_days,b.block_threshold,b.hard_block,b.active)
        d=evaluate_credit_control(p,b.order_value,management_override=b.management_override)
        return {'state':d.state,'reason':d.reason,'available_credit':str(d.available_credit)}
    except (CollectionsError,ValueError) as e: raise HTTPException(400,str(e))

@app.post('/v38/collections/progress')
def progress(b:TargetIn):
    try:
        r=calculate_collection_progress(CollectionTarget(b.salesperson_id,b.period_start,b.period_end,b.target_amount,b.target_customers),b.verified_amount,b.active_customers)
        return {'target_amount':str(r.target_amount),'verified_amount':str(r.verified_amount),'achievement_pct':str(r.achievement_pct),'target_customers':r.target_customers,'active_customers':r.active_customers}
    except (CollectionsError,ValueError) as e: raise HTTPException(400,str(e))

@app.post('/v38/receipts/transition')
def receipt_transition(b:ReceiptIn):
    try:
        r=ReceiptEvidence(b.receipt_id,b.mode,b.amount,b.status,b.reference_no,b.evidence_photo_ref,b.collected_by,b.verified_by,b.failure_reason)
        validate_receipt_transition(r,b.new_status,actor_role=b.actor_role)
        return {'valid':True,'new_status':b.new_status}
    except (CollectionsError,ValueError) as e: raise HTTPException(400,str(e))

@app.post('/v38/receipts/allocation/validate')
def allocation(b:AllocIn):
    try:
        validate_allocation(receipt_amount=b.receipt_amount,already_allocated=b.already_allocated,allocation=b.allocation,invoice_outstanding=b.invoice_outstanding)
        return {'valid':True}
    except (CollectionsError,ValueError) as e: raise HTTPException(400,str(e))

@app.post('/v38/collections/alert')
def alert(b:AlertIn): return {'level':collection_alert_level(overdue=b.overdue,overdue_days=b.overdue_days,due_soon_days=b.due_soon_days)}

@app.post('/v38/override/validate')
def override(b:OverrideIn):
    try:
        o=ManagementOverride(b.override_id,b.customer_id,b.requested_by,b.approved_by,b.reason,b.created_on,b.status)
        validate_override(o,actor_id=b.actor_id); return {'valid':True}
    except (CollectionsError,ValueError) as e: raise HTTPException(400,str(e))
