from datetime import datetime, timezone
from sqlalchemy import BigInteger, String, Numeric, DateTime, ForeignKey, UniqueConstraint, Index, Text, Integer, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class SyncChangeLog(Base):
    __tablename__ = "sync_change_log"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(80), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(120), nullable=False)
    operation: Mapped[str] = mapped_column(String(20), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (Index("idx_sync_change_org_id", "organization_id", "id"), Index("idx_sync_change_entity", "organization_id", "entity_type", "entity_id"))

class SyncCursor(Base):
    __tablename__ = "sync_cursors"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    device_id: Mapped[str] = mapped_column(String(120), nullable=False)
    cursor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (UniqueConstraint("organization_id", "device_id", name="uq_sync_cursor_device"),)

class SyncConflict(Base):
    __tablename__ = "sync_conflicts"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    device_id: Mapped[str] = mapped_column(String(120), nullable=False)
    client_event_id: Mapped[str] = mapped_column(String(120), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(80), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(120), nullable=False)
    client_version: Mapped[int|None] = mapped_column(Integer)
    server_version: Mapped[int|None] = mapped_column(Integer)
    client_payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    server_payload_json: Mapped[str|None] = mapped_column(Text)
    resolution_status: Mapped[str] = mapped_column(String(30), default="OPEN", nullable=False)
    resolution_note: Mapped[str|None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    resolved_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
    resolved_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    __table_args__ = (Index("idx_sync_conflict_open", "organization_id", "resolution_status", "created_at"),)

class SyncDeadLetter(Base):
    __tablename__ = "sync_dead_letters"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    device_id: Mapped[str] = mapped_column(String(120), nullable=False)
    client_event_id: Mapped[str] = mapped_column(String(120), nullable=False)
    event_type: Mapped[str] = mapped_column(String(60), nullable=False)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    error_code: Mapped[str] = mapped_column(String(60), nullable=False)
    error_message: Mapped[str] = mapped_column(Text, nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="OPEN", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
