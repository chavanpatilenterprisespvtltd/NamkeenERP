from datetime import datetime, timezone
from sqlalchemy import BigInteger, String, Numeric, DateTime, ForeignKey, UniqueConstraint, Index, Text
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class OrderAllocation(Base):
    __tablename__ = "order_allocations"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    order_id: Mapped[int] = mapped_column(ForeignKey("sales_orders.id"), nullable=False)
    order_line_id: Mapped[int] = mapped_column(ForeignKey("sales_order_lines.id"), nullable=False)
    lot_id: Mapped[int] = mapped_column(ForeignKey("inventory_lots.id"), nullable=False)
    qty: Mapped[Numeric] = mapped_column(Numeric(16,3), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="RESERVED")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (
        UniqueConstraint("order_line_id", "lot_id", name="uq_order_alloc_line_lot"),
        Index("idx_order_alloc_order_status", "order_id", "status"),
    )

class RefreshReplayGuard(Base):
    __tablename__ = "refresh_replay_guards"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    session_id: Mapped[str] = mapped_column(String(120), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    used_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (UniqueConstraint("session_id", "token_hash", name="uq_refresh_replay"),)
