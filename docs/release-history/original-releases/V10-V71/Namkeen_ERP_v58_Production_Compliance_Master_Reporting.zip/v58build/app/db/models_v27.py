from sqlalchemy import BigInteger, String, Numeric, Date, DateTime, Boolean, ForeignKey, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime
from decimal import Decimal
from .base import Base

class BarcodeMaster(Base):
    __tablename__ = 'barcode_master'
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    barcode: Mapped[str] = mapped_column(String(128), nullable=False)
    barcode_type: Mapped[str] = mapped_column(String(20), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(30), nullable=False)
    entity_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sku_id: Mapped[int|None] = mapped_column(ForeignKey('skus.id'))
    lot_id: Mapped[int|None] = mapped_column(ForeignKey('inventory_lots.id'))
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('organization_id','barcode', name='uq_barcode_master_org_code'), Index('idx_barcode_master_entity','organization_id','entity_type','entity_id'), Index('idx_barcode_master_lot','organization_id','lot_id'))
