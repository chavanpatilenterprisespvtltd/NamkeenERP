from datetime import datetime
from sqlalchemy import BigInteger, Integer, String, Numeric, DateTime, ForeignKey, Boolean, Text, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class PartyLedgerLinkV44(Base):
    __tablename__='party_ledger_links_v44'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    party_type:Mapped[str]=mapped_column(String(20),nullable=False)  # CUSTOMER/SUPPLIER
    party_id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),nullable=False)
    ledger_code:Mapped[str]=mapped_column(String(80),nullable=False)
    external_name:Mapped[str|None]=mapped_column(String(180))
    status:Mapped[str]=mapped_column(String(20),nullable=False,default='PENDING')
    last_synced_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    sync_error:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
    __table_args__=(UniqueConstraint('organization_id','entity_id','party_type','party_id',name='uq_v44_party_ledger'),Index('idx_v44_party_ledger_status','organization_id','entity_id','party_type','status'))

class LedgerSyncJobV44(Base):
    __tablename__='ledger_sync_jobs_v44'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    ledger_code:Mapped[str]=mapped_column(String(80),nullable=False)
    direction:Mapped[str]=mapped_column(String(20),nullable=False,default='PUSH')
    status:Mapped[str]=mapped_column(String(20),nullable=False,default='PENDING')
    attempts:Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    available_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    external_reference:Mapped[str|None]=mapped_column(String(180))
    last_error:Mapped[str|None]=mapped_column(Text)
    idempotency_key:Mapped[str]=mapped_column(String(160),nullable=False,unique=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
    __table_args__=(Index('idx_v44_ledger_job_queue','organization_id','entity_id','status','available_at'),)

class AccountingReconciliationActionV44(Base):
    __tablename__='accounting_reconciliation_actions_v44'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    reconciliation_id:Mapped[int]=mapped_column(ForeignKey('accounting_reconciliations_v43.id'),nullable=False)
    action:Mapped[str]=mapped_column(String(40),nullable=False) # ACCEPT_EXTERNAL/REQUEUE/CORRECT_MAPPING/REJECT
    reason:Mapped[str]=mapped_column(Text,nullable=False)
    requested_by:Mapped[int]=mapped_column(ForeignKey('users.id'),nullable=False)
    approved_by:Mapped[int|None]=mapped_column(ForeignKey('users.id'))
    status:Mapped[str]=mapped_column(String(20),nullable=False,default='PENDING')
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
    approved_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    __table_args__=(Index('idx_v44_recon_action_status','organization_id','entity_id','status'),)
