from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import BigInteger, String, Numeric, DateTime, ForeignKey, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class ProductionExecutionRunV53(Base):
    __tablename__ = 'production_execution_runs'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__('sqlalchemy').Integer,'sqlite'), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    production_order_id: Mapped[int] = mapped_column(ForeignKey('production_order.production_order_id'), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey('skus.id'), nullable=False)
    bom_version: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default='RELEASED')
    planned_output_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False)
    actual_input_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False, default=0)
    good_output_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False, default=0)
    reject_output_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False, default=0)
    wip_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False, default=0)
    completed_batch_id: Mapped[int|None] = mapped_column(ForeignKey('production_batches.id'))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    completed_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint('organization_id','production_order_id',name='uq_prod_exec_order'), Index('idx_prod_exec_status','organization_id','entity_id','status'))

class ProductionExecutionIssueV53(Base):
    __tablename__ = 'production_execution_issues'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__('sqlalchemy').Integer,'sqlite'), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    execution_id: Mapped[int] = mapped_column(ForeignKey('production_execution_runs.id'), nullable=False)
    item_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    lot_id: Mapped[int] = mapped_column(ForeignKey('inventory_lots.id'), nullable=False)
    issue_type: Mapped[str] = mapped_column(String(30), nullable=False)
    planned_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False)
    reserved_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False, default=0)
    actual_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,6), nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (Index('idx_prod_exec_issue_exec','execution_id'), Index('idx_prod_exec_issue_lot','lot_id'))
