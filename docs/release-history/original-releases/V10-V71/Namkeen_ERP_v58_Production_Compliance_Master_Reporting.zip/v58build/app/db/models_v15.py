# v15 models are separated to avoid changing existing model definitions until the migration is applied.
from datetime import datetime
from sqlalchemy import BigInteger, String, Boolean, DateTime, Text, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class UserDevice(Base):
    __tablename__="user_devices"
    id:Mapped[int]=mapped_column(BigInteger,primary_key=True)
    user_id:Mapped[int]=mapped_column(ForeignKey("users.id"),nullable=False)
    device_id:Mapped[str]=mapped_column(String(120),nullable=False)
    device_name:Mapped[str|None]=mapped_column(String(150))
    platform:Mapped[str|None]=mapped_column(String(40))
    app_version:Mapped[str|None]=mapped_column(String(40))
    active:Mapped[bool]=mapped_column(Boolean,default=True,nullable=False)
    last_seen_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)

class UserSession(Base):
    __tablename__="user_sessions"
    id:Mapped[str]=mapped_column(String(120),primary_key=True)
    user_id:Mapped[int]=mapped_column(ForeignKey("users.id"),nullable=False)
    device_id:Mapped[str]=mapped_column(String(120),nullable=False)
    refresh_token_hash:Mapped[str]=mapped_column(String(64),nullable=False)
    expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    revoked_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
    last_used_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))

class NotificationOutbox(Base):
    __tablename__="notification_outbox"
    id:Mapped[int]=mapped_column(BigInteger,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),nullable=False)
    user_id:Mapped[int|None]=mapped_column(ForeignKey("users.id"))
    role:Mapped[str|None]=mapped_column(String(50))
    notification_type:Mapped[str]=mapped_column(String(60),nullable=False)
    title:Mapped[str]=mapped_column(String(200),nullable=False)
    body:Mapped[str]=mapped_column(Text,nullable=False)
    data_json:Mapped[str]=mapped_column(Text,nullable=False,default="{}")
    status:Mapped[str]=mapped_column(String(30),nullable=False,default="PENDING")
    attempts:Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    sent_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
