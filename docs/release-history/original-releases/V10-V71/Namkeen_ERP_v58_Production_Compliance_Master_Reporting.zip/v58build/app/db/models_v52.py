from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import BigInteger, String, Numeric, Date, DateTime, Text, ForeignKey, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class ProductionOrderV52(Base):
    __tablename__='production_order'
    production_order_id: Mapped[int]=mapped_column(BigInteger().with_variant(__import__('sqlalchemy').Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id: Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id: Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    sku_id: Mapped[int]=mapped_column(ForeignKey('skus.id'),nullable=False)
    bom_version: Mapped[str]=mapped_column(String(50),nullable=False)
    planned_good_output_kg: Mapped[Decimal]=mapped_column(Numeric(18,6),nullable=False)
    due_date: Mapped[object]=mapped_column(Date,nullable=False)
    status: Mapped[str]=mapped_column(String(30),nullable=False,default='DRAFT')
    created_by: Mapped[int|None]=mapped_column(ForeignKey('users.id'))
    approved_by: Mapped[int|None]=mapped_column(ForeignKey('users.id'))
    release_reason: Mapped[str|None]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda: datetime.now(timezone.utc),nullable=False)
    __table_args__=(UniqueConstraint('entity_id','production_order_id',name='uq_production_order_entity_id'),Index('ix_production_order_entity_status_due','entity_id','status','due_date'))
