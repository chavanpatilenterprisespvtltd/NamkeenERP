from datetime import datetime, timezone
from sqlalchemy import BigInteger, String, Numeric, DateTime, ForeignKey, Text, Boolean, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class ProductionBatch(Base):
    __tablename__ = "production_batches"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    batch_no: Mapped[str] = mapped_column(String(80), nullable=False)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), nullable=False)
    planned_qty_kg: Mapped[Numeric] = mapped_column(Numeric(16,3), nullable=False)
    actual_qty_kg: Mapped[Numeric] = mapped_column(Numeric(16,3), nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PLANNED")
    production_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    __table_args__ = (UniqueConstraint("organization_id", "batch_no", name="uq_prod_batch_org_no"), Index("idx_prod_batch_org_status", "organization_id", "entity_id", "status"))

class ProductionRecord(Base):
    __tablename__ = "production_records"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    batch_id: Mapped[int] = mapped_column(ForeignKey("production_batches.id"), nullable=False)
    good_qty_kg: Mapped[Numeric] = mapped_column(Numeric(16,3), nullable=False)
    reject_qty_kg: Mapped[Numeric] = mapped_column(Numeric(16,3), nullable=False, default=0)
    note: Mapped[str|None] = mapped_column(Text)
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class QCInspection(Base):
    __tablename__ = "qc_inspections"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    batch_id: Mapped[int|None] = mapped_column(ForeignKey("production_batches.id"))
    return_id: Mapped[int|None] = mapped_column(ForeignKey("sales_returns.id"))
    result: Mapped[str] = mapped_column(String(30), nullable=False)  # PASS/FAIL/HOLD
    remarks: Mapped[str|None] = mapped_column(Text)
    evidence_file_id: Mapped[str|None] = mapped_column(String(160))
    inspected_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    inspected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (Index("idx_qc_inspection_scope", "organization_id", "entity_id", "result"),)

class DispatchNote(Base):
    __tablename__ = "dispatch_notes"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    order_id: Mapped[int] = mapped_column(ForeignKey("sales_orders.id"), nullable=False, unique=True)
    dispatch_no: Mapped[str] = mapped_column(String(80), nullable=False, unique=True)
    vehicle_no: Mapped[str|None] = mapped_column(String(40))
    transporter: Mapped[str|None] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="CREATED")
    dispatched_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    dispatched_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))

class PriceException(Base):
    __tablename__ = "price_exceptions"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    order_id: Mapped[int] = mapped_column(ForeignKey("sales_orders.id"), nullable=False)
    line_id: Mapped[int] = mapped_column(ForeignKey("sales_order_lines.id"), nullable=False)
    negotiated_price: Mapped[Numeric] = mapped_column(Numeric(14,2), nullable=False)
    floor_price: Mapped[Numeric] = mapped_column(Numeric(14,2), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="PENDING")
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    decided_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    reason: Mapped[str|None] = mapped_column(Text)
    decided_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
