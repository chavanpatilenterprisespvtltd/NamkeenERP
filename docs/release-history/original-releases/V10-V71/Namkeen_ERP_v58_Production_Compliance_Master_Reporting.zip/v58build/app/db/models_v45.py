from datetime import date, datetime
from sqlalchemy import BigInteger, Integer, String, Numeric, Date, DateTime, ForeignKey, Boolean, Text, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class GSTTaxRateRuleV45(Base):
    __tablename__='gst_tax_rate_rules_v45'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    tax_code:Mapped[str]=mapped_column(String(20),nullable=False)
    rate_pct:Mapped[Numeric]=mapped_column(Numeric(10,3),nullable=False)
    effective_from:Mapped[date]=mapped_column(Date,nullable=False)
    effective_to:Mapped[date|None]=mapped_column(Date)
    taxable:Mapped[bool]=mapped_column(Boolean,nullable=False,default=True)
    rcm_allowed:Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    active:Mapped[bool]=mapped_column(Boolean,nullable=False,default=True)
    __table_args__=(Index('idx_v45_tax_rule_lookup','organization_id','entity_id','tax_code','effective_from'),)

class GSTProductTaxProfileV45(Base):
    __tablename__='gst_product_tax_profiles_v45'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    sku_id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),nullable=False)
    tax_code:Mapped[str]=mapped_column(String(40),nullable=False)
    hsn:Mapped[str]=mapped_column(String(20),nullable=False)
    rate_rule_key:Mapped[str]=mapped_column(String(80),nullable=False)
    exempt:Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    nil_rated:Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    zero_rated:Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    effective_from:Mapped[date]=mapped_column(Date,nullable=False)
    effective_to:Mapped[date|None]=mapped_column(Date)
    __table_args__=(UniqueConstraint('organization_id','entity_id','sku_id','effective_from',name='uq_v45_product_tax_effective'),Index('idx_v45_product_hsn','organization_id','entity_id','hsn'),)

class GSTDocumentTaxV45(Base):
    __tablename__='gst_document_tax_v45'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    source_type:Mapped[str]=mapped_column(String(40),nullable=False)
    source_id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),nullable=False)
    doc_type:Mapped[str]=mapped_column(String(30),nullable=False)
    document_no:Mapped[str]=mapped_column(String(60),nullable=False)
    document_date:Mapped[date]=mapped_column(Date,nullable=False)
    supplier_gstin:Mapped[str|None]=mapped_column(String(20))
    recipient_gstin:Mapped[str|None]=mapped_column(String(20))
    place_of_supply:Mapped[str]=mapped_column(String(80),nullable=False)
    supply_type:Mapped[str]=mapped_column(String(30),nullable=False)
    reverse_charge:Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    taxable_value:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False,default=0)
    cgst:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False,default=0)
    sgst:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False,default=0)
    igst:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False,default=0)
    utgst:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False,default=0)
    cess:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False,default=0)
    status:Mapped[str]=mapped_column(String(20),nullable=False,default='POSTED')
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
    __table_args__=(UniqueConstraint('organization_id','entity_id','doc_type','document_no',name='uq_v45_gst_doc'),Index('idx_v45_gst_period','organization_id','entity_id','document_date','status'),Index('idx_v45_gst_pos_rcm','organization_id','entity_id','place_of_supply','reverse_charge'),)

class GSTReturnPeriodV45(Base):
    __tablename__='gst_return_periods_v45'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    period_key:Mapped[str]=mapped_column(String(20),nullable=False)
    start_date:Mapped[date]=mapped_column(Date,nullable=False)
    end_date:Mapped[date]=mapped_column(Date,nullable=False)
    state:Mapped[str]=mapped_column(String(24),nullable=False,default='OPEN')
    locked_by:Mapped[int|None]=mapped_column(ForeignKey('users.id'))
    locked_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    filed_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    __table_args__=(UniqueConstraint('organization_id','entity_id','period_key',name='uq_v45_gst_period'),)

class GSTReconciliationV45(Base):
    __tablename__='gst_reconciliations_v45'
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer,'sqlite'),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey('organizations.id'),nullable=False)
    entity_id:Mapped[int]=mapped_column(ForeignKey('entities.id'),nullable=False)
    period_key:Mapped[str]=mapped_column(String(20),nullable=False)
    source:Mapped[str]=mapped_column(String(50),nullable=False)
    local_taxable:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False)
    external_taxable:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False)
    local_tax:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False)
    external_tax:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False)
    taxable_difference:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False)
    tax_difference:Mapped[Numeric]=mapped_column(Numeric(18,2),nullable=False)
    status:Mapped[str]=mapped_column(String(20),nullable=False)
    resolved_by:Mapped[int|None]=mapped_column(ForeignKey('users.id'))
    resolution_reason:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=datetime.utcnow,nullable=False)
    __table_args__=(Index('idx_v45_gst_recon_status','organization_id','entity_id','period_key','status'),)
