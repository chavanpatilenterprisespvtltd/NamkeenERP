from datetime import datetime, timezone
from sqlalchemy import BigInteger, String, Numeric, DateTime, ForeignKey, UniqueConstraint, Index, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class CustomerProfile(Base):
    __tablename__ = "customer_profiles"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), nullable=False, unique=True)
    address_text: Mapped[str|None] = mapped_column(Text)
    shop_photo_file_id: Mapped[str|None] = mapped_column(String(160))
    aadhaar_file_id: Mapped[str|None] = mapped_column(String(160))
    pan_file_id: Mapped[str|None] = mapped_column(String(160))
    extra_docs_json: Mapped[str|None] = mapped_column(Text)
    captured_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class CustomerApproval(Base):
    __tablename__ = "customer_approvals"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    decided_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    reason: Mapped[str|None] = mapped_column(Text)
    decided_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (Index("idx_customer_approval_lookup", "organization_id", "customer_id", "status"),)

class CollectionEvidence(Base):
    __tablename__ = "collection_evidence"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id"), nullable=False, unique=True)
    counterparty_photo_file_id: Mapped[str] = mapped_column(String(160), nullable=False)
    captured_lat: Mapped[Numeric|None] = mapped_column(Numeric(10,7))
    captured_lng: Mapped[Numeric|None] = mapped_column(Numeric(10,7))
    collected_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class CollectionDeposit(Base):
    __tablename__ = "collection_deposits"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id"), nullable=False, unique=True)
    mode: Mapped[str] = mapped_column(String(30), nullable=False)  # COMPANY_ACCOUNT / AUTHORIZED_HANDOVER
    deposit_ref: Mapped[str|None] = mapped_column(String(160))
    deposited_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    verified_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="SUBMITTED")
    deposited_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class SalesReturn(Base):
    __tablename__ = "sales_returns"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), nullable=False)
    order_id: Mapped[int|None] = mapped_column(ForeignKey("sales_orders.id"))
    return_no: Mapped[str] = mapped_column(String(80), nullable=False, unique=True)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="QC_HOLD")
    reason_code: Mapped[str] = mapped_column(String(50), nullable=False)
    initiated_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    evidence_file_id: Mapped[str|None] = mapped_column(String(160))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (Index("idx_returns_customer_status", "organization_id", "customer_id", "status"),)

class SalesReturnLine(Base):
    __tablename__ = "sales_return_lines"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    return_id: Mapped[int] = mapped_column(ForeignKey("sales_returns.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    qty: Mapped[Numeric] = mapped_column(Numeric(16,3), nullable=False)
    batch_no: Mapped[str|None] = mapped_column(String(80))

class ReturnDisposition(Base):
    __tablename__ = "return_dispositions"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    return_id: Mapped[int] = mapped_column(ForeignKey("sales_returns.id"), nullable=False, unique=True)
    disposition: Mapped[str] = mapped_column(String(30), nullable=False)  # SALEABLE/REPACK/REWORK/DAMAGE/EXPIRED/DISPOSE
    reason: Mapped[str|None] = mapped_column(Text)
    authorized_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    authorized_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class NotificationDelivery(Base):
    __tablename__ = "notification_deliveries"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    outbox_id: Mapped[int] = mapped_column(ForeignKey("notification_outbox.id"), nullable=False)
    channel: Mapped[str] = mapped_column(String(30), nullable=False)
    destination: Mapped[str] = mapped_column(String(240), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    attempts: Mapped[int] = mapped_column(default=0)
    last_error: Mapped[str|None] = mapped_column(Text)
    delivered_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("outbox_id", "channel", "destination", name="uq_notification_delivery_target"), Index("idx_notification_delivery_status", "status"))
