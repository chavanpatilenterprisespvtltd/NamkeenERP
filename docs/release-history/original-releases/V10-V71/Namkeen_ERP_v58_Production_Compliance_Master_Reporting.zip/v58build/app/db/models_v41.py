from datetime import datetime, timezone
from sqlalchemy import BigInteger, Integer, String, Numeric, DateTime, ForeignKey, UniqueConstraint, Index, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class PersistentSalesTxnRun(Base):
    __tablename__ = 'persistent_sales_txn_runs'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    order_id: Mapped[int] = mapped_column(ForeignKey('sales_orders.id'), nullable=False)
    order_no: Mapped[str] = mapped_column(String(60), nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(160))
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    invoice_id: Mapped[int | None] = mapped_column(ForeignKey('sales_invoices_v41.id'))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        UniqueConstraint('organization_id', 'idempotency_key', name='uq_v41_txn_idem'),
        Index('idx_v41_txn_order', 'organization_id', 'entity_id', 'order_no'),
        Index('idx_v41_txn_state', 'organization_id', 'state'),
    )

class SalesInvoiceV41(Base):
    __tablename__ = 'sales_invoices_v41'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    order_id: Mapped[int] = mapped_column(ForeignKey('sales_orders.id'), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey('customers.id'), nullable=False)
    invoice_no: Mapped[str] = mapped_column(String(60), nullable=False)
    taxable_total: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    tax_total: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    grand_total: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False)
    posted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (UniqueConstraint('organization_id', 'invoice_no', name='uq_v41_invoice_no'),)

class SalesInvoiceLineV41(Base):
    __tablename__ = 'sales_invoice_lines_v41'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey('sales_invoices_v41.id'), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey('skus.id'), nullable=False)
    qty_kg: Mapped[Numeric] = mapped_column(Numeric(18,3), nullable=False)
    unit_price: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    taxable_value: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    tax_amount: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)

class CustomerReceivableV41(Base):
    __tablename__ = 'customer_receivables_v41'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey('customers.id'), nullable=False)
    invoice_id: Mapped[int] = mapped_column(ForeignKey('sales_invoices_v41.id'), nullable=False, unique=True)
    original_amount: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    outstanding_amount: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False)
    due_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class ReceiptAllocationV41(Base):
    __tablename__ = 'receipt_allocations_v41'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    payment_id: Mapped[int] = mapped_column(ForeignKey('payments.id'), nullable=False)
    receivable_id: Mapped[int] = mapped_column(ForeignKey('customer_receivables_v41.id'), nullable=False)
    amount: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class AccountingOutboxV41(Base):
    __tablename__ = 'accounting_outbox_v41'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    transaction_run_id: Mapped[int] = mapped_column(ForeignKey('persistent_sales_txn_runs.id'), nullable=False)
    integration_code: Mapped[str] = mapped_column(String(50), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(180), nullable=False)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default='PENDING')
    attempts: Mapped[int] = mapped_column(default=0, nullable=False)
    last_error: Mapped[str | None] = mapped_column(Text)
    available_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (UniqueConstraint('organization_id','integration_code','idempotency_key',name='uq_v41_outbox_idem'),)
