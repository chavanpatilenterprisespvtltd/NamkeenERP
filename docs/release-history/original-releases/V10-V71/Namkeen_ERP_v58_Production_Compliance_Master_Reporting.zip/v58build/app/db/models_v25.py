from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import BigInteger, String, Numeric, DateTime, Date, ForeignKey, Text, Boolean, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class Warehouse(Base):
    __tablename__ = "warehouses"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    warehouse_type: Mapped[str] = mapped_column(String(40), nullable=False, default="FG")
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("entity_id", "code", name="uq_warehouse_entity_code"), Index("idx_warehouse_scope", "organization_id", "entity_id", "active"))

class Supplier(Base):
    __tablename__ = "suppliers"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    code: Mapped[str] = mapped_column(String(60), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    gstin: Mapped[str|None] = mapped_column(String(20))
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("organization_id", "code", name="uq_supplier_org_code"),)

class Receipt(Base):
    __tablename__ = "inventory_receipts"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"), nullable=False)
    supplier_id: Mapped[int|None] = mapped_column(ForeignKey("suppliers.id"))
    receipt_no: Mapped[str] = mapped_column(String(80), nullable=False)
    receipt_type: Mapped[str] = mapped_column(String(30), nullable=False)  # RM / PACKAGING / OTHER
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="DRAFT")
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    qc_status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    evidence_file_id: Mapped[str|None] = mapped_column(String(160))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    __table_args__ = (UniqueConstraint("entity_id", "receipt_no", name="uq_receipt_entity_no"), Index("idx_receipt_scope_status", "organization_id", "entity_id", "status", "qc_status"))

class ReceiptLine(Base):
    __tablename__ = "inventory_receipt_lines"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    receipt_id: Mapped[int] = mapped_column(ForeignKey("inventory_receipts.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    supplier_lot_no: Mapped[str|None] = mapped_column(String(100))
    qty_received: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    qty_accepted: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    qty_rejected: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    expiry_date: Mapped[date|None] = mapped_column(Date)
    unit_cost: Mapped[Decimal|None] = mapped_column(Numeric(14,4))
    qc_result: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")

class StockMovement(Base):
    __tablename__ = "stock_movements"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    from_warehouse_id: Mapped[int|None] = mapped_column(ForeignKey("warehouses.id"))
    to_warehouse_id: Mapped[int|None] = mapped_column(ForeignKey("warehouses.id"))
    lot_id: Mapped[int|None] = mapped_column(ForeignKey("inventory_lots.id"))
    qty: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    movement_type: Mapped[str] = mapped_column(String(40), nullable=False)
    reference_type: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(100), nullable=False)
    barcode: Mapped[str|None] = mapped_column(String(140))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (Index("idx_stock_movement_scope", "organization_id", "entity_id", "created_at"), Index("idx_stock_movement_ref", "reference_type", "reference_id"))

class StockTransfer(Base):
    __tablename__ = "stock_transfers"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    transfer_no: Mapped[str] = mapped_column(String(80), nullable=False)
    from_warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"), nullable=False)
    to_warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="DRAFT")
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    approved_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (UniqueConstraint("entity_id", "transfer_no", name="uq_transfer_entity_no"), Index("idx_transfer_scope_status", "organization_id", "entity_id", "status"))

class StockTransferLine(Base):
    __tablename__ = "stock_transfer_lines"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    transfer_id: Mapped[int] = mapped_column(ForeignKey("stock_transfers.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    lot_id: Mapped[int|None] = mapped_column(ForeignKey("inventory_lots.id"))
    qty: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)

class StockAdjustment(Base):
    __tablename__ = "stock_adjustments"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("skus.id"), nullable=False)
    lot_id: Mapped[int|None] = mapped_column(ForeignKey("inventory_lots.id"))
    qty_delta: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    approved_by: Mapped[int|None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))

class InventoryQc(Base):
    __tablename__ = "inventory_qc"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    receipt_id: Mapped[int|None] = mapped_column(ForeignKey("inventory_receipts.id"))
    receipt_line_id: Mapped[int|None] = mapped_column(ForeignKey("inventory_receipt_lines.id"))
    lot_id: Mapped[int|None] = mapped_column(ForeignKey("inventory_lots.id"))
    result: Mapped[str] = mapped_column(String(30), nullable=False)
    remarks: Mapped[str|None] = mapped_column(Text)
    coa_reference: Mapped[str|None] = mapped_column(String(160))
    evidence_file_id: Mapped[str|None] = mapped_column(String(160))
    checked_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

class BarcodeEvent(Base):
    __tablename__ = "barcode_events"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    barcode: Mapped[str] = mapped_column(String(140), nullable=False)
    code_type: Mapped[str] = mapped_column(String(30), nullable=False, default="QR")
    event_type: Mapped[str] = mapped_column(String(40), nullable=False)
    reference_type: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(100), nullable=False)
    captured_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (Index("idx_barcode_scope_code", "organization_id", "entity_id", "barcode"),)

class TraceabilityLink(Base):
    __tablename__ = "traceability_links"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id"), nullable=False)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)
    source_id: Mapped[str] = mapped_column(String(100), nullable=False)
    target_type: Mapped[str] = mapped_column(String(50), nullable=False)
    target_id: Mapped[str] = mapped_column(String(100), nullable=False)
    relationship: Mapped[str] = mapped_column(String(50), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (Index("idx_trace_source", "organization_id", "entity_id", "source_type", "source_id"), Index("idx_trace_target", "organization_id", "entity_id", "target_type", "target_id"))
