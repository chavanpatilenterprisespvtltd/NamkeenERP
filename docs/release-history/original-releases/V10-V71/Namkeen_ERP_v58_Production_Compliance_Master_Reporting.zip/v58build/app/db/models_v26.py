from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import BigInteger, String, Numeric, DateTime, Date, ForeignKey, Text, Index, Boolean, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class ProductionMaterialIssue(Base):
    __tablename__ = 'production_material_issues'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    batch_id: Mapped[int] = mapped_column(ForeignKey('production_batches.id'), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey('skus.id'), nullable=False)
    lot_id: Mapped[int] = mapped_column(ForeignKey('inventory_lots.id'), nullable=False)
    warehouse_code: Mapped[str] = mapped_column(String(50), nullable=False)
    qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    issue_type: Mapped[str] = mapped_column(String(30), nullable=False, default='RM')
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (Index('idx_prod_issue_batch', 'organization_id','entity_id','batch_id'),)

class ProductionWipLot(Base):
    __tablename__ = 'production_wip_lots'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    batch_id: Mapped[int] = mapped_column(ForeignKey('production_batches.id'), nullable=False)
    product_id: Mapped[int] = mapped_column(ForeignKey('products.id'), nullable=False)
    warehouse_code: Mapped[str] = mapped_column(String(50), nullable=False)
    wip_batch_no: Mapped[str] = mapped_column(String(100), nullable=False)
    qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    qty_available_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('entity_id','wip_batch_no', name='uq_wip_batch_entity_no'), Index('idx_wip_available','entity_id','warehouse_code','product_id','qty_available_kg'))

class ProductionWipMovement(Base):
    __tablename__ = 'production_wip_movements'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    wip_lot_id: Mapped[int] = mapped_column(ForeignKey('production_wip_lots.id'), nullable=False)
    qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    movement_type: Mapped[str] = mapped_column(String(30), nullable=False)
    reference_type: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(100), nullable=False)
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

class PackingRun(Base):
    __tablename__ = 'packing_runs'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    batch_id: Mapped[int] = mapped_column(ForeignKey('production_batches.id'), nullable=False)
    wip_lot_id: Mapped[int] = mapped_column(ForeignKey('production_wip_lots.id'), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey('skus.id'), nullable=False)
    fg_warehouse_code: Mapped[str] = mapped_column(String(50), nullable=False)
    planned_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    actual_good_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    reject_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default='PLANNED')
    packing_no: Mapped[str] = mapped_column(String(100), nullable=False)
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('entity_id','packing_no', name='uq_packing_entity_no'), Index('idx_packing_batch','organization_id','entity_id','batch_id'))

class PackingMaterialIssue(Base):
    __tablename__ = 'packing_material_issues'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    packing_run_id: Mapped[int] = mapped_column(ForeignKey('packing_runs.id'), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey('skus.id'), nullable=False)
    lot_id: Mapped[int] = mapped_column(ForeignKey('inventory_lots.id'), nullable=False)
    warehouse_code: Mapped[str] = mapped_column(String(50), nullable=False)
    qty_base: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    issue_type: Mapped[str] = mapped_column(String(30), nullable=False, default='PACKAGING')
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

class ProductionFgOutput(Base):
    __tablename__ = 'production_fg_outputs'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    packing_run_id: Mapped[int] = mapped_column(ForeignKey('packing_runs.id'), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey('skus.id'), nullable=False)
    lot_id: Mapped[int] = mapped_column(ForeignKey('inventory_lots.id'), nullable=False)
    batch_no: Mapped[str] = mapped_column(String(100), nullable=False)
    good_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    good_pack_qty: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    reject_qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False, default=0)
    expiry_date: Mapped[date|None] = mapped_column(Date)
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (Index('idx_fg_output_batch','organization_id','entity_id','batch_no'), Index('idx_fg_output_lot','lot_id'))

class ProductionWastage(Base):
    __tablename__ = 'production_wastage'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(__import__("sqlalchemy").Integer, "sqlite"), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    batch_id: Mapped[int] = mapped_column(ForeignKey('production_batches.id'), nullable=False)
    packing_run_id: Mapped[int|None] = mapped_column(ForeignKey('packing_runs.id'))
    qty_kg: Mapped[Decimal] = mapped_column(Numeric(16,3), nullable=False)
    reason_code: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default='RECORDED')
    authorized_by: Mapped[int|None] = mapped_column(ForeignKey('users.id'))
    created_by: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
