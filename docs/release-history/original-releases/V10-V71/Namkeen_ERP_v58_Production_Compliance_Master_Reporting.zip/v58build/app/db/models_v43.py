from datetime import datetime
from sqlalchemy import BigInteger, Integer, String, Numeric, DateTime, ForeignKey, UniqueConstraint, Index, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class AccountingLedgerV43(Base):
    __tablename__ = 'accounting_ledgers_v43'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, 'sqlite'), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    code: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    ledger_group: Mapped[str] = mapped_column(String(80), nullable=False)
    tax_role: Mapped[str | None] = mapped_column(String(40))
    external_name: Mapped[str | None] = mapped_column(String(180))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('organization_id','entity_id','code',name='uq_v43_ledger_code'), Index('idx_v43_ledger_lookup','organization_id','entity_id','ledger_group','is_active'))

class VoucherMappingV43(Base):
    __tablename__ = 'voucher_mappings_v43'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, 'sqlite'), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    document_type: Mapped[str] = mapped_column(String(50), nullable=False)
    voucher_type: Mapped[str] = mapped_column(String(80), nullable=False)
    party_ledger_code: Mapped[str | None] = mapped_column(String(80))
    base_ledger_code: Mapped[str | None] = mapped_column(String(80))
    cgst_ledger_code: Mapped[str | None] = mapped_column(String(80))
    sgst_ledger_code: Mapped[str | None] = mapped_column(String(80))
    igst_ledger_code: Mapped[str | None] = mapped_column(String(80))
    cess_ledger_code: Mapped[str | None] = mapped_column(String(80))
    effective_from: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    effective_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint('organization_id','entity_id','document_type','effective_from',name='uq_v43_voucher_mapping'), Index('idx_v43_mapping_lookup','organization_id','entity_id','document_type','is_active'))

class AccountingVoucherV43(Base):
    __tablename__ = 'accounting_vouchers_v43'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, 'sqlite'), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)
    source_id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, 'sqlite'), nullable=False)
    source_number: Mapped[str] = mapped_column(String(100), nullable=False)
    voucher_type: Mapped[str] = mapped_column(String(80), nullable=False)
    voucher_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    amount: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default='DRAFT')
    external_reference: Mapped[str | None] = mapped_column(String(180))
    payload_hash: Mapped[str | None] = mapped_column(String(64))
    response_hash: Mapped[str | None] = mapped_column(String(64))
    last_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('organization_id','entity_id','source_type','source_id',name='uq_v43_voucher_source'), Index('idx_v43_voucher_status','organization_id','entity_id','status','voucher_date'))

class AccountingReconciliationV43(Base):
    __tablename__ = 'accounting_reconciliations_v43'
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, 'sqlite'), primary_key=True, autoincrement=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_id: Mapped[int] = mapped_column(ForeignKey('entities.id'), nullable=False)
    voucher_id: Mapped[int] = mapped_column(ForeignKey('accounting_vouchers_v43.id'), nullable=False)
    internal_amount: Mapped[Numeric] = mapped_column(Numeric(18,2), nullable=False)
    external_amount: Mapped[Numeric | None] = mapped_column(Numeric(18,2))
    amount_difference: Mapped[Numeric | None] = mapped_column(Numeric(18,2))
    external_reference: Mapped[str | None] = mapped_column(String(180))
    status: Mapped[str] = mapped_column(String(30), nullable=False, default='UNMATCHED')
    mismatch_reason: Mapped[str | None] = mapped_column(Text)
    reconciled_by: Mapped[int | None] = mapped_column(ForeignKey('users.id'))
    reconciled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint('voucher_id','external_reference',name='uq_v43_recon_ref'), Index('idx_v43_recon_status','organization_id','entity_id','status'))
