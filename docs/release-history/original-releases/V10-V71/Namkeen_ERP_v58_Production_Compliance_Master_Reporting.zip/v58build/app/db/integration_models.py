from datetime import datetime
from sqlalchemy import BigInteger,Integer,String,DateTime,Text,ForeignKey
from sqlalchemy.orm import Mapped,mapped_column
from .base import Base
class IntegrationRun(Base):
    __tablename__="integration_runs"
    id:Mapped[int]=mapped_column(BigInteger().with_variant(Integer, "sqlite"),primary_key=True,autoincrement=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),nullable=False)
    integration_code:Mapped[str]=mapped_column(String(60),nullable=False)
    direction:Mapped[str]=mapped_column(String(20),nullable=False,default="OUTBOUND")
    idempotency_key:Mapped[str]=mapped_column(String(160),nullable=False)
    status:Mapped[str]=mapped_column(String(30),nullable=False)
    request_hash:Mapped[str|None]=mapped_column(String(64))
    response_hash:Mapped[str|None]=mapped_column(String(64))
    error_message:Mapped[str|None]=mapped_column(Text)
    started_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    completed_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
