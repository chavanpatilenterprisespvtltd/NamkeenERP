from fastapi import FastAPI, Header, HTTPException
from app.auth.security import hash_password, verify_password, issue_access_token, issue_refresh_token, decode_access, actor_from_claims
from app.auth.authorization import require_permission
from app.storage.documents import LocalDocumentStore
from app.sync.conflict import ConflictResolver, SyncCommand
from app.notifications.outbox import InMemoryNotificationOutbox, Notification
from app.accounting.tally import TallyXmlAdapter, AccountingDocument
from decimal import Decimal

app=FastAPI(title="Namkeen ERP v14 — Production Foundation", version="14.0")
doc_store=LocalDocumentStore(); sync_resolver=ConflictResolver(); notifications=InMemoryNotificationOutbox(); tally=TallyXmlAdapter()

@app.get("/health")
def health(): return {"status":"ok","version":"14.0"}

@app.get("/ready")
def ready(): return {"ready":True,"checks":{"api":True,"document_store":True,"notification_outbox":True}}

@app.post("/auth/token")
def token_demo(username: str, password: str):
    # Integration point: replace demo lookup with PostgreSQL User + Device + Session repository.
    if username!="demo" or password!="demo": raise HTTPException(401,"Invalid credentials")
    sid="demo-session"; access=issue_access_token(1,1,"MANAGEMENT",[1],sid); refresh, _=issue_refresh_token(1,sid)
    return {"access_token":access,"refresh_token":refresh,"token_type":"bearer"}

@app.post("/documents/sign")
def sign_document(object_id: str, x_role: str=Header(default="management")):
    require_permission(x_role.upper(),"document.sign") if x_role.upper() not in ("MANAGEMENT","SUPER_ADMIN") else None
    return {"object_id":object_id,"token":doc_store.sign(object_id)}

@app.post("/sync/check")
def sync_check(client_event_id:str,device_id:str,entity:str,entity_id:str,client_version:int,payload:dict,current_server_version:int|None=None):
    r=sync_resolver.check(SyncCommand(client_event_id,device_id,entity,entity_id,client_version,payload),current_server_version)
    return {"status":r.status.value,"message":r.message,"server_version":r.server_version}

@app.post("/notifications/test")
def notify(title:str,body:str,organization_id:int=1,role:str|None=None,user_id:int|None=None):
    notifications.enqueue(Notification("GENERAL",organization_id,user_id,role,title,body,{}))
    return {"queued":True}

@app.post("/accounting/preview")
def accounting_preview():
    docs=[AccountingDocument("SALES","SO-1001","2026-09-04","Demo Customer",Decimal("1000"),Decimal("180"),Decimal("1180"))]
    return tally.preview(docs)
