from __future__ import annotations
from fastapi import FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from app.db.session import SessionLocal
from app.db.models_v19 import DomainChange
from app.db.models_v18 import SyncChangeLog
from app.auth.security import decode_access, actor_from_claims
from app.sync.domain_events import mirror_to_v18_change_log

app = FastAPI(title='Namkeen ERP v19 — Domain Change Log & Mobile Sync', version='19.0')

class PullIn(BaseModel):
    cursor: int = Field(default=0, ge=0)
    limit: int = Field(default=200, ge=1, le=1000)
    device_id: str = Field(min_length=2, max_length=120)

def actor(auth: str|None):
    if not auth or not auth.lower().startswith('bearer '): raise HTTPException(401,'Bearer token required')
    try: return actor_from_claims(decode_access(auth.split(' ',1)[1]))
    except Exception: raise HTTPException(401,'Invalid or expired token')

@app.get('/v19/sync/pull')
def pull(body: PullIn = PullIn(), authorization: str|None = Header(default=None)):
    a=actor(authorization); db=SessionLocal()
    try:
        rows=db.execute(select(DomainChange).where(DomainChange.organization_id==a.organization_id,DomainChange.id>body.cursor).order_by(DomainChange.id).limit(body.limit)).scalars().all()
        return {'device_id':body.device_id,'from_cursor':body.cursor,'next_cursor':rows[-1].id if rows else body.cursor,'has_more':len(rows)>=body.limit,'deltas':[{'change_id':r.id,'entity_type':r.aggregate_type,'entity_id':r.aggregate_id,'operation':r.operation,'version':r.version,'event_name':r.event_name,'payload':__import__('json').loads(r.payload_json),'occurred_at':r.occurred_at.isoformat()} for r in rows]}
    finally: db.close()

@app.post('/v19/admin/bridge-unmirrored')
def bridge(authorization: str|None=Header(default=None), limit: int=Query(default=500, ge=1, le=5000)):
    a=actor(authorization)
    if a.role not in {'MANAGER','MANAGEMENT','SUPER_ADMIN'}: raise HTTPException(403,'Management role required')
    db=SessionLocal(); count=0
    try:
        with db.begin():
            rows=db.execute(select(DomainChange).where(DomainChange.organization_id==a.organization_id).order_by(DomainChange.id).limit(limit)).scalars().all()
            for row in rows:
                mirror_to_v18_change_log(db,row=row,change_log_model=SyncChangeLog); count+=1
        return {'bridged':count}
    finally: db.close()
