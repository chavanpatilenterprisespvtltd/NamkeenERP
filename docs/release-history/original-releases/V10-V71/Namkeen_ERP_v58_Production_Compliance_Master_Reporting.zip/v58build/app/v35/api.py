from datetime import date
from decimal import Decimal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.v35_p2p import (
    PurchaseOrderRef, POItem, GRNRef, GRNItem, SupplierInvoice, SupplierInvoiceLine,
    MatchTolerance, three_way_match, approve_payable, P2PError
)

app = FastAPI(title="Namkeen ERP API v35 — Purchase-to-Pay", version="35.0")

class POItemIn(BaseModel):
    po_line_id:int; sku_id:int; ordered_qty_kg:Decimal; unit_price:Decimal; tax_code:str|None=None
class PORefIn(BaseModel):
    po_id:int; supplier_id:int; entity_id:int; status:str; items:list[POItemIn]
class GRNItemIn(BaseModel):
    po_line_id:int; received_qty_kg:Decimal; accepted_qty_kg:Decimal; rejected_qty_kg:Decimal=0; unit_price:Decimal|None=None
class GRNRefIn(BaseModel):
    grn_id:int; po_id:int; supplier_id:int; status:str; items:list[GRNItemIn]; receipt_date:date
class InvoiceLineIn(BaseModel):
    po_line_id:int; quantity_kg:Decimal; unit_price:Decimal; tax_code:str|None=None
class InvoiceIn(BaseModel):
    invoice_id:int; supplier_id:int; invoice_no:str; invoice_date:date; due_date:date; lines:list[InvoiceLineIn]
    taxable_total:Decimal; tax_total:Decimal; grand_total:Decimal; status:str="DRAFT"; document_file_id:str|None=None
class ToleranceIn(BaseModel):
    qty_kg:Decimal=0; price_per_kg:Decimal=0; amount:Decimal=Decimal("0.01")

@app.get('/v35/health')
def health(): return {'version':'35.0','service':'purchase-to-pay'}

@app.post('/v35/purchase-invoices/three-way-match')
def match_invoice(body:dict):
    try:
        po_m = PORefIn.model_validate(body['po'])
        invoice_m = InvoiceIn.model_validate(body['invoice'])
        grns_m = [GRNRefIn.model_validate(x) for x in body.get('grns', [])]
        tol_m = ToleranceIn.model_validate(body.get('tolerance', {}))
        po = PurchaseOrderRef(po_m.po_id, po_m.supplier_id, po_m.entity_id, po_m.status,
                              tuple(POItem(x.po_line_id,x.sku_id,x.ordered_qty_kg,x.unit_price,x.tax_code) for x in po_m.items))
        grns = [GRNRef(g.grn_id,g.po_id,g.supplier_id,g.status,tuple(GRNItem(x.po_line_id,x.received_qty_kg,x.accepted_qty_kg,x.rejected_qty_kg,x.unit_price) for x in g.items),g.receipt_date) for g in grns_m]
        invoice = SupplierInvoice(invoice_m.invoice_id,invoice_m.supplier_id,invoice_m.invoice_no,invoice_m.invoice_date,invoice_m.due_date,
                                   tuple(SupplierInvoiceLine(x.po_line_id,x.quantity_kg,x.unit_price,x.tax_code) for x in invoice_m.lines),
                                   invoice_m.taxable_total,invoice_m.tax_total,invoice_m.grand_total,invoice_m.status,invoice_m.document_file_id)
        result = three_way_match(invoice,po,grns,MatchTolerance(tol_m.qty_kg,tol_m.price_per_kg,tol_m.amount))
        return {'match': {'invoice_id':result.invoice_id,'status':result.status,'reasons':result.exception_reasons,
                          'subtotal_variance':str(result.subtotal_variance),
                          'lines':[x.__dict__ for x in result.lines]}}
    except (KeyError, P2PError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))
