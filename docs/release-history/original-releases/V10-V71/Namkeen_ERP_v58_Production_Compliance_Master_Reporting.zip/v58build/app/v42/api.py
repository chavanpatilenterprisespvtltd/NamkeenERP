from fastapi import FastAPI, HTTPException
from app.v42.tally_worker import TallyWorker, outbox_reconciliation
from app.db.session import get_session

app=FastAPI(title='Namkeen ERP v42 Accounting Integration')
worker=TallyWorker()

@app.get('/outbox/reconciliation')
def reconciliation(organization_id:int):
    with get_session() as db:
        return outbox_reconciliation(db, organization_id=organization_id)

@app.post('/outbox/{outbox_id}/process')
def process(outbox_id:int, organization_id:int):
    with get_session() as db:
        try:
            r=worker.process_one(db,organization_id=organization_id,outbox_id=outbox_id)
            db.commit(); return r.__dict__
        except ValueError as e: db.rollback(); raise HTTPException(404,str(e))
        except Exception:
            db.rollback(); raise HTTPException(500,'INTEGRATION_PROCESSING_FAILED')
