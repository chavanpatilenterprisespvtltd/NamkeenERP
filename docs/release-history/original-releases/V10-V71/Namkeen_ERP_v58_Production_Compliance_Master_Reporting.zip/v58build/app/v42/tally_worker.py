from __future__ import annotations
import json, random, hashlib
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from sqlalchemy import select, and_
from sqlalchemy.orm import Session
from app.db.models_v41 import AccountingOutboxV41
from app.accounting.tally import AccountingDocument, TallyXmlAdapter

@dataclass(frozen=True)
class DeliveryResult:
    outbox_id:int; status:str; attempts:int; message:str

class TallyTransport:
    def send(self, *, payload:str, idempotency_key:str, config:dict)->dict:
        # Deployment seam. A real adapter may POST to TallyPrime's configured endpoint.
        return {"ack": True, "reference": idempotency_key, "payload_sha256": hashlib.sha256(payload.encode()).hexdigest()}

def utc_now():
    return datetime.now(timezone.utc)

def as_aware(dt):
    if dt is None: return None
    if dt.tzinfo is None: return dt.replace(tzinfo=timezone.utc)
    return dt

class TallyWorker:
    def __init__(self, transport:TallyTransport|None=None, adapter:TallyXmlAdapter|None=None, rng=None):
        self.transport=transport or TallyTransport(); self.adapter=adapter or TallyXmlAdapter(); self.rng=rng or random.Random(0)

    def _backoff(self, attempt:int, base:int=30, cap:int=3600)->int:
        raw=min(cap, base*(2**max(0,attempt-1)))
        return int(raw + raw*0.20*(self.rng.random()*2-1))

    def _build_xml(self, payload:dict)->str:
        doc=AccountingDocument(
            doc_type=payload.get('doc_type','SALES'), doc_no=str(payload['invoice_no']),
            doc_date=str(payload.get('doc_date','')), party=str(payload.get('party_code') or payload.get('customer_id')),
            taxable_value=Decimal(str(payload['taxable_total'])), gst=Decimal(str(payload['tax_total'])),
            total=Decimal(str(payload['grand_total']))
        )
        return self.adapter.export([doc])

    def process_one(self, db:Session, *, organization_id:int, outbox_id:int, config:dict|None=None)->DeliveryResult:
        row=db.execute(select(AccountingOutboxV41).where(AccountingOutboxV41.organization_id==organization_id,AccountingOutboxV41.id==outbox_id).with_for_update()).scalar_one_or_none()
        if not row: raise ValueError('OUTBOX_NOT_FOUND')
        if row.status=='POSTED': return DeliveryResult(row.id,'DUPLICATE',row.attempts,'Already posted')
        if row.status=='DEAD_LETTER': return DeliveryResult(row.id,'DEAD_LETTER',row.attempts,'Dead-lettered')
        if row.status=='PENDING' and row.available_at and as_aware(row.available_at) > utc_now():
            return DeliveryResult(row.id,'WAITING',row.attempts,'Not yet available')
        payload=json.loads(row.payload_json)
        row.status='PROCESSING'; row.attempts=int(row.attempts or 0)+1
        try:
            xml=self._build_xml(payload)
            ack=self.transport.send(payload=xml,idempotency_key=row.idempotency_key,config=config or {})
            if not ack.get('ack'): raise RuntimeError(ack.get('message','TALLY_NOT_ACK'))
            row.status='POSTED'; row.last_error=None; db.flush()
            return DeliveryResult(row.id,'POSTED',row.attempts,str(ack.get('reference','ACK')))
        except Exception as exc:
            row.last_error=str(exc)
            if row.attempts >= int((config or {}).get('max_attempts',5)):
                row.status='DEAD_LETTER'
                return DeliveryResult(row.id,'DEAD_LETTER',row.attempts,str(exc))
            row.status='PENDING'; delay=self._backoff(row.attempts, int((config or {}).get('base_backoff_seconds',30)), int((config or {}).get('max_backoff_seconds',3600)))
            row.available_at=utc_now()+timedelta(seconds=delay)
            db.flush()
            return DeliveryResult(row.id,'RETRY',row.attempts,str(exc))

    def process_batch(self, db:Session, *, organization_id:int, limit:int=20, config:dict|None=None)->list[DeliveryResult]:
        now=utc_now()
        ids=[x[0] for x in db.execute(select(AccountingOutboxV41.id).where(and_(AccountingOutboxV41.organization_id==organization_id,AccountingOutboxV41.status=='PENDING',AccountingOutboxV41.available_at<=now)).order_by(AccountingOutboxV41.id).limit(limit)).all()]
        return [self.process_one(db,organization_id=organization_id,outbox_id=i,config=config) for i in ids]


def outbox_reconciliation(db:Session, *, organization_id:int)->dict:
    rows=db.execute(select(AccountingOutboxV41.status).where(AccountingOutboxV41.organization_id==organization_id)).scalars().all()
    result={k:0 for k in ('PENDING','PROCESSING','POSTED','DEAD_LETTER')}
    for s in rows: result[s]=result.get(s,0)+1
    return result
