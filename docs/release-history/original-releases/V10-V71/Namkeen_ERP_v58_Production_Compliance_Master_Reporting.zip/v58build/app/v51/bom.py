from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Iterable, Optional

Q6 = Decimal('0.000001')
Q2 = Decimal('0.01')


def qty(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q6, rounding=ROUND_HALF_UP)


def money(v: Decimal | int | str) -> Decimal:
    return Decimal(v).quantize(Q2, rounding=ROUND_HALF_UP)


class BomError(ValueError):
    pass


class BomComponentType(str, Enum):
    RM = 'RM'
    PACKAGING = 'PACKAGING'
    INTERMEDIATE = 'INTERMEDIATE'
    BYPRODUCT = 'BYPRODUCT'


@dataclass(frozen=True)
class BomComponent:
    item_id: int
    item_type: BomComponentType
    qty_per_output_kg: Decimal
    scrap_pct: Decimal = Decimal('0')
    unit_cost: Optional[Decimal] = None

    def __post_init__(self):
        if self.item_id <= 0:
            raise BomError('INVALID_COMPONENT_ITEM')
        q = qty(self.qty_per_output_kg)
        s = Decimal(self.scrap_pct)
        if q <= 0:
            raise BomError('INVALID_COMPONENT_QTY')
        if s < 0 or s >= 100:
            raise BomError('INVALID_SCRAP_PCT')
        if self.unit_cost is not None and Decimal(self.unit_cost) < 0:
            raise BomError('NEGATIVE_UNIT_COST')

    @property
    def gross_qty_per_output_kg(self) -> Decimal:
        # Scrap is additional planned issue over the net recipe quantity.
        return qty(self.qty_per_output_kg * (Decimal('1') + Decimal(self.scrap_pct) / Decimal('100')))


@dataclass(frozen=True)
class BomByproduct:
    item_id: int
    qty_per_output_kg: Decimal
    recovery_value_per_kg: Decimal = Decimal('0')

    def __post_init__(self):
        if self.item_id <= 0 or qty(self.qty_per_output_kg) <= 0:
            raise BomError('INVALID_BYPRODUCT')
        if Decimal(self.recovery_value_per_kg) < 0:
            raise BomError('NEGATIVE_RECOVERY_VALUE')


@dataclass(frozen=True)
class BomVersion:
    bom_id: int
    sku_id: int
    entity_id: int
    version: str
    effective_from: str
    effective_to: Optional[str]
    expected_yield_pct: Decimal
    components: tuple[BomComponent, ...]
    byproducts: tuple[BomByproduct, ...] = ()
    active: bool = True
    notes: Optional[str] = None

    def __post_init__(self):
        if self.bom_id <= 0 or self.sku_id <= 0 or self.entity_id <= 0:
            raise BomError('INVALID_BOM_IDENTITY')
        y = Decimal(self.expected_yield_pct)
        if y <= 0 or y > 100:
            raise BomError('INVALID_EXPECTED_YIELD')
        if not self.components:
            raise BomError('BOM_COMPONENTS_REQUIRED')
        ids = [c.item_id for c in self.components]
        if len(ids) != len(set(ids)):
            raise BomError('DUPLICATE_BOM_COMPONENT')
        bpids = [b.item_id for b in self.byproducts]
        if len(bpids) != len(set(bpids)):
            raise BomError('DUPLICATE_BYPRODUCT')

    @property
    def component_cost_per_output_kg(self) -> Decimal:
        total = Decimal('0')
        for c in self.components:
            if c.unit_cost is None:
                continue
            total += c.gross_qty_per_output_kg * Decimal(c.unit_cost)
        return money(total)


@dataclass(frozen=True)
class MaterialRequirement:
    item_id: int
    item_type: BomComponentType
    net_required_qty: Decimal
    gross_issue_qty: Decimal
    expected_cost: Optional[Decimal]


@dataclass(frozen=True)
class ProductionPlan:
    sku_id: int
    planned_good_output_kg: Decimal
    expected_input_kg: Decimal
    requirements: tuple[MaterialRequirement, ...]
    byproduct_qty: tuple[tuple[int, Decimal], ...]
    planned_material_cost: Optional[Decimal]


@dataclass(frozen=True)
class ConsumptionVariance:
    item_id: int
    planned_qty: Decimal
    actual_qty: Decimal
    variance_qty: Decimal
    variance_pct: Optional[Decimal]


def calculate_requirements(bom: BomVersion, planned_good_output_kg: Decimal) -> ProductionPlan:
    output = qty(planned_good_output_kg)
    if output <= 0:
        raise BomError('INVALID_PLANNED_OUTPUT')
    expected_input = qty(output * Decimal('100') / Decimal(bom.expected_yield_pct))
    reqs: list[MaterialRequirement] = []
    total_cost = Decimal('0')
    priced = True
    for c in bom.components:
        net = qty(c.qty_per_output_kg * output)
        gross = qty(c.gross_qty_per_output_kg * output)
        amount = None
        if c.unit_cost is None:
            priced = False
        else:
            amount = money(gross * Decimal(c.unit_cost))
            total_cost += amount
        reqs.append(MaterialRequirement(c.item_id, c.item_type, net, gross, amount))
    byproducts = tuple((b.item_id, qty(b.qty_per_output_kg * output)) for b in bom.byproducts)
    return ProductionPlan(
        sku_id=bom.sku_id,
        planned_good_output_kg=output,
        expected_input_kg=expected_input,
        requirements=tuple(reqs),
        byproduct_qty=byproducts,
        planned_material_cost=money(total_cost) if priced else None,
    )


def compare_consumption(plan: ProductionPlan, actual: Iterable[tuple[int, Decimal]], tolerance_pct: Decimal = Decimal('0')) -> tuple[ConsumptionVariance, ...]:
    if Decimal(tolerance_pct) < 0:
        raise BomError('NEGATIVE_VARIANCE_TOLERANCE')
    actual_map = {int(i): qty(q) for i, q in actual}
    planned = {r.item_id: r.gross_issue_qty for r in plan.requirements}
    for item_id, a in actual_map.items():
        if a < 0:
            raise BomError('NEGATIVE_ACTUAL_CONSUMPTION')
        if item_id not in planned:
            raise BomError('UNPLANNED_ITEM_CONSUMPTION')
    out: list[ConsumptionVariance] = []
    for item_id, p in planned.items():
        a = actual_map.get(item_id, Decimal('0'))
        v = qty(a - p)
        vp = (v / p * Decimal('100')).quantize(Q2, rounding=ROUND_HALF_UP) if p else None
        out.append(ConsumptionVariance(item_id, p, a, v, vp))
    return tuple(out)
