"""v51 standard BOM/recipe and production-planning integration."""
