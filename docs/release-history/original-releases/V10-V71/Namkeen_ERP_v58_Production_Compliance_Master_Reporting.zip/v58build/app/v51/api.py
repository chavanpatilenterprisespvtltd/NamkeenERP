from __future__ import annotations
from decimal import Decimal
from fastapi import APIRouter, HTTPException
from .bom import BomComponent, BomComponentType, BomByproduct, BomVersion, calculate_requirements, compare_consumption

router = APIRouter(prefix='/v51/production-planning', tags=['v51-production-planning'])


def _bom(payload: dict) -> BomVersion:
    return BomVersion(
        bom_id=int(payload['bom_id']), sku_id=int(payload['sku_id']), entity_id=int(payload['entity_id']),
        version=str(payload['version']), effective_from=str(payload['effective_from']),
        effective_to=payload.get('effective_to'), expected_yield_pct=Decimal(str(payload['expected_yield_pct'])),
        components=tuple(BomComponent(int(x['item_id']), BomComponentType(x['item_type']), Decimal(str(x['qty_per_output_kg'])), Decimal(str(x.get('scrap_pct','0'))), Decimal(str(x['unit_cost'])) if x.get('unit_cost') is not None else None) for x in payload['components']),
        byproducts=tuple(BomByproduct(int(x['item_id']), Decimal(str(x['qty_per_output_kg'])), Decimal(str(x.get('recovery_value_per_kg','0')))) for x in payload.get('byproducts', [])),
        active=bool(payload.get('active', True)), notes=payload.get('notes')
    )


@router.post('/requirements/calculate')
def requirements(payload: dict):
    try:
        plan = calculate_requirements(_bom(payload['bom']), Decimal(str(payload['planned_good_output_kg'])))
        return {
            'sku_id': plan.sku_id, 'planned_good_output_kg': str(plan.planned_good_output_kg),
            'expected_input_kg': str(plan.expected_input_kg),
            'planned_material_cost': str(plan.planned_material_cost) if plan.planned_material_cost is not None else None,
            'requirements': [
                {'item_id': r.item_id, 'item_type': r.item_type.value, 'net_required_qty': str(r.net_required_qty),
                 'gross_issue_qty': str(r.gross_issue_qty), 'expected_cost': str(r.expected_cost) if r.expected_cost is not None else None}
                for r in plan.requirements
            ],
            'byproducts': [{'item_id': i, 'qty': str(q)} for i, q in plan.byproduct_qty],
        }
    except (KeyError, ValueError) as exc:
        raise HTTPException(400, str(exc))


@router.post('/consumption/variance')
def consumption_variance(payload: dict):
    try:
        plan = calculate_requirements(_bom(payload['bom']), Decimal(str(payload['planned_good_output_kg'])))
        rows = compare_consumption(plan, [(int(x['item_id']), Decimal(str(x['actual_qty']))) for x in payload.get('actual', [])], Decimal(str(payload.get('tolerance_pct','0'))))
        return {'variances': [{'item_id': x.item_id, 'planned_qty': str(x.planned_qty), 'actual_qty': str(x.actual_qty), 'variance_qty': str(x.variance_qty), 'variance_pct': str(x.variance_pct) if x.variance_pct is not None else None} for x in rows]}
    except (KeyError, ValueError) as exc:
        raise HTTPException(400, str(exc))
