from __future__ import annotations
import json
from datetime import datetime, timezone
from sqlalchemy import select, func
from app.db.models_v19 import DomainChange


def _next_version(db, *, org_id: int, aggregate_type: str, aggregate_id: str) -> int:
    current = db.execute(
        select(func.max(DomainChange.version)).where(
            DomainChange.organization_id == org_id,
            DomainChange.aggregate_type == aggregate_type,
            DomainChange.aggregate_id == str(aggregate_id),
        )
    ).scalar_one()
    return int(current or 0) + 1


def record_change(
    db, *, org_id: int, aggregate_type: str, aggregate_id: str,
    operation: str, event_name: str, payload: dict,
    actor_user_id: int|None = None, entity_scope_id: int|None = None,
) -> DomainChange:
    version = _next_version(db, org_id=org_id, aggregate_type=aggregate_type, aggregate_id=aggregate_id)
    row = DomainChange(
        organization_id=org_id,
        entity_scope_id=entity_scope_id,
        aggregate_type=aggregate_type,
        aggregate_id=str(aggregate_id),
        operation=operation,
        version=version,
        event_name=event_name,
        payload_json=json.dumps(payload, separators=(',', ':'), default=str),
        actor_user_id=actor_user_id,
        occurred_at=datetime.now(timezone.utc),
    )
    db.add(row)
    db.flush()
    return row


def mirror_to_v18_change_log(db, *, row: DomainChange, change_log_model) -> object:
    """Bridge new domain changes into the existing v18 pull stream during migration."""
    existing = db.execute(
        select(change_log_model).where(
            change_log_model.organization_id == row.organization_id,
            change_log_model.entity_type == row.aggregate_type,
            change_log_model.entity_id == row.aggregate_id,
            change_log_model.version == row.version,
        )
    ).scalar_one_or_none()
    if existing:
        return existing
    out = change_log_model(
        organization_id=row.organization_id,
        entity_type=row.aggregate_type,
        entity_id=row.aggregate_id,
        operation=row.operation,
        version=row.version,
        payload_json=row.payload_json,
        occurred_at=row.occurred_at,
    )
    db.add(out)
    db.flush()
    return out
