import json
from app.db.models import SyncEvent

SERVER_EVENTS = {"CREATE_CUSTOMER", "CUSTOMER_APPROVAL", "CREATE_ORDER", "PAYMENT_CAPTURE", "COLLECTION_CAPTURE", "COLLECTION_DEPOSIT", "CREATE_RETURN"}

def accept_sync_event(db, *, org_id, device_id, client_event_id, event_type, payload, base_version=None):
    if event_type not in SERVER_EVENTS: raise ValueError("Unsupported sync event type")
    existing = db.query(SyncEvent).filter(SyncEvent.organization_id==org_id, SyncEvent.client_event_id==client_event_id).one_or_none()
    if existing:
        return existing, "DUPLICATE"
    status = "PENDING"
    if base_version is not None and base_version < 0: status = "CONFLICT"
    ev = SyncEvent(organization_id=org_id, device_id=device_id, client_event_id=client_event_id, event_type=event_type,
                   payload_json=json.dumps(payload, separators=(",", ":")), status=status)
    db.add(ev); db.flush(); return ev, status
