from dataclasses import dataclass
from enum import Enum

class SyncStatus(str, Enum):
    ACCEPTED="ACCEPTED"; DUPLICATE="DUPLICATE"; CONFLICT="CONFLICT"; REJECTED="REJECTED"

@dataclass(frozen=True)
class SyncCommand:
    client_event_id: str
    device_id: str
    entity: str
    entity_id: str
    client_version: int
    payload: dict

@dataclass(frozen=True)
class SyncResult:
    status: SyncStatus
    message: str
    server_version: int|None = None

class ConflictResolver:
    """Generic optimistic concurrency gate. Domain services decide whether a conflict can be merged."""
    def check(self, command: SyncCommand, current_version: int|None) -> SyncResult:
        if current_version is None or command.client_version == current_version:
            return SyncResult(SyncStatus.ACCEPTED,"Apply server-side",current_version)
        return SyncResult(SyncStatus.CONFLICT, f"Version mismatch: client={command.client_version}, server={current_version}", current_version)
