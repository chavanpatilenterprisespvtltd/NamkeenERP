from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from sqlalchemy import select, and_, or_, func
from app.db.models import SyncEvent

@dataclass(frozen=True)
class Delta:
    id: int
    entity_type: str
    entity_id: str
    operation: str
    version: int
    payload: dict
    occurred_at: str

@dataclass(frozen=True)
class SyncBatchResult:
    accepted: list[dict]
    conflicts: list[dict]
    rejected: list[dict]
    deltas: list[dict]
    next_cursor: int

class SyncDomainError(Exception):
    pass

def record_server_change(db, *, change_log_model, org_id:int, entity_type:str, entity_id:str, operation:str, version:int, payload:dict):
    row = change_log_model(
        organization_id=org_id, entity_type=entity_type, entity_id=str(entity_id),
        operation=operation, version=version,
        payload_json=json.dumps(payload, separators=(",", ":")),
        occurred_at=datetime.now(timezone.utc),
    )
    db.add(row)
    db.flush()
    return row

def get_deltas(db, *, change_log_model, org_id:int, cursor:int=0, limit:int=200):
    rows = db.execute(
        select(change_log_model).where(
            change_log_model.organization_id == org_id,
            change_log_model.id > cursor,
        ).order_by(change_log_model.id).limit(limit)
    ).scalars().all()
    deltas=[]
    for r in rows:
        deltas.append({
            "change_id": r.id, "entity_type": r.entity_type, "entity_id": r.entity_id,
            "operation": r.operation, "version": r.version,
            "payload": json.loads(r.payload_json),
            "occurred_at": r.occurred_at.isoformat() if r.occurred_at else None,
        })
    next_cursor = rows[-1].id if rows else cursor
    return deltas, next_cursor

def compare_version(*, client_version:int, server_version:int|None):
    if server_version is None or client_version == server_version:
        return "ACCEPTED"
    if client_version < server_version:
        return "CONFLICT"
    return "REJECTED"

def upsert_sync_event(db, *, org_id:int, device_id:str, client_event_id:str, event_type:str, payload:dict, base_version:int|None):
    existing = db.execute(select(SyncEvent).where(
        SyncEvent.organization_id == org_id,
        SyncEvent.client_event_id == client_event_id,
    )).scalar_one_or_none()
    if existing:
        return existing, "DUPLICATE"
    if base_version is not None and base_version < 0:
        status = "REJECTED"
    else:
        status = "PENDING"
    row = SyncEvent(
        organization_id=org_id, device_id=device_id, client_event_id=client_event_id,
        event_type=event_type, payload_json=json.dumps(payload, separators=(",", ":")), status=status,
    )
    db.add(row); db.flush()
    return row, status
