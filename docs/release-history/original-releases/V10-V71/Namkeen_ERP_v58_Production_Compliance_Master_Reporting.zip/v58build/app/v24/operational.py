from __future__ import annotations
from decimal import Decimal
from datetime import datetime, timezone
from sqlalchemy import select
from app.db.models_v24 import ProductionBatch, ProductionRecord, QCInspection, PriceException
from app.db.models_v17 import SalesReturn
from app.sync.domain_integration_v20 import emit

PRODUCTION_ROLES = {"PRODUCTION", "FACTORY", "MANAGER", "MANAGEMENT", "SUPER_ADMIN"}
QC_ROLES = {"QC", "MANAGER", "MANAGEMENT", "SUPER_ADMIN"}
PRICE_APPROVER_ROLES = {"MANAGER", "MANAGEMENT", "SUPER_ADMIN"}

def create_batch(db, *, org_id, entity_id, actor_id, actor_role, batch_no, product_id, planned_qty_kg):
    if actor_role not in PRODUCTION_ROLES: raise PermissionError("PRODUCTION_ROLE_REQUIRED")
    qty=Decimal(str(planned_qty_kg))
    if qty <= 0: raise ValueError("PLANNED_QTY_MUST_BE_POSITIVE")
    exists=db.execute(select(ProductionBatch).where(ProductionBatch.organization_id==org_id, ProductionBatch.batch_no==batch_no)).scalar_one_or_none()
    if exists: raise ValueError("BATCH_NO_ALREADY_EXISTS")
    b=ProductionBatch(organization_id=org_id, entity_id=entity_id, batch_no=batch_no, product_id=product_id, planned_qty_kg=qty, actual_qty_kg=Decimal("0"), status="PLANNED", created_by=actor_id)
    db.add(b); db.flush()
    emit(db, org_id=org_id, entity_id=entity_id, aggregate_type="PRODUCTION_BATCH", aggregate_id=batch_no, event_name="PRODUCTION_BATCH_CREATED", operation="CREATE", actor_user_id=actor_id, payload={"id":b.id,"batch_no":batch_no,"product_id":product_id,"planned_qty_kg":str(qty),"status":b.status})
    return b

def record_production(db, *, org_id, entity_id, actor_id, actor_role, batch_id, good_qty_kg, reject_qty_kg=0, note=None):
    if actor_role not in PRODUCTION_ROLES: raise PermissionError("PRODUCTION_ROLE_REQUIRED")
    b=db.execute(select(ProductionBatch).where(ProductionBatch.id==batch_id, ProductionBatch.organization_id==org_id, ProductionBatch.entity_id==entity_id).with_for_update()).scalar_one()
    if b.status not in {"PLANNED","IN_PROGRESS"}: raise ValueError(f"BATCH_NOT_RECORDABLE:{b.status}")
    good=Decimal(str(good_qty_kg)); reject=Decimal(str(reject_qty_kg))
    if good<0 or reject<0 or good+reject<=0: raise ValueError("INVALID_PRODUCTION_QTY")
    if Decimal(b.actual_qty_kg)+good > Decimal(b.planned_qty_kg): raise ValueError("GOOD_QTY_EXCEEDS_PLAN")
    r=ProductionRecord(organization_id=org_id, entity_id=entity_id, batch_id=batch_id, good_qty_kg=good, reject_qty_kg=reject, note=note, recorded_by=actor_id)
    db.add(r); b.actual_qty_kg += good; b.status="IN_PROGRESS" if b.actual_qty_kg < b.planned_qty_kg else "COMPLETED"; db.flush()
    emit(db, org_id=org_id, entity_id=entity_id, aggregate_type="PRODUCTION_BATCH", aggregate_id=b.batch_no, event_name="PRODUCTION_BATCH_QC_RECORDED", operation="UPDATE", actor_user_id=actor_id, payload={"batch_id":b.id,"good_qty_kg":str(good),"reject_qty_kg":str(reject),"status":b.status})
    return b

def record_qc(db, *, org_id, entity_id, actor_id, actor_role, batch_id=None, return_id=None, result="HOLD", remarks=None, evidence_file_id=None):
    if actor_role not in QC_ROLES: raise PermissionError("QC_ROLE_REQUIRED")
    if bool(batch_id) == bool(return_id): raise ValueError("EXACTLY_ONE_QC_TARGET_REQUIRED")
    if result not in {"PASS","FAIL","HOLD"}: raise ValueError("INVALID_QC_RESULT")
    qi=QCInspection(organization_id=org_id, entity_id=entity_id, batch_id=batch_id, return_id=return_id, result=result, remarks=remarks, evidence_file_id=evidence_file_id, inspected_by=actor_id)
    db.add(qi); db.flush()
    if batch_id:
        b=db.execute(select(ProductionBatch).where(ProductionBatch.id==batch_id, ProductionBatch.organization_id==org_id, ProductionBatch.entity_id==entity_id).with_for_update()).scalar_one()
        if result=="PASS": b.status="QC_PASSED"
        elif result=="FAIL": b.status="QC_FAILED"
    if return_id:
        r=db.execute(select(SalesReturn).where(SalesReturn.id==return_id, SalesReturn.organization_id==org_id, SalesReturn.entity_id==entity_id).with_for_update()).scalar_one()
        if result=="PASS": r.status="QC_PASSED"
        elif result=="FAIL": r.status="QC_FAILED"
    db.flush()
    return qi

def request_price_exception(db, *, org_id, entity_id, actor_id, order_id, line_id, negotiated_price, floor_price, reason=None):
    price=Decimal(str(negotiated_price)); floor=Decimal(str(floor_price))
    if price >= floor: raise ValueError("PRICE_IS_NOT_BELOW_FLOOR")
    x=PriceException(organization_id=org_id, entity_id=entity_id, order_id=order_id, line_id=line_id, negotiated_price=price, floor_price=floor, requested_by=actor_id, reason=reason, status="PENDING")
    db.add(x); db.flush(); return x

def decide_price_exception(db, *, org_id, entity_id, actor_id, actor_role, exception_id, approve, reason=None):
    if actor_role not in PRICE_APPROVER_ROLES: raise PermissionError("PRICE_APPROVAL_ROLE_REQUIRED")
    x=db.execute(select(PriceException).where(PriceException.id==exception_id, PriceException.organization_id==org_id, PriceException.entity_id==entity_id, PriceException.status=="PENDING").with_for_update()).scalar_one()
    x.status="APPROVED" if approve else "REJECTED"; x.decided_by=actor_id; x.decided_at=datetime.now(timezone.utc); x.reason=reason or x.reason
    db.flush(); return x
