# v48 Android Contract — Delivery Settlement

Screens: Delivery Reconciliation, Short/Failed/Return Exception, Customer Adjustment Review, Freight Settlement.

Flow: Trip/Delivery → delivered/failed/returned quantities → evidence → reconciliation → exception approval → controlled posting.

Offline writes carry `client_event_id`. Server remains authoritative for stock, receivable and credit-note effects. Android never directly changes inventory or customer ledger balances.
