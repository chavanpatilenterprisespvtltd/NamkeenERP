# Android v38 — Collections & Credit Control Contract

## Salesperson
- Customer ageing and available credit view
- Credit status badge: CLEAR / SOFT BLOCK / HARD BLOCK
- Collection target/progress
- Receipt capture: UPI / Cash / Cheque / Bank Transfer / Other
- Cash collection requires counterparty/shop photo evidence
- Cheque reference + evidence capture
- Failed/bounced payment reason capture
- Offline receipt event queue with client_event_id

## Manager / Accounts / Management
- Verify / reject receipts
- Mark cheque/payment failed or bounced with reason
- Customer outstanding drill-down
- Credit override request / approve workflow
- Collection target assignment
- Collection alert acknowledgement

## Server authority
- Server is authoritative for credit blocks, receipt verification, allocation and override status.
- Mobile cannot bypass outstanding/credit-limit checks.
- Receipt allocation is validated before posting.
- All overrides require reason and approval audit trail.
