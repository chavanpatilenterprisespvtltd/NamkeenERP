plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.namkeen.erp.v24"; compileSdk = 35
    defaultConfig { applicationId = "com.namkeen.erp.v24"; minSdk = 26; targetSdk = 35; versionCode = 24; versionName = "24.0" }
}

dependencies {
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.ui:ui:1.7.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
}
