package com.namkeen.erp.v24

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OperationalApp() }
    }
}

@Composable
fun OperationalApp() {
    var screen by remember { mutableStateOf("dashboard") }
    MaterialTheme {
        Scaffold(topBar={TopAppBar(title={Text("Namkeen ERP v24")})}) { pad ->
            Column(Modifier.padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("Operational controls", style=MaterialTheme.typography.headlineSmall)
                Button(onClick={screen="production"}, modifier=Modifier.fillMaxWidth()){Text("Production / Batches")}
                Button(onClick={screen="qc"}, modifier=Modifier.fillMaxWidth()){Text("QC Inspection")}
                Button(onClick={screen="approvals"}, modifier=Modifier.fillMaxWidth()){Text("Price / Order Approvals")}
                Button(onClick={screen="dispatch"}, modifier=Modifier.fillMaxWidth()){Text("Stock Reservation / Dispatch")}
                Button(onClick={screen="payment"}, modifier=Modifier.fillMaxWidth()){Text("Payment Verification / Cheque")}
                Divider()
                Text("Screen: ${screen.uppercase()}")
                when(screen){
                    "production" -> Text("Plan batch • record good/reject kg • sync when online")
                    "qc" -> Text("Select batch/return • PASS/FAIL/HOLD • attach evidence")
                    "approvals" -> Text("Review below-floor exceptions • approve/reject with reason")
                    "dispatch" -> Text("Reserve FEFO stock • review allocation • post dispatch")
                    "payment" -> Text("Verify payment • clear cheque only after authorized decision")
                    else -> Text("Choose an operational function")
                }
            }
        }
    }
}
