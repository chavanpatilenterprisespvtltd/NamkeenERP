# Android v29 — LPN / Carton Operations

Reference shell for scanner-driven carton workflows. The production client should:
- resolve LPN barcode through the server;
- show carton contents, lot and earliest expiry;
- require server-approved actions for seal/open/move/pick/dispatch/return/quarantine;
- queue scans offline with the existing v21+ sync layer and client_event_id;
- never locally overwrite inventory stock balances.
