plugins { id("com.android.application"); kotlin("android") }

android { namespace = "com.namkeen.erp.v29"; compileSdk = 35
    defaultConfig { applicationId = "com.namkeen.erp.v29"; minSdk = 26; targetSdk = 35; versionCode = 29; versionName = "0.29" }
}
