package com.namkeen.erp.v29

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        root.addView(TextView(this).apply { text = "Carton / LPN Operations"; textSize = 24f })
        root.addView(TextView(this).apply { text = "Scan LPN • View Contents • Move • Seal • Pick • Dispatch • Return/Quarantine"; textSize = 16f })
        setContentView(root)
    }
}
