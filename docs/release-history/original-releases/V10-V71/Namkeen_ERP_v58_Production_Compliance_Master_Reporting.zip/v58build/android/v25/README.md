# v25 Android inventory shell

Reference Compose shell for warehouse operations. Wire these screens to `/v25` APIs and the existing v21 synchronization layer. Client is not authoritative for stock, QC, approvals or traceability posting.
