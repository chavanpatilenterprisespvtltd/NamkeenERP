package com.namkeen.erp.v25

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { V25Home() } }
}

@Composable
fun V25Home() {
    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Namkeen ERP v25", style = MaterialTheme.typography.headlineMedium)
            Text("Inventory & Warehouse", style = MaterialTheme.typography.titleMedium)
            listOf("GRN / Receiving", "Incoming QC", "Stock by Warehouse", "Transfers", "Stock Adjustments", "Barcode / QR Scan", "Traceability").forEach { label ->
                OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text(label) }
            }
        }
    }
}
