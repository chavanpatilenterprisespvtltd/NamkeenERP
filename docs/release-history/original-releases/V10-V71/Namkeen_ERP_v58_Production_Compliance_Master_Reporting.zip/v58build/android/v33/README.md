# Android v33 — Procurement Planning Client Contract

Screens:
- Procurement dashboard
- Demand horizon selector
- Suggested purchases
- Suggested production requirements
- Supplier/lead-time detail
- Approval queue
- Planning history

Offline rules:
- Read cached suggestions offline.
- Draft planning inputs may be captured offline.
- Final approval and PO/production creation are server-authoritative.
- Conflicts are surfaced through the v21-v22 sync mechanism.
