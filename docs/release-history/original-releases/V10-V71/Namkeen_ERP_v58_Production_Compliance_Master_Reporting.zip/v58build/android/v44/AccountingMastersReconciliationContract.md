# v44 Android contract

Screens:
1. Accounts dashboard
2. Customer ledger mapping
3. Supplier ledger mapping
4. Ledger sync queue
5. Reconciliation queue
6. Mismatch detail
7. Reconciliation action request/approval

Rules:
- Party ledger mapping is entity-scoped.
- Customer/supplier source master remains ERP-authoritative.
- External ledger name/reference is a synchronization result, not a replacement for the ERP party identity.
- Reconciliation actions require reason and preserve audit history.
- Requester cannot approve own reconciliation action.
- Accepting an external match may close only the reconciliation record; it cannot rewrite the source transaction.
