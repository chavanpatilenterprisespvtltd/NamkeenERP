# Android v28 — Barcode Warehouse Operations

Reference UI/architecture for the scanner screens:

- Scan Home: Receive / Issue / Transfer / Pick / Dispatch / Count / Verify Lot
- Scan Result: barcode, entity, SKU, lot, batch, expiry, current available quantity
- Quantity Entry: quantity + UOM, with converted kg preview when applicable
- Carton View: carton/pallet identifier and contained SKU/lot summary
- Stock Count: physical count capture; submit creates adjustment request, never direct stock overwrite
- Offline Queue: stores scan event + quantity + warehouse + client_event_id
- Sync: retries online, preserves ACK/RETRY/CONFLICT/DEAD_LETTER states

Camera/keyboard-wedge scanning remains modular. The server remains authoritative for stock posting.
