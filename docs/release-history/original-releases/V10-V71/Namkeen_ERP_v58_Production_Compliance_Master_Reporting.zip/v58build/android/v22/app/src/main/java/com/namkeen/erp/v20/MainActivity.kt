package com.namkeen.erp.v22

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.namkeen.erp.v22.ui.OfflineRepository
import com.namkeen.erp.v22.security.SecureTokenStore
import com.namkeen.erp.v22.data.ErpClient
import com.namkeen.erp.v22.api.LoginRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var offline: OfflineRepository
    private lateinit var tokens: SecureTokenStore
    private val products = listOf("Special Farsan","Simple / Regular Farsan","Zero Shev – Small Size","Chana Dal","Makka Chivda","Lasoon Shev","Medium Shev","Motichur Boondi","Masala Shenga","Khari Boondi","Papdi","Chilli Milli","Sabu Chivda","Batata Chivda","Shev Chivda")
    private val packSizes = listOf("100 g","200 g","250 g","500 g","1 kg","2 kg","5 kg")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        offline = OfflineRepository(applicationContext, "android-${UUID.randomUUID()}")
        tokens = SecureTokenStore(applicationContext)
        requestLocation()
        showLogin()
    }

    private fun base(title:String): LinearLayout {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,24,28,24) }
        val h=TextView(this).apply { text=title; textSize=24f; setPadding(0,0,0,18); gravity=Gravity.CENTER_VERTICAL }
        root.addView(h)
        setContentView(ScrollView(this).apply { addView(root) })
        return root
    }
    private fun button(text:String, action:()->Unit): Button = Button(this).apply { this.text=text; setOnClickListener{action()} }
    private fun input(hint:String): EditText = EditText(this).apply { this.hint=hint; setSingleLine(true) }

    private fun showLogin() {
        val r=base("Namkeen ERP • Salesperson")
        val server=input("ERP Server URL (e.g. https://erp.example.com/)"); val user=input("Mobile / User ID"); val pass=input("Password")
        r.addView(server); r.addView(user); r.addView(pass)
        r.addView(button("Login") {
            val baseUrl=server.text.toString().trim()
            if (baseUrl.isBlank()) { toast("Enter ERP server URL"); return@button }
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val api=ErpClient(baseUrl,tokens).service()
                    val out=api.login(LoginRequest(user.text.toString(),pass.text.toString(),"android-device"))
                    tokens.save(out.access_token,out.refresh_token)
                    launch(Dispatchers.Main) { showHome(out.role) }
                } catch (e:Exception) { launch(Dispatchers.Main) { toast("Login failed: ${e.message ?: "network error"}") } }
            }
        })
        r.addView(TextView(this).apply { text="After first authentication, queued transactions can be captured offline and synchronized when connected."; setPadding(0,22,0,0) })
    }
    private fun showHome(user:String) {
        val r=base("Welcome, $user")
        r.addView(button("New Customer") { showCustomer() })
        r.addView(button("New Sales Order") { showOrder() })
        r.addView(button("Collect Payment") { showCollection() })
        r.addView(button("Sales Return / QC") { showReturn() })
        r.addView(button("Sync / Conflicts") { showSyncStatus() })
        r.addView(button("Logout") { tokens.clear(); showLogin() })
    }
    private fun showCustomer() {
        val r=base("Customer Onboarding")
        val code=input("Customer code"); val name=input("Shop / Customer name"); val mobile=input("Mobile"); val address=input("Address")
        r.addView(code);r.addView(name);r.addView(mobile);r.addView(address)
        val gps=TextView(this).apply { text=getGpsText() }; r.addView(gps)
        r.addView(button("Capture / Attach Shop Photo") { toast("Camera upload queue ready") })
        r.addView(button("Save Customer Offline") {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                offline.enqueue("CUSTOMER_ONBOARDED","CUSTOMER",code.text.toString().ifBlank{"LOCAL"}, mapOf("code" to code.text.toString(),"name" to name.text.toString(),"mobile" to mobile.text.toString(),"address" to address.text.toString(),"gps" to getGpsText()))
                toast("Customer queued. Manager approval required on server.")
            }
        })
        r.addView(button("Back") { showHome("Salesperson") })
    }
    private fun showOrder() {
        val r=base("Sales Order")
        val customer=input("Customer ID"); val product=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,products) }
        val pack=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,packSizes) }
        val qty=input("Quantity"); val price=input("Negotiated selling price / unit")
        val pay=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("UPI","Cash","Cheque","Credit")) }
        r.addView(customer);r.addView(product);r.addView(pack);r.addView(qty);r.addView(price);r.addView(pay)
        r.addView(TextView(this).apply { text="Price/discount is preview only here; server enforces floor, margin, approval and GST rules."; setPadding(0,10,0,10) })
        r.addView(button("Submit Order Offline") {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                offline.enqueue("SALES_ORDER_CREATED","SALES_ORDER",UUID.randomUUID().toString(), mapOf("customer_id" to customer.text.toString(),"product" to product.selectedItem.toString(),"pack_size" to pack.selectedItem.toString(),"qty" to qty.text.toString(),"negotiated_price" to price.text.toString(),"payment_mode" to pay.selectedItem.toString()))
                toast("Order queued for authoritative server validation.")
            }
        })
        r.addView(button("Back") { showHome("Salesperson") })
    }
    private fun showCollection() {
        val r=base("Payment Collection")
        val paymentId=input("Payment ID"); val mode=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("UPI","Cash","Cheque")) }
        r.addView(paymentId);r.addView(mode)
        r.addView(button("Add Mandatory Counterparty Photo") { toast("Photo evidence queued") })
        r.addView(button("Capture Collection Offline") {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch { offline.enqueue("COLLECTION_CAPTURED","PAYMENT",paymentId.text.toString(),mapOf("payment_id" to paymentId.text.toString(),"mode" to mode.selectedItem.toString(),"counterparty_photo" to "REQUIRED","gps" to getGpsText())); toast("Collection captured. Deposit and Accounts verification remain controlled server steps.") }
        })
        r.addView(button("Back") { showHome("Salesperson") })
    }
    private fun showReturn() {
        val r=base("Sales Return → QC Hold")
        val order=input("Original Order ID"); val sku=input("SKU ID"); val qty=input("Return quantity"); val reason=input("Reason code")
        r.addView(order);r.addView(sku);r.addView(qty);r.addView(reason)
        r.addView(button("Attach Return Photo") { toast("Return evidence queued") })
        val disp=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("QC HOLD","Saleable","Repack","Rework","Damage","Expired","Dispose")) }
        r.addView(disp)
        r.addView(button("Submit Return Offline") {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch { offline.enqueue("SALES_RETURN_CREATED","SALES_RETURN",order.text.toString().ifBlank{"LOCAL"},mapOf("order_id" to order.text.toString(),"sku_id" to sku.text.toString(),"qty" to qty.text.toString(),"reason" to reason.text.toString(),"initial_disposition" to "QC HOLD")); toast("Return queued; saleable stock will not be changed directly by mobile.") }
        })
        r.addView(button("Back") { showHome("Salesperson") })
    }
    private fun showSyncStatus() {
        val r=base("Sync / Conflict Center")
        r.addView(TextView(this).apply { text="Sync runs only on connected network. Business decisions stay server-authoritative." })
        r.addView(button("Run Sync Now") { enqueueSync(); toast("Sync worker scheduled") })
        r.addView(button("Open Conflicts") { toast("Conflict screen uses explicit review / accept-server / discard actions") })
        r.addView(button("Back") { showHome("Salesperson") })
    }
    private fun enqueueSync() {
        val request=OneTimeWorkRequestBuilder<com.namkeen.erp.v22.sync.SyncWorker>().setConstraints(com.namkeen.erp.v22.sync.SyncWorker.constraints()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build()
        WorkManager.getInstance(this).enqueueUniqueWork("erp-v22-sync",ExistingWorkPolicy.KEEP,request)
    }
    private fun requestLocation(){ if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.CAMERA),501) }
    private fun getGpsText():String { if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return "permission-required"; val lm=getSystemService(LOCATION_SERVICE) as LocationManager; val p=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); return p?.let{"${it.latitude},${it.longitude}"} ?: "unavailable" }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
