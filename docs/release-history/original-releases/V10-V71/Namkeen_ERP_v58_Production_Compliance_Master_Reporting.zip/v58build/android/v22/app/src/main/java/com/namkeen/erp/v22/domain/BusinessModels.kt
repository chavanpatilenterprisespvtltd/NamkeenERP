package com.namkeen.erp.v22.domain

data class CustomerDraft(
    val code: String,
    val name: String,
    val mobile: String,
    val address: String,
    val gpsLat: Double?,
    val gpsLng: Double?,
    val shopPhotoFileId: String? = null,
    val aadhaarFileId: String? = null,
    val panFileId: String? = null
)

data class OrderLineDraft(
    val skuId: Long,
    val productName: String,
    val packSize: String,
    val qty: Double,
    val negotiatedPrice: Double
)

data class OrderDraft(
    val entityId: Long,
    val customerId: Long,
    val orderNo: String,
    val lines: List<OrderLineDraft>,
    val paymentMode: String,
    val total: Double
)
