package com.namkeen.erp.v22.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SyncDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun enqueue(item: SyncOutbox)
    @Query("SELECT * FROM sync_outbox WHERE state IN ('PENDING','RETRY') ORDER BY rowid LIMIT :limit") suspend fun pending(limit: Int): List<SyncOutbox>
    @Query("UPDATE sync_outbox SET state=:state, attempts=attempts+1, lastError=:error WHERE clientEventId=:id") suspend fun mark(id:String, state:String, error:String?)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertInbox(change: SyncInbox): Long
    @Query("SELECT value FROM sync_meta WHERE key='cursor' LIMIT 1") suspend fun cursor(): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveMeta(meta: SyncMeta)
    @Insert suspend fun conflict(item: SyncConflict)
}
