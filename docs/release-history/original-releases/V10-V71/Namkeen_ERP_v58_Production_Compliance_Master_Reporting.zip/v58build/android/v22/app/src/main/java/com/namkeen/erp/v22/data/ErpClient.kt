package com.namkeen.erp.v22.data

import com.namkeen.erp.v22.api.*
import com.namkeen.erp.v22.security.SecureTokenStore
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType

class ErpClient(baseUrl: String, tokenStore: SecureTokenStore) {
    private val api: ErpApi
    init {
        val contentType = "application/json".toMediaType()
        api = Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith('/')) baseUrl else "$baseUrl/")
            .addConverterFactory(kotlinx.serialization.json.Json { ignoreUnknownKeys = true }.asConverterFactory(contentType))
            .build().create(ErpApi::class.java)
    }
    fun service(): ErpApi = api
}
