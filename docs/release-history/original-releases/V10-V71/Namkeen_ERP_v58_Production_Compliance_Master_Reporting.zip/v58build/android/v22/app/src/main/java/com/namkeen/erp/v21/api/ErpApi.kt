package com.namkeen.erp.v22.api

import retrofit2.http.*

interface ErpApi {
    @POST("auth/login") suspend fun login(@Body body:LoginRequest):LoginResponse
    @POST("auth/refresh") suspend fun refresh(@Body body:RefreshRequest):LoginResponse
    @POST("v21/mobile/push") suspend fun push(@Body event:PushEvent):PushResult
    @GET("v21/mobile/pull") suspend fun pull(@Query("device_id") deviceId:String,@Query("cursor") cursor:Long,@Query("limit") limit:Int=200):PullResponse
    @POST("v17/customers") suspend fun createCustomer(@Body body:CustomerCreateRequest, @Header("Authorization") bearer:String):CustomerCreateResponse
    @POST("v17/customers/{customerId}/decision") suspend fun decideCustomer(@Path("customerId") customerId:Long,@Body body:DecisionRequest,@Header("Authorization") bearer:String):GenericResponse
    @POST("v17/collections/capture") suspend fun captureCollection(@Body body:CollectionRequest,@Header("Authorization") bearer:String):GenericResponse
    @POST("v17/collections/deposit") suspend fun submitDeposit(@Body body:DepositRequest,@Header("Authorization") bearer:String):GenericResponse
    @POST("v17/returns") suspend fun createReturn(@Body body:ReturnCreateRequest,@Header("Authorization") bearer:String):GenericResponse
    @POST("v17/returns/{returnId}/disposition") suspend fun disposeReturn(@Path("returnId") returnId:Long,@Body body:ReturnDispositionRequest,@Header("Authorization") bearer:String):GenericResponse
    @POST("orders") suspend fun createOrder(@Body body:OrderCreateRequest,@Header("Authorization") bearer:String):GenericResponse
}
