package com.namkeen.erp.v22.ui

import android.content.Context
import androidx.room.Room
import com.namkeen.erp.v22.db.ErpSyncDatabase
import com.namkeen.erp.v22.db.SyncOutbox
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.JsonObject
import java.util.UUID

class OfflineRepository(context: Context, private val deviceId: String) {
    private val db = Room.databaseBuilder(context, ErpSyncDatabase::class.java, "namkeen_erp_v22.db").fallbackToDestructiveMigration().build()
    private val dao = db.syncDao()
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun enqueue(eventType: String, entityType: String, entityId: String, payload: Map<String, String>, clientVersion: Int? = null) = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val payloadJson: JsonObject = buildJsonObject { payload.forEach { (k, v) -> put(k, v) } }
        dao.enqueue(SyncOutbox(id, deviceId, eventType, entityType, entityId, clientVersion, payloadJson.toString()))
    }
}
