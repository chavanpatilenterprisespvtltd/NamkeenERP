package com.namkeen.erp.v22.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities=[SyncOutbox::class, SyncMeta::class, SyncInbox::class, SyncConflict::class], version=22, exportSchema=true)
abstract class ErpSyncDatabase : RoomDatabase() { abstract fun syncDao(): SyncDao }
