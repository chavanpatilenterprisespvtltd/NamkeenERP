package com.namkeen.erp.v22.api

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement


@Serializable data class LoginRequest(val username:String,val password:String,val device_id:String,val device_name:String?=null,val platform:String="ANDROID",val app_version:String="22.0")
@Serializable data class LoginResponse(val access_token:String,val refresh_token:String,val session_id:String,val user_id:Long,val organization_id:Long,val role:String,val entity_ids:List<Long>)
@Serializable data class RefreshRequest(val session_id:String,val refresh_token:String)

@Serializable data class PushEvent(val device_id:String,val client_event_id:String,val event_type:String,val entity_type:String,val entity_id:String,val client_version:Int?=null,val payload:Map<String,JsonElement>)
@Serializable data class PushResult(val status:String,val client_event_id:String,val event_id:Long?=null,val server_version:Int?=null,val reason:String?=null)
@Serializable data class PullResponse(val device_id:String,val from_cursor:Long,val next_cursor:Long,val has_more:Boolean,val deltas:List<Delta>)
@Serializable data class Delta(val change_id:Long,val entity_type:String,val entity_id:String,val operation:String,val version:Int,val event_name:String,val payload:Map<String,JsonElement>,val occurred_at:String?)
@Serializable data class CustomerCreateRequest(val entity_id:Int,val code:String,val name:String,val mobile:String?=null,val address:String?=null,val gps_lat:Double?=null,val gps_lng:Double?=null,val shop_photo_file_id:String?=null,val aadhaar_file_id:String?=null,val pan_file_id:String?=null)
@Serializable data class CustomerCreateResponse(val id:Long,val status:String)
@Serializable data class DecisionRequest(val approve:Boolean,val reason:String?=null)
@Serializable data class OrderLineRequest(val sku_id:Long,val qty:Double,val negotiated_price:Double)
@Serializable data class OrderLineServerRequest(val sku_id:Long,val qty:Double,val negotiated_price:Double,val floor_price:Double,val company_cost:Double)
@Serializable data class OrderCreateRequest(val entity_id:Int,val customer_id:Long,val order_no:String,val payment_mode:String,val payment_state:String,val credit_state:String,val lines:List<OrderLineServerRequest>)
@Serializable data class GenericResponse(val id:Long?=null,val status:String,val message:String?=null)
@Serializable data class CollectionRequest(val payment_id:Long,val counterparty_photo_file_id:String,val lat:Double?=null,val lng:Double?=null)
@Serializable data class DepositRequest(val payment_id:Long,val mode:String,val deposit_ref:String?=null)
@Serializable data class ReturnLineRequest(val sku_id:Long,val qty:Double,val batch_no:String?=null)
@Serializable data class ReturnCreateRequest(val entity_id:Int,val customer_id:Long,val order_id:Long?=null,val return_no:String,val reason_code:String,val evidence_file_id:String?=null,val lines:List<ReturnLineRequest>)
@Serializable data class ReturnDispositionRequest(val disposition:String,val reason:String?=null)
