# Android v36 — Accounts & Tax Contract

Screens/contracts:
- Supplier ageing: CURRENT, 1-30, 31-60, 61-90, 91-120, 120+
- Invoice tax breakdown with CGST/SGST/IGST/UTGST/Cess as configured
- Debit/Credit note entry with reason and original invoice reference
- Payment reconciliation: matched / short / over / unmatched
- Tax transaction posting status and accounting export status
- Due-date alerts

Controls:
- Tax rates are effective-dated and configuration-driven; never hard-code a GST rate in the client.
- TDS/TCS are separate configurable deductions; they are not silently treated as GST.
- Accounting export is idempotent and audit-tracked.
- Mobile users may capture drafts/reconciliation evidence offline; final tax, posting and payment-reconciliation decisions are server-authoritative.
