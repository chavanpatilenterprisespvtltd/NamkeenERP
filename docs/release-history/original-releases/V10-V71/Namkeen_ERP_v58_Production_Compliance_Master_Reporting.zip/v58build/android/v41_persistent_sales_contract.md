# v41 Android contract — persistent sales posting

POST `/v41/sales/post`

The mobile client sends the same commercial inputs as v40 plus an `idempotency_key`.

The server commits, in one database transaction:
1. sales order + lines
2. payment record
3. FEFO reservation
4. inventory dispatch ledger
5. posted sales invoice + lines
6. customer receivable + receipt allocation
7. accounting outbox item
8. domain-change events

On any failure, the database transaction rolls back. A retry with the same idempotency key returns the committed result instead of applying the sale again.

Mobile must never treat a local success as authoritative until the server returns `COMMITTED`.
