# Android v27 — UOM / SKU / Barcode client contract

The mobile client should never assume `1 carton = N packs` globally. It loads the active SKU hierarchy from the server and caches it with an effective date.

Supported scan intents:
- RECEIVE_RM
- ISSUE_RM
- ISSUE_PACKAGING
- PRODUCTION_BATCH
- PACKING_RUN
- FG_MOVE
- SALES_ORDER
- DISPATCH
- RETURN
- STOCK_COUNT

Every scan stores barcode, barcode type, entity/SKU/lot resolution, device time, server time after sync, user/device and client_event_id.
