# v46 Android Contract

Outbound integrations are queued server-side; mobile never holds IRP/EWB secrets.

Screens/states:
- Invoice compliance status
- Generate IRN request
- IRN/ACK/QR display
- E-way bill generation/status
- Vehicle/transporter update
- Error/retry queue
- Government API reconciliation

Offline actions create intent records; server is authoritative for eligibility, posting, external calls and cancellation.
