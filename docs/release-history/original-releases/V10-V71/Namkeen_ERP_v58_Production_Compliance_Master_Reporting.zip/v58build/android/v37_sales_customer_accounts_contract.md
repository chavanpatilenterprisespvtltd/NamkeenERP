# v37 Android Contract — Sales & Customer Accounts

## Salesperson
- Customer selector and customer credit exposure
- Order/invoice preview with configurable GST/tax breakup
- Payment/receipt capture and proof reference
- Outstanding and customer ledger summary
- Return/credit-note initiation stays subject to approval/QC rules
- Incentive preview is read-only; policy is controlled by management

## Accounts / Manager
- Post/verify customer invoices
- Allocate receipts to invoices
- Customer ageing and overdue alerts
- Debit/credit note approval
- Customer ledger
- Credit-limit override with approval/audit

## Offline
Capture is allowed offline. Server remains authoritative for credit limits, invoice posting, payment verification, tax rules, accounting posting, and incentive policy.
