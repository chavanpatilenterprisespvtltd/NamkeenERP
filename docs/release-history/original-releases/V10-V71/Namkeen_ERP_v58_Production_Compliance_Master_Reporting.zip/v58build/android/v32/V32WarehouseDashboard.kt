package com.namkeen.erp.v32

// Production UI contract: server is authoritative; dashboard is read-only intelligence.
data class WarehouseSummary(val totalStockKg: String,val availableKg: String,val reservedKg: String,val expiredKg: String,val expiring7dKg: String,val expiring30dKg: String,val occupancyPct: String)
data class ReplenishmentAlert(val skuId: Long,val availableKg: String,val reorderLevelKg: String,val targetStockKg: String,val suggestedQtyKg: String,val severity: String)

interface WarehouseDashboardApi {
    suspend fun summary(entityId: Long, warehouseId: Long): WarehouseSummary
    suspend fun replenishment(entityId: Long, warehouseId: Long): List<ReplenishmentAlert>
    suspend fun fefo(entityId: Long, warehouseId: Long, skuId: Long): List<Map<String,String>>
    suspend fun pickingKpis(entityId: Long, warehouseId: Long): Map<String,String>
    suspend fun countKpis(entityId: Long, warehouseId: Long): Map<String,String>
}

// Screens to wire into the existing v23+ role navigation:
// Management: Warehouse Overview / Replenishment / Expiry
// Factory/Stores: Stock Availability / FEFO
// Warehouse: Picking / Bin Occupancy / Cycle Count
// Accounts/Management: inventory valuation can remain a future accounting adapter concern.
