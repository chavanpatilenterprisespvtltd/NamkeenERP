# v39 Android Contract — Pricing, Schemes & Incentives

## Salesperson
- Load effective SKU/customer price.
- Show target price, floor price, proposed negotiated price, discount and expected margin.
- Show applicable promotion/scheme.
- Keep GST separate from discount and incentive preview.
- Submit below-floor/max-discount exception for approval.
- Never edit management incentive policy.

## Manager / Management
- Approve/reject pricing exceptions.
- Create/effect-date customer pricing and promotions.
- Approve incentive policy versions.
- View expected incentive before final posting.

## Offline
Pricing master may be cached with effective dates and version numbers. A salesperson's offline quote/order may be captured, but the server re-validates price, customer rule, promotion, floor and approval state on synchronization. Stale pricing must not silently overwrite a newer policy.

## Incentive basis
Eligible kg/sales/margin are derived from posted transactions and adjusted for returns/cancellations. Verified collections may be a separate component. The device displays a preview; final calculation is server-side.
