# v55 Factory QC + Process Control — Android Contract

Screens:
- Batch QC checklist
- Product specification / limits
- Sampling entry
- Temperature / time / process parameter entry
- Oil TPC entry
- Water-test evidence
- Deviation capture
- CAPA creation and follow-up
- QC disposition / release / hold / rework / reject / scrap

Offline rules:
- Measurements/deviations may be captured offline.
- Server is authoritative for specification version, limits, disposition authority and release decisions.
- Every write carries client_event_id/device_id/user_id/captured_at/location/evidence refs.
- FAIL/HOLD and disposal/release decisions cannot silently overwrite server state.
