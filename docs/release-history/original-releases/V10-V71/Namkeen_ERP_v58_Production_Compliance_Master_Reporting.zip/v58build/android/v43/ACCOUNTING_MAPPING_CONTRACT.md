# v43 Android Accounts Contract

The Accounts mobile workflow consumes the same server-side accounting mapping as web.

## Screens
- Ledger & Voucher Mapping
- Voucher Preview
- Tally Posting Status
- Reconciliation Exceptions
- Mismatch Drill-down

## Rules
- Mapping is effective-dated and organization/entity scoped.
- Voucher types are configurable; no hard-coded Tally voucher name is required.
- Tax ledger mapping supports CGST, SGST, IGST and Cess.
- Customer/supplier party ledger can be mapped centrally or supplied by resolved master data.
- Reconciliation is informational/control state; it must not silently change the source transaction.
