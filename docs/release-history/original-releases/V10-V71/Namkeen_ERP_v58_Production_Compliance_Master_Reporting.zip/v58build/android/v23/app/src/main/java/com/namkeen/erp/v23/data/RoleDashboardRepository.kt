package com.namkeen.erp.v23.data

import com.namkeen.erp.v23.api.DashboardResponse
import com.namkeen.erp.v23.api.ErpApi
import com.namkeen.erp.v23.api.MeResponse

class RoleDashboardRepository(private val api: ErpApi, private val bearer: () -> String) {
    suspend fun loadMe(): MeResponse = api.me(bearer())
    suspend fun loadDashboard(): DashboardResponse = api.dashboard(bearer())
}
