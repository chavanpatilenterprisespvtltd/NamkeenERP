package com.namkeen.erp.v23

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.namkeen.erp.v23.api.*
import com.namkeen.erp.v23.data.RoleDashboardRepository
import com.namkeen.erp.v23.ui.RoleDashboardViewModel
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val api = Retrofit.Builder().baseUrl("http://10.0.2.2:8000/").client(OkHttpClient()).addConverterFactory(Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType())).build().create(ErpApi::class.java)
        val repo = RoleDashboardRepository(api) { "Bearer ${getSharedPreferences("auth", MODE_PRIVATE).getString("access_token", "")}" }
        val vm = RoleDashboardViewModel(repo)
        setContent { MaterialTheme { RoleDashboardScreen(vm) } }
        vm.refresh()
    }
}

@Composable
fun RoleDashboardScreen(vm: RoleDashboardViewModel) {
    val state by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (state.role.isBlank()) "ERP Dashboard" else "ERP — ${state.role}", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(state.cards) { card ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(card.label, style = MaterialTheme.typography.titleMedium)
                        Text(card.value, style = MaterialTheme.typography.headlineMedium)
                        if (card.action != null) Text("Open: ${card.action}")
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.refresh() }) { Text("Refresh") }
    }
}
