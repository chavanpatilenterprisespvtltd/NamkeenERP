package com.namkeen.erp.v23.api

import retrofit2.http.GET
import retrofit2.http.Header

interface ErpApi {
    @GET("v23/me") suspend fun me(@Header("Authorization") bearer: String): MeResponse
    @GET("v23/dashboard") suspend fun dashboard(@Header("Authorization") bearer: String): DashboardResponse
}
