package com.namkeen.erp.v23.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.namkeen.erp.v23.api.DashboardCard
import com.namkeen.erp.v23.data.RoleDashboardRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class RoleDashboardState(val loading: Boolean = false, val role: String = "", val cards: List<DashboardCard> = emptyList(), val error: String? = null)

class RoleDashboardViewModel(private val repo: RoleDashboardRepository) : ViewModel() {
    private val _state = MutableStateFlow(RoleDashboardState())
    val state: StateFlow<RoleDashboardState> = _state

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val me = repo.loadMe()
                val dash = repo.loadDashboard()
                _state.value = RoleDashboardState(false, me.role, dash.cards)
            } catch (t: Throwable) {
                _state.value = _state.value.copy(loading = false, error = t.message ?: "Unable to load dashboard")
            }
        }
    }
}
