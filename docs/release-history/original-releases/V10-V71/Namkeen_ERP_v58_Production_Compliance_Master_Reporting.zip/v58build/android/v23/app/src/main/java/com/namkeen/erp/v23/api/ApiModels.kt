package com.namkeen.erp.v23.api

data class MeResponse(val user_id: Long, val organization_id: Long, val role: String, val entity_ids: List<Long>, val dashboard: String, val offline_capabilities: List<String>)
data class DashboardCard(val key: String, val label: String, val value: String, val severity: String = "NORMAL", val action: String? = null)
data class DashboardResponse(val role: String, val metrics: Map<String, String> = emptyMap(), val cards: List<DashboardCard>, val server_authoritative: Boolean = true)
