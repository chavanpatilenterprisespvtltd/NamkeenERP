package com.namkeen.erp.v26

/** Reference Compose-facing state/actions for the production-to-packing workflow. */
data class ProductionPackingState(
    val batchNo: String,
    val materialIssuesKg: String = "0",
    val wipAvailableKg: String = "0",
    val packingNo: String = "",
    val plannedKg: String = "0",
    val goodKg: String = "0",
    val rejectKg: String = "0",
    val goodPackQty: String = "0",
    val syncStatus: String = "ONLINE"
)

sealed interface ProductionPackingAction {
    data class IssueMaterial(val lotId: Long, val qtyKg: String): ProductionPackingAction
    data class CreateWip(val qtyKg: String, val wipBatchNo: String): ProductionPackingAction
    data class StartPacking(val skuId: Long, val plannedKg: String, val packingNo: String): ProductionPackingAction
    data class IssuePackaging(val lotId: Long, val qtyBase: String): ProductionPackingAction
    data class CompletePacking(val goodKg: String, val packQty: String, val rejectKg: String): ProductionPackingAction
    data class RecordWastage(val qtyKg: String, val reason: String): ProductionPackingAction
}
