# v54 Android Production Floor Contract

Offline-capable factory workflow for:

- shift/operator entry
- stage start/complete
- machine/process parameters
- downtime capture
- oil/fuel consumption
- production QC checkpoints
- wastage with authorization/evidence
- good/reject/WIP output
- handoff to v26 WIP/packing and v50 costing

Client writes use the existing `client_event_id` + device/session model. Server remains authoritative for inventory, costing, QC disposition, wastage posting and production completion.
