# v45 Android — GST Compliance Contract

Role-scoped screens:

- Tax Master: effective-dated tax rates, Cess, RCM applicability, product HSN mapping.
- Invoice Tax Review: HSN, GSTIN, place of supply, supply type, RCM and tax breakup.
- GST Period: open/lock/filed status and period evidence.
- Return Summary: GSTR-1-oriented outward supply summary and GSTR-3B-oriented tax summary.
- Reconciliation: ERP vs external/GST data, differences, resolution reason and approver.
- Export Queue: immutable JSON/CSV payload snapshot for CA/GST workflow; final filing remains external/authorised.

Server is authoritative. Mobile cannot change tax rates, return period status or reconciliation outcomes without the required role/approval.
