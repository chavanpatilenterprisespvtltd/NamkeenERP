# v51 Android Production Planning Contract

Endpoints:
- `POST /v51/production-planning/requirements/calculate`
- `POST /v51/production-planning/consumption/variance`

Mobile workflow:
1. Select SKU and effective BOM/recipe version.
2. Enter planned good output.
3. Display expected input and RM/packaging requirements.
4. Allow offline capture of observations, but server decides active/effective BOM.
5. Record actual issue/consumption by lot and compare against planned issue.
6. Show material variance; configured exceptions require supervisor/management approval before posting.
7. Record by-products/recovery separately from saleable FG.

The mobile client must not create or edit an already-used BOM version; new versions are created with effective dates and audit history.
