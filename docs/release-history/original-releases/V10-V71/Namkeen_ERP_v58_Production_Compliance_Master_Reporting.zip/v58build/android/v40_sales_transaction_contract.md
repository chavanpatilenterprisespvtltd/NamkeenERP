# Android v40 — Sales Transaction Contract

## Mobile flow
Customer → SKU/Pack → negotiated price → pricing/floor check → credit check → payment capture → order submission → stock availability → FEFO/LPN reservation → dispatch → invoice/receipt → incentive basis.

## Server authority
The mobile client may capture data offline, but the server authoritatively decides:
- pricing/floor exceptions
- credit state and overrides
- payment verification/cheque clearance
- FEFO reservation
- inventory dispatch
- invoice posting
- customer receivable
- incentive eligibility/calculation
- accounting integration posting

## Offline behavior
Store the draft/order/payment evidence with `client_event_id` and idempotency key. Synchronization must replay through the transaction API; it must not directly mutate invoice, stock or accounting records.

## Required evidence
Cash payment requires counterparty photo evidence before verified status. Cheque clearance requires cheque reference. Failed/bounced payments retain a reason.
