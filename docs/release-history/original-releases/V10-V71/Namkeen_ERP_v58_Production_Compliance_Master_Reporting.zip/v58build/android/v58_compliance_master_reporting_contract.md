# v58 Android Contract — Compliance Master + Inspection Reporting

Offline-capable screens:
- Compliance controls
- Source references
- Site document register
- Document camera/upload evidence
- Expiry alert list
- Inspection checklist
- Finding capture
- Evidence-pack preparation
- Statutory-register export request
- Compliance management score

Security rules:
- Never embed Aadhaar/PAN/private evidence bytes in logs.
- Offline devices store references/queue metadata; server controls final master-data activation and statutory interpretation.
- Every write uses client_event_id/device_id/user_id/timestamps.
