# v52 Android Contract

Screens: MRP Plan -> Material Shortfall -> Production Requirement -> Approval -> Production Order -> Release -> Start -> Complete.

Rules: mobile may create/submit and display plans; server remains authoritative for stock, BOM version, approvals, reservations, material issue, batch creation and actual production posting. Offline events use client_event_id and reconcile through the existing sync pipeline.
