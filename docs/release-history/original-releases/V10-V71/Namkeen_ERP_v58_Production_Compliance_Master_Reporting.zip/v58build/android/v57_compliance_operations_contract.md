# v57 Android Compliance Operations Contract

## Screens
- Compliance Dashboard
- Today / Overdue Tasks
- Requirement Detail
- Evidence Capture (photo/document/lab result)
- Inspection Finding
- CAPA status
- Oil TPC Check
- Water Test
- Calibration
- Pest Control
- Cleaning & Sanitation
- Hygiene Training / Medical Fitness
- Product Test / Retention Sample
- Complaint / Recall linkage
- Inspection & Authority Correspondence

## Offline rules
Evidence can be captured offline with `client_event_id`, SHA-256 and local timestamp.
Task verification, legal disposition, CAPA closure and inspection-ready status remain server-authoritative.

## Evidence
Sensitive documents use private storage references; the Android client never stores government/API credentials.
