# Android v35 P2P Contract

Screens:
1. Supplier Invoice Inbox
2. Invoice Capture + document/photo attachment
3. PO/GRN selector
4. 3-Way Match result
5. Exception review + reason + approval
6. Payable ageing/outstanding
7. Payment schedule/capture
8. Supplier payment history

Offline rule: invoices/documents can be captured offline, but final 3-way match, exception approval, payable creation and payment posting remain server-authoritative. Document uploads use the existing v21 queue/idempotency mechanism.
