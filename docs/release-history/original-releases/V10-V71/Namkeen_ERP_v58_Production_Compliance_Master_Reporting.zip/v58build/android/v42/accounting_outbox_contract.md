# v42 Android Accounts contract

Screens:
- Accounting Integration Dashboard
- Pending Queue
- Failed / Retry Queue
- Dead Letter Queue
- Integration Detail
- Manual Retry
- Reconciliation

The mobile client never edits accounting payloads directly. It requests retry/requeue through the server, which preserves the original idempotency key and audit trail.
