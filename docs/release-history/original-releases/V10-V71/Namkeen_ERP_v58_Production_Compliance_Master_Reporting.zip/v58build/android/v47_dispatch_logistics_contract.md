# Android v47 — Dispatch Logistics Contract

Screens/workflows: Transporter Master, Vehicle Master, Trip Planning, Load/Carton Scan, E-Way Bill status, Depart Trip, Delivery Queue, POD Capture, Short/Failed Delivery, Return-to-warehouse initiation, Freight summary.

Offline-capable operations: scan load, capture delivery/POD evidence, record GPS/time, queue event with `client_event_id`. Server remains authoritative for invoice status, EWB state, LPN ownership, stock, customer credit and accounting.

POD evidence may include camera photo, signature reference, OTP verification result and GPS coordinates. The actual binary image is stored through the existing private document-storage abstraction; v47 stores only the document reference/hash in the transaction/event layer.

Transport controls: vehicle number normalization/validation, transporter-to-vehicle relation, trip state machine, load-before-departure, EWB reference capture, no duplicate LPN on one trip, delivery quantity cannot exceed ordered quantity, and incomplete deliveries prevent trip close.
