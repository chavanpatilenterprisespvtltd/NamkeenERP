package com.namkeen.erp.v34

/** Reference contract for Android supplier and purchase-order screens. */
sealed interface PurchaseOrderStatus {
    data object Draft : PurchaseOrderStatus
    data object PendingApproval : PurchaseOrderStatus
    data object Approved : PurchaseOrderStatus
    data object PartiallyReceived : PurchaseOrderStatus
    data object FullyReceived : PurchaseOrderStatus
    data object Cancelled : PurchaseOrderStatus
    data object Closed : PurchaseOrderStatus
}

data class SupplierSummary(
    val supplierId: Long,
    val legalName: String,
    val displayName: String,
    val gstin: String?,
    val paymentTermsDays: Int,
    val status: String
)

data class PurchaseOrderLineUi(
    val lineId: Long,
    val skuId: Long,
    val orderedQtyKg: String,
    val unitPricePerKg: String,
    val expectedUnitPricePerKg: String?,
    val openQtyKg: String
)

data class PurchaseOrderUi(
    val poId: Long,
    val supplier: SupplierSummary,
    val warehouseId: Long,
    val status: PurchaseOrderStatus,
    val approvalRequired: Boolean,
    val lines: List<PurchaseOrderLineUi>
)

/** UI actions should call server APIs; the device must not directly post inventory. */
object PurchaseOrderActions {
    const val CREATE = "CREATE"
    const val SUBMIT_FOR_APPROVAL = "SUBMIT_FOR_APPROVAL"
    const val APPROVE = "APPROVE"
    const val REJECT = "REJECT"
    const val RECORD_GRN = "RECORD_GRN"
}
