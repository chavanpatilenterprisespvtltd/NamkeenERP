# v49 Android Contract — Sales Return & Reverse Logistics

## Salesperson / Delivery
- Create return request against customer + invoice.
- Select invoice line/SKU and quantity.
- Capture reason and photos.
- Scan LPN/carton and lot where available.
- Offline queue uses `client_event_id`.
- GPS/evidence references may be captured with the return event.

## Manager / Accounts
- Approve or reject return request.
- Schedule reverse pickup.
- Review exception evidence.
- Approve credit-note path where required.

## Warehouse / QC
- Scan incoming returned LPN/carton.
- Receive into **QC HOLD**, never directly into saleable stock.
- Record disposition: Saleable / Repack / Rework / Damage / Expired / Dispose.
- Evidence/reason required for rejected/damage/expiry/disposal outcomes.

## Posting boundary
The mobile client never directly increases saleable inventory or customer credit. Final posting must use the server transaction service and emit inventory, receivable, accounting and domain-change records atomically.
