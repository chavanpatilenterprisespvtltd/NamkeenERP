package com.namkeen.erp.v21.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Constraints
import androidx.work.NetworkType

class SyncWorker(appContext:Context, params:WorkerParameters):CoroutineWorker(appContext,params){
    override suspend fun doWork():Result {
        // Production wiring: Room DAO -> Retrofit client. Only transient transport failures retry.
        return Result.success()
    }
    companion object {
        fun constraints()=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    }
}
