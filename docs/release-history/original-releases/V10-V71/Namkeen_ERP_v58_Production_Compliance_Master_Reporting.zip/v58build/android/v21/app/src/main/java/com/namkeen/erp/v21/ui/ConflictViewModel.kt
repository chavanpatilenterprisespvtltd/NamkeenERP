package com.namkeen.erp.v21.ui

data class ConflictRow(val id:Long,val entityType:String,val entityId:String,val clientVersion:Int?,val serverVersion:Int?)
sealed interface ConflictAction { data object AcceptServer:ConflictAction; data object Discard:ConflictAction; data class ReviewClient(val note:String?):ConflictAction }
