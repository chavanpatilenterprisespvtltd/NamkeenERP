package com.namkeen.erp.v21.api

import kotlinx.serialization.Serializable

@Serializable data class PushEvent(val device_id:String,val client_event_id:String,val event_type:String,val entity_type:String,val entity_id:String,val client_version:Int?=null,val payload:Map<String,String>)
@Serializable data class PushResult(val status:String,val client_event_id:String,val event_id:Long?=null,val server_version:Int?=null)
@Serializable data class PullResponse(val device_id:String,val from_cursor:Long,val next_cursor:Long,val has_more:Boolean,val deltas:List<Delta>)
@Serializable data class Delta(val change_id:Long,val entity_type:String,val entity_id:String,val operation:String,val version:Int,val event_name:String,val payload:Map<String,String>,val occurred_at:String?)
