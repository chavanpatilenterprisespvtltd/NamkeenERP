package com.namkeen.erp.v21.api

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ErpApi {
    @POST("v21/mobile/push") suspend fun push(@Body event:PushEvent):PushResult
    @GET("v21/mobile/pull") suspend fun pull(@Query("device_id") deviceId:String,@Query("cursor") cursor:Long,@Query("limit") limit:Int=200):PullResponse
}
