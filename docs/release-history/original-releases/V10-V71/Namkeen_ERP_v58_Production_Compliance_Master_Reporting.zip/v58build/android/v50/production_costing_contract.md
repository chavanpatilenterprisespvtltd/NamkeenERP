# v50 Android Production Costing Contract

## Factory
- Open production batch
- Enter/scan RM lot issues
- Enter oil/fuel/packaging usage
- Capture labour/power/utility allocation
- Capture good/reject/rework quantity
- Review live estimated cost/kg
- Submit batch cost for review

## Manager / Management
- Review actual vs standard cost
- Review yield and wastage
- Review component variances
- Approve cost finalization
- Compare batch profitability by SKU

## Controls
- Android is a capture/review client only.
- Actual cost and standard cost are server authoritative.
- Lot references should be retained for RM/oil/fuel inputs where applicable.
- Cost finalization must be idempotent for offline retries.
- GST is excluded from production cost unless explicitly configured as non-recoverable cost.
