# v56 Android contract — QC to Production/Inventory/Compliance

The factory app may capture QC measurements and evidence while offline. The server remains authoritative for the release gate and disposition.

## Workflow
1. Open production batch.
2. Capture required QC measurements/evidence.
3. Sync measurements.
4. Server evaluates effective specification/sampling rules.
5. If PASS + good output exists, batch may be released/completed.
6. FAIL/HOLD creates controlled REWORK/QUARANTINE/HOLD outcome.
7. Rework/reject quantities become inventory-action intents for the authoritative posting service.
8. A compliance trace link is created for the batch/process-control requirement.

The app must never directly increase saleable stock, close a production batch, or create an accounting posting merely because an offline device says PASS.
