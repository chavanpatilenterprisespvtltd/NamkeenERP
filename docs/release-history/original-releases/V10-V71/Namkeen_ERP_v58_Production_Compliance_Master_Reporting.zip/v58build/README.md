# Namkeen ERP v58 — Compliance Master Data + Inspection-Ready Reporting

v58 builds on v57 by making compliance requirements/source references versioned master data and adding document-register, inspection-checklist and register-export support.

## Added
- compliance source reference master with official-domain validation
- effective-dated compliance control master
- requirement classification: Mandatory / Condition-dependent / Inspection-supporting / Internal recommended
- site document register with expiry/perpetual-validity handling
- inspection checklist generation from active controls
- deterministic inspection/statutory register export support
- management compliance score
- PostgreSQL migration `047_v58_compliance_master_reporting.sql`
- v58 Android contract
- seed template using current official FSSAI 2026 source references

## Important boundary
Legal requirements remain data/configuration, not hard-coded assumptions. Activation requires responsible compliance review. Inspection readiness and management score are operational indicators, not legal certification.

## Validation
Run `pytest` from this directory. v58 adds focused tests and retains the inherited suite.
