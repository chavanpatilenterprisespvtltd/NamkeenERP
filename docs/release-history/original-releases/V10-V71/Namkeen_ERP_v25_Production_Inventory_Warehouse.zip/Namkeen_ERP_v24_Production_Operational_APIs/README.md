# Namkeen ERP v25 — Production Inventory & Warehouse Layer

v25 extends v24 with the controlled inventory/warehouse transaction layer for RM, packaging, WIP and FG.

Included:
- warehouse master and configurable warehouse types
- supplier master
- GRN/receipt receiving and supplier-lot capture
- incoming QC: PASS / FAIL / HOLD with COA/evidence reference
- explicit posting of accepted receipt quantities into inventory lots
- stock movement ledger for receipt, transfer and adjustment
- stock transfers with management/warehouse-manager approval
- stock adjustments with approval and negative-stock protection
- barcode/QR event capture
- source/target traceability links
- expiry-ordered inventory view to support FEFO
- PostgreSQL migration `014_v25_inventory_warehouse.sql`
- Android v25 inventory/warehouse screen shell

Important: the server remains authoritative. Barcode scans are event evidence; they do not bypass inventory posting. Production, packing, dispatch, recall and compliance traceability still need to consume this layer in later integration stages.

Validation in this build: Python compile check and 2/2 targeted v25 inventory service tests pass using SQLite test configuration. A live PostgreSQL instance was not available in the build environment, so PostgreSQL execution/UAT remains pending.
