# Namkeen ERP v24 — Production Operational APIs

v24 connects role dashboards to real server-side operational workflows using PostgreSQL-ready SQLAlchemy services.

Included:
- production batch planning and quantity recording
- QC inspection API for production batch / sales return
- below-floor price exception request + management decision
- sales-order approval and payment/cheque verification APIs
- FEFO stock reservation and persistent dispatch API
- entity-scoped authenticated FastAPI routes
- PostgreSQL migration `013_v24_operational_apis.sql`
- Android v24 operational screen shell
- full inherited test suite + v24 tests

The server remains authoritative for inventory, payment, QC, approvals, GST/accounting and dispatch. v24 does not claim live deployment or legal/regulatory certification.
