# Namkeen ERP v44 — Accounting Master Synchronization & Tally Reconciliation Dashboard

v44 extends v43 with controlled accounting master synchronization and Accounts reconciliation workflow.

Included:
- Customer and supplier → accounting ledger mapping
- Entity/organization-scoped party ledger links
- Idempotent ledger master sync queue
- External ledger name/reference capture
- Accounts reconciliation dashboard counters
- Reconciliation action requests and approval
- Self-approval prevention
- ACCEPT_EXTERNAL / REQUEUE / CORRECT_MAPPING / REJECT actions
- Reconciliation actions do not overwrite source ERP transactions
- PostgreSQL migration `033_v44_accounting_master_sync.sql`
- Android Accounts reconciliation contract
- v44 API layer

Boundary:
- ERP customer/supplier masters remain authoritative.
- Tally ledger creation/update remains an adapter/worker responsibility.
- Live TallyPrime company-specific configuration requires deployment/UAT.
