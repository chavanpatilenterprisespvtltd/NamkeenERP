# Namkeen ERP v30 — Production Warehouse Locations, Put-away, Picking & Pallet Hierarchy

Builds on v29 LPN/carton tracking and adds a physical warehouse address model.

## Added
- Warehouse location hierarchy: zone / aisle / rack / shelf / bin
- Location path resolution and cycle protection
- Put-away permissions and configurable capacity
- SKU/product/quantity-aware put-away rules
- Deterministic picking route and pick tasks
- LPN location attachment and movement
- Pallet/container → carton/child LPN hierarchy
- Parent/child cycle prevention
- PostgreSQL migration 019
- Android workflow contract for location scans, put-away, picking and cycle count
- API reference under `/v30/warehouse`

## Control boundary
Location and LPN state is the physical warehouse view. Inventory ledger remains authoritative; location moves must ultimately be posted through inventory transaction services and cannot bypass QC, stock, approval or accounting controls.
