# Namkeen ERP v14 — Production Security, Sync & Integration Foundation

v14 builds on v13 with production-facing foundations:
- JWT access/refresh token pattern with password hashing using stdlib-compatible PBKDF2.
- Device registration and session model with revocation and refresh-token rotation concepts.
- Organization/entity-scoped authorization helpers (RBAC + entity access).
- Secure document storage abstraction with local filesystem and signed-download-token pattern; designed for S3-compatible object storage.
- Offline sync ingestion with idempotency, optimistic version checks, explicit CONFLICT state, and no silent overwrite.
- Notification outbox + worker abstraction for role/user notifications.
- Tally accounting adapter interface with export/preview implementation point.
- Operational health/readiness probes and structured request correlation IDs.
- Migration 004 for sessions/devices/documents/notification outbox plus sync version fields.
- Security and deployment runbook.

This is a production foundation, not a live deployment. PostgreSQL, Redis/object storage, SMTP/WhatsApp/SMS/UPI/bank and Tally endpoints still require environment-specific configuration and UAT.
