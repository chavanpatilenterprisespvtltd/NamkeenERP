# Namkeen ERP v55 — Factory QC + Process Control

v55 integrates production-floor execution with a configurable quality-control and process-control layer.

## Scope

- versioned product/process specifications
- parameter limits, target values, units and severity
- sampling plans and sample-count enforcement
- production-batch QC inspections
- measured process parameters with evidence refs
- FAIL/HOLD/release/rework/reject/scrap dispositions
- mandatory reasons for non-release outcomes
- oil TPC check support
- water-test record support
- process deviations and CAPA linkage
- CAPA owner/due-date/root-cause/corrective/preventive action lifecycle
- QC result aggregation for production completion gating
- PostgreSQL migration `044_v55_factory_qc_process_control.sql`
- Android offline QC/process-control contract

## Key controls

- Specification limits are versioned and effective-dated; historical inspection records keep their specification reference.
- QC FAIL/HOLD cannot be released as saleable without a PASS result.
- Non-release dispositions require a reason.
- Critical/Major failures can automatically require CAPA.
- Offline measurements are allowed, but server-side specification, disposition authority and final release remain authoritative.
- QC does not directly mutate inventory/accounting; approved outcomes feed the existing transaction/posting services.

## Validation

v55-specific tests cover specification evaluation, sampling completeness, QC pass/fail, release controls, TPC, aggregation, HOLD and CAPA closure. Live PostgreSQL and factory-device UAT remain deployment activities.
