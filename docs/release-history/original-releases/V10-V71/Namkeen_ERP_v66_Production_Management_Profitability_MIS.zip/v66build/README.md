# Namkeen ERP v66 — Management Profitability & MIS

## Scope
Combine sales, COGS, returns, discounts, collections, production variance, inventory ageing, customer/SKU/salesperson performance and incentive basis into a management reporting layer.

## Flow
**Posted Transactions → Read Models/Aggregations → KPI Validation → Management Dashboard → Drill-down**

## Included
- Management KPI aggregation
- Net sales after returns
- COGS after returned-COGS reversal
- Gross margin and gross-margin percentage
- Discount visibility
- Collection allocation and outstanding estimate
- SKU profitability
- Customer profitability
- Salesperson performance
- Incentive basis: eligible kg, net sales, gross margin, collection
- Production standard-vs-actual variance
- Inventory ageing and expiry-risk summary
- PostgreSQL read-side migration `055_v66_management_mis.sql`
- Android management MIS contract

## Control boundaries
- Reporting is read-side only; source transactions remain authoritative.
- Incentive basis is not incentive payment calculation; policy engine remains management-controlled.
- GST/tax is excluded from gross-margin revenue by default.
- Historical transaction values are not rewritten by dashboard refreshes.
