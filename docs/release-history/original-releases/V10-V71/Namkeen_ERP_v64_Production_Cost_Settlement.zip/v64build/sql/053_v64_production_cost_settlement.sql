-- v64: authoritative production cost settlement and SKU roll-up
CREATE TABLE IF NOT EXISTS production_cost_settlement (
  settlement_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  site_id UUID NOT NULL,
  batch_id UUID NOT NULL,
  output_good_kg NUMERIC(18,6) NOT NULL CHECK (output_good_kg > 0),
  reject_kg NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (reject_kg >= 0),
  rework_kg NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (rework_kg >= 0),
  total_actual_cost NUMERIC(18,6) NOT NULL CHECK (total_actual_cost >= 0),
  actual_cost_per_good_kg NUMERIC(18,6) NOT NULL CHECK (actual_cost_per_good_kg >= 0),
  standard_cost NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (standard_cost >= 0),
  variance_amount NUMERIC(18,6) NOT NULL DEFAULT 0,
  variance_pct NUMERIC(18,6) NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, batch_id)
);

CREATE TABLE IF NOT EXISTS production_cost_component (
  component_id UUID PRIMARY KEY,
  settlement_id UUID NOT NULL REFERENCES production_cost_settlement(settlement_id),
  category TEXT NOT NULL,
  quantity NUMERIC(18,6) NOT NULL CHECK (quantity >= 0),
  unit_cost NUMERIC(18,6) NOT NULL CHECK (unit_cost >= 0),
  cost_amount NUMERIC(18,6) NOT NULL CHECK (cost_amount >= 0),
  source_type TEXT NOT NULL,
  source_id UUID NOT NULL
);

CREATE TABLE IF NOT EXISTS production_sku_cost_allocation (
  allocation_id UUID PRIMARY KEY,
  settlement_id UUID NOT NULL REFERENCES production_cost_settlement(settlement_id),
  sku_id UUID NOT NULL,
  output_kg NUMERIC(18,6) NOT NULL CHECK (output_kg > 0),
  allocated_cost NUMERIC(18,6) NOT NULL CHECK (allocated_cost >= 0),
  cost_per_kg NUMERIC(18,6) NOT NULL CHECK (cost_per_kg >= 0),
  UNIQUE (settlement_id, sku_id)
);

CREATE INDEX IF NOT EXISTS ix_prod_cost_batch ON production_cost_settlement(organization_id, batch_id);
CREATE INDEX IF NOT EXISTS ix_prod_cost_status ON production_cost_settlement(organization_id, status);
CREATE INDEX IF NOT EXISTS ix_prod_sku_cost_sku ON production_sku_cost_allocation(sku_id);
