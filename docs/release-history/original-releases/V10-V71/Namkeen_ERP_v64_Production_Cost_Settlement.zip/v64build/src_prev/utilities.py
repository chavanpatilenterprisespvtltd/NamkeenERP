from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

class OilStatus(str, Enum):
    RECEIVED='RECEIVED'; IN_USE='IN_USE'; FILTERED='FILTERED'; QUARANTINED='QUARANTINED'; DISPOSED='DISPOSED'

class UtilityType(str, Enum):
    ELECTRICITY='ELECTRICITY'; DIESEL='DIESEL'; WOOD='WOOD'; LPG='LPG'; NATURAL_GAS='NATURAL_GAS'; WATER='WATER'; NITROGEN='NITROGEN'; OTHER='OTHER'

class AllocationMethod(str, Enum):
    DIRECT='DIRECT'; RUNTIME='RUNTIME'; OUTPUT_KG='OUTPUT_KG'; METER_DELTA='METER_DELTA'; MANUAL_APPROVED='MANUAL_APPROVED'

@dataclass
class FuelReceipt:
    receipt_id: str
    fuel_type: str
    qty: float
    uom: str
    unit_cost: float
    supplier_id: Optional[str]=None
    lot_no: Optional[str]=None
    received_at: datetime=field(default_factory=datetime.utcnow)

@dataclass
class FuelConsumption:
    consumption_id: str
    fuel_type: str
    qty: float
    uom: str
    source_type: str
    source_id: str
    issued_lot_no: Optional[str]=None
    unit_cost: float=0.0

@dataclass
class OilLot:
    oil_lot_id: str
    oil_type: str
    opening_qty_kg: float
    current_qty_kg: float
    status: OilStatus=OilStatus.RECEIVED
    supplier_lot_no: Optional[str]=None
    tpc_pct: Optional[float]=None
    last_tpc_at: Optional[datetime]=None
    filter_cycle_count: int=0

@dataclass
class OilEvent:
    event_id: str
    oil_lot_id: str
    event_type: str
    qty_kg: float=0.0
    tpc_pct: Optional[float]=None
    source_id: Optional[str]=None
    note: Optional[str]=None
    created_at: datetime=field(default_factory=datetime.utcnow)

@dataclass
class FurnaceRun:
    run_id: str
    asset_id: str
    started_at: datetime
    ended_at: Optional[datetime]=None
    fuel_qty: float=0.0
    fuel_uom: str='kg'
    fuel_cost: float=0.0
    batch_id: Optional[str]=None

@dataclass
class UtilityMeter:
    meter_id: str
    utility_type: UtilityType
    site_id: str
    opening_reading: float=0.0
    closing_reading: Optional[float]=None
    uom: str='unit'

@dataclass
class UtilityConsumption:
    utility_type: UtilityType
    qty: float
    unit_cost: float
    source_type: str
    source_id: str
    allocation_method: AllocationMethod
    cost: float

@dataclass
class UtilityPolicy:
    oil_tpc_limit_pct: Optional[float]=None
    max_meter_delta: float=10_000_000.0
    require_tpc_before_continuing_fry: bool=False
    require_utility_cost_approval_above: Optional[float]=None


def record_oil_usage(oil: OilLot, qty_kg: float, batch_id: str) -> OilEvent:
    if qty_kg <= 0:
        raise ValueError('INVALID_OIL_USAGE')
    if qty_kg > oil.current_qty_kg:
        raise ValueError('OIL_STOCK_SHORTFALL')
    oil.current_qty_kg -= qty_kg
    oil.status = OilStatus.IN_USE
    return OilEvent(f'OILUSE-{oil.oil_lot_id}-{batch_id}', oil.oil_lot_id, 'USED', qty_kg, oil.tpc_pct, batch_id)


def record_filter(oil: OilLot, recovered_qty_kg: float) -> OilEvent:
    if recovered_qty_kg < 0 or recovered_qty_kg > oil.current_qty_kg:
        raise ValueError('INVALID_FILTER_RECOVERY')
    oil.current_qty_kg = recovered_qty_kg
    oil.filter_cycle_count += 1
    oil.status = OilStatus.FILTERED
    return OilEvent(f'FILTER-{oil.oil_lot_id}-{oil.filter_cycle_count}', oil.oil_lot_id, 'FILTERED', recovered_qty_kg)


def record_tpc(oil: OilLot, tpc_pct: float, checked_at: datetime|None=None) -> OilEvent:
    if tpc_pct < 0 or tpc_pct > 100:
        raise ValueError('INVALID_TPC')
    oil.tpc_pct = tpc_pct
    oil.last_tpc_at = checked_at or datetime.utcnow()
    oil.status = OilStatus.IN_USE if oil.current_qty_kg > 0 else oil.status
    return OilEvent(f'TPC-{oil.oil_lot_id}-{int(oil.last_tpc_at.timestamp())}', oil.oil_lot_id, 'TPC_CHECK', 0, tpc_pct)


def validate_frying_use(oil: OilLot, policy: UtilityPolicy) -> list[str]:
    errors=[]
    if oil.status in {OilStatus.QUARANTINED, OilStatus.DISPOSED}:
        errors.append('OIL_NOT_USABLE')
    if policy.require_tpc_before_continuing_fry and oil.tpc_pct is None:
        errors.append('TPC_CHECK_REQUIRED')
    if policy.oil_tpc_limit_pct is not None and oil.tpc_pct is not None and oil.tpc_pct >= policy.oil_tpc_limit_pct:
        errors.append('TPC_LIMIT_EXCEEDED')
    return errors


def meter_delta(meter: UtilityMeter) -> float:
    if meter.closing_reading is None:
        raise ValueError('MISSING_CLOSING_READING')
    delta = meter.closing_reading - meter.opening_reading
    if delta < 0:
        raise ValueError('METER_ROLLOVER_OR_BAD_READING')
    return delta


def allocate_utility_cost(utility_type: UtilityType, qty: float, unit_cost: float, source_type: str, source_id: str, method: AllocationMethod) -> UtilityConsumption:
    if qty < 0 or unit_cost < 0:
        raise ValueError('INVALID_UTILITY_INPUT')
    return UtilityConsumption(utility_type, qty, unit_cost, source_type, source_id, method, round(qty*unit_cost, 2))


def allocate_by_runtime(total_qty: float, batch_runtime_minutes: float, total_runtime_minutes: float) -> float:
    if total_qty < 0 or batch_runtime_minutes < 0 or total_runtime_minutes <= 0:
        raise ValueError('INVALID_RUNTIME_ALLOCATION')
    if batch_runtime_minutes > total_runtime_minutes:
        raise ValueError('RUNTIME_EXCEEDS_TOTAL')
    return round(total_qty * batch_runtime_minutes / total_runtime_minutes, 6)


def allocate_by_output(total_qty: float, batch_output_kg: float, total_output_kg: float) -> float:
    if total_qty < 0 or batch_output_kg < 0 or total_output_kg <= 0:
        raise ValueError('INVALID_OUTPUT_ALLOCATION')
    if batch_output_kg > total_output_kg:
        raise ValueError('OUTPUT_EXCEEDS_TOTAL')
    return round(total_qty * batch_output_kg / total_output_kg, 6)


def reconcile_utility_consumption(recorded: list[UtilityConsumption], measured_qty: float, tolerance_qty: float=0.0) -> dict:
    total = round(sum(x.qty for x in recorded), 6)
    variance = round(measured_qty-total, 6)
    return {'recorded_qty': total, 'measured_qty': measured_qty, 'variance_qty': variance, 'within_tolerance': abs(variance) <= tolerance_qty}


def batch_utility_costs(records: list[UtilityConsumption], batch_id: str) -> float:
    return round(sum(r.cost for r in records if r.source_id == batch_id), 2)
