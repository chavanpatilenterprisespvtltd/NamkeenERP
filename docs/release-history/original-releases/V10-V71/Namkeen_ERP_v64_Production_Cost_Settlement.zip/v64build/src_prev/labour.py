from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Optional

class EmployeeStatus(str, Enum):
    ACTIVE='ACTIVE'; INACTIVE='INACTIVE'; ON_LEAVE='ON_LEAVE'; EXITED='EXITED'

class ShiftStatus(str, Enum):
    OPEN='OPEN'; CLOSED='CLOSED'; CANCELLED='CANCELLED'

class AttendanceStatus(str, Enum):
    PRESENT='PRESENT'; ABSENT='ABSENT'; LEAVE='LEAVE'; HALF_DAY='HALF_DAY'; LATE='LATE'; OFF='OFF'

@dataclass
class Employee:
    employee_id: str
    employee_code: str
    name: str
    role: str
    status: EmployeeStatus=EmployeeStatus.ACTIVE
    hourly_rate: float=0.0
    overtime_multiplier: float=1.5
    home_site_id: Optional[str]=None

@dataclass
class Shift:
    shift_id: str
    site_id: str
    shift_code: str
    starts_at: datetime
    ends_at: datetime
    status: ShiftStatus=ShiftStatus.OPEN
    supervisor_id: Optional[str]=None

@dataclass
class Attendance:
    attendance_id: str
    employee_id: str
    shift_id: str
    status: AttendanceStatus
    check_in: Optional[datetime]=None
    check_out: Optional[datetime]=None
    photo_ref: Optional[str]=None
    gps_lat: Optional[float]=None
    gps_lon: Optional[float]=None
    note: Optional[str]=None

@dataclass
class LabourAssignment:
    assignment_id: str
    employee_id: str
    batch_id: str
    process_stage: str
    started_at: datetime
    ended_at: Optional[datetime]=None
    regular_hours: float=0.0
    overtime_hours: float=0.0
    approved: bool=False
    client_event_id: Optional[str]=None

@dataclass
class LabourCost:
    assignment_id: str
    batch_id: str
    employee_id: str
    regular_cost: float
    overtime_cost: float
    total_cost: float

@dataclass
class Productivity:
    batch_id: str
    good_output_kg: float
    labour_hours: float
    kg_per_labour_hour: float
    labour_cost_per_kg: float


def validate_employee(employee: Employee) -> None:
    if not employee.employee_id or not employee.employee_code or not employee.name.strip():
        raise ValueError('INVALID_EMPLOYEE')
    if employee.hourly_rate < 0 or employee.overtime_multiplier < 0:
        raise ValueError('INVALID_LABOUR_RATE')


def calculate_shift_hours(shift: Shift) -> float:
    if shift.ends_at <= shift.starts_at:
        raise ValueError('INVALID_SHIFT_WINDOW')
    return round((shift.ends_at-shift.starts_at).total_seconds()/3600, 4)


def validate_attendance(att: Attendance) -> None:
    if att.status in {AttendanceStatus.PRESENT, AttendanceStatus.LATE, AttendanceStatus.HALF_DAY}:
        if not att.check_in or not att.check_out:
            raise ValueError('ATTENDANCE_TIME_REQUIRED')
        if att.check_out <= att.check_in:
            raise ValueError('INVALID_ATTENDANCE_WINDOW')
    if not (att.status == AttendanceStatus.PRESENT and att.check_in):
        return


def derive_hours(started_at: datetime, ended_at: datetime, standard_hours: float=8.0) -> tuple[float,float]:
    if ended_at <= started_at or standard_hours < 0:
        raise ValueError('INVALID_LABOUR_WINDOW')
    total = (ended_at-started_at).total_seconds()/3600
    regular = min(total, standard_hours)
    overtime = max(0.0, total-standard_hours)
    return round(regular,4), round(overtime,4)


def close_assignment(assignment: LabourAssignment, ended_at: datetime, standard_hours: float=8.0) -> None:
    regular, overtime = derive_hours(assignment.started_at, ended_at, standard_hours)
    assignment.ended_at = ended_at
    assignment.regular_hours = regular
    assignment.overtime_hours = overtime


def approve_assignment(assignment: LabourAssignment) -> None:
    if assignment.ended_at is None:
        raise ValueError('ASSIGNMENT_NOT_CLOSED')
    if assignment.regular_hours < 0 or assignment.overtime_hours < 0:
        raise ValueError('INVALID_LABOUR_HOURS')
    assignment.approved = True


def calculate_labour_cost(assignment: LabourAssignment, employee: Employee) -> LabourCost:
    if not assignment.approved:
        raise ValueError('LABOUR_NOT_APPROVED')
    regular = round(assignment.regular_hours * employee.hourly_rate, 2)
    overtime = round(assignment.overtime_hours * employee.hourly_rate * employee.overtime_multiplier, 2)
    return LabourCost(assignment.assignment_id, assignment.batch_id, assignment.employee_id, regular, overtime, round(regular+overtime,2))


def batch_productivity(batch_id: str, good_output_kg: float, costs: list[LabourCost], assignments: list[LabourAssignment]) -> Productivity:
    if good_output_kg < 0:
        raise ValueError('INVALID_OUTPUT')
    total_hours = round(sum(a.regular_hours+a.overtime_hours for a in assignments if a.batch_id == batch_id and a.approved),4)
    total_cost = round(sum(c.total_cost for c in costs if c.batch_id == batch_id),2)
    if total_hours <= 0:
        raise ValueError('NO_APPROVED_LABOUR_HOURS')
    return Productivity(batch_id, good_output_kg, total_hours, round(good_output_kg/total_hours,4), round(total_cost/good_output_kg,4) if good_output_kg > 0 else 0.0)


def allocate_labour_cost_to_batch(total_cost: float, batch_output_kg: float, total_output_kg: float) -> float:
    if total_cost < 0 or batch_output_kg < 0 or total_output_kg <= 0 or batch_output_kg > total_output_kg:
        raise ValueError('INVALID_LABOUR_ALLOCATION')
    return round(total_cost * batch_output_kg / total_output_kg, 2)
