import sys
sys.path.insert(0,'src')
from cost_settlement import *

def test_settlement_all_components():
    inputs = [
        make_cost_input('RM', 900, 100, 'rm1'),
        make_cost_input('OIL', 30, 120, 'oil1'),
        make_cost_input('FUEL', 10, 50, 'fuel1'),
        make_cost_input('PACKAGING', 100, 5, 'pack1'),
        make_cost_input('LABOUR', 12, 100, 'lab1'),
        make_cost_input('POWER', 80, 8, 'p1'),
        make_cost_input('OVERHEAD', 1, 500, 'ov1'),
    ]
    s = settle_batch('B1', inputs, BatchOutput(1000), 110000)
    assert s.total_cost == 96940
    assert s.good_cost_per_kg == 96.94
    assert s.status == 'SETTLED'

def test_category_totals_and_variance():
    xs=[make_cost_input('RM',10,10,'a'),make_cost_input('RM',5,12,'b'),make_cost_input('LABOUR',2,10,'c')]
    assert category_totals(xs)=={'RM':160,'LABOUR':20}
    s=settle_batch('B2', xs, BatchOutput(20), 150)
    assert s.variance == 30
    assert s.variance_pct == 20

def test_sku_allocation():
    s=settle_batch('B3',[make_cost_input('RM',100,10,'x')],BatchOutput(100),1000)
    assert allocated_sku_cost(s, {'SKU1':60,'SKU2':40}) == {'SKU1':600.0,'SKU2':400.0}

def test_bad_output_blocked():
    try:
        settle_batch('B4', [], BatchOutput(0))
        assert False
    except ValueError as e:
        assert str(e)=='GOOD_OUTPUT_REQUIRED'

def test_sku_mismatch_blocked():
    s=settle_batch('B5',[make_cost_input('RM',100,10,'x')],BatchOutput(100))
    try:
        allocated_sku_cost(s, {'SKU1':80})
        assert False
    except ValueError as e:
        assert str(e)=='SKU_OUTPUT_MISMATCH'
