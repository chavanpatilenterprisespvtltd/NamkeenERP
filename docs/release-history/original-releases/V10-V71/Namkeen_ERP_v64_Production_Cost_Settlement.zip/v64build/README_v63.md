# Namkeen ERP v63 — Labour, Manpower, Shifts & Production Productivity

## Purpose
Connect operator/manpower activity to production batches and v50 actual costing.

## Scope
- Employee/operator master
- Roles/status and hourly labour rates
- Shift master and shift lifecycle
- Attendance with optional GPS/photo evidence
- Operator assignment to production batch/process stage
- Regular vs overtime hours
- Supervisor approval before costing
- Labour cost calculation with configurable overtime multiplier
- Batch labour productivity: kg/labour-hour
- Labour cost/kg
- Output-proportional labour allocation
- Offline client_event_id idempotency
- PostgreSQL migration `052_v63_labour_manpower_productivity.sql`

## Key controls
- inactive/exited employees must be blocked by the service layer
- attendance requires time fields for worked statuses
- assignments must be closed before approval
- only approved labour enters costing input
- overtime multiplier is configurable, never hard-coded as law/policy
- labour cost never directly rewrites historical posted batch cost

## v50 integration
Approved labour assignments produce controlled cost-allocation inputs for actual batch costing. Historical posted costs are not recalculated automatically.

## Validation
Focused v63 tests cover employee/shift validation, attendance, hours/overtime, approval, labour costing, productivity and allocation.
