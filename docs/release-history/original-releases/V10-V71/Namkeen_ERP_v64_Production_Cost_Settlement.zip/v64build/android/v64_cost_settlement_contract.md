# v64 Android Cost Settlement Contract

Screens/workflows:
- Batch cost input review
- Planned vs actual component variance
- Good/reject/rework output summary
- Actual cost/kg preview
- Standard vs actual cost variance
- SKU cost allocation preview
- Settlement submission/approval
- Management profitability drill-down

Rules:
- mobile may capture and preview but cannot finalize posted cost directly
- approved v62 utility, v63 labour, v26 production/packing, and inventory cost inputs are referenced by source id
- historical posted settlements are immutable; corrections use controlled adjustment/reversal
- SKU allocation must reconcile exactly to good output kg (within configured rounding tolerance)
