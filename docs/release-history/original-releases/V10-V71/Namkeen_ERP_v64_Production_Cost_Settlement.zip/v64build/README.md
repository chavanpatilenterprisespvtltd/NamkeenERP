# Namkeen ERP v64 — Authoritative Production Cost Settlement

## Purpose
Bring RM, oil, fuel, packaging, utilities, labour, wastage/rework and output together into one authoritative production-cost settlement that feeds management profitability and SKU cost roll-up.

## Flow
v26 production/packing + v50 costing + v62 utilities + v63 labour -> v64 Settlement -> SKU cost allocation -> profitability/MIS

## Cost components
RM, OIL, FUEL, PACKAGING, LABOUR, POWER, UTILITIES, REWORK, OVERHEAD, OTHER.

## Controls
- good output must be > 0
- all component costs are non-negative
- settlement is unique per organization/batch
- SKU output must reconcile to batch good output
- posted history is immutable; corrections use controlled adjustment/reversal
- GST is not included unless explicitly configured as non-recoverable cost
- mobile clients cannot post final cost directly

## Validation
5 focused v64 tests pass. Python compilation and package integrity validated.

## Deployment note
Live PostgreSQL execution and integration against the prior transaction services require deployment/UAT; this build provides the authoritative service/migration contract.
