from dataclasses import dataclass
from typing import List, Dict

@dataclass
class CostInput:
    category: str
    quantity: float
    unit_cost: float
    cost: float
    source_id: str

@dataclass
class BatchOutput:
    good_kg: float
    reject_kg: float = 0.0
    rework_kg: float = 0.0

@dataclass
class BatchCostSettlement:
    batch_id: str
    inputs: List[CostInput]
    output: BatchOutput
    total_cost: float
    good_cost_per_kg: float
    standard_cost: float
    variance: float
    variance_pct: float
    status: str


def make_cost_input(category: str, quantity: float, unit_cost: float, source_id: str) -> CostInput:
    if quantity < 0 or unit_cost < 0:
        raise ValueError('INVALID_COST_INPUT')
    return CostInput(category, quantity, unit_cost, round(quantity * unit_cost, 2), source_id)


def settle_batch(batch_id: str, inputs: List[CostInput], output: BatchOutput, standard_cost: float = 0.0) -> BatchCostSettlement:
    if output.good_kg <= 0:
        raise ValueError('GOOD_OUTPUT_REQUIRED')
    if any(x.cost < 0 for x in inputs):
        raise ValueError('NEGATIVE_INPUT_COST')
    total = round(sum(x.cost for x in inputs), 2)
    cost_per_kg = round(total / output.good_kg, 4)
    variance = round(total - max(standard_cost, 0.0), 2)
    variance_pct = round((variance / standard_cost) * 100, 4) if standard_cost > 0 else 0.0
    return BatchCostSettlement(batch_id, inputs, output, total, cost_per_kg, standard_cost, variance, variance_pct, 'SETTLED')


def category_totals(inputs: List[CostInput]) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for item in inputs:
        out[item.category] = round(out.get(item.category, 0.0) + item.cost, 2)
    return out


def allocated_sku_cost(batch: BatchCostSettlement, sku_outputs: Dict[str, float]) -> Dict[str, float]:
    total_kg = round(sum(v for v in sku_outputs.values()), 6)
    if total_kg <= 0:
        raise ValueError('SKU_OUTPUT_REQUIRED')
    if abs(total_kg - batch.output.good_kg) > 0.001:
        raise ValueError('SKU_OUTPUT_MISMATCH')
    return {sku: round(batch.total_cost * kg / total_kg, 2) for sku, kg in sku_outputs.items()}
