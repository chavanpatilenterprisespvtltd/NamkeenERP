# Namkeen ERP v18 — Production Two-Way Mobile Sync

v18 completes the generic two-way synchronization foundation requested after v17.

## Added
- Server-to-device delta feed with monotonic `sync_change_log` IDs.
- Per-device sync cursors and acknowledgement tracking.
- Generic optimistic-concurrency comparison for client/server versions.
- Persistent conflict records with management resolution workflow.
- Dead-letter records for invalid/rejected sync events.
- `GET /v18/sync/pull` delta API.
- `POST /v18/sync/push` idempotent push API with conflict/reject handling.
- Conflict list and management resolution APIs.
- PostgreSQL migration `008_v18_two_way_sync.sql`.
- SQLite-compatible unit tests for cursor/delta/version semantics.

## Integrity rules
- The server remains authoritative for approvals, payment verification, inventory, QC, accounting and other transactional state.
- Pull cursors only move forward; clients must never silently overwrite server data after a version conflict.
- `ACCEPT_CLIENT` conflict resolution is recorded but does not bypass the domain transaction service; domain-specific replay remains explicit.
- Sync event ids are organization-scoped and idempotent.

## Remaining production gates
- Add change-log writes to every mutating domain transaction (customer/order/payment/inventory/collections/returns/compliance).
- Implement device-specific delta filtering by user/entity/territory policy.
- Add actual mobile client queue/SQLite implementation and background retry/backoff.
- Add encrypted object storage + upload/download APIs.
- Complete FCM/SMS/WhatsApp/email provider integrations.
- Add PostgreSQL migration execution/Alembic, load testing, security testing, backup/restore and field UAT.
