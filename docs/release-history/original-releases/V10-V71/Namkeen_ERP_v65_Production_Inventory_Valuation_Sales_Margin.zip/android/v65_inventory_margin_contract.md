# v65 Android Contract — Inventory Valuation & Margin

## Screens
- FG Lot Valuation
- SKU Cost Snapshot
- Invoice Gross Margin
- Customer Profitability
- Return COGS Preview

## Rules
- Server calculates authoritative COGS and gross margin.
- GST is excluded from sales-margin revenue unless an approved accounting policy explicitly states otherwise; default basis is taxable/exclusive sales value.
- Returns/reversals create linked COGS reversal records; historical posted COGS is never overwritten.
- Offline devices may capture requests, but cannot finalize valuation or ledger posting.
