# Namkeen ERP v65 — Inventory Valuation + Sales Margin Integration

## Scope
Connect v64 settled production cost to FG inventory valuation and sales gross margin.

Flow:
**Production Cost Settlement → FG Lot Cost → Inventory Valuation → Sales COGS → Gross Margin → Customer Profitability**

## Included
- FG lot valuation from authoritative production settlement cost/kg
- SKU cost snapshots for reporting/pricing reference
- Weighted-average cost helper for non-FEFO valuation views
- Sales-line COGS and gross-margin calculation
- Customer profitability aggregation
- Return COGS reversal calculation
- PostgreSQL migration `054_v65_inventory_valuation_margin.sql`
- Android contract

## Control boundaries
- Inventory ledger remains the authoritative stock quantity.
- COGS posting must reference the authoritative inventory/lot transaction and cannot directly rewrite it.
- Tax is not treated as gross-margin revenue/cost by default; tax treatment remains configurable under the tax/accounting layer.
- Historical posted cost is immutable; corrections require reversal/adjustment transactions.
