-- v65: FG inventory valuation and sales gross-margin integration
CREATE TABLE IF NOT EXISTS fg_inventory_valuation (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    entity_id UUID NOT NULL,
    fg_lot_id UUID NOT NULL,
    sku_id UUID NOT NULL,
    production_batch_id UUID NOT NULL,
    good_qty_kg NUMERIC(18,6) NOT NULL,
    cost_per_kg NUMERIC(18,6) NOT NULL,
    inventory_value NUMERIC(18,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    valuation_method VARCHAR(30) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, entity_id, fg_lot_id)
);

CREATE TABLE IF NOT EXISTS sku_cost_snapshot (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    entity_id UUID NOT NULL,
    sku_id UUID NOT NULL,
    cost_source VARCHAR(40) NOT NULL,
    effective_at TIMESTAMPTZ NOT NULL,
    cost_per_kg NUMERIC(18,6) NOT NULL,
    source_batch_id UUID,
    UNIQUE (organization_id, entity_id, sku_id, effective_at)
);

CREATE TABLE IF NOT EXISTS sales_cogs_posting (
    id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    entity_id UUID NOT NULL,
    invoice_id UUID NOT NULL,
    invoice_line_id UUID NOT NULL,
    fg_lot_id UUID,
    qty_kg NUMERIC(18,6) NOT NULL,
    unit_cost_per_kg NUMERIC(18,6) NOT NULL,
    cogs_value NUMERIC(18,2) NOT NULL,
    valuation_method VARCHAR(30) NOT NULL,
    reversal_of_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, entity_id, invoice_line_id, reversal_of_id)
);

CREATE INDEX IF NOT EXISTS idx_fg_val_sku ON fg_inventory_valuation(organization_id, entity_id, sku_id, created_at);
CREATE INDEX IF NOT EXISTS idx_cogs_invoice ON sales_cogs_posting(organization_id, entity_id, invoice_id);
