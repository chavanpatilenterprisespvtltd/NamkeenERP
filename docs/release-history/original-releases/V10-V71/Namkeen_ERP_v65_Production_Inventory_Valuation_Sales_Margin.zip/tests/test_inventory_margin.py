import sys
sys.path.insert(0,'src')
from inventory_margin import *


def test_fg_lot_valuation():
    v = value_fg_lot('L1','SKU1','B1',1000,128.5)
    assert v.inventory_value == 128500


def test_weighted_average():
    assert weighted_average_cost(100, 10000, 50, 7500) == 116.6667


def test_sales_margin():
    m = line_margin('SKU1', 100, 20000, 12000)
    assert m.gross_margin == 8000
    assert m.gross_margin_pct == 40
    assert m.unit_sales_price == 200


def test_customer_profitability():
    rows=[line_margin('A',100,20000,12000), line_margin('B',50,9000,6500)]
    p=customer_profitability(rows)
    assert p == {'sales':29000,'cogs':18500,'gross_margin':10500,'gross_margin_pct':36.2069,'qty_kg':150}


def test_return_reverses_cogs():
    assert return_cogs_reversal(10,120) == 1200


def test_blocks_negative_cost():
    try:
        value_fg_lot('L2','S','B',10,-1)
        assert False
    except ValueError as e:
        assert str(e)=='NEGATIVE_COST'


def test_blocks_zero_sales_qty():
    try:
        line_margin('S',0,100,50)
        assert False
    except ValueError as e:
        assert str(e)=='POSITIVE_SALES_QTY_REQUIRED'


def test_cogs_not_inflated_by_gst():
    m=line_margin('S',100,12800,9000)
    assert m.cogs == 9000
    assert m.gross_margin == 3800
