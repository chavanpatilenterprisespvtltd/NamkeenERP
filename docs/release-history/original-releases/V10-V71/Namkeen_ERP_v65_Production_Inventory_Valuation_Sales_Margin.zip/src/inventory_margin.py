from dataclasses import dataclass
from typing import Dict, List

@dataclass(frozen=True)
class FGLotValuation:
    fg_lot_id: str
    sku_id: str
    batch_id: str
    good_kg: float
    cost_per_kg: float
    inventory_value: float
    currency: str = 'INR'

@dataclass(frozen=True)
class SalesLineMargin:
    sku_id: str
    qty_kg: float
    taxable_sales_value: float
    unit_sales_price: float
    cogs: float
    gross_margin: float
    gross_margin_pct: float


def value_fg_lot(fg_lot_id: str, sku_id: str, batch_id: str, good_kg: float, cost_per_kg: float) -> FGLotValuation:
    if good_kg <= 0:
        raise ValueError('GOOD_FG_QTY_REQUIRED')
    if cost_per_kg < 0:
        raise ValueError('NEGATIVE_COST')
    return FGLotValuation(fg_lot_id, sku_id, batch_id, round(good_kg, 6), round(cost_per_kg, 4), round(good_kg * cost_per_kg, 2))


def weighted_average_cost(existing_qty_kg: float, existing_value: float, received_qty_kg: float, received_value: float) -> float:
    if existing_qty_kg < 0 or received_qty_kg < 0 or existing_value < 0 or received_value < 0:
        raise ValueError('INVALID_VALUATION_INPUT')
    total_qty = existing_qty_kg + received_qty_kg
    if total_qty <= 0:
        raise ValueError('POSITIVE_STOCK_REQUIRED')
    return round((existing_value + received_value) / total_qty, 4)


def line_margin(sku_id: str, qty_kg: float, taxable_sales_value: float, cogs: float) -> SalesLineMargin:
    if qty_kg <= 0:
        raise ValueError('POSITIVE_SALES_QTY_REQUIRED')
    if taxable_sales_value < 0 or cogs < 0:
        raise ValueError('INVALID_MARGIN_INPUT')
    price = round(taxable_sales_value / qty_kg, 4)
    margin = round(taxable_sales_value - cogs, 2)
    pct = round((margin / taxable_sales_value) * 100, 4) if taxable_sales_value > 0 else 0.0
    return SalesLineMargin(sku_id, round(qty_kg, 6), round(taxable_sales_value, 2), price, round(cogs, 2), margin, pct)


def customer_profitability(lines: List[SalesLineMargin]) -> Dict[str, float]:
    sales = round(sum(x.taxable_sales_value for x in lines), 2)
    cogs = round(sum(x.cogs for x in lines), 2)
    gross = round(sales - cogs, 2)
    pct = round((gross / sales) * 100, 4) if sales > 0 else 0.0
    return {'sales': sales, 'cogs': cogs, 'gross_margin': gross, 'gross_margin_pct': pct, 'qty_kg': round(sum(x.qty_kg for x in lines), 6)}


def return_cogs_reversal(return_qty_kg: float, unit_cost_per_kg: float) -> float:
    if return_qty_kg <= 0:
        raise ValueError('POSITIVE_RETURN_QTY_REQUIRED')
    if unit_cost_per_kg < 0:
        raise ValueError('NEGATIVE_COST')
    return round(return_qty_kg * unit_cost_per_kg, 2)
