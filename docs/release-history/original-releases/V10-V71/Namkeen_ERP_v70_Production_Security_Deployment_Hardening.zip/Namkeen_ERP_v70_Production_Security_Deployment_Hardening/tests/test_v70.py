import unittest
from app.security import DeploymentConfig, validate_config, secret_name_allowed, security_headers
from app.audit import audit_hash, verify_chain

class V70Tests(unittest.TestCase):
    def test_prod_config_has_no_blockers(self):
        c=DeploymentConfig("production", True, False, "managed_secret_store", True, True, True)
        self.assertEqual(validate_config(c), [])
    def test_prod_debug_is_blocked(self):
        c=DeploymentConfig("production", True, True, "managed_secret_store", True, True, True)
        self.assertIn("DEBUG must be false in production", validate_config(c))
    def test_secret_naming(self):
        self.assertTrue(secret_name_allowed("ERP_JWT_KEY"))
        self.assertFalse(secret_name_allowed("password"))
    def test_headers(self):
        h=security_headers()
        self.assertEqual(h["X-Frame-Options"], "DENY")
        self.assertIn("max-age=31536000", h["Strict-Transport-Security"])
    def test_audit_chain(self):
        payloads=["login", "order", "dispatch"]
        events=[]; prev=""
        for p in payloads:
            h=audit_hash(prev,p); events.append({"payload":p,"hash":h}); prev=h
        self.assertTrue(verify_chain(events))
        events[1]["payload"]="tampered"
        self.assertFalse(verify_chain(events))

if __name__ == "__main__": unittest.main()
