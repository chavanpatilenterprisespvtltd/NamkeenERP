# Namkeen ERP v70 — Production Security & Deployment Hardening

v70 is the production-security gate after the v69 operations/DR layer.

## Scope
- Secret-management abstraction; no secrets committed to source/config
- TLS/HTTPS deployment policy and secure-cookie/header configuration
- PostgreSQL least-privilege roles and SSL enforcement contract
- Encryption-at-rest key references for PII/documents/backups
- PII/document access policy with audit requirements
- Session/device security policy: expiry, revocation, max devices
- API rate-limit policy and authentication-failure throttling
- Security headers and request correlation IDs
- Audit-log hardening and tamper-evidence metadata
- Dependency/container vulnerability-scan contracts
- Container hardening policy (non-root, read-only filesystem, dropped capabilities)
- Backup encryption verification and restore-gate policy
- Production deployment configuration validation
- Go-live readiness checklist and explicit blockers
- PostgreSQL migration `059_v70_security_deployment.sql`

## Important
This package is a deployable security/control-plane foundation, not proof of certification or a completed production deployment. Actual TLS certificates, KMS/secret-manager integration, network policy, vulnerability scans, PostgreSQL hardening, and penetration testing must run in the target environment.

Run tests:
`python -m unittest discover -s tests -v`
