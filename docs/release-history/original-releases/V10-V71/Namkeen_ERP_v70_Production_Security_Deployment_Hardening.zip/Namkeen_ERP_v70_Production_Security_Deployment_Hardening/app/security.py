from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class DeploymentConfig:
    environment: str
    https_required: bool
    debug: bool
    secret_backend: str
    db_ssl_required: bool
    audit_tamper_evident: bool
    backup_encryption_required: bool
    max_session_hours: int = 12
    max_devices_per_user: int = 5

class SecurityError(ValueError):
    pass

def validate_config(c: DeploymentConfig) -> list[str]:
    errors=[]
    if c.environment.lower() == "production" and c.debug:
        errors.append("DEBUG must be false in production")
    if c.environment.lower() == "production" and not c.https_required:
        errors.append("HTTPS is required in production")
    if c.environment.lower() == "production" and c.secret_backend in {"env_plaintext", "local_file"}:
        errors.append("Production secrets must use a managed secret backend")
    if c.environment.lower() == "production" and not c.db_ssl_required:
        errors.append("PostgreSQL SSL is required in production")
    if c.environment.lower() == "production" and not c.audit_tamper_evident:
        errors.append("Audit tamper-evidence is required in production")
    if c.environment.lower() == "production" and not c.backup_encryption_required:
        errors.append("Encrypted backups are required in production")
    if not 1 <= c.max_session_hours <= 168:
        errors.append("max_session_hours must be 1..168")
    if not 1 <= c.max_devices_per_user <= 20:
        errors.append("max_devices_per_user must be 1..20")
    return errors

def secret_name_allowed(name: str) -> bool:
    return bool(name) and name.upper() == name and name.replace("_", "").isalnum() and name.startswith(("ERP_", "DB_", "TALLY_", "GST_", "EWB_", "STORAGE_", "KMS_"))

def security_headers() -> dict[str,str]:
    return {
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'",
    }
