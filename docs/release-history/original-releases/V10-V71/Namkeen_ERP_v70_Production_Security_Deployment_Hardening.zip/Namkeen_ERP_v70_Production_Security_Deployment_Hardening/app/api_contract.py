V70_ENDPOINTS = {
    "POST /v70/security/validate-deployment": "Validate production security configuration and return blockers",
    "GET /v70/security/headers": "Return enforced HTTP security headers",
    "GET /v70/security/session-policy": "Return effective session/device policy",
    "GET /v70/security/go-live": "Return go-live readiness status",
}
