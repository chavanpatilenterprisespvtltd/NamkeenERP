from hashlib import sha256

def audit_hash(previous_hash: str, event_payload: str) -> str:
    return sha256((previous_hash + event_payload).encode()).hexdigest()

def verify_chain(events):
    prev = ""
    for event in events:
        expected = audit_hash(prev, event["payload"])
        if expected != event["hash"]:
            return False
        prev = event["hash"]
    return True
