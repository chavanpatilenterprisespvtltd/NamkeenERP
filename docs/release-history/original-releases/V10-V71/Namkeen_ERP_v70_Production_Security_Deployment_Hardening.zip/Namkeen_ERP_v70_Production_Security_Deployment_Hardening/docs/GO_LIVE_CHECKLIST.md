# v70 Go-Live Checklist

Production may proceed only when every mandatory gate is VERIFIED:

1. TLS certificate and HTTPS redirect verified.
2. Managed secret/KMS references configured; no secrets in source or images.
3. PostgreSQL SSL, least-privilege roles and network restrictions verified.
4. PII/document object storage encryption and access audit verified.
5. Session/device revocation and rate limiting tested.
6. Audit hash-chain verification tested.
7. Dependency/container vulnerability scan completed with no unaccepted critical/high findings.
8. Backup encryption verified and at least one restore drill marked VERIFIED.
9. Monitoring, alert delivery and dead-letter processing tested.
10. Android offline sync + document upload + conflict handling UAT completed.
11. Tally/IRP/E-Way Bill integration UAT completed where applicable.
12. FSSAI/Maharashtra FDA compliance UAT and CA/statutory review completed.
13. Data migration and rollback plan approved.
14. Named production owner and incident contacts recorded.

A failed gate is a go-live blocker unless formally risk-accepted by authorized management.
