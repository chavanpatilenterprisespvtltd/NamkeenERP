# Security Model

PII and customer evidence are treated as sensitive business data. The ERP stores references/metadata separately from protected object bytes and requires authorization plus audit logging for access.

External integration credentials (Tally, IRP/EWB, storage, SMTP/SMS, KMS) must be referenced from a managed secret backend and must never be stored in Android binaries, source control, database business tables, or logs.

The server remains authoritative for pricing, payments, inventory, QC, accounting and compliance. Mobile devices are untrusted/offline clients and cannot bypass those controls.
