-- v70: Production Security & Deployment Hardening
CREATE TABLE IF NOT EXISTS security_policy (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    environment TEXT NOT NULL,
    https_required BOOLEAN NOT NULL DEFAULT TRUE,
    db_ssl_required BOOLEAN NOT NULL DEFAULT TRUE,
    managed_secret_backend TEXT NOT NULL,
    audit_tamper_evident BOOLEAN NOT NULL DEFAULT TRUE,
    backup_encryption_required BOOLEAN NOT NULL DEFAULT TRUE,
    max_session_hours INTEGER NOT NULL DEFAULT 12,
    max_devices_per_user INTEGER NOT NULL DEFAULT 5,
    effective_from TIMESTAMPTZ NOT NULL,
    effective_to TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS secret_reference (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    secret_name TEXT NOT NULL,
    backend TEXT NOT NULL,
    external_reference TEXT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organization_id, secret_name)
);

CREATE TABLE IF NOT EXISTS security_event (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    user_id BIGINT,
    device_id BIGINT,
    event_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    correlation_id TEXT,
    payload_hash TEXT NOT NULL,
    previous_hash TEXT,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vulnerability_scan_run (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT,
    scanner TEXT NOT NULL,
    target TEXT NOT NULL,
    status TEXT NOT NULL,
    critical_count INTEGER NOT NULL DEFAULT 0,
    high_count INTEGER NOT NULL DEFAULT 0,
    report_reference TEXT,
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS go_live_gate (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    gate_code TEXT NOT NULL,
    status TEXT NOT NULL,
    evidence_reference TEXT,
    approved_by BIGINT,
    approved_at TIMESTAMPTZ,
    UNIQUE (organization_id, gate_code)
);

CREATE INDEX IF NOT EXISTS idx_security_event_org_time ON security_event(organization_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_scan_run_status ON vulnerability_scan_run(status, completed_at);
