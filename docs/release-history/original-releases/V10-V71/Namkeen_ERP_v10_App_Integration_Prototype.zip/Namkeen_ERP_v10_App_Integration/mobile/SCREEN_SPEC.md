# Android App Integration Screens

1. Login / Entity selection
- English default; Marathi/Hindi switch.
- Offline sign-in policy defined per customer deployment.

2. Salesperson Home
- Visits, orders, collections, approvals, sync state, alerts.

3. Customer Visit
- GPS check-in/out, shop photo, customer documents, notes.

4. Customer Onboarding
- Name/mobile/address, GSTIN if applicable, GPS, shop photo, documents.
- Draft -> Manager/Management review -> Active.

5. Order Builder
- Product -> Variant -> Pack Size -> SKU -> Qty.
- Negotiated price, floor price, expected margin, incentive preview.
- UPI/Cash/Cheque; attach payment proof.
- Cheque pending -> hold; management override -> approval.

6. Collection
- Amount/mode/reference.
- Cash requires customer/party evidence photo.
- Deposit/handover -> Accounts verification.

7. Factory Home
- Production plan, RM issue, batch, QC, packing, low-stock alerts.

8. Scan
- Barcode/QR batch/SKU/location/expiry lookup.

9. Production
- Material issue, output, wastage, machine/process fields, QC.

10. Compliance
- Daily/periodic tasks, evidence capture, overdue alerts.

11. Sync Center
- Pending / synced / conflict / retry.
- Server is authoritative for stock, price, approval and payment states.

API integration rules:
- Every write has client_event_id idempotency key.
- Images/files upload through a secure object-storage API, not directly into transaction tables.
- Offline queue replays after connectivity.
- Server validates entity/location/role, price, stock and payment state before posting.
