
from fastapi.testclient import TestClient
import sys
sys.path.insert(0, ".")
from backend.main import app

c=TestClient(app)

def test_health(): assert c.get("/health").json()["version"]=="10.0"

def test_cheque_hold():
    r=c.post("/api/v1/orders",json={
      "client_event_id":"E1","customer_id":"C1","payment_mode":"Cheque","payment_status":"CHEQUE_PENDING",
      "lines":[{"sku":"SKU500","qty":10,"price":124}]
    })
    assert r.json()["status"]=="CHEQUE_HOLD"

def test_duplicate_order_idempotency():
    body={"client_event_id":"E2","customer_id":"C1","payment_mode":"UPI","payment_status":"VERIFIED",
          "lines":[{"sku":"SKU500","qty":1,"price":125}]}
    assert c.post("/api/v1/orders",json=body).json()["status"]=="READY_FOR_STOCK_CHECK"
    assert c.post("/api/v1/orders",json=body).json()["status"]=="DUPLICATE"

def test_cash_collection_goes_to_accounts():
    r=c.post("/api/v1/collections",json={"client_event_id":"P1","customer_id":"C1","amount":1000,"mode":"Cash","reference":"R1","proof_file_name":"cash.jpg"})
    assert r.json()["status"]=="PENDING_ACCOUNTS_VERIFICATION"
