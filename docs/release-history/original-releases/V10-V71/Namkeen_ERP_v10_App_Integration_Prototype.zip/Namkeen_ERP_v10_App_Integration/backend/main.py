
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from decimal import Decimal
from datetime import datetime, timezone

app = FastAPI(title="Namkeen ERP v10 App Integration", version="10.0")

# Demo state only. Production uses PostgreSQL + Redis/object storage/etc.
orders = {}
customers = {}
notifications = []
sync_ids = set()

class OrderLine(BaseModel):
    sku: str
    qty: Decimal = Field(gt=0)
    price: Decimal = Field(gt=0)

class SalesOrder(BaseModel):
    client_event_id: str
    customer_id: str
    entity: str = "Y"
    warehouse: str = "Y-WH1"
    payment_mode: str
    payment_status: str
    lines: list[OrderLine]

class CustomerIn(BaseModel):
    client_event_id: str
    name: str
    mobile: str
    address: str
    gps_lat: float
    gps_lng: float

class CollectionIn(BaseModel):
    client_event_id: str
    customer_id: str
    amount: Decimal = Field(gt=0)
    mode: str
    reference: str | None = None
    proof_file_name: str | None = None

@app.get("/health")
def health(): return {"status":"ok","version":"10.0"}

@app.post("/api/v1/customers")
def customer_create(c: CustomerIn):
    if c.client_event_id in sync_ids:
        return {"status":"DUPLICATE","client_event_id":c.client_event_id}
    sync_ids.add(c.client_event_id)
    customers[c.client_event_id] = c.model_dump()
    return {"status":"SUBMITTED","customer_id":c.client_event_id}

@app.post("/api/v1/orders")
def order_create(o: SalesOrder):
    if o.client_event_id in sync_ids:
        return {"status":"DUPLICATE","client_event_id":o.client_event_id}
    sync_ids.add(o.client_event_id)
    # Simplified state machine for UI integration.
    if o.payment_mode.upper()=="CHEQUE" and o.payment_status.upper()!="CLEARED":
        status="CHEQUE_HOLD"
    elif o.payment_status.upper()!="VERIFIED":
        status="PAYMENT_VERIFICATION"
    else:
        status="READY_FOR_STOCK_CHECK"
    orders[o.client_event_id] = {"order":o.model_dump(),"status":status}
    if status != "READY_FOR_STOCK_CHECK":
        notifications.append({"role":"MANAGER","event":status,"ref":o.client_event_id})
    return {"order_id":o.client_event_id,"status":status}

@app.post("/api/v1/collections")
def collection_create(c: CollectionIn):
    if c.client_event_id in sync_ids:
        return {"status":"DUPLICATE","client_event_id":c.client_event_id}
    sync_ids.add(c.client_event_id)
    status = "PENDING_ACCOUNTS_VERIFICATION"
    notifications.append({"role":"ACCOUNTS","event":"PAYMENT_VERIFICATION","ref":c.client_event_id})
    return {"collection_id":c.client_event_id,"status":status}

@app.get("/api/v1/notifications")
def get_notifications(role: str="MANAGER"):
    return [n for n in notifications if n["role"]==role][-50:]

@app.post("/api/v1/sync")
def sync(events: list[dict]):
    accepted=[]; duplicates=[]
    for e in events:
        key=e.get("client_event_id")
        if not key: raise HTTPException(400,"client_event_id required")
        if key in sync_ids:
            duplicates.append(key)
        else:
            sync_ids.add(key); accepted.append(key)
    return {"accepted":accepted,"duplicates":duplicates,"conflicts":[]}
