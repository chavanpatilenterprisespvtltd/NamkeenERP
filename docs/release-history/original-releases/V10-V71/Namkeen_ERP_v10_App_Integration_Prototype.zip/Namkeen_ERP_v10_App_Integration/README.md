# Namkeen ERP v10 — App Integration Prototype

This stage connects the conceptual web/mobile UI to an API boundary.

Included:
- FastAPI integration API
- Web ERP order flow prototype
- Android screen specification for salesperson and factory apps
- Idempotent client_event_id for offline replay protection
- Cheque hold and payment verification behavior
- Collection-to-Accounts verification state
- Entity-ready API shape for X/Y
- Integration points for barcode/QR, GPS, photos and compliance

Run backend:
    python -m pip install -r backend/requirements.txt
    uvicorn backend.main:app --reload --port 8000

Open web/index.html locally.

Production hardening still required:
PostgreSQL repository implementation, JWT/refresh/device policy, object storage,
notification worker, real offline local database, conflict resolver, database locks,
Tally adapter, UPI/bank adapter, monitoring, backup and UAT.
