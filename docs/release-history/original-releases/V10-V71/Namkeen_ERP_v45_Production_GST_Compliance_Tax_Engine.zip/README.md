# Namkeen ERP v45 — GST Compliance & Statutory Tax Engine

v45 adds a configurable, auditable GST/tax engine and return-support layer:

- Effective-dated tax rules
- Product/SKU HSN tax profiles
- GSTIN structural validation
- Place-of-supply and intra/inter-state determination
- CGST/SGST/IGST/UTGST/Cess split
- Reverse-charge flag and support path
- Credit/debit note support
- GST return periods with lock/filed states
- GSTR-1-oriented summary support
- GSTR-3B-oriented summary support
- External reconciliation and mismatch tracking
- E-invoice-ready document data contract
- FastAPI endpoints for calculation, invoice validation, return summaries and reconciliation
- PostgreSQL migration `034_v45_gst_compliance_tax.sql`
- Android GST compliance contract

## Important compliance boundary

Rates, HSN applicability, RCM applicability and statutory filing rules are configuration/version driven. The system is designed to support CA/Accounts review and GST portal/IRP integrations; it is not a legal opinion or a claim of automatic statutory filing compliance.
