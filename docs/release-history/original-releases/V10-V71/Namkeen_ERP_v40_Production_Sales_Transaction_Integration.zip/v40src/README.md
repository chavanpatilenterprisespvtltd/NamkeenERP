# Namkeen ERP v40 — Sales Transaction Integration

Builds on v39 pricing/schemes/incentives, v38 credit controls, v37 customer accounts, and the existing persistent order/inventory services.

## Delivered
- Single commercial orchestration contract for Sales Order → Invoice → Dispatch
- Per-line v39 price/scheme calculation
- Credit-control gate before invoice
- Payment/cheque/cash evidence gate
- Customer invoice construction and validation
- Customer receivable/output-tax posting intents
- Incentive eligibility only after invoice state
- Offline/mobile idempotency-key propagation
- PostgreSQL migration 029_v40_sales_transaction_integration.sql
- FastAPI v40 quote/post contract
- Android sales transaction contract

## Important boundary
This release provides the transaction orchestration contract and posting-intent layer. The authoritative inventory reservation/dispatch and accounting mutation must still execute inside the existing persistent transaction services; this build does not claim live production deployment or live PostgreSQL UAT.
