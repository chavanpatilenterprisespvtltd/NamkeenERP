# Namkeen ERP v27 — UOM, SKU Pack/Carton Conversion & Barcode Hierarchy

Built on v26 production/packing traceability.

### Included
- Canonical UOM registry for weight/count units.
- Effective-dated SKU pack hierarchy.
- Dynamic piece -> pack -> carton -> kg conversion per SKU.
- No hard-coded carton quantity.
- Server-side normalization to kg for weight-based inventory valuation.
- Transaction quantity + transaction UOM + normalized kg contract.
- Historical conversion preservation via effective dates.
- Barcode master with organization-level uniqueness.
- EAN13 validation plus extensible EAN8/UPC-A/CODE128/QR/GS1/Internal support.
- Barcode resolution contract for SKU and lot operations.
- Android v27 scan/UOM contract.
- PostgreSQL migration `016_v27_uom_sku_barcode.sql`.
- Reconciliation specification and exception-control rules.

### Business examples
500 g SKU with 20 packs/carton => 1 carton = 10 kg.
1 kg SKU with 12 packs/carton => 1 carton = 12 kg.
Both configurations coexist; carton quantity is SKU-specific and effective-dated.

### Important boundary
v27 establishes the conversion master and barcode hierarchy. Existing v26 inventory quantities are not blindly rewritten. A migration/normalization step is required before every legacy SKU is allowed to transact in piece/pack/carton units.
