# Namkeen ERP v46 — E-Invoice + E-Way Bill Integration

Adds government-integration preparation/execution boundaries for e-invoice and e-way bill. Includes IRP/EWB adapter abstractions, asynchronous outbox, status models, validation, cancellation checks, retry controls, PostgreSQL migration, API and Android contract.

External portal connectivity is intentionally mockable and must be configured/UATed against the authorized IRP/EWB provider before production.
