# Namkeen ERP v43 — Accounting Reconciliation & Voucher Mapping

v43 formalizes the accounting bridge from v42.

Included:
- Configurable accounting ledger master
- Organization/entity scoped ledgers
- Effective-dated voucher mappings
- SALES / PURCHASE / RECEIPT / PAYMENT / CREDIT_NOTE / DEBIT_NOTE mapping
- CGST / SGST / IGST / Cess ledger mapping
- Balanced double-entry validation
- Accounting voucher persistence model
- External reference and amount reconciliation
- MATCHED / MISMATCH / UNMATCHED states
- v43 preview/reconciliation API
- Android Accounts workflow contract
- PostgreSQL migration `032_v43_accounting_ledgers_vouchers_reconciliation.sql`

Boundary:
- ERP source transactions remain authoritative.
- v43 maps/reconciles accounting representation.
- v42 worker remains responsible for external delivery/retry/dead-letter.
- Exact TallyPrime company/voucher/XML configuration remains deployment/UAT work.
