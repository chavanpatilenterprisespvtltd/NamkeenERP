# Namkeen ERP v23 — Production Role-Based Application

v23 extends v22 from a salesperson-centric mobile shell to a multi-role application contract for Sales, Manager, Factory, QC, Accounts and Management.

## Included
- Server-side `/v23/me` role/entity capability endpoint.
- Server-side `/v23/dashboard` role-scoped dashboard aggregation.
- Explicit offline capability matrix by role.
- Role dashboards for sales, management, factory, QC and accounts.
- Android v23 Compose dashboard client with authenticated API loading.
- PostgreSQL dashboard indexes.
- Test coverage for role policy and dashboard behavior.

## Security rule
The Android app renders capabilities; it never grants them. Offline writes remain queued through the existing sync layer and must be accepted by the server's business transaction services.

## Next integration work
The dashboard is the role shell. The next stage should connect each role's cards to real screens and real server query/mutation APIs for production entry, QC, inventory, dispatch, accounts verification and management approval, followed by PostgreSQL integration/UAT.
