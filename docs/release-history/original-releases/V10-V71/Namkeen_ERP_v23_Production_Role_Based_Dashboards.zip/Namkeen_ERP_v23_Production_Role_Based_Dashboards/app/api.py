from fastapi import FastAPI
from app.api_v16 import app as v16_app
from app.api_v17 import app as v17_app
from app.api_v23 import app as v23_app

app=FastAPI(title="Namkeen ERP API")
app.mount("/v16",v16_app)
app.mount("/v17",v17_app)
app.mount("/v23",v23_app)
