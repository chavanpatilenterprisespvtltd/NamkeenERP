from datetime import datetime, timezone
from sqlalchemy import BigInteger, String, DateTime, ForeignKey, UniqueConstraint, Index, Text, Integer
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class DomainChange(Base):
    __tablename__ = 'domain_changes'
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey('organizations.id'), nullable=False)
    entity_scope_id: Mapped[int|None] = mapped_column(ForeignKey('entities.id'))
    aggregate_type: Mapped[str] = mapped_column(String(80), nullable=False)
    aggregate_id: Mapped[str] = mapped_column(String(120), nullable=False)
    operation: Mapped[str] = mapped_column(String(20), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    event_name: Mapped[str] = mapped_column(String(100), nullable=False)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    actor_user_id: Mapped[int|None] = mapped_column(ForeignKey('users.id'))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    __table_args__ = (
        UniqueConstraint('organization_id','aggregate_type','aggregate_id','version', name='uq_domain_change_version'),
        Index('idx_domain_change_org_seq','organization_id','id'),
        Index('idx_domain_change_aggregate','organization_id','aggregate_type','aggregate_id','version'),
    )
