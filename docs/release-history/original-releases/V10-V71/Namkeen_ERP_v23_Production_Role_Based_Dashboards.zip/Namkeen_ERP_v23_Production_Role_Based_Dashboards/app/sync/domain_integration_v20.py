from __future__ import annotations
from typing import Any
from app.sync.domain_events import record_change

# v20 domain-event vocabulary. These names are stable contracts consumed by
# mobile, integrations and projections. Transaction services remain authoritative.
EVENTS = {
    'CUSTOMER_CREATED','CUSTOMER_APPROVED','CUSTOMER_REJECTED',
    'COLLECTION_CAPTURED','COLLECTION_DEPOSIT_SUBMITTED','COLLECTION_VERIFIED',
    'SALES_RETURN_CREATED','SALES_RETURN_DISPOSITIONED',
    'PRODUCTION_BATCH_CREATED','PRODUCTION_BATCH_QC_RECORDED',
    'COMPLIANCE_TASK_CREATED','COMPLIANCE_TASK_COMPLETED',
}

def emit(db, *, org_id: int, entity_id: int|None, aggregate_type: str,
         aggregate_id: str|int, event_name: str, operation: str, payload: dict,
         actor_user_id: int|None = None):
    if event_name not in EVENTS:
        raise ValueError(f'UNSUPPORTED_V20_EVENT:{event_name}')
    return record_change(
        db, org_id=org_id, entity_scope_id=entity_id,
        aggregate_type=aggregate_type, aggregate_id=str(aggregate_id),
        operation=operation, event_name=event_name, payload=payload,
        actor_user_id=actor_user_id,
    )
