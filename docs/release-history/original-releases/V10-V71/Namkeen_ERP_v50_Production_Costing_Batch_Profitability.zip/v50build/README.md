# Namkeen ERP v48 — Delivery & Proof-of-Delivery Settlement

Builds on v47 logistics and connects delivery outcomes back to controlled inventory, customer receivable and freight settlement decisions.

## Scope
- Delivery reconciliation against ordered quantity
- Full/partial/failed/returned delivery settlement
- Short/failed/return exception records with evidence/reason
- Management/Accounts exception approval
- Customer adjustment-note foundation
- Controlled stock disposition choices
- Controlled receivable actions
- Freight settlement and per-kg calculation
- PostgreSQL migration `037_v48_delivery_settlement.sql`
- Android settlement workflow contract

## Control boundary
Settlement does not directly rewrite inventory, receivables or accounting. It creates an approved decision that must be posted through the existing authoritative transaction services.

## Flow
`Delivery/POD → Reconciliation → Exception (if needed) → Approval → Controlled Posting → Inventory/Receivable/Accounting`

## Validation
Run `pytest -q`. v48-specific tests cover reconciliation, exception authorization, controlled posting and freight settlement.
Live PostgreSQL/Tally/IRP/EWB execution remains deployment/UAT work.

# v49 — Sales Return & Reverse Logistics
Adds controlled customer-return lifecycle, reverse pickup, LPN/lot scan references, QC HOLD, disposition, credit-note approval, and settlement posting boundary.

Migration: `038_v49_sales_returns_reverse_logistics.sql`.

Run `pytest -q` for the inherited suite plus v49 tests.

# v50 — Production Costing & Batch Profitability
Adds standard and actual production costing across RM, oil, fuel/wood, packaging, labour, power, utilities, rework, overhead and other configured components; calculates yield, actual cost/kg, standard variance and margin preview. Migration: `039_v50_production_costing.sql`.
