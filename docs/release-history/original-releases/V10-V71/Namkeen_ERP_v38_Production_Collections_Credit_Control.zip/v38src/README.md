# Namkeen ERP v38 — Collections & Credit Control

Builds on v37 customer accounts.

## Delivered
- Customer credit-control evaluation
- Hard/soft credit block logic
- Overdue threshold and credit-day policy gates
- Collection targets and achievement calculation
- Receipt verification/failed/bounced workflow controls
- Cash evidence requirement
- Receipt allocation protections
- Collection alert severity
- Management credit overrides with self-approval protection
- PostgreSQL migration 027_v38_collections_credit_control.sql
- FastAPI v38 endpoints
- Android v38 contract

## Control boundary
Nothing here directly mutates customer ledgers. These services validate decisions; final accounting posting remains in the authoritative transaction/posting layer.
