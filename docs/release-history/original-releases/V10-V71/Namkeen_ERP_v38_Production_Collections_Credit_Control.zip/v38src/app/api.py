from fastapi import FastAPI
from app.api_v16 import app as v16_app
from app.api_v17 import app as v17_app
from app.api_v23 import app as v23_app
from app.api_v25 import app as v25_app
from app.v26.api import app as v26_app
from app.v32.api import app as v32_app
from app.v33.api import app as v33_app
from app.v35.api import app as v35_app

app=FastAPI(title="Namkeen ERP API")
app.mount("/v16",v16_app)
app.mount("/v17",v17_app)
app.mount("/v23",v23_app)
app.mount("/v25",v25_app)
app.mount('/v26', v26_app)
app.mount('/v32', v32_app)
app.mount('/v33', v33_app)
app.mount('/v35', v35_app)
