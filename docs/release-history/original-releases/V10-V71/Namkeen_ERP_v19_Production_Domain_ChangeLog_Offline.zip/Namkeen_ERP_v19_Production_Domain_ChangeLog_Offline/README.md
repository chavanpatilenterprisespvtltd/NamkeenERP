# Namkeen ERP v19 — Production Domain Change Log + Offline Mobile Client Core

v19 builds on v18. It introduces a canonical append-only domain change stream and a reference offline client store so business transactions can synchronize through real domain events rather than a generic transport-only log.

## Included
- `domain_changes` PostgreSQL migration (`009_v19_domain_change_log.sql`)
- Domain event recorder with per-aggregate versions
- v18 change-log bridge for staged rollout
- Sales-order lifecycle change events (create, approval, payment verification, cheque clearance, stock reservation, dispatch)
- Reference mobile offline store with SQLite outbox/inbox/cursor/conflict state
- v19 pull API
- Android sync contract documentation
- Tests for versioning, idempotency, delta application and conflict persistence

## Validation
Run:

```bash
pytest -q
```

The package is a production integration stage, not a statement that Android, PostgreSQL, or external accounting/notification providers are already deployed in a live environment.
