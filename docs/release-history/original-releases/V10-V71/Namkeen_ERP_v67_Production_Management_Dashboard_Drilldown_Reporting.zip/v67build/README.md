# Namkeen ERP v67 — Management Dashboard API + Drill-down Reporting

v67 adds a read-only management reporting engine over the v66 profitability MIS layer.

## Scope
- Period, entity, warehouse, territory, salesperson, SKU and customer filters
- Daily/monthly KPI trends
- Top/bottom rankings by SKU, customer, salesperson, territory and warehouse
- Margin waterfall
- Production-vs-sales reconciliation
- Management export payloads
- Saved-view database structure
- Android management dashboard contract
- Read-side indexes only; no operational transaction writes

## KPI boundary
All figures are reporting aggregates. Operational posting remains authoritative in the existing sales, inventory, accounting, costing and collection transaction services.

## Validation
- v67 focused tests included in `tests/test_v67_reporting.py`
- Python compile validation
- Live PostgreSQL execution still requires deployment/UAT
