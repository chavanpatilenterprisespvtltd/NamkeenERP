# Namkeen ERP v41 — Persistent End-to-End Transaction Posting

v41 converts the v40 commercial orchestration/posting-intent layer into a persistent transaction boundary.

## Delivered
- PostgreSQL/SQLAlchemy persistent transaction-run record
- Persistent sales invoice + invoice lines
- Customer receivable and receipt allocation
- Payment persistence
- Existing FEFO reservation + dispatch posting called inside the same SQLAlchemy transaction
- Inventory ledger mutation participates in rollback
- Accounting integration outbox with Tally idempotency key
- Domain change-log events for invoice/receivable
- Server-side idempotency for mobile retries
- Duplicate order/invoice protections
- FastAPI `/v41/sales/post`
- Android v41 contract
- PostgreSQL migration `030_v41_persistent_end_to_end_sales.sql`

## Atomicity boundary
The caller must open one SQLAlchemy `db.begin()` block. v41 creates/updates all transactional records before commit. If reservation, dispatch, invoice, receivable, or outbox creation fails, the transaction rolls back.

External accounting integrations are intentionally asynchronous via the outbox; Tally is never called inside the DB transaction.

## Remaining production work
Live PostgreSQL execution, authenticated API actor resolution, transaction isolation/load tests, DB sequence/index review, full accounting adapter execution, and UAT remain deployment gates.
