# Namkeen ERP v32 — Warehouse Dashboard, Replenishment & Inventory Intelligence

Builds on v31 warehouse execution and adds a read-oriented warehouse intelligence layer.

## Added
- Warehouse KPI summary: total / available / reserved stock
- Expiry ageing: expired / expiring within 7 days / 30 days
- Bin occupancy KPI contract
- FEFO availability view
- Configurable minimum stock / reorder level / target stock / safety stock
- Replenishment suggestions with CRITICAL vs REORDER severity
- Directed picking KPIs and short-pick count contract
- Cycle-count KPIs and variance visibility
- PostgreSQL migration 021 with read views
- Android dashboard contract wired to existing role navigation plan

## Control boundary
This stage does **not** create a second source of stock truth. Inventory lots / inventory ledger remain authoritative. Dashboard views calculate availability from authoritative inventory balances. Replenishment is a recommendation/alert, not automatic purchase or production release.

## Important
Bin occupancy is a dashboard contract; capacity-aware live occupancy requires the physical location/LPN tables to be joined in deployment. Expiry metrics use available stock (quantity after reservation) so reserved goods are not double-counted as freely available stock.
