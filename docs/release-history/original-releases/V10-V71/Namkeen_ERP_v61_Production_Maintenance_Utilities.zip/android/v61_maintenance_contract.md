# v61 Android Maintenance Contract

Screens/contracts:
- Asset list/search/QR scan
- Asset detail (status, warranty, AMC, PM due)
- PM task list and checklist
- Breakdown/work-order creation
- Downtime entry
- Spare-part issue request
- Labour-hour entry
- Calibration upload/reference capture
- Work-order completion approval state
- Maintenance dashboard KPIs

Offline writes require `client_event_id`, device/user identity and timestamp. The server remains authoritative for work-order closure, inventory spare issues, calibration validity and any approval-required action.
