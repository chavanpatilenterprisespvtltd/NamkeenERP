# Namkeen ERP v61 — Maintenance, Utilities, Machine & Preventive Maintenance

## Purpose
Adds a controlled factory maintenance layer for equipment used in frying, seasoning, packing, utilities and QC.

## Scope
- Asset / machine master
- Asset status, warranty and AMC references
- Preventive-maintenance plans and due tasks
- Maintenance work orders and breakdown capture
- Downtime tracking
- Spare-parts consumption and maintenance-cost basis
- Labour-hour capture
- Calibration records for measurement/QC equipment
- Certificate/evidence references with integrity hash support
- Meter readings for future hour/cycle based PM
- Maintenance audit events with offline client-event idempotency
- Approval boundary for excessive downtime

## Factory examples
Fryer, dough mixer, sev extruder, seasoning drum, elevator/conveyor, packing machine, compressor, generator, furnace/heating system, high-temperature oil pump, weighing scale and label printer can each be represented as separate assets.

## Control boundaries
Maintenance completion does not directly modify production, inventory or accounting. Spare-part issues, downtime cost, calibration status and production availability are inputs to their authoritative transaction services.

A QC-critical measuring asset should not be treated as calibration-valid unless its current calibration record is valid. Long downtime can require configurable approval before closure.

## Migration
`sql/050_v61_maintenance_utilities.sql`

## API/client contract
See `android/v61_maintenance_contract.md`.
