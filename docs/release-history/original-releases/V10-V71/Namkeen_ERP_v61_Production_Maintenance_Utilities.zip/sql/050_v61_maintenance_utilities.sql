-- v61: maintenance, assets, preventive maintenance, breakdowns, spares and calibration
CREATE TABLE IF NOT EXISTS maintenance_asset (
  asset_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  site_id UUID NOT NULL,
  asset_code TEXT NOT NULL,
  asset_name TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  warranty_until DATE,
  amc_vendor_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, asset_code)
);
CREATE TABLE IF NOT EXISTS maintenance_pm_plan (
  plan_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  asset_id UUID NOT NULL REFERENCES maintenance_asset(asset_id),
  frequency_days INTEGER NOT NULL CHECK (frequency_days > 0),
  next_due DATE NOT NULL,
  checklist_version TEXT NOT NULL DEFAULT '1',
  active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS maintenance_work_order (
  wo_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  asset_id UUID NOT NULL REFERENCES maintenance_asset(asset_id),
  status TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'MEDIUM',
  requested_by UUID,
  failure_mode TEXT,
  downtime_minutes INTEGER NOT NULL DEFAULT 0 CHECK (downtime_minutes >= 0),
  labour_hours NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (labour_hours >= 0),
  completion_approval_required BOOLEAN NOT NULL DEFAULT FALSE,
  evidence_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS maintenance_work_order_part (
  wo_id UUID NOT NULL REFERENCES maintenance_work_order(wo_id),
  spare_part_id UUID NOT NULL,
  qty NUMERIC(14,3) NOT NULL CHECK (qty > 0),
  unit_cost NUMERIC(14,4) NOT NULL DEFAULT 0,
  PRIMARY KEY (wo_id, spare_part_id)
);
CREATE TABLE IF NOT EXISTS maintenance_calibration (
  calibration_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  asset_id UUID NOT NULL REFERENCES maintenance_asset(asset_id),
  due_date DATE NOT NULL,
  status TEXT NOT NULL,
  certificate_ref TEXT,
  certificate_hash TEXT,
  checked_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS maintenance_meter_reading (
  reading_id UUID PRIMARY KEY,
  asset_id UUID NOT NULL REFERENCES maintenance_asset(asset_id),
  meter_code TEXT NOT NULL,
  reading NUMERIC(14,3) NOT NULL,
  reading_at TIMESTAMPTZ NOT NULL,
  UNIQUE(asset_id, meter_code, reading_at)
);
CREATE TABLE IF NOT EXISTS maintenance_audit_event (
  event_id UUID PRIMARY KEY,
  organization_id UUID NOT NULL,
  asset_id UUID,
  wo_id UUID,
  event_type TEXT NOT NULL,
  actor_user_id UUID,
  client_event_id TEXT,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(organization_id, client_event_id)
);
CREATE INDEX IF NOT EXISTS idx_pm_due ON maintenance_pm_plan(organization_id, next_due) WHERE active;
CREATE INDEX IF NOT EXISTS idx_wo_asset_status ON maintenance_work_order(organization_id, asset_id, status);
CREATE INDEX IF NOT EXISTS idx_cal_due ON maintenance_calibration(organization_id, due_date, status);
