from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from enum import Enum
from typing import Optional

class WOStatus(str, Enum):
    DRAFT='DRAFT'; OPEN='OPEN'; IN_PROGRESS='IN_PROGRESS'; COMPLETED='COMPLETED'; CANCELLED='CANCELLED'

class AssetStatus(str, Enum):
    ACTIVE='ACTIVE'; OUT_OF_SERVICE='OUT_OF_SERVICE'; RETIRED='RETIRED'

@dataclass
class Asset:
    asset_id: str
    name: str
    asset_type: str
    site_id: str
    status: AssetStatus=AssetStatus.ACTIVE
    warranty_until: Optional[date]=None
    amc_vendor_id: Optional[str]=None

@dataclass
class PMPlan:
    plan_id: str
    asset_id: str
    frequency_days: int
    next_due: date
    active: bool=True
    checklist_version: str='1'

@dataclass
class WorkOrder:
    wo_id: str
    asset_id: str
    status: WOStatus=WOStatus.DRAFT
    priority: str='MEDIUM'
    requested_by: str=''
    failure_mode: Optional[str]=None
    downtime_minutes: int=0
    spare_parts: list[dict]=field(default_factory=list)
    labour_hours: float=0.0
    evidence_refs: list[str]=field(default_factory=list)

@dataclass
class Calibration:
    calibration_id: str
    asset_id: str
    due_date: date
    status: str='VALID'
    certificate_ref: Optional[str]=None

@dataclass
class MaintenancePolicy:
    max_downtime_minutes_without_approval: int=120
    require_calibration_valid_for_qc_assets: bool=True
    spare_variance_approval_pct: float=10.0


def due_pm(plans: list[PMPlan], as_of: date) -> list[PMPlan]:
    return [p for p in plans if p.active and p.next_due <= as_of]


def schedule_next_pm(plan: PMPlan, completed_on: date) -> PMPlan:
    plan.next_due = completed_on + timedelta(days=plan.frequency_days)
    return plan


def validate_work_order_completion(wo: WorkOrder, asset: Asset, policy: MaintenancePolicy, calibration: Calibration|None=None) -> list[str]:
    errors=[]
    if asset.status == AssetStatus.RETIRED:
        errors.append('RETIRED_ASSET')
    if wo.downtime_minutes < 0:
        errors.append('NEGATIVE_DOWNTIME')
    if wo.labour_hours < 0:
        errors.append('NEGATIVE_LABOUR')
    if policy.max_downtime_minutes_without_approval >= 0 and wo.downtime_minutes > policy.max_downtime_minutes_without_approval:
        errors.append('DOWNTIME_APPROVAL_REQUIRED')
    if calibration and policy.require_calibration_valid_for_qc_assets and calibration.status != 'VALID':
        errors.append('CALIBRATION_NOT_VALID')
    return errors


def maintenance_cost(wo: WorkOrder, spare_prices: dict[str,float], labour_rate: float) -> float:
    parts=sum(float(x.get('qty',0))*float(spare_prices.get(x.get('part_id',''),0)) for x in wo.spare_parts)
    return round(parts + wo.labour_hours*labour_rate, 2)
