from datetime import date, timedelta
import sys
sys.path.insert(0, '/mnt/data/v61build/src')
from maintenance import *

def test_pm_due_and_reschedule():
    p=PMPlan('P1','A1',30,date(2026,9,1))
    assert due_pm([p], date(2026,9,5)) == [p]
    schedule_next_pm(p,date(2026,9,5))
    assert p.next_due == date(2026,10,5)

def test_downtime_gate():
    a=Asset('A1','Fryer','FRYER','S1')
    w=WorkOrder('W1','A1',WOStatus.IN_PROGRESS,downtime_minutes=180)
    assert 'DOWNTIME_APPROVAL_REQUIRED' in validate_work_order_completion(w,a,MaintenancePolicy(120))

def test_calibration_gate():
    a=Asset('A1','Weighing Scale','SCALE','S1')
    w=WorkOrder('W2','A1',WOStatus.IN_PROGRESS)
    c=Calibration('C1','A1',date(2026,9,1),status='EXPIRED')
    assert 'CALIBRATION_NOT_VALID' in validate_work_order_completion(w,a,MaintenancePolicy(),c)

def test_costing():
    w=WorkOrder('W3','A1',WOStatus.COMPLETED, labour_hours=2.5, spare_parts=[{'part_id':'BEARING','qty':2}])
    assert maintenance_cost(w, {'BEARING':125.0}, 400.0) == 1250.0
