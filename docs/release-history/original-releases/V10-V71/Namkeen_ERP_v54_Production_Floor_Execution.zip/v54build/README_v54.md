# Namkeen ERP v54 — Production Floor Execution

v54 connects v53 production execution to the physical factory-floor workflow.

## Scope

- operator/shift capture
- sequenced process stages
- machine references and target process metrics
- downtime capture
- oil and fuel consumption
- in-process QC checkpoints
- wastage authorization/evidence
- output/yield capture
- material-cost preview compatible with v50 costing
- controlled completion gate
- PostgreSQL migration `043_v54_production_floor_execution.sql`
- Android contract for offline factory operation

## Key controls

A run cannot complete until all stages are completed, QC checkpoints pass, and good output is recorded. QC failure/hold moves the run to HOLD. Wastage requires authorization/evidence before authorized status. Inventory/accounting mutations remain in the existing authoritative transaction services.

## Validation

v54-specific tests cover lifecycle, downtime, costing, oil/fuel, QC, wastage and completion controls. Live PostgreSQL/factory hardware integration remains a deployment/UAT activity.
