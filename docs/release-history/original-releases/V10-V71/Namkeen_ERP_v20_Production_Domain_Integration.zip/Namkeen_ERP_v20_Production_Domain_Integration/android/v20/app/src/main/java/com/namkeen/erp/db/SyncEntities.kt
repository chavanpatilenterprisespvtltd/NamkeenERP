package com.namkeen.erp.v20.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sync_outbox")
data class SyncOutbox(
    @PrimaryKey val clientEventId: String,
    val deviceId: String,
    val eventType: String,
    val entityType: String,
    val entityId: String,
    val clientVersion: Int?,
    val payloadJson: String,
    val state: String = "PENDING",
    val attempts: Int = 0,
    val lastError: String? = null
)

@Entity(tableName = "sync_meta")
data class SyncMeta(@PrimaryKey val key: String, val value: String)

@Entity(tableName = "sync_inbox")
data class SyncInbox(
    @PrimaryKey val changeId: Long,
    val entityType: String,
    val entityId: String,
    val version: Int,
    val operation: String,
    val payloadJson: String,
    val occurredAt: String?
)

@Entity(tableName = "sync_conflicts")
data class SyncConflict(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientEventId: String,
    val entityType: String,
    val entityId: String,
    val clientVersion: Int?,
    val serverVersion: Int?,
    val clientPayloadJson: String,
    val serverPayloadJson: String?,
    val state: String = "OPEN"
)
