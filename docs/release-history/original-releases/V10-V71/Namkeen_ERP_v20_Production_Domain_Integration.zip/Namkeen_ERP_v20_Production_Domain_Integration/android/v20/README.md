# Android v20 sync skeleton

Reference Android client structure for the v20 server contract.

- Room: durable outbox/inbox/cursor/conflicts
- WorkManager: retryable background synchronization
- Server authoritative for price/payment/credit/stock/QC/accounting decisions
- Client-generated `clientEventId` for idempotency
- Conflicts remain visible; no silent overwrite

This is an integration skeleton, not a claim of a finished production Android application.
