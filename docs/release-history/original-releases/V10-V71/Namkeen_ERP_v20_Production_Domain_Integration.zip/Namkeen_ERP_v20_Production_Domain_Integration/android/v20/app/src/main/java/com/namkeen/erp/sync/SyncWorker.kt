package com.namkeen.erp.v20.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // v20 reference flow: upload pending outbox -> apply server result -> pull deltas -> advance cursor.
        // Business rules remain server-authoritative; conflicts are stored for explicit resolution.
        return Result.success()
    }
}
