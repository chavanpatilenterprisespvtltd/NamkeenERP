package com.namkeen.erp.v20.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities=[SyncOutbox::class, SyncMeta::class, SyncInbox::class, SyncConflict::class], version=20, exportSchema=true)
abstract class ErpSyncDatabase : RoomDatabase() { abstract fun syncDao(): SyncDao }
