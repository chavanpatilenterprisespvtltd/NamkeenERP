# Namkeen ERP v20 — Production Domain Integration + Android Offline Skeleton

v20 extends v19 so the remaining operational domains participate in the canonical domain change stream, while adding a concrete Android Room/WorkManager reference skeleton.

## Included
- Customer onboarding + approval/rejection domain events
- Collection capture + deposit + verification domain events
- Sales return + QC disposition domain events
- Production-batch event bridge
- Compliance-task event bridge
- v20 domain-event contract and transaction rules
- PostgreSQL indexing migration `010_v20_domain_integration.sql`
- Android Room entities/DAO/database skeleton
- WorkManager sync worker skeleton
- v20 documentation and tests

## Validation
Run:

```bash
pytest -q
```

This package is an integration/build stage. It is not a claim that a complete Android application or live production deployment already exists.
