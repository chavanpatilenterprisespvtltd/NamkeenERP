# Namkeen ERP v13 — PostgreSQL Persistence + Production Transaction Core

This stage makes the transaction engine database-backed and defines the transaction boundaries required for production.

Included:
- SQLAlchemy PostgreSQL models for customer, sales order, payments, inventory lots/ledger, approvals, audit, sync and compliance tasks.
- PostgreSQL session/unit-of-work pattern.
- Row-locking patterns for receipt, FEFO reservation and dispatch.
- Persistent audit events and approval requests.
- Payment verification and cheque-clearance transaction services.
- Production migration for new core tables/indexes.
- Server-authoritative offline sync uniqueness model.
- Production DB rules document.

Validated local service contracts: FEFO ordering and price-floor calculation.

Before live deployment:
- Run migrations on PostgreSQL.
- Wire v13 services to the complete existing v7-v12 schema/migrations.
- Replace development headers with JWT/session/device authentication.
- Implement object storage and signed URLs.
- Add real sync conflict resolver, background notification worker, bank/UPI adapters, Tally adapter, observability and backups.
- Complete full integration/load/security/UAT tests.
