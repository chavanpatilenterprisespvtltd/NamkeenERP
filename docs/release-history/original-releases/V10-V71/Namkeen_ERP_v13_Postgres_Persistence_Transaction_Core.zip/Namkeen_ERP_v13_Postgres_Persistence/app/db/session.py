
from contextlib import contextmanager
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
import os

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg://erp:erp@localhost:5432/namkeen_erp"
)

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=int(os.getenv("DB_POOL_SIZE","10")),
    max_overflow=int(os.getenv("DB_MAX_OVERFLOW","20")),
    future=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

@contextmanager
def transaction():
    db = SessionLocal()
    try:
        with db.begin():
            yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
