# Namkeen ERP v57 — Compliance Operations Engine

v57 turns the existing FSSAI/Maharashtra FDA compliance foundation into a daily operational control layer.

## Scope
- effective-dated, condition-aware compliance requirements
- recurring site compliance task generation
- evidence capture/reference and integrity hash
- inspection findings and controlled dispositions
- CAPA-required visibility
- site compliance snapshot/readiness indicator
- oil TPC checks
- water/lab/calibration/test-result control primitives
- links from GRN/QC/production/packing/complaints/recall/inspection workflows
- Android offline evidence/task contract
- PostgreSQL migration `046_v57_compliance_operations.sql`

## Important boundary
`inspection_ready` is a derived ERP readiness indicator, not a legal certification. The module supports compliance work and audit evidence; regulatory applicability and final statutory decisions remain controlled by the customer's responsible food-safety/management/CA/legal team.

## Validation
Run `pytest` from this directory. v57 adds 10 focused tests and retains the inherited suite.
